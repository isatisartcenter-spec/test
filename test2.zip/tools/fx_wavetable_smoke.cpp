#include "../Source/FX/SimpleDelay.h"
#include "../Source/FX/SimpleChorus.h"
#include "../Source/FX/SimpleReverb.h"
#include "../Source/FX/SimplePhaser.h"
#include "../Source/FX/SimpleCompressor.h"
#include "../Source/FX/SimpleDistortion.h"
#include "../Source/FX/MagicEngine.h"
#include "../Source/FX/EffectTailEstimate.h"
#include "../Source/Wavetables/WavetableData.h"
#include <cmath>
#include <iostream>

static int failures = 0;
static void check (bool ok, const char* message)
{
    if (! ok)
    {
        std::cerr << "FAIL: " << message << '\n';
        ++failures;
    }
}

int main()
{
    constexpr double sr = 48000.0;
    constexpr int block = 128;

    juce::AudioBuffer<float> dry (2, block);
    for (int ch = 0; ch < 2; ++ch)
        for (int i = 0; i < block; ++i)
            dry.setSample (ch, i, 0.17f * std::sin (0.07f * i + 0.3f * ch));
    juce::AudioBuffer<float> original (2, block);
    original.makeCopyOf (dry);

    salek::SimpleChorus chorus;
    salek::SimpleDelay delay;
    salek::SimpleReverb reverb;
    salek::SimplePhaser phaser;
    salek::SimpleCompressor compressor;
    chorus.prepare (sr, block);
    delay.prepare (sr, block);
    reverb.prepare (sr, block);
    phaser.prepare (sr, block);
    compressor.prepare (sr, block);
    chorus.process (dry); delay.process (dry); reverb.process (dry);
    phaser.process (dry); compressor.process (dry);
    bool exact = true;
    for (int ch = 0; ch < 2; ++ch)
        for (int i = 0; i < block; ++i)
            exact = exact && dry.getSample (ch, i) == original.getSample (ch, i);
    check (exact, "zero-mix FX stay bit-exact");

    delay.setMix (1.0f); delay.setFeedback (0.0f); delay.setTone (1.0f);
    delay.setTimeMsL (50.0f); delay.setTimeMsR (75.0f);
    juce::AudioBuffer<float> warmup (2, block);
    for (int i = 0; i < 400; ++i) { warmup.clear(); delay.process (warmup); }
    delay.reset();
    juce::AudioBuffer<float> impulse (2, 5000);
    impulse.clear();
    impulse.setSample (0, 0, 1.0f); impulse.setSample (1, 0, 1.0f);
    delay.process (impulse);
    int firstL = -1, firstR = -1;
    for (int i = 0; i < 5000; ++i)
    {
        if (firstL < 0 && std::abs (impulse.getSample (0, i)) > 1.0e-3f) firstL = i;
        if (firstR < 0 && std::abs (impulse.getSample (1, i)) > 1.0e-3f) firstR = i;
    }
    check (std::abs (firstL - 2400) <= 1 && std::abs (firstR - 3600) <= 1, "stereo delay times");

    compressor.setMix (1.0f); compressor.setThresholdDb (0.0f);
    compressor.setRatio (1.0f); compressor.setDepth (1.0f); compressor.setMakeupDb (24.0f);
    juce::AudioBuffer<float> tone (2, 48000);
    for (int i = 0; i < 48000; ++i) { tone.setSample (0, i, 0.01f); tone.setSample (1, i, 0.01f); }
    compressor.process (tone);
    double squares = 0.0;
    for (int i = 48000 - 1024; i < 48000; ++i)
        squares += static_cast<double> (tone.getSample (0, i)) * tone.getSample (0, i);
    const float rms = static_cast<float> (std::sqrt (squares / 1024.0));
    check (rms > 0.15f && rms < 0.17f, "compressor +24 dB makeup");

    salek::MagicEngine magic;
    magic.prepare (sr, block);
    juce::AudioBuffer<float> mag (2, block);
    for (int b = 0; b < 375; ++b)
    {
        for (int i = 0; i < block; ++i)
        {
            const int s = b * block + i;
            const float v = 0.3f * std::sin (juce::MathConstants<float>::twoPi * 440.0f * s / static_cast<float> (sr));
            mag.setSample (0, i, v); mag.setSample (1, i, v);
        }
        magic.process (mag);
    }
    magic.setMode (0); magic.setXY (0.5f, 0.5f); magic.setActive (true);
    mag.clear();
    magic.process (mag);
    double magSq = 0.0;
    for (int i = 0; i < block; ++i)
        magSq += static_cast<double> (mag.getSample (0, i)) * mag.getSample (0, i);
    check (std::sqrt (magSq / block) > 0.05, "magic pre-roll");

    const auto dryTail = salek::estimateEffectTailSeconds (0, 280, 0.35f, 0, 0, 0.55f, 0.25f);
    const auto maxDelay = salek::estimateEffectTailSeconds (1, 800, 0.95f, 0, 0, 0.55f, 0.22f);
    const auto longRev = salek::estimateEffectTailSeconds (0, 280, 0.35f, 0, 1, 0.95f, 0.22f);
    check (std::abs (dryTail - 0.25) < 1.0e-6, "dry tail");
    check (maxDelay > 110.0 && maxDelay < 120.0, "delay tail");
    check (longRev > 8.5 && longRev < 9.0, "reverb tail");

    salek::Wavetable table;
    const float sine = table.getSample (0.0f, 0.25f, 0);
    check (std::abs (sine - 0.72f) < 0.05f, "wavetable sine peak");
    check (table.getNumFrames() == salek::Wavetable::numFrames, "frame count");
    check (table.mipForPhaseInc (0.0001) == 0, "low mip");
    check (salek::Wavetable::getFrameName (0) != nullptr, "frame name");

    if (failures == 0)
        std::cout << "fx + wavetable smoke: ok\n";
    return failures == 0 ? 0 : 1;
}
