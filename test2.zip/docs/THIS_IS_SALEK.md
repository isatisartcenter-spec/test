# This Is Salek — preset bank / پک پریست

## فارسی

این بانک شامل ۹۰ صدای تازه و مستقل از GITI و presetهای قبلی است. در فیلتر موجود مرورگر، **THIS IS SALEK** را انتخاب کنید یا روی **ALL** بگذارید؛ نام تمام اعضا با `THIS IS SALEK/` شروع می‌شود تا دستهٔ جداگانه‌شان حفظ شود. مرورگر و چیدمان آن تغییری نکرده است.

این پچ‌ها صدای تازه‌ای هستند که با اسیلیتورهای wavetable، FM/PM، فیلتر، envelope، LFO و افکت‌های داخلی ساخته شده‌اند. اسم‌های «کلاسیک» به آرکتایپ و رفتار صوتی اشاره دارند؛ ادعای بازسازی preset منتشرشده، صدای ضبط‌شده یا همکاری رسمی با هنرمند/سازنده‌ای نیستند.

### ۱. Psy / Hi-Tech — ۳۰ صدا

1. Kick-Locked Sub Bass
2. Rolling 16th Pulse
3. Rubberline Reese
4. Dark Rolling Mono
5. Low Orbit Bass
6. Tight Night Bass
7. 303 Memory Squelch
8. Acid Ladder Bite
9. Resonant Spiral
10. Rubber Acid Sequence
11. Forest Acid Rake
12. Glass Acid Drop
13. Neon Razor Lead
14. Full-On Peak Lead
15. Hi-Tech Photon Saw
16. Darkpsy Bark Lead
17. Forest Root Growl
18. Morning Goa Ribbon
19. Psycho Hoover Rise
20. Phase Splitter
21. Cyan Arpeggio Blade
22. Crystal Pluck Relay
23. Staccato Shroom
24. Bell Comet Pluck
25. Alien Radio Phrase
26. Night Ritual Drone
27. Psy Portal Sweep
28. Glitch Comet Burst
29. Rising Plasma Arc
30. Interstellar Hit

### ۲. Classic Signals — ۳۰ آرکتایپ کلاسیک سینتی‌سایزر

1. TB-Flavoured Acid Box
2. Minimoog Mono Bass
3. MS-20 Filter Growl
4. SH-101 Pulse Sequence
5. Model-D Subline
6. Odyssey Rubber Bass
7. JP-Style Arena Supersaw
8. Jupiter Brass Poly
9. Prophet Unison Lead
10. CS-80 Expressive Lead
11. Portamento Synth Lead
12. Virus-Style Trance Stack
13. DX-Style FM Glass Bell
14. FM Metal Pluck
15. Rhodes-Like Electric Key
16. Synclavier Mallet Key
17. FM EP Chime
18. DX FM Tine
19. Retro Chip Pulse
20. Goa Gate Pluck
21. Mallet Circuit
22. PPG Glass Pluck
23. Damped Bell Arp
24. Juno Jangle Sequence
25. Prophet Crystal Keys
26. Juno Ensemble Pad
27. Solina-Style Strings
28. OB Poly Bloom
29. Mellotron Choir
30. Jupiter Brass Pad

### ۳. Odd Worlds — ۳۰ اتمسفر و افکت تجربی

1. Submerged Machine
2. Black Moss Drone
3. Distant Metal Choir
4. Underwater Lantern
5. Cold Reactor Bed
6. Low Orbit Haze
7. Breathing Stone
8. Forest Pressure
9. Alien Abduction Beam
10. Radio Nebula
11. Fractal Mouth
12. Bent Glass Transmission
13. Space Dentist
14. Pseudofrog Signal
15. Antimatter Bell
16. Broken Satellite
17. Wormhole Vocal Shard
18. Quantum Larva
19. Soft Plasma Veil
20. Hollow Observatory
21. Slow Phase Mist
22. Polar Carrier
23. Cosmic Dust Bloom
24. Ghost Current
25. Phase Displacement
26. UFO Tractor Beam
27. Glitch Gate Array
28. Impact Vector
29. Portal Unfolding
30. Last Signal Falling

### یادداشت‌های طراحی و منابع

- کاتالوگ [G-Sonique Psytrance VST](https://www.g-sonique.com/psytrance-vst-plugins) صدا را بر اساس نقش در آهنگ تفکیک می‌کند: بیس/اسید، کیک، لید و اتمسفر، و افکت‌های فضایی. همان صفحه روی حرکت envelope و فیلتر برای بیس‌های رولی و رابطهٔ کیک/بیس تأکید می‌کند. به همین دلیل شش پچ آغازین بیس مونو با حمله و رهایی کوتاه‌ترند؛ بانک خودش کیک‌ساز مستقل یا sidechain اضافه نمی‌کند.
- مشخصات رسمی [Renegade](https://www.g-sonique.com/renegade) از اسیلیتور supersaw، چند شکل موج، فیلترهای ترکیبی، envelope سریع، chorus/unison، delay و saturation نام می‌برد؛ این‌ها مبنای طراحی آرکتایپ‌های lead/acid و stack هستند، با پارامترهای داخلی خود GITI.
- معرفی رسمی [Psytrance Synths 8000 X1](https://www.g-sonique.com/psytrance-synths-8000x1-vst-au-plugin) نقش‌های آمادهٔ lead، FX، drone، pad، sweep و صدای شبه‌وکال را کنار هم می‌گذارد؛ گروه تجربی این پک همین وسعت نقش‌ها را به شکل پچ‌های قابل‌ویرایش پوشش می‌دهد.
- [DarkPsy FX466](https://www.g-sonique.com/darkpsyfx466-vst-au-plug-in-instrument) بر soundscape، monster/sci-fi، hit، pad، LFO و کنترل‌های envelope/فضا تمرکز دارد؛ از همین نقش‌ها برای گروه Odd Worlds الهام گرفته شد.
- [Psychedelic Spiral S1](https://www.g-sonique.com/psychedelicspirals1) نمونه‌هایی از زنجیرهٔ شکل‌دهی مولتی‌پلایر/مدولاتور، LFO و فیلتر را معرفی می‌کند؛ پچ‌های عجیب اینجا از ترکیب FM/PM، warp/fold، فیلترهای چندحالته، LFO و FX داخلی استفاده می‌کنند.
- معرفی رسمی [Xfer Serum 2](https://xferrecords.com/products/serum-2) نمونه‌هایی از ترکیب حرکت wavetable، انواع warp و مدولاسیون ارائه می‌کند. راهنمای CPU همان ساز هم توصیه می‌کند unison افراطی جایگزین طراحی پچ نشود: [CPU guidelines](https://support.xferrecords.com/article/51-serum2-sound-design-guidelines-for-optimizing-cpu-usage). در این پک فقط اسیلیتور اول unison چندصدایی می‌گیرد و دو اسیلیتور دیگر تک‌صدا می‌مانند؛ تعداد unison آن‌ها حداکثر ۶ است.

### English

The 90 original patches live under the separate **THIS IS SALEK** category. The three groups contain 30 Psy/Hi-Tech patches, 30 classic synthesizer archetypes, and 30 experimental atmospheres and effects. The classic references describe broad synthesis archetypes rather than copied artist recordings or commercial presets. The patches use the synth’s existing oscillators, modulation, filters, envelopes, and effects. Oscillator 1 is the only unison-stacked oscillator; oscillators 2 and 3 remain single-voice to keep the bank’s polyphonic cost controlled.
