# GITI Audio Engine Audit — 2026-10-02

## Scope

This pass followed the main control paths from the APVTS parameters and MIDI input through the synthesizer, modulation matrix, filters, effects, meters, and factory banks. It focused on controls whose displayed value did not match the sound, incorrect voice and filter behavior, and avoidable monitor or capture latency. The installed JUCE 8.0.4 codebase already provides the required framework; no external audio plug-ins or libraries were added.

## Fixes

- Mono and Legato now use an allocation-free held-note stack. Legato keeps its envelope through a phrase and restarts it when a new phrase begins during the prior release tail.
- Glide is logarithmic in pitch and now follows each active oscillator and unison voice. MIDI pitch wheel and pitch modulation are applied to the same tuning path.
- Oscillator detune is included in audible tuning. Global unison controls combine with per-oscillator voices, detune, and spread.
- Modulation sources are evaluated before their destinations for the current audio block. Pitch routes change pitch, noise and sub routes reach their own levels, Distortion Mix and Drive remain separate, and Master Drive has an independent route.
- High-Pass 24 now advances its second filter stage once per sample. The very-low-cutoff attenuation is limited to low-pass modes. All-Pass preserves magnitude, and Ring Mod uses a cutoff-controlled carrier.
- Delay left and right times reach their separate delay taps; wow-rate phase is sample-rate-aware. Magic keeps a low-cost rolling input history while bypassed so Loop/Freeze captures the signal that played before activation.
- Compressor makeup gain now honors its full advertised +24 dB range.
- FX monitor values are published as atomics from the audio thread and polled by their own 90 Hz UI timers. This changes only the display path; it adds no audio buffer.

## Verification

The offline SHAE and audio self-tests pass. Audio checks include the full 250-preset GITI bank and 90-preset This Is Salek bank, finite output across 44.1/48/96 kHz and 32/128/512-sample blocks, measured A4 pitch, detune, MIDI bend, Mono and Legato Glide movement and destinations, 24 dB high-pass behavior, All-Pass magnitude, Magic pre-roll capture, independent 50/75 ms stereo delay times, compressor +24 dB gain, effect bypass/crossfades, and effect-tail estimates.

Windows x64 Standalone and VST3 Release targets both build successfully with the current source.

## Compatibility note

`comp_thr_lo`, `comp_thr_mid`, and `comp_thr_hi` remain stored for old preset/state compatibility. The current compressor is deliberately wideband; these legacy band-threshold values do not act as three independent compressor bands and are not shown as controls.

The offline suite validates the DSP paths, but no live DAW session or hardware loopback audition was available during this pass.
