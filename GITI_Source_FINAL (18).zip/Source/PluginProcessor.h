#pragma once
#include <set>
#include <JuceHeader.h>
#include "Synth/SynthEngine.h"
#include "FX/SimpleDelay.h"
#include "FX/SimpleChorus.h"
#include "FX/SimpleReverb.h"
#include "FX/SimpleCompressor.h"
#include "FX/SimpleEQ.h"
#include "FX/SimpleSpatial.h"
#include "FX/SimplePhaser.h"
#include "FX/SimpleDistortion.h"
#include "Network/RemoteControl.h"
#include "FX/MagicEngine.h"
#include "Oscillators/GranularOscillator.h"
#include "Sequencer/Arpeggiator.h"
#include "Sequencer/StepSequencer.h"
#include "Modulation/ModMatrix.h"
#include "Modulation/LFO.h"
#include "UI/VisualFifo.h"
#include "SHAE/SHAECore.h"
#include <map>
#include <array>
#include <vector>
#include <atomic>
#include <chrono>

class SalekHightechAudioProcessor : public juce::AudioProcessor, private juce::AudioProcessorParameter::Listener
{
public:
    SalekHightechAudioProcessor();
    ~SalekHightechAudioProcessor() override;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    void processBlockChunk (juce::AudioBuffer<float>&, juce::MidiBuffer&);   // the real work, on <= 64 sample pieces
    juce::MidiBuffer chunkMidi;
    struct Snapshot { std::vector<float> values; juce::String matrix; };
    std::vector<Snapshot> undoStack, redoStack;
    bool restoringSnapshot = false;
    Snapshot captureSnapshot();
    void applySnapshot (const Snapshot& s);
    void parameterValueChanged (int, float) override {}
    void parameterGestureChanged (int, bool starting) override
    {   // the start of every knob drag becomes one undo step
        if (starting && ! restoringSnapshot && juce::MessageManager::getInstance()->isThisTheMessageThread()) pushUndoPoint();
    }
    int chunkOffsetSamples = 0;                 // start of the current 64-sample piece inside the host buffer
    double lastSeqPpqEnd = -1.0; bool seqLocked = false;
    // Parameter lookup cache (audio thread only): the engine reads ~300 parameters per 64-sample piece, so each
    // string literal is resolved to its parameter once and then read through a stored pointer.
    struct ParamSlot { const char* key = nullptr; std::atomic<float>* value = nullptr; };
    static constexpr int kParamSlots = 2048;
    std::array<ParamSlot, kParamSlots> paramCache;
    float fastParam (const char* id) noexcept;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return JucePlugin_Name; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override;

    int getNumPrograms() override { return (int) factoryPresets.size(); }
    int getCurrentProgram() override { return currentProgram; }
    void setCurrentProgram (int index) override;
    const juce::String getProgramName (int index) override;
    juce::String getProgramDescription (int index) const;
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState& getAPVTS() { return apvts; }
    juce::MidiKeyboardState& getKeyboardState() { return keyboardState; }
    float getOutputPeak() const { return outputPeak.load(); }
    float getAudioLoadPercent() const noexcept { return audioLoadPercent.load (std::memory_order_relaxed); }
    float getAudioPeakLoadPercent() const noexcept { return audioPeakLoadPercent.load (std::memory_order_relaxed); }
    float getAudioCallbackMs() const noexcept { return audioCallbackMs.load (std::memory_order_relaxed); }
    std::atomic<float>* getFxActivityMeter (int index) noexcept
    {
        return juce::isPositiveAndBelow (index, (int) fxActivity.size()) ? &fxActivity[(size_t) index] : nullptr;
    }
    VisualFifo& getVisualFifo() { return visualFifo; }
    salek::StepSequencer& getStepSequencer() { return stepSequencer; }
    salek::Arpeggiator& getArpeggiator() { return arpeggiator; }
    salek::ModMatrix& getModMatrix() { return modMatrix; }
    salek::LFO& getLfo1() { return lfo1; }
    salek::LFO& getLfo2() { return lfo2; }
    salek::LFO& getLfo3() { return lfo3; }
    salek::MagicEngine& getMagic() { return magic; }
    salek::SimpleCompressor& getCompressor() { return compressor; }
    salek::SimpleReverb& getReverb() { return reverb; }
    salek::GranularOscillator& getGranular() { return granular; }

    juce::StringArray getPresetNames() const;
    int saveCurrentAsUserPreset (const juce::String& name);
    void loadUserPresetsFromDisk();
    bool saveUserPresetsToDisk();   // false = the file could not be written
    bool exportCurrentPresetToFile (const juce::File& file, const juce::String& displayName);
    int importPresetFromFile (const juce::File& file);
    bool exportUserBankToFile (const juce::File& file);
    int importUserBankFromFile (const juce::File& file);
    int  deletePresets (const juce::String& path);       // "Bank" or "Bank/Folder": removes it (user presets, or purchased bank file / hides a folder)
    // ---- Undo / Redo of the whole sound (every parameter + the modulation matrix) ----
    void pushUndoPoint();                 // call before a change (message thread)
    bool undoParams();
    bool redoParams();
    bool canUndo() const noexcept { return ! undoStack.empty(); }
    bool canRedo() const noexcept { return ! redoStack.empty(); }
    void applyRandomPatch (int style);
    std::unique_ptr<juce::XmlElement> matrixWithExtras();   // mod matrix + step pattern + custom LFO shapes
    void applyExtras (const juce::XmlElement* matrixXml);
    juce::String remoteInfoText();
    // phone keyboard: notes are queued from the network thread and injected into the MIDI stream in processBlockChunk
    void queueRemoteNote (bool on, int note, int vel);
    static constexpr int remoteQueueSize = 256;
    std::array<juce::MidiMessage, remoteQueueSize> remoteQueue;
    std::atomic<int> remoteQueueWrite { 0 }, remoteQueueRead { 0 };
    std::shared_ptr<bool> processorAlive = std::make_shared<bool> (true);   // false while the processor is being destroyed   // phone address and pairing code, for the PHONE button
    void updateCustomWavetableIfChanged();   // message thread: rebuilds the CUSTOM wavetable frame when its points change
    std::array<float, 64> customCache {};
    bool customCacheValid = false;   // 0 BASS, 1 PAD, 2 LEAD, 3 PLUCK, 4 FX
    juce::String getAccountEmail() const;
    void setAccountEmail (const juce::String& email);   // saves the purchase e-mail and re-checks installed banks
    int  installEncryptedBank (const juce::File& file);     // .gitibank -> installs (copies) and loads, returns preset count, -1 = invalid
    void loadEncryptedBanks();                              // loads every installed .gitibank at start-up
    bool isCurrentPresetLocked() const { return lockedPresetNames.count (getProgramNameForIndex (currentProgram)) > 0; }
    bool deleteUserPreset (int programIndex);
    int getNumUserPresets() const;

private:
    juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    void applyParamsToEngine (int samplesThisBlock);
    void initFactoryPresets();
    int loadBankXml (const juce::XmlElement& root);     // encrypted-bank helpers (see PluginProcessorVault.inl)
    int loadBankFile (const juce::File& f);
    void loadFactoryPreset (int index);

    juce::AudioProcessorValueTreeState apvts;

    std::unique_ptr<giti::remote::RemoteControl> remote;   // Wi-Fi control from the GITI phone app (UDP 9731)
    salek::SynthEngine synthEngine;
    salek::SimpleDelay delay;
    salek::SimpleChorus chorus;
    salek::SimpleReverb reverb;
    salek::SimpleCompressor compressor;
    salek::SimpleEQ eq;
    salek::SimpleSpatial spatial;
    salek::SimplePhaser phaser;
    salek::SimpleDistortion distortion;
    salek::MagicEngine magic;
    salek::GranularOscillator granular;
    salek::Arpeggiator arpeggiator;
    salek::StepSequencer stepSequencer;
    salek::ModMatrix modMatrix;
    salek::LFO lfo1, lfo2, lfo3;
    bool lfoNoteTrig = false;
    double hostBpm = 120.0;
    juce::MidiKeyboardState keyboardState;
    juce::MidiBuffer routedMidiBuffer, arpMidiBuffer;
    VisualFifo visualFifo;
    // Peak level after each FX stage: 0 chorus, 1 delay, 2 reverb, 3 bassify,
    // 4 compressor, 5 EQ, 6 phaser, 7 distortion. Audio thread publishes;
    // each mini monitor reads its own value on the message thread.
    std::array<std::atomic<float>, 8> fxActivity {};
    std::atomic<float> outputPeak { 0.f };
    std::atomic<float> audioLoadPercent { 0.f }, audioPeakLoadPercent { 0.f }, audioCallbackMs { 0.f };
    std::atomic<bool> presetVoiceResetRequested { false };
    shae::SafetyStage shaeSafety;
    std::array<float, 4> bassifyState {};
    float bassifyMixSmooth = 0.f, bassifyMixCoeff = 1.f;
    float masterGainSmooth = 0.8f, masterDriveSmooth = 0.f, masterSmoothCoeff = 1.f;
    float modWheelValue = 0.0f, velocityValue = 0.0f;

    void publishFxActivity (int index, const juce::AudioBuffer<float>& buffer) noexcept
    {
        if (! juce::isPositiveAndBelow (index, (int) fxActivity.size()) || buffer.getNumChannels() <= 0)
            return;
        float peak = buffer.getMagnitude (0, 0, buffer.getNumSamples());
        if (buffer.getNumChannels() > 1)
            peak = juce::jmax (peak, buffer.getMagnitude (1, 0, buffer.getNumSamples()));
        fxActivity[(size_t) index].store (peak, std::memory_order_relaxed);
    }

    struct FactoryPreset
    {
        juce::String name;
        std::map<juce::String, float> values;
        juce::String modMatrixXml;
    };
    std::vector<FactoryPreset> factoryPresets;
    std::set<juce::String> lockedPresetNames;
    std::map<juce::String, juce::File> lockedSource;   // preset name -> .gitibank it came from
    juce::File loadingBankFile;     // presets from encrypted banks: cannot be exported or re-saved
    juce::String getProgramNameForIndex (int i) const { return (i >= 0 && i < (int) factoryPresets.size()) ? factoryPresets[(size_t) i].name : juce::String(); }
    int currentProgram = 0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (SalekHightechAudioProcessor)
};
