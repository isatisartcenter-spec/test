#pragma once
// REFERENCE wavetable bank (frames 128..191): single-cycle reference shapes for building sounds
// (sine, saw, square, SSQ, razor, 808 / kick, psy bass, leads, vocal, FM bells, lo-fi, steps...).
#include <cmath>
#include <initializer_list>
#include <cstdint>

namespace salek { namespace refwave
{
    static constexpr int count = 64;

    inline const char* name (int i)
    {
        static const char* n[count] = {
            "Sine", "Triangle", "Saw", "Square", "Pulse 25", "Pulse 12", "Half Sine", "Full Rect",
            "Sine +2nd", "Sine +3rd", "Octave Stack", "Odd 1-7", "Even 2-8", "Saw 4", "Saw 8", "Square 5",
            "SSQ", "Razor", "Razor Wide", "Hard Saw Clip", "Soft Saw Clip", "Fold Saw", "Warp Ramp", "Tri-Saw",
            "808 Fat", "808 Clip", "808 Boom", "Kick Click", "Hard Kick", "Tom", "Sub Thump", "Snare Body",
            "Psy Growl", "Psy Fold", "Reese", "Acid Saw", "Acid Reso", "Dark Bass", "Mid Growl", "Sub Clean",
            "Glass Bell", "Organ", "Brass", "Clarinet", "Vocal A", "Vocal O", "Bowed", "Pluck",
            "FM Bell 1", "FM Bell 2", "Gong", "Ring Mod", "Crush 4", "Crush 8", "Chirp", "Sync Saw",
            "Noise Cluster", "S&H Harm", "Stairs 8", "Stairs 16", "Soft Square", "Cos Bump", "Saw 1/h2", "CUSTOM (draw)" };
        return n[(i < 0 ? 0 : (i >= count ? count - 1 : i))];
    }

    inline float saw (float t) { return 2.f * t - 1.f; }
    inline float sq (float t)  { return t < 0.5f ? 1.f : -1.f; }
    inline float tri (float t) { return 1.f - 4.f * std::fabs (t - 0.5f); }
    inline float tanhk (float x, float k) { return std::tanh (k * x); }
    // additive helpers (phase p = 2*pi*t)
    inline float addOdd (float p, int maxH) { float s = 0.f; for (int h = 1; h <= maxH; h += 2) s += std::sin ((float) h * p) / (float) h; return s; }
    inline float addEven (float p, int maxH) { float s = 0.f; for (int h = 2; h <= maxH; h += 2) s += std::sin ((float) h * p) / (float) h; return s; }
    inline float addSaw (float p, int maxH) { float s = 0.f; for (int h = 1; h <= maxH; ++h) s += ((h & 1) ? 1.f : -1.f) * std::sin ((float) h * p) / (float) h; return s; }
    inline float addSqr (float p, int maxH) { float s = 0.f; for (int h = 1; h <= maxH; h += 2) s += std::sin ((float) h * p) / (float) h; return s; }
    inline float wrap (float x) { x -= std::floor (x); return x; }
    inline float hash (int i) { uint32_t x = (uint32_t) i * 2654435761u; x ^= x >> 13; return ((x & 0xffff) / 32768.f) - 1.f; }

    inline float sample (int idx, float t)
    {
        const float p = 2.f * 3.14159265f * t, s = std::sin (p);
        switch (idx)
        {
            case 0:  return s;
            case 1:  return tri (t);
            case 2:  return saw (t);
            case 3:  return sq (t);
            case 4:  return t < 0.25f ? 1.f : -1.f;
            case 5:  return t < 0.125f ? 1.f : -1.f;
            case 6:  return std::max (s, 0.f);
            case 7:  return std::fabs (s) * 2.f - 1.f;
            case 8:  return s + 0.5f * std::sin (2.f * p);
            case 9:  return s + 0.33f * std::sin (3.f * p);
            case 10: return s + 0.5f * std::sin (2.f * p) + 0.25f * std::sin (4.f * p);
            case 11: return addOdd (p, 7);
            case 12: return addEven (p, 8);
            case 13: return addSaw (p, 4) * 1.2f;
            case 14: return addSaw (p, 8) * 1.1f;
            case 15: return addSqr (p, 5) * 1.2f;
            case 16: return 0.5f * saw (t) + 0.5f * sq (t);
            case 17: return std::exp (-std::pow ((t - 0.5f) * 12.f, 2.f)) * 2.f - 1.f;
            case 18: return std::exp (-std::pow ((t - 0.5f) * 6.f, 2.f)) * 2.f - 1.f;
            case 19: return tanhk (saw (t), 4.f);
            case 20: return tanhk (saw (t), 1.5f);
            case 21: return std::sin (saw (t) * 3.14159f * 2.f);
            case 22: return std::pow (t, 3.f) * 2.f - 1.f;
            case 23: return 0.5f * tri (t) + 0.5f * saw (t);
            case 24: return tanhk (s, 2.f) * 0.9f + 0.2f * std::sin (2.f * p);
            case 25: return tanhk (s, 3.f);
            case 26: return s + 0.15f * std::sin (2.f * p);
            case 27: return s + 0.4f * std::sin (9.f * p) * (1.f - t);
            case 28: return tanhk (s, 5.f);
            case 29: return s + 0.3f * std::sin (2.f * p) * (1.f - t);
            case 30: return s * (0.7f + 0.3f * std::cos (p));
            case 31: return (std::sin (3 * p) / 3.f + std::sin (5 * p) / 5.f + std::sin (7 * p) / 7.f + std::sin (11 * p) / 11.f + std::sin (13 * p) / 13.f) * 1.6f;
            case 32: return tanhk (s + 0.5f * std::sin (3.f * p), 3.f);
            case 33: return std::sin (2.5f * s);
            case 34: return 0.34f * (saw (wrap (t)) + saw (wrap (t * 1.01f)) + saw (wrap (t * 0.99f)));
            case 35: { float v = 0.f; for (int h = 1; h <= 16; ++h) v += std::sin ((float) h * p) / (float) h; return v + 0.6f * std::sin (8.f * p); }
            case 36: { float v = 0.f; for (int h = 1; h <= 12; ++h) v += std::sin ((float) h * p) * std::exp (-std::pow ((float) h - 6.f, 2.f) * 0.15f) / (float) h; return v * 2.f; }
            case 37: { float v = 0.f; for (int h = 1; h <= 8; ++h) v += std::sin ((float) h * p) / std::pow ((float) h, 1.5f); return v; }
            case 38: return saw (t) * s;
            case 39: return s;
            case 40: return s + 0.5f * std::sin (2.76f * p) + 0.2f * std::sin (5.4f * p);
            case 41: return s + 0.5f * std::sin (2.f * p) + 0.33f * std::sin (3.f * p) + 0.25f * std::sin (4.f * p) + 0.2f * std::sin (6.f * p) + 0.15f * std::sin (8.f * p);
            case 42: { float v = 0.f; for (int h = 1; h <= 10; ++h) v += std::sin ((float) h * p) / (float) h * (1.f + 0.2f * (float) h / 10.f); return v * 0.6f; }
            case 43: return addOdd (p, 9);
            case 44: return s + 0.5f * std::sin (3.f * p) + 0.3f * std::sin (5.f * p);
            case 45: return s + 0.4f * std::sin (2.f * p) + 0.2f * std::sin (5.f * p);
            case 46: { float v = 0.f; for (int h = 1; h <= 20; ++h) v += std::cos ((float) h * p + 0.3f * (float) h) / (float) h; return v * 0.5f; }
            case 47: return s * std::exp (-3.f * t) + 0.3f * std::sin (2.f * p) * std::exp (-6.f * t);
            case 48: return std::sin (p + 2.f * std::sin (1.4f * p));
            case 49: return std::sin (p + 3.f * std::sin (2.f * p));
            case 50: return std::sin (p + 4.f * std::sin (0.5f * p));
            case 51: return s * std::sin (3.f * p);
            case 52: return std::floor (s * 8.f) / 8.f;
            case 53: return std::floor (s * 32.f) / 32.f;
            case 54: return std::sin (p * (1.f + 2.f * t));
            case 55: return saw (wrap (t * 2.f));
            case 56: { float v = 0.f; for (int h = 1; h <= 24; ++h) v += hash (h * 7 + 3) * std::sin ((float) h * p) / (float) h; return v * 2.f; }
            case 57: return std::sin (p * std::floor (t * 8.f + 1.f)) * 0.9f;
            case 58: return std::floor (t * 8.f) / 7.f * 2.f - 1.f;
            case 59: return std::floor (t * 16.f) / 15.f * 2.f - 1.f;
            case 60: return tanhk (s, 4.f);
            case 61: return 1.f - std::cos (p);
            case 62: { float v = 0.f; for (int h = 1; h <= 16; ++h) v += std::sin ((float) h * p) / ((float) h * (float) h); return v * 4.f; }
            case 63: return s;   // CUSTOM slot: starts as a sine, replaced by the drawn shape (setCustomShape)
            default: return s;
        }
    }
}}
