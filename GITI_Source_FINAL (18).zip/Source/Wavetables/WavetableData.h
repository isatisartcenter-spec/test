#pragma once

#include <JuceHeader.h>
#include <array>
#include <vector>
#include <cmath>
#include <complex>
#include <atomic>
#include <algorithm>
#include "ReferenceWaves.h"

namespace salek
{

struct WavetableFrame
{
    static constexpr int tableSize = 2048;
    static constexpr int tableMask = tableSize - 1;
    std::array<float, tableSize> samples {};

    float getSample (float phase) const noexcept
    {
        // Catmull-Rom cubic — cleaner high-end than linear (hi-tech / crystal clarity)
        const float pos = phase * static_cast<float> (tableSize);
        const int i1 = static_cast<int> (pos) & tableMask;
        const int i0 = (i1 - 1) & tableMask;
        const int i2 = (i1 + 1) & tableMask;
        const int i3 = (i1 + 2) & tableMask;
        const float frac = pos - std::floor (pos);
        const float y0 = samples[static_cast<size_t> (i0)];
        const float y1 = samples[static_cast<size_t> (i1)];
        const float y2 = samples[static_cast<size_t> (i2)];
        const float y3 = samples[static_cast<size_t> (i3)];
        const float a0 = -0.5f * y0 + 1.5f * y1 - 1.5f * y2 + 0.5f * y3;
        const float a1 = y0 - 2.5f * y1 + 2.0f * y2 - 0.5f * y3;
        const float a2 = -0.5f * y0 + 0.5f * y2;
        const float a3 = y1;
        return ((a0 * frac + a1) * frac + a2) * frac + a3;
    }

    void normalize() noexcept
    {
        float peak = 0.0f;
        for (float s : samples)
            peak = juce::jmax (peak, std::abs (s));
        if (peak > 1.0e-6f)
        {
            const float inv = 1.0f / peak;
            for (float& s : samples)
                s *= inv;
        }
    }
};

class Wavetable
{
public:
    static constexpr int maxFrames = 192;          // 128 classic/hi-tech/formant/metallic + 64 reference shapes

    Wavetable() { generateDefaultTables(); }

    void setNumFrames (int n)
    {
        n = juce::jlimit (1, maxFrames, n);
        frames.resize (static_cast<size_t> (n));
    }

    int getNumFrames() const noexcept { return static_cast<int> (frames.size()); }

    static juce::String getFrameName (int index)
    {
        index = juce::jlimit (0, maxFrames - 1, index);
        static constexpr const char* classicNames[] = {
            "Sine", "Triangle", "Square", "Saw", "Bright Saw", "Saw Square", "Harmonic 1", "Harmonic 2",
            "Quantized Saw", "Bright Square", "Warm Harmonics", "Dense Harmonics", "Vocal Harmonics", "Odd Harmonics",
            "Saw Square Mix", "Screamer", "Warm Saw", "Full Saw", "Bright Saw 2", "Soft Square", "Hard Square",
            "Saw Square 2", "Bright Triangle", "Triangle Saw", "Pulse 25", "Narrow Pulse", "Formant A", "Formant E",
            "Metallic 1", "Metallic 2", "Crushed Saw", "Crushed Square"
        };

        if (index >= 128)
            return "REF " + juce::String (index - 127).paddedLeft ('0', 2) + "  " + juce::String (refwave::name (index - 128));
        if (index < 32)
            return classicNames[index];
        if (index < 48)
            return "Hi-Tech " + juce::String (index - 31).paddedLeft ('0', 2);
        if (index < 64)
            return "Darkpsy " + juce::String (index - 47).paddedLeft ('0', 2);
        if (index < 96)
            return "Formant " + juce::String (index - 63).paddedLeft ('0', 2);
        return "Metallic " + juce::String (index - 95).paddedLeft ('0', 2);
    }

    WavetableFrame& getFrame (int index)
    {
        return frames[static_cast<size_t> (juce::jlimit (0, getNumFrames() - 1, index))];
    }

    const WavetableFrame& getFrame (int index) const
    {
        return frames[static_cast<size_t> (juce::jlimit (0, getNumFrames() - 1, index))];
    }

    float getSample (float tablePos, float phase) const noexcept
    {
        const int n = getNumFrames();
        if (n <= 0) return 0.0f;
        if (n == 1) return frames[0].getSample (phase);

        const float scaled = juce::jlimit (0.0f, 1.0f, tablePos) * static_cast<float> (n - 1);
        const int f0 = static_cast<int> (scaled);
        const int f1 = juce::jmin (f0 + 1, n - 1);
        const float frac = scaled - static_cast<float> (f0);
        const float s0 = frameAt (static_cast<size_t> (f0)).getSample (phase);
        const float s1 = frameAt (static_cast<size_t> (f1)).getSample (phase);
        return s0 * (1.0f - frac) + s1 * frac;
    }

    void clearFrame (int index)
    {
        if (index < 0 || index >= getNumFrames()) return;
        frames[static_cast<size_t>(index)].samples.fill (0.0f);
    }

    void setSample (int frameIdx, int sampleIdx, float value)
    {
        if (frameIdx < 0 || frameIdx >= getNumFrames()) return;
        frames[static_cast<size_t>(frameIdx)].samples[static_cast<size_t>(sampleIdx & WavetableFrame::tableMask)] = value;
    }

    // ---- Band-limited mip levels -------------------------------------------------------
    // Level k keeps only the harmonics up to (1024 >> k). The oscillator picks the level that stays below
    // Nyquist for the played pitch, so bright tables stay clean (no aliasing) on high notes.
    static constexpr int numMips = 10;

    int mipForPhaseInc (double inc) const noexcept
    {
        if (inc <= 1.0e-9 || mips.empty()) return 0;
        const double hmax = 0.44 / inc;          // harmonics that fit below Nyquist (with a safety margin)
        int lvl = 0; double h = 1024.0;
        while (h > hmax && lvl < numMips - 1) { h *= 0.5; ++lvl; }
        return lvl;
    }

    float getSample (float tablePos, float phase, int mip) const noexcept
    {
        const int n = getNumFrames();
        if (mip <= 0 || mips.empty() || n <= 1 || mips[0].size() != frames.size())
            return getSample (tablePos, phase);
        const size_t lvl = (size_t) juce::jmin (mip, numMips - 1) - 1;
        const float scaled = juce::jlimit (0.0f, 1.0f, tablePos) * static_cast<float> (n - 1);
        const int f0 = static_cast<int> (scaled);
        const int f1 = juce::jmin (f0 + 1, n - 1);
        const float frac = scaled - static_cast<float> (f0);
        return mipAt (lvl, (size_t) f0).getSample (phase) * (1.0f - frac) + mipAt (lvl, (size_t) f1).getSample (phase) * frac;
    }

    void rebuildMipmaps()
    {
        const int N = WavetableFrame::tableSize;
        mips.assign ((size_t) numMips - 1, std::vector<WavetableFrame> (frames.size()));
        std::vector<std::complex<double>> spec ((size_t) N), tmp ((size_t) N);
        for (size_t f = 0; f < frames.size(); ++f)
        {
            for (int i = 0; i < N; ++i) spec[(size_t) i] = { (double) frames[f].samples[(size_t) i], 0.0 };
            fft (spec, false);
            for (int k = 1; k < numMips; ++k)
            {
                const int keep = 1024 >> k;
                tmp = spec;
                for (int b = keep + 1; b <= N - keep - 1; ++b) tmp[(size_t) b] = { 0.0, 0.0 };
                fft (tmp, true);
                for (int i = 0; i < N; ++i) mips[(size_t) k - 1][f].samples[(size_t) i] = (float) (tmp[(size_t) i].real() / N);
            }
        }
    }

    static void fft (std::vector<std::complex<double>>& a, bool inverse)
    {
        const size_t n = a.size();
        for (size_t i = 1, j = 0; i < n; ++i)
        {
            size_t bit = n >> 1;
            for (; j & bit; bit >>= 1) j ^= bit;
            j ^= bit;
            if (i < j) std::swap (a[i], a[j]);
        }
        for (size_t len = 2; len <= n; len <<= 1)
        {
            const double ang = 2.0 * 3.14159265358979323846 / (double) len * (inverse ? 1.0 : -1.0);
            const std::complex<double> wl (std::cos (ang), std::sin (ang));
            for (size_t i = 0; i < n; i += len)
            {
                std::complex<double> w (1.0, 0.0);
                for (size_t k = 0; k < len / 2; ++k)
                {
                    const auto u = a[i + k], v = a[i + k + len / 2] * w;
                    a[i + k] = u + v; a[i + k + len / 2] = u - v; w *= wl;
                }
            }
        }
    }

    void generateFromHarmonics (int frameIdx, const float* amps, int numHarmonics) noexcept
    {
        if (frameIdx < 0 || frameIdx >= getNumFrames() || amps == nullptr || numHarmonics <= 0)
            return;
        auto& frame = frames[static_cast<size_t>(frameIdx)];
        frame.samples.fill (0.0f);
        for (int i = 0; i < WavetableFrame::tableSize; ++i)
        {
            const float phase = static_cast<float> (i) / static_cast<float> (WavetableFrame::tableSize)
                              * juce::MathConstants<float>::twoPi;
            float s = 0.0f;
            for (int h = 0; h < numHarmonics; ++h)
                s += amps[h] * std::sin (phase * static_cast<float> (h + 1));
            frame.samples[static_cast<size_t>(i)] = s;
        }
        frame.normalize();
    }

    void morphFrames (int srcA, int srcB, int dest, float t) noexcept
    {
        const int n = getNumFrames();
        if (srcA < 0 || srcB < 0 || dest < 0 || srcA >= n || srcB >= n || dest >= n) return;
        t = juce::jlimit (0.0f, 1.0f, t);
        auto& a = frames[static_cast<size_t>(srcA)];
        auto& b = frames[static_cast<size_t>(srcB)];
        auto& d = frames[static_cast<size_t>(dest)];
        for (int i = 0; i < WavetableFrame::tableSize; ++i)
            d.samples[static_cast<size_t>(i)] = a.samples[static_cast<size_t>(i)] * (1.0f - t)
                                              + b.samples[static_cast<size_t>(i)] * t;
        d.normalize();
    }

    void processFrame (int frameIdx, float foldAmt, float driveAmt) noexcept
    {
        if (frameIdx < 0 || frameIdx >= getNumFrames()) return;
        auto& frame = frames[static_cast<size_t>(frameIdx)];
        for (float& s : frame.samples)
        {
            if (foldAmt > 1e-4f)
            {
                float thresh = 1.0f - foldAmt * 0.85f;
                float x = s * (1.0f + foldAmt * 4.0f);
                for (int k = 0; k < 3; ++k)
                {
                    if (x > thresh) x = thresh - (x - thresh);
                    else if (x < -thresh) x = -thresh - (x + thresh);
                    else break;
                }
                s = x / (1.0f + foldAmt * 1.5f);
            }
            if (driveAmt > 1e-4f)
                s = std::tanh (s * (1.0f + driveAmt * 6.0f));
        }
        frame.normalize();
    }

    void generateDefaultTables()
    {
        // Big bank: 128 frames — analog-style morph (sine→tri→sqr→saw→complex→metallic)
        frames.resize (192); // 128 classic + 64 reference frames
        for (int i = 0; i < WavetableFrame::tableSize; ++i)
        {
            const float t = static_cast<float> (i) / static_cast<float> (WavetableFrame::tableSize);
            const float phase = t * juce::MathConstants<float>::twoPi;
            const size_t idx = static_cast<size_t> (i);
            auto addSaw = [&](int harm) {
                float s = 0.0f;
                for (int h = 1; h <= harm; ++h)
                    s += std::sin (static_cast<float> (h) * phase) / static_cast<float> (h);
                return s;
            };
            auto addSqr = [&](int harm) {
                float s = 0.0f;
                for (int h = 1; h <= harm; h += 2)
                    s += std::sin (static_cast<float> (h) * phase) / static_cast<float> (h);
                return s;
            };
            auto addTri = [&](int harm) {
                float s = 0.0f;
                for (int h = 1; h <= harm; h += 2) {
                    float sign = ((h - 1) / 2) % 2 == 0 ? 1.0f : -1.0f;
                    s += sign * std::sin ((float) h * phase) / (float) (h * h);
                }
                return s;
            };

            // 0–15 classic morph (kept + refined)
            frames[0].samples[idx]  = std::sin (phase);
            frames[1].samples[idx]  = addTri (15) * 0.95f;
            frames[2].samples[idx]  = addSqr (15) * 0.9f;
            frames[3].samples[idx]  = addSaw (32) * 0.85f;
            frames[4].samples[idx]  = addSaw (48) * 0.7f;
            frames[5].samples[idx]  = (addSqr (31) * 0.7f + addSaw (16) * 0.3f) * 0.85f;
            frames[6].samples[idx]  = (std::sin (phase) + 0.35f * std::sin (3.f * phase) + 0.2f * std::sin (5.f * phase)) * 0.75f;
            frames[7].samples[idx]  = (std::sin (phase) + 0.28f * std::sin (4.f * phase) + 0.2f * std::sin (8.f * phase)) * 0.7f;
            frames[8].samples[idx]  = std::floor (addSaw (20) * 6.f) / 6.f * 0.8f;
            frames[9].samples[idx]  = addSqr (41) * 0.75f;
            frames[10].samples[idx] = (std::sin (phase) * 0.85f + 0.4f * std::sin (2.f * phase) + 0.15f * std::sin (3.f * phase));
            {
                float s = 0.f;
                for (int h = 1; h <= 64; ++h)
                    s += (1.f / (1.f + 0.12f * (float) h)) * std::sin ((float) h * phase);
                frames[11].samples[idx] = s * 0.4f;
            }
            frames[12].samples[idx] = (std::sin (phase) + 0.5f * std::sin (6.f * phase) + 0.3f * std::sin (7.f * phase)) * 0.7f;
            frames[13].samples[idx] = (std::sin (phase) - 0.6f * std::sin (2.f * phase) + 0.3f * std::sin (5.f * phase)) * 0.75f;
            frames[14].samples[idx] = (0.55f * addSaw (24) + 0.45f * addSqr (31)) * 0.85f;
            frames[15].samples[idx] = (addSaw (8) + 0.15f * std::sin (23.f * phase) + 0.1f * std::sin (29.f * phase)) * 0.7f;

            // 16–31 Virus-style / analog fat morphs
            frames[16].samples[idx] = addSaw (12) * 0.9f;                          // warm saw
            frames[17].samples[idx] = addSaw (24) * 0.85f;
            frames[18].samples[idx] = addSaw (64) * 0.65f;                          // bright saw
            frames[19].samples[idx] = addSqr (9) * 0.9f;                            // soft square
            frames[20].samples[idx] = addSqr (25) * 0.8f;
            frames[21].samples[idx] = (addSaw (20) * 0.6f + addSqr (15) * 0.4f) * 0.85f;
            frames[22].samples[idx] = addTri (31) * 0.9f;
            frames[23].samples[idx] = (addTri (15) * 0.5f + addSaw (16) * 0.5f) * 0.85f;
            // pulse-ish
            frames[24].samples[idx] = (t < 0.25f ? 0.9f : (t < 0.5f ? -0.3f : (t < 0.75f ? 0.5f : -0.9f)));
            frames[25].samples[idx] = (t < 0.125f ? 1.f : -0.35f) * 0.85f;         // narrow pulse
            // formant-ish
            frames[26].samples[idx] = (std::sin (phase) + 0.55f * std::sin (3.f * phase) + 0.35f * std::sin (5.f * phase)
                                       + 0.2f * std::sin (7.f * phase)) * 0.65f;
            frames[27].samples[idx] = (std::sin (phase) + 0.4f * std::sin (5.f * phase) + 0.3f * std::sin (9.f * phase)) * 0.7f;
            // metallic / partial clusters
            frames[28].samples[idx] = (std::sin (phase) + 0.45f * std::sin (2.7f * phase) + 0.3f * std::sin (4.1f * phase)
                                       + 0.2f * std::sin (6.3f * phase)) * 0.65f;
            frames[29].samples[idx] = (std::sin (phase) + 0.5f * std::sin (3.3f * phase) + 0.35f * std::sin (7.1f * phase)) * 0.6f;
            // bit-crushed morph
            frames[30].samples[idx] = std::floor (addSaw (32) * 4.f) / 4.f * 0.85f;
            frames[31].samples[idx] = std::floor (addSqr (21) * 8.f) / 8.f * 0.8f;

            // 32–47 hi-tech / alien / screech material
            for (int f = 32; f < 48; ++f)
            {
                float morph = (float) (f - 32) / 15.f;
                float s = 0.f;
                int harm = 8 + (int) (morph * 48.f);
                for (int h = 1; h <= harm; ++h)
                {
                    float amp = 1.f / (1.f + 0.08f * h * (1.f + morph));
                    float det = 1.f + morph * 0.15f * std::sin ((float) h);
                    s += amp * std::sin ((float) h * det * phase);
                }
                // add odd harmonics for scream
                if (morph > 0.4f)
                    s += 0.3f * morph * std::sin (11.f * phase) + 0.2f * morph * std::sin (13.f * phase);
                frames[(size_t) f].samples[idx] = s * (0.55f - morph * 0.15f);
            }

            // 48–63 darkpsy / supersaw-ish / folded
            for (int f = 48; f < 64; ++f)
            {
                float morph = (float) (f - 48) / 15.f;
                float s = addSaw (16 + (int) (morph * 40.f));
                s = std::tanh (s * (1.2f + morph * 2.5f));
                s += 0.12f * morph * std::sin (2.f * phase);
                s += 0.08f * morph * std::sin (4.f * phase);
                frames[(size_t) f].samples[idx] = s * 0.7f;
            }
            // 64–95 formant / vowel / vocal-ish
            for (int f = 64; f < 96; ++f)
            {
                float morph = (float) (f - 64) / 31.f;
                float f1 = 0.8f + morph * 2.5f;
                float f2 = 2.2f + morph * 4.f;
                float f3 = 5.0f + morph * 6.f;
                float s = std::sin (phase)
                        + 0.55f * std::sin (f1 * phase)
                        + 0.35f * std::sin (f2 * phase)
                        + 0.2f * std::sin (f3 * phase);
                s *= (0.55f + 0.2f * std::sin (3.f * phase + morph));
                frames[(size_t) f].samples[idx] = s * 0.55f;
            }
            // 96–127 metallic / sync / FM-ish / glassy
            for (int f = 96; f < 128; ++f)
            {
                float morph = (float) (f - 96) / 31.f;
                float mod = std::sin ((2.f + morph * 8.f) * phase);
                float s = std::sin (phase + morph * 2.5f * mod);
                s += 0.25f * morph * std::sin ((7.f + morph * 11.f) * phase);
                s = std::tanh (s * (1.1f + morph));
                frames[(size_t) f].samples[idx] = s * 0.6f;
            }
        }
        // reference bank (frames 128..191)
        for (int k = 128; k < maxFrames; ++k)
            for (int i = 0; i < WavetableFrame::tableSize; ++i)
                frames[(size_t) k].samples[(size_t) i] = refwave::sample (k - 128, (float) i / (float) WavetableFrame::tableSize);
        for (auto& f : frames)
            f.normalize();
        rebuildMipmaps();
        initCustomSlot();
    }

public:
    // ---- CUSTOM frame: double-buffered so the audio thread never reads a half-written frame ----
    // The audio thread reads customFrame[slot] / customMips[slot]. The message thread writes the OTHER slot and then
    // flips 'slot' atomically. frames.back() and mips[..].back() are no longer read by the audio thread.
    void setCustomShape (const float* pts, int n)
    {
        if (frames.empty() || n < 2) return;
        const int N = WavetableFrame::tableSize;
        const int next = 1 - customSlot.load (std::memory_order_acquire);
        auto& cf = customFrame[(size_t) next];
        for (int i = 0; i < N; ++i)
        {
            const float x = (float) i / (float) N * (float) n;
            const int i0 = juce::jlimit (0, n - 1, (int) x);
            const int i1 = (i0 + 1) % n;
            const float fr = x - (float) i0;
            cf.samples[(size_t) i] = pts[i0] * (1.f - fr) + pts[i1] * fr;
        }
        cf.normalize();
        buildMipsForFrame (cf, customMips[(size_t) next]);
        frames.back() = cf;                         // keeps the editor / monitor readers in sync
        customSlot.store (next, std::memory_order_release);
    }

    // band-limited copies of one frame (levels 1..numMips-1)
    void buildMipsForFrame (const WavetableFrame& src, std::array<WavetableFrame, numMips - 1>& dst) const
    {
        const int N = WavetableFrame::tableSize;
        std::vector<std::complex<double>> spec ((size_t) N), tmp ((size_t) N);
        for (int i = 0; i < N; ++i) spec[(size_t) i] = { (double) src.samples[(size_t) i], 0.0 };
        fft (spec, false);
        for (int k = 1; k < numMips; ++k)
        {
            const int keep = 1024 >> k;
            tmp = spec;
            for (int b = keep + 1; b <= N - keep - 1; ++b) tmp[(size_t) b] = { 0.0, 0.0 };
            fft (tmp, true);
            for (int i = 0; i < N; ++i) dst[(size_t) k - 1].samples[(size_t) i] = (float) (tmp[(size_t) i].real() / N);
        }
    }

    void initCustomSlot()
    {
        customFrame[0] = frames.back();
        buildMipsForFrame (customFrame[0], customMips[0]);
        customSlot.store (0, std::memory_order_release);
    }

    const WavetableFrame& frameAt (size_t f) const noexcept
    {
        return (f + 1 == frames.size()) ? customFrame[(size_t) customSlot.load (std::memory_order_acquire)] : frames[f];
    }

    const WavetableFrame& mipAt (size_t lvl, size_t f) const noexcept
    {
        return (f + 1 == frames.size()) ? customMips[(size_t) customSlot.load (std::memory_order_acquire)][lvl] : mips[lvl][f];
    }

    void rebuildMipsFor (size_t f)
    {
        if (mips.size() != (size_t) numMips - 1 || f >= frames.size()) return;
        const int N = WavetableFrame::tableSize;
        std::vector<std::complex<double>> spec ((size_t) N), tmp ((size_t) N);
        for (int i = 0; i < N; ++i) spec[(size_t) i] = { (double) frames[f].samples[(size_t) i], 0.0 };
        fft (spec, false);
        for (int k = 1; k < numMips; ++k)
        {
            const int keep = 1024 >> k;
            tmp = spec;
            for (int b = keep + 1; b <= N - keep - 1; ++b) tmp[(size_t) b] = { 0.0, 0.0 };
            fft (tmp, true);
            for (int i = 0; i < N; ++i) mips[(size_t) k - 1][f].samples[(size_t) i] = (float) (tmp[(size_t) i].real() / N);
        }
    }

private:
    std::vector<WavetableFrame> frames;
    std::vector<std::vector<WavetableFrame>> mips;   // [level-1][frame]
    std::array<WavetableFrame, 2> customFrame;                                  // CUSTOM frame, two copies
    std::array<std::array<WavetableFrame, numMips - 1>, 2> customMips;          // and their band-limited levels
    std::atomic<int> customSlot { 0 };
};

} // namespace salek
