SalekHightechAudioProcessorEditor::SalekHightechAudioProcessorEditor (SalekHightechAudioProcessor& p)
    : AudioProcessorEditor (&p), processor (p),
      keyboard (p.getKeyboardState(), juce::MidiKeyboardComponent::horizontalKeyboard)
{
    keyboard.setAvailableRange (21, 108);
    keyboard.clearKeyMappings();   // the component had its own letter mapping: every key played 2 notes
    keyboard.setOctaveForMiddleC (4);
    keyboard.setColour (juce::MidiKeyboardComponent::whiteNoteColourId, juce::Colour (0xffd8dce0));
    keyboard.setColour (juce::MidiKeyboardComponent::blackNoteColourId, juce::Colour (0xff18232b));
    keyboard.setColour (juce::MidiKeyboardComponent::keySeparatorLineColourId, juce::Colour (0xff697680));
    keyboard.setColour (juce::MidiKeyboardComponent::mouseOverKeyOverlayColourId, SalekLookAndFeel::teal().withAlpha (0.22f));
    keyboard.setColour (juce::MidiKeyboardComponent::keyDownOverlayColourId, SalekLookAndFeel::teal().withAlpha (0.48f));
    keyboard.setColour (juce::MidiKeyboardComponent::textLabelColourId, SalekLookAndFeel::mutedText());
    keyboard.setColour (juce::MidiKeyboardComponent::shadowColourId, juce::Colours::black.withAlpha (0.34f));
    keyboard.setWantsKeyboardFocus (true);
    // Keep computer-keyboard → MIDI working even while mouse is on knobs
    setWantsKeyboardFocus (true);
    sonicCore = nullptr;

    addAndMakeVisible (keyboard);
    // VBlank disabled — was causing 5-10 FPS lag with heavy BG paint
    // Animation driven by timer only at 12 Hz
    startTimerHz (3); // lighter UI refresh

    setLookAndFeel (&lnf);
    logoImg   = SalekAssets::loadLogoGiti();
    if (! logoImg.isValid()) logoImg = SalekAssets::loadLogo();
    // Prefer transparent sheet logo when available
    {
        auto sheet = SalekAssets::loadSalekSheetLogo();
        if (sheet.isValid() && sheet.getWidth() > 100)
            logoImg = sheet;
    }
    logoOverlay.img = logoImg;
    logoOverlay.setInterceptsMouseClicks (false, false);
    addAndMakeVisible (logoOverlay);
    stageLogo.setInterceptsMouseClicks (false, false);
    addAndMakeVisible (stageLogo);
    stageLogo.setVisible (false);

    inspireBtn.setButtonText ("INSPIRE");
    inspireBtn.setColour (juce::TextButton::buttonColourId, SalekLookAndFeel::panel());
    inspireBtn.setColour (juce::TextButton::textColourOffId, SalekLookAndFeel::rose());
    inspireBtn.setTooltip ("Randomize in current style (genre-aware)");
    addAndMakeVisible (inspireBtn);
    inspireBtn.onClick = [this]
    {
        // Style-aware randomize from current program category
        const int n = processor.getNumPrograms();
        if (n <= 1) return;
        juce::String cur = processor.getProgramName (processor.getCurrentProgram());
        juce::String cat = cur.upToFirstOccurrenceOf ("/", false, false);
        juce::Array<int> pool;
        for (int i = 0; i < n; ++i)
        {
            auto nm = processor.getProgramName (i);
            if (cat.isNotEmpty() && nm.startsWithIgnoreCase (cat + "/"))
                pool.add (i);
        }
        if (pool.isEmpty())
        {
            for (int i = 1; i < n; ++i) pool.add (i); // skip Init
        }
        if (pool.isEmpty()) return;
        const int pick = pool[juce::Random::getSystemRandom().nextInt (pool.size())];
        processor.setCurrentProgram (pick);
        rebuildPresetRows();
        repaint();
    };

    randomZones.onPick = [this] (const juce::String& cat)
    {   // SPARK: build a brand-new patch in the style of the zone you clicked
        const int style = cat == "BASS" ? 0 : cat == "PAD" ? 1 : cat == "LEAD" ? 2 : cat == "PLUCK" ? 3 : 4;
        processor.applyRandomPatch (style);
        presetLabel.setText ("SPARK  -  " + cat, juce::dontSendNotification);
        repaint();
    };
    randomZones.setTooltip ("SPARK: click a colour to forge a new sound - red BASS, green PAD, blue LEAD, violet PLUCK, gold FX");
    spaceScene.getLevel = [this] { return processor.getOutputPeak(); };
    uiLogo = SalekUiImages::load (0);
    stageLogo.img = SalekUiImages::load (1);
    spaceScene.logo = uiLogo;
    spaceScene.drone = SalekUiImages::load (2);
    spaceScene.robot = SalekUiImages::load (3);
    updateBtn.setTooltip ("Check online for a newer version");
    updateBtn.setColour (juce::TextButton::buttonColourId, SalekLookAndFeel::panel());
    updateBtn.setColour (juce::TextButton::textColourOffId, juce::Colour (0xffffc861));
    updateBtn.onClick = [this]
    {
        juce::Component::SafePointer<juce::Component> safe (this);
        juce::Thread::launch ([safe]
        {
            juce::URL url (GITI_UPDATE_URL);
            auto text = url.readEntireTextStream (false);
            auto info = juce::JSON::parse (text);
            juce::MessageManager::callAsync ([safe, info]
            {
                if (safe == nullptr) return;
                if (! info.isObject())
                {
                    juce::AlertWindow::showMessageBoxAsync (juce::MessageBoxIconType::WarningIcon, "GITI update",
                        "Could not reach the update server.\nCheck your internet connection (or the update address).");
                    return;
                }
                const juce::String latest = info.getProperty ("version", "").toString();
                const juce::String link = info.getProperty ("url", "").toString();
                const juce::String notes = info.getProperty ("notes", "").toString();
               #ifdef JucePlugin_VersionString
                const juce::String current (JucePlugin_VersionString);
               #else
                const juce::String current ("1.0.0");
               #endif
                auto tokens = [] (const juce::String& v) { juce::StringArray t; t.addTokens (v, ".", ""); return t; };
                auto a = tokens (latest), b = tokens (current);
                bool newer = false;
                for (int i = 0; i < juce::jmax (a.size(), b.size()); ++i)
                {
                    const int x = a[i].getIntValue(), y = b[i].getIntValue();
                    if (x != y) { newer = x > y; break; }
                }
                if (! newer)
                {
                    juce::AlertWindow::showMessageBoxAsync (juce::MessageBoxIconType::InfoIcon, "GITI update", "You are up to date (v" + current + ").");
                    return;
                }
                juce::AlertWindow::showOkCancelBox (juce::MessageBoxIconType::InfoIcon, "GITI update available",
                    "New version " + latest + " is available (you have " + current + ").\n\n" + notes + "\n\nOpen the download page?",
                    "Download", "Later", nullptr,
                    juce::ModalCallbackFunction::create ([link] (int r) { if (r == 1 && link.isNotEmpty()) juce::URL (link).launchInDefaultBrowser(); }));
            });
        });
    };
    addAndMakeVisible (updateBtn);
    storeBtn.setTooltip ("Packs: activate your purchase e-mail, download or install banks");
    storeBtn.setColour (juce::TextButton::buttonColourId, SalekLookAndFeel::panel());
    storeBtn.setColour (juce::TextButton::textColourOffId, juce::Colour (0xff35e6ff));
    storeBtn.onClick = [this]
    {
        auto* panel = new StorePanel (processor, [this] { rebuildPresetRows(); presetList.updateContent(); presetList.repaint(); });
        juce::DialogWindow::LaunchOptions o;
        o.content.setOwned (panel);
        o.dialogTitle = "GITI STORE";
        o.dialogBackgroundColour = juce::Colour (0xff0b0d26);
        o.escapeKeyTriggersCloseButton = true;
        o.useNativeTitleBar = true;
        o.resizable = false;
        o.componentToCentreAround = this;
        o.launchAsync();
    };
    addAndMakeVisible (storeBtn);
    drawWaveBtn.setTooltip ("Draw the CUSTOM wavetable (REF 64 CUSTOM) like an LFO shape");
    drawWaveBtn.setColour (juce::TextButton::buttonColourId, SalekLookAndFeel::panel());
    drawWaveBtn.setColour (juce::TextButton::textColourOffId, juce::Colour (0xffffc861));
    addAndMakeVisible (drawWaveBtn);
    drawWaveBtn.onClick = [this]
    {
        auto* panel = new CustomWaveEditor (processor.getAPVTS());
        juce::DialogWindow::LaunchOptions o;
        o.content.setOwned (panel);
        o.dialogTitle = "GITI  -  DRAW WAVETABLE";
        o.dialogBackgroundColour = juce::Colour (0xff0b0d26);
        o.escapeKeyTriggersCloseButton = true;
        o.useNativeTitleBar = true;
        o.resizable = false;
        o.componentToCentreAround = this;
        o.launchAsync();
    };
    for (auto* b : { &undoBtn, &redoBtn })
    {
        b->setColour (juce::TextButton::buttonColourId, SalekLookAndFeel::panel());
        b->setColour (juce::TextButton::textColourOffId, juce::Colour (0xffc4c887));
        addAndMakeVisible (*b);
    }
    undoBtn.setTooltip ("Undo the last change (Ctrl+Z)");
    redoBtn.setTooltip ("Redo (Ctrl+Y or Ctrl+Shift+Z)");
    undoBtn.onClick = [this] { if (processor.undoParams()) repaint(); };
    redoBtn.onClick = [this] { if (processor.redoParams()) repaint(); };
    addAndMakeVisible (spaceScene);
    addAndMakeVisible (modStage);
    magicRndBtn.setTooltip ("Random MAGIC X and Y");
    magicRndBtn.setColour (juce::TextButton::buttonColourId, SalekLookAndFeel::panel());
    magicRndBtn.setColour (juce::TextButton::textColourOffId, juce::Colour (0xffffc861));
    magicRndBtn.onClick = [this]
    {
        for (auto* id : { "magic_x", "magic_y" })
            if (auto* p = processor.getAPVTS().getParameter (id))
            {
                p->beginChangeGesture();
                p->setValueNotifyingHost (juce::Random::getSystemRandom().nextFloat());
                p->endChangeGesture();
            }
    };
    magicTab.addAndMakeVisible (magicRndBtn);
    ecoBtn.setTooltip ("ECO: turn oversampling off (less CPU, a little more aliasing)");
    ecoBtn.setClickingTogglesState (true);
    ecoBtn.setColour (juce::TextButton::buttonColourId, SalekLookAndFeel::panel());
    ecoBtn.setColour (juce::TextButton::buttonOnColourId, juce::Colour (0xff1fa85a));
    ecoBtn.setColour (juce::TextButton::textColourOffId, juce::Colour (0xff35e6ff));
    ecoBtn.setColour (juce::TextButton::textColourOnId, juce::Colours::white);
    addAndMakeVisible (ecoBtn);
    phoneBtn.setTooltip ("Phone control: address and pairing code");
    phoneBtn.setColour (juce::TextButton::buttonColourId, SalekLookAndFeel::panel());
    phoneBtn.setColour (juce::TextButton::textColourOffId, juce::Colour (0xff35e6ff));
    phoneBtn.onClick = [this]
    {
        juce::AlertWindow::showMessageBoxAsync (juce::MessageBoxIconType::InfoIcon, "GITI  -  Phone control",
                                                processor.remoteInfoText());
    };
    addAndMakeVisible (phoneBtn);
    btnAtts.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (processor.getAPVTS(), "perf_eco", ecoBtn));
    lfoFrames = std::make_unique<GroupFrames> (lfoColBox, 3,
        std::vector<juce::String> { "LFO 1", "LFO 2", "LFO 3" },
        std::vector<juce::Colour> { juce::Colour (0xff35e6ff), juce::Colour (0xffff3ccf), juce::Colour (0xffffc861) });
    lfoTab.addAndMakeVisible (*lfoFrames);
    modFrames = std::make_unique<GroupFrames> (modBox, 6,
        std::vector<juce::String> { "FM", "AM", "PM", "RM", "MACRO 1-4 (GITI)", "MACRO 5-8" },
        std::vector<juce::Colour> { juce::Colour (0xffffc861), juce::Colour (0xff73c9c5), juce::Colour (0xffff3ccf), juce::Colour (0xffa24bff), juce::Colour (0xff35e6ff), juce::Colour (0xff6cff7a) });
    modTab.addAndMakeVisible (*modFrames);
    quickLfo[0] = std::make_unique<QuickLfoPanel> (processor.getAPVTS(), processor.getLfo1(), "lfo",  SalekLookAndFeel::teal());
    quickLfo[1] = std::make_unique<QuickLfoPanel> (processor.getAPVTS(), processor.getLfo2(), "lfo2", SalekLookAndFeel::rose());
    quickLfo[2] = std::make_unique<QuickLfoPanel> (processor.getAPVTS(), processor.getLfo3(), "lfo3", juce::Colour (0xffffc861));
    for (auto& q : quickLfo) addChildComponent (*q);
    modStage.onTab = [this] { resized(); };
    addAndMakeVisible (randomZones);
    for (int i = 0; i < SalekBackgrounds::count(); ++i)
    {
        auto im = SalekBackgrounds::load (i);
        if (im.isValid()) bgImages.push_back (im);
    }
    logoOverlay.toFront (false);

    // Bottom model strip title
    modelStripTitle.setText ("SALEK HIGHTECH", juce::dontSendNotification);
    modelStripTitle.setJustificationType (juce::Justification::centred);
    modelStripTitle.setFont (juce::FontOptions (13.0f, juce::Font::bold));
    modelStripTitle.setColour (juce::Label::textColourId, SalekLookAndFeel::teal());
    addAndMakeVisible (modelStripTitle);
    modelStrip.clear();
    for (int i = 0; i < 8; ++i)
    {
        auto* ic = new juce::ImageComponent ("model" + juce::String (i));
        auto im = SalekAssets::loadCharPortrait (i, 160, 240); // thumbnail size keeps multi-instance RAM low
        if (im.isValid())
        {
            ic->setImage (im);
            ic->setImagePlacement (juce::RectanglePlacement::xMid | juce::RectanglePlacement::yBottom | juce::RectanglePlacement::onlyReduceInSize);
        }
        ic->setInterceptsMouseClicks (true, false);
        addAndMakeVisible (ic);
        modelStrip.add (ic);
    }

    
    for (int i = 0; i < modelStrip.size(); ++i)
    {
        if (auto* ic = modelStrip[i])
        {
            ic->setMouseCursor (juce::MouseCursor::PointingHandCursor);
            // capture index for click
        }
    }
    // Click any strip model → set main character
    struct ModelPickHook : public juce::MouseListener
    {
        SalekHightechAudioProcessorEditor* ed = nullptr;
        int idx = 0;
        void mouseDown (const juce::MouseEvent&) override
        {
            if (ed == nullptr) return;
            ed->charPortraitIdx = idx;
            ed->refreshCharCache();
            ed->repaint();
        }
    };
    for (int i = 0; i < modelStrip.size(); ++i)
    {
        auto* hook = new ModelPickHook();
        hook->ed = this;
        hook->idx = i;
        if (auto* ic = modelStrip[i])
            ic->addMouseListener (hook, false);
        modHookListeners.push_back (std::unique_ptr<juce::MouseListener> (hook));
    }

    charPortraitIdx = 5; // startup hero: the white/cyan cyber model from the carousel
    refreshCharCache();
    // face.png removed (was ~2MB) — BGs only
    // backgrounds now come only from BackgroundsData.h (BG button); the old bg_isatis / bg_salek files are no longer embedded
    refreshCharCache(); // load char PNGs ONCE
    
    // Global LFO mod sources (Serum/Vital style) — visible all tabs
    auto styleModSrc = [this] (juce::TextButton& b, juce::Colour c, int src)
    {
        b.setColour (juce::TextButton::buttonColourId, SalekLookAndFeel::panel());
        b.setColour (juce::TextButton::buttonOnColourId, c.withAlpha (0.55f));
        b.setColour (juce::TextButton::textColourOffId, c);
        b.setColour (juce::TextButton::textColourOnId, juce::Colours::white);
        b.setClickingTogglesState (false);   // drag-only: a plain click never leaves the source armed
        b.setTooltip ("Drag " + b.getButtonText() + " onto any knob | Shift=100% | Alt=invert | Ctrl=25% | Right-click=clear");
        b.onClick = [this]
        {
            armedModSource = -1;
            modSrcLfo1.setToggleState (false, juce::dontSendNotification);
            modSrcLfo2.setToggleState (false, juce::dontSendNotification);
            modSrcLfo3.setToggleState (false, juce::dontSendNotification);
        };
        addAndMakeVisible (b);
    };
    styleModSrc (modSrcLfo1, SalekLookAndFeel::teal(), 0);
    styleModSrc (modSrcLfo2, SalekLookAndFeel::rose(), 1);
    styleModSrc (modSrcLfo3, juce::Colour (0xffffc94a), 2);
    modSrcLfo1.setComponentID ("giti_img_lfo0");   // crystal vortex buttons, hue-shifted per LFO
    modSrcLfo2.setComponentID ("giti_img_lfo1");
    modSrcLfo3.setComponentID ("giti_img_lfo2");
    inspireBtn.setComponentID ("giti_img_random"); // random / creative button
    inspireBtn.setTooltip ("SPARK - forge a new sound. Pick a colour zone below: BASS / PAD / LEAD / PLUCK / FX");
    inspireBtn.setButtonText (juce::String::fromUTF8 ("\xd8\xac\xd8\xb1\xd9\x82\xd9\x87 \xc2\xb7 SPARK"));

    // Global: when LFO armed, click any knob to route (works even if DnD target misses)
    struct GlobalModClickHook : public juce::MouseListener
    {
        SalekHightechAudioProcessorEditor* ed = nullptr;
        void mouseDown (const juce::MouseEvent& e) override
        {
            if (ed == nullptr || ed->armedModSource < 0) return;
            if (e.eventComponent == &ed->modSrcLfo1 || e.eventComponent == &ed->modSrcLfo2
                || e.eventComponent == &ed->modSrcLfo3)
                return;
            auto pos = e.getEventRelativeTo (ed).getPosition();
            float amt = 0.5f;
            if (e.mods.isShiftDown()) amt = 1.0f;
            if (e.mods.isAltDown()) amt = -0.5f;
            if (e.mods.isCommandDown() || e.mods.isCtrlDown()) amt = 0.25f;
            if (e.mods.isRightButtonDown()) amt = 0.f;
            ed->tryAssignModAt (pos, amt, e.mods);
        }
        void mouseDrag (const juce::MouseEvent& e) override
        {
            if (ed == nullptr || e.getDistanceFromDragStart() < 3)
                return;
            if (e.eventComponent == &ed->modSrcLfo1) ed->armedModSource = 0;
            else if (e.eventComponent == &ed->modSrcLfo2) ed->armedModSource = 1;
            else if (e.eventComponent == &ed->modSrcLfo3) ed->armedModSource = 2;
            else return;
            // This capture-phase listener sees the gesture even when a DAW
            // keeps the mouse attached to the source button while dragging.
            ed->isModDragging = true;
            ed->setMouseCursor (juce::MouseCursor::CopyingCursor);
        }
        void mouseUp (const juce::MouseEvent& e) override
        {
            if (ed == nullptr || ! ed->isModDragging) return;
            const auto pos = ed->currentMousePositionInEditor();
            float amt = 0.5f;
            if (e.mods.isShiftDown()) amt = 1.0f;
            if (e.mods.isAltDown()) amt = -0.5f;
            ed->tryAssignModAt (pos, amt, e.mods);
            ed->isModDragging = false;
            ed->setMouseCursor (juce::MouseCursor::NormalCursor);
        }
    };
    {
        auto* ghook = new GlobalModClickHook();
        ghook->ed = this;
        addMouseListener (ghook, true); // all children
        modHookListeners.push_back (std::unique_ptr<juce::MouseListener> (ghook));
    }

    // Real drag-and-drop from LFO pills onto knobs
    struct LfoDragHook : public juce::MouseListener
    {
        SalekHightechAudioProcessorEditor* ed = nullptr;
        int src = 0;
        void mouseDown (const juce::MouseEvent&) override
        {
            if (ed == nullptr) return;
            ed->armedModSource = src;
            ed->isModDragging = false;
            // exclusive arm UI
            ed->modSrcLfo1.setToggleState (src == 0, juce::dontSendNotification);
            ed->modSrcLfo2.setToggleState (src == 1, juce::dontSendNotification);
            ed->modSrcLfo3.setToggleState (src == 2, juce::dontSendNotification);
        }
        void mouseDrag (const juce::MouseEvent& e) override
        {
            if (ed == nullptr || e.getDistanceFromDragStart() < 3) return;
            ed->armedModSource = src;
            ed->isModDragging = true;
            ed->setMouseCursor (juce::MouseCursor::CopyingCursor);
            if (auto* container = juce::DragAndDropContainer::findParentDragContainerFor (e.eventComponent))
                container->startDragging ("SALEK_LFO" + juce::String (src), e.eventComponent);
        }
        void mouseUp (const juce::MouseEvent& e) override
        {
            if (ed == nullptr) return;
            if (ed->isModDragging || ed->armedModSource >= 0)
            {
                const auto pos = ed->currentMousePositionInEditor();
                float amt = 0.5f;
                if (e.mods.isShiftDown()) amt = 1.0f;
                if (e.mods.isAltDown()) amt = -0.5f;
                if (e.mods.isRightButtonDown()) amt = 0.f;
                ed->tryAssignModAt (pos, amt, e.mods);
            }
            ed->isModDragging = false;
            ed->setMouseCursor (juce::MouseCursor::NormalCursor);
        }
    };
    for (int i = 0; i < 3; ++i)
    {
        auto* hook = new LfoDragHook();
        hook->ed = this;
        hook->src = i;
        juce::TextButton* btns[3] = { &modSrcLfo1, &modSrcLfo2, &modSrcLfo3 };
        btns[i]->addMouseListener (hook, false);
        // leak-free store
        modHookListeners.push_back (std::unique_ptr<juce::MouseListener> (hook));
    }

    masterGainSlider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    masterGainSlider.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
    masterGainSlider.setTooltip ("Master Volume");
    masterGainSlider.getProperties().set ("pid", "master_gain");   // crystal puck knob
    addAndMakeVisible (masterGainSlider);
    masterGainAtt = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
        processor.getAPVTS(), "master_gain", masterGainSlider);

    title.setText ("SALEK HIGHTECH", juce::dontSendNotification);
    addAndMakeVisible (title);
    tagline.setText ("ALIEN", juce::dontSendNotification);
    addAndMakeVisible (tagline);
    scope.setFifo (&processor.getVisualFifo());
    spectrum.setFifo (&processor.getVisualFifo());
    addAndMakeVisible (scope);
    addAndMakeVisible (spectrum);
    wtDisplay = std::make_unique<WavetableDisplay> (processor.getAPVTS());
    addAndMakeVisible (*wtDisplay);
    adsrDisplay = std::make_unique<AdsrDisplay> (processor.getAPVTS());
    filterDisplay = std::make_unique<FilterCurveDisplay> (processor.getAPVTS());
    lfoDisplay = std::make_unique<LfoDisplay> (processor.getAPVTS());
    lfoDisplay->onSelect = [this, alive = editorAlive] (int i)
    {   // click LFO 1 / 2 / 3 above: the big editor below now edits that LFO
        lfoShapeTarget = i;
        auto& L = i == 0 ? processor.getLfo1() : (i == 1 ? processor.getLfo2() : processor.getLfo3());
        lfoShapeEditor.setLfo (&L);
        lfoShapeEditor.setTitleIndex (i + 1);
        lfoShapeEditor.syncFromLfo();
    };
    lfoShapeEditor.onEdited = [this]
    {   // the first edit switches that LFO to its Custom wave so you hear your drawing
        const char* ids[3] = { "lfo_wave", "lfo2_wave", "lfo3_wave" };
        if (auto* p = processor.getAPVTS().getParameter (ids[juce::jlimit (0, 2, lfoShapeTarget)]))
            if (p->convertFrom0to1 (p->getValue()) < 4.5f) p->setValueNotifyingHost (p->convertTo0to1 (5.f));
    };
    matrixPanel = std::make_unique<ModMatrixPanel> (processor.getModMatrix());
    speedMonitor = std::make_unique<AudioSpeedMonitor> (processor);
    aboutInfo = std::make_unique<AboutInfoPanel>();
    speedTab.addAndMakeVisible (*speedMonitor);
    aboutTab.addAndMakeVisible (*aboutInfo);

    tabs.addTab ("MAIN", juce::Colours::transparentBlack, &mainTab, false);
    tabs.addTab ("MOD", juce::Colours::transparentBlack, &modTab, false);
    tabs.addTab ("LFO", juce::Colours::transparentBlack, &lfoTab, false);
    tabs.addTab ("FX", juce::Colours::transparentBlack, &fxTab, false);
    tabs.addTab ("MAGIC", juce::Colours::transparentBlack, &magicTab, false);
    
    // SALEK icon pack badges for MAIN / LFO / MOD
    {
        // indices: OSC1,OSC2,OSC3,FILTER1,ENV, LFO,LFO_SYNC,LFO_RND, MATRIX,MACRO,FM,WAVETABLE
        const int idxs[] = { 0, 1, 2, 11, 15, 17, 18, 19, 20, 21, 5, 3 };
        for (int i = 0; i < 12; ++i)
        {
            auto* ic = tabSectionIcons.add (new juce::ImageComponent ("tabIcon" + juce::String (i)));
            auto img = SalekAssets::loadIcon (idxs[i]);
            if (img.isValid())
            {
                ic->setImage (img);
                ic->setImagePlacement (juce::RectanglePlacement::centred);
            }
            ic->setInterceptsMouseClicks (false, false);
            ic->setVisible (false);
            addAndMakeVisible (ic); // reparent to tabs in layout
        }
    }

    tabs.addTab ("SEQ", juce::Colours::transparentBlack, &seqTab, false);
    tabs.addTab ("SPEED", juce::Colours::transparentBlack, &speedTab, false);
    tabs.addTab ("ABOUT", juce::Colours::transparentBlack, &aboutTab, false);
    addAndMakeVisible (tabs);
    tabs.setTabBarDepth (28);
    // Glass UI: transparent so animated theme shows through (no solid pink slab)
    tabs.setOpaque (false);
    tabs.setColour (juce::TabbedComponent::backgroundColourId, juce::Colours::transparentBlack);
    tabs.setColour (juce::TabbedComponent::outlineColourId, SalekLookAndFeel::border().withAlpha (0.62f));
    for (auto* panel : { &mainTab, &modTab, &lfoTab, &magicTab, &seqTab, &speedTab, &aboutTab, &oscTab, &filterTab, &envTab, &presetTab })
    {
        panel->setOpaque (false);
        panel->setColour (juce::ResizableWindow::backgroundColourId, juce::Colours::transparentBlack);
    }
    // FX: solid dark underlay so knobs readable (user: black under FX)
    // Opaque without paint() shows garbage/pink — keep transparent; editor paints dark underlay
    fxTab.setOpaque (false);
    fxTab.setColour (juce::ResizableWindow::backgroundColourId, juce::Colours::transparentBlack);

    {
        mainTab.addAndMakeVisible (oscTab);
        mainTab.addAndMakeVisible (filterTab);
        mainTab.addAndMakeVisible (envTab);
        // presetTab is global left column — parent is editor (not mainTab)
        addAndMakeVisible (presetTab);
        if (filterDisplay != nullptr) filterTab.addAndMakeVisible (*filterDisplay);
        if (adsrDisplay != nullptr) envTab.addAndMakeVisible (*adsrDisplay);

        const auto C = SalekLookAndFeel::teal();
        const auto M = SalekLookAndFeel::rose();
        const auto O = juce::Colour (0xffa8c895);
        const auto V = juce::Colour (0xffc4c887);
        const auto G = juce::Colour (0xffb6a5d7);

        addKnob (oscTab, "osc1_level", "LVL", C); addKnob (oscTab, "osc1_table", "TABLE", M);
        addKnob (oscTab, "osc1_warp", "WARP", O); addKnob (oscTab, "osc1_fold", "FOLD", M);
        addKnob (oscTab, "osc1_drive", "DRIVE", O); addKnob (oscTab, "osc1_octave", "OCT", V); addKnob (oscTab, "osc1_semi", "SEMI", M); addKnob (oscTab, "osc1_coarse", "CRS PITCH", G);
        addKnob (oscTab, "osc1_fine", "FINE", C); addKnob (oscTab, "osc1_detune", "DETUNE", M);
        addKnob (oscTab, "osc2_level", "LVL", C); addKnob (oscTab, "osc2_table", "TABLE", M);
        addKnob (oscTab, "osc2_warp", "WARP", O); addKnob (oscTab, "osc2_fold", "FOLD", M);
        addKnob (oscTab, "osc2_drive", "DRIVE", O); addKnob (oscTab, "osc2_octave", "OCT", V); addKnob (oscTab, "osc2_semi", "SEMI", M); addKnob (oscTab, "osc2_coarse", "CRS PITCH", G);
        addKnob (oscTab, "osc2_fine", "FINE", C); addKnob (oscTab, "osc2_detune", "DETUNE", M);
        addKnob (oscTab, "osc3_level", "LVL", C); addKnob (oscTab, "osc3_table", "TABLE", M);
        addKnob (oscTab, "osc3_warp", "WARP", O); addKnob (oscTab, "osc3_fold", "FOLD", M);
        addKnob (oscTab, "osc3_drive", "DRIVE", O); addKnob (oscTab, "osc3_octave", "OCT", V); addKnob (oscTab, "osc3_semi", "SEMI", M); addKnob (oscTab, "osc3_coarse", "CRS PITCH", G);
        addKnob (oscTab, "osc3_fine", "FINE", C); addKnob (oscTab, "osc3_detune", "DETUNE", M);
        // Per-osc unison row (each column gets its own UNI / DET / SPR)
        addKnob (oscTab, "osc1_unison", "UNI", C);
        addKnob (oscTab, "osc1_udet", "DET", M);
        addKnob (oscTab, "osc1_uspread", "SPR", O);
        addKnob (oscTab, "osc2_unison", "UNI", C);
        addKnob (oscTab, "osc2_udet", "DET", M);
        addKnob (oscTab, "osc2_uspread", "SPR", O);
        addKnob (oscTab, "osc3_unison", "UNI", C);
        addKnob (oscTab, "osc3_udet", "DET", M);
        addKnob (oscTab, "osc3_uspread", "SPR", O);
        // Phase + random phase (prevents locked static note phase)
        addKnob (oscTab, "osc1_phase", "PHASE", C); addKnob (oscTab, "osc1_rand", "RAND", M); addKnob (oscTab, "osc1_pan", "PAN", O);
        addKnob (oscTab, "osc2_phase", "PHASE", C); addKnob (oscTab, "osc2_rand", "RAND", M); addKnob (oscTab, "osc2_pan", "PAN", O);
        addKnob (oscTab, "osc3_phase", "PHASE", C); addKnob (oscTab, "osc3_rand", "RAND", M); addKnob (oscTab, "osc3_pan", "PAN", O);

        #include "PluginEditorOscMonitors.inl"

        addKnob (filterTab, "filter_cutoff", "CUTOFF", C);
        addKnob (filterTab, "filter_reso", "RESO", M);
        addKnob (filterTab, "filter_drive", "F DRIVE", O);
        addKnob (filterTab, "filter_env", "F ENV", G);
        // 16-mode filter bank
        addCombo (filterTab, filterMode, "filter_mode", {
            "LP12","LP24","HP12","HP24","BP","Notch","Peak","AllPass",
            "AcidLP","Ladder","Comb","Formant","BandRej","LoShelf","HiShelf","PhaserN",
            "DiodeLP","Sallen","Vocal","RingMod","BP-Q","LP+HP","Notch2","Wide"
        });
        filterMode.setColour (juce::ComboBox::backgroundColourId, SalekLookAndFeel::panel());
        filterMode.setColour (juce::ComboBox::outlineColourId, SalekLookAndFeel::border());
        filterMode.setColour (juce::ComboBox::textColourId, SalekLookAndFeel::teal());
        addCombo (filterTab, filterRouteBox, "filter_route", {
            "All","OSC1","OSC2","OSC3","1+2","1+3","2+3"
        });
        filterRouteBox.setColour (juce::ComboBox::backgroundColourId, SalekLookAndFeel::panel());
        filterRouteBox.setColour (juce::ComboBox::outlineColourId, SalekLookAndFeel::border());
        filterRouteBox.setColour (juce::ComboBox::textColourId, SalekLookAndFeel::rose());
        addCombo (envTab, voiceModeBox, "voice_mode", { "Poly", "Mono", "Legato" });
        voiceModeBox.setColour (juce::ComboBox::backgroundColourId, SalekLookAndFeel::panel());
        voiceModeBox.setColour (juce::ComboBox::outlineColourId, SalekLookAndFeel::border());
        voiceModeBox.setColour (juce::ComboBox::textColourId, SalekLookAndFeel::teal());

        addKnob (envTab, "amp_attack", "ATTACK", C);
        addKnob (envTab, "amp_decay", "DECAY", M);
        addKnob (envTab, "amp_sustain", "SUSTAIN", O);
        addKnob (envTab, "amp_release", "RELEASE", G);

        presetList.setModel (this);
        presetList.setRowHeight (30);
        presetList.setOpaque (false);
        presetTab.setOpaque (false);
        presetList.setColour (juce::ListBox::backgroundColourId, juce::Colour (0xff0a0e17));
        presetList.setColour (juce::ListBox::outlineColourId, SalekLookAndFeel::teal().withAlpha (0.50f));
        presetSearchBox.setMultiLine (false);
        presetSearchBox.setReturnKeyStartsNewLine (false);
        presetSearchBox.setTextToShowWhenEmpty ("SEARCH 001 / NEY / DEEP", juce::Colour (0xff8477a8));
        presetSearchBox.setColour (juce::TextEditor::backgroundColourId, juce::Colour (0xff0a1018));
        presetSearchBox.setColour (juce::TextEditor::textColourId, SalekLookAndFeel::text());
        presetSearchBox.setColour (juce::TextEditor::highlightColourId, SalekLookAndFeel::teal().withAlpha (0.32f));
        presetSearchBox.setColour (juce::TextEditor::outlineColourId, SalekLookAndFeel::teal().withAlpha (0.58f));
        presetSearchBox.setFont (juce::FontOptions (10.5f));
        presetSearchBox.setTooltip ("Search GITI number, name, branch, voice, mood, or preset variation");
        presetSearchBox.onTextChange = [this] { rebuildPresetRows(); };

        presetFilterBox.clear (juce::dontSendNotification);
        presetFilterBox.addItem ("ALL", 1);
        presetFilterBox.addItem ("GITI", 2);
        juce::StringArray filterCategories;
        for (int i = 0; i < processor.getNumPrograms(); ++i)
        {
            const auto category = getPresetCategory (processor.getProgramName (i));
            if (category != "GITI" && ! filterCategories.contains (category, false))
                filterCategories.add (category);
        }
        int filterId = 3;
        for (auto& category : filterCategories)
            presetFilterBox.addItem (category.toUpperCase(), filterId++);
        presetFilterBox.setSelectedId (2, juce::dontSendNotification);
        presetFilterBox.setColour (juce::ComboBox::backgroundColourId, juce::Colour (0xff101821));
        presetFilterBox.setColour (juce::ComboBox::outlineColourId, SalekLookAndFeel::rose().withAlpha (0.66f));
        presetFilterBox.setColour (juce::ComboBox::textColourId, SalekLookAndFeel::champagne());
        presetFilterBox.setTooltip ("Filter the browser by sound bank");
        presetFilterBox.onChange = [this] { rebuildPresetRows(); };

        presetTab.addAndMakeVisible (presetList);
        presetTab.addAndMakeVisible (presetSearchBox);
        presetTab.addAndMakeVisible (presetFilterBox);
        presetTab.addAndMakeVisible (prevPreset);
        presetTab.addAndMakeVisible (nextPreset);
        presetTab.addAndMakeVisible (initBtn);
        presetTab.addAndMakeVisible (savePresetBtn);
        presetTab.addAndMakeVisible (loadPresetBtn);
        presetTab.addAndMakeVisible (bankBtn);
        presetTab.addAndMakeVisible (presetLabel);
        presetLabel.setFont (juce::FontOptions (11.0f));
        presetLabel.setColour (juce::Label::textColourId, juce::Colour (0xff00e8ff));
        savePresetBtn.setColour (juce::TextButton::buttonColourId, juce::Colour (0xff2a1050));
        savePresetBtn.setColour (juce::TextButton::textColourOffId, juce::Colour (0xffffd700));
        loadPresetBtn.setColour (juce::TextButton::buttonColourId, juce::Colour (0xff0a3050));
        loadPresetBtn.setColour (juce::TextButton::textColourOffId, juce::Colour (0xff00e8ff));
        bankBtn.setColour (juce::TextButton::buttonColourId, juce::Colour (0xff201040));
        bankBtn.setColour (juce::TextButton::textColourOffId, juce::Colour (0xffffaa00));
        prevPreset.onClick = [this] {
            int i = processor.getCurrentProgram();
            if (i > 0) processor.setCurrentProgram (i - 1);
            presetLabel.setText (processor.getProgramName (processor.getCurrentProgram()), juce::dontSendNotification);
            presetLabel.setTooltip (processor.getProgramDescription (processor.getCurrentProgram()));
            presetList.updateContent();
            presetList.repaint();
        };
        nextPreset.onClick = [this] {
            int i = processor.getCurrentProgram();
            if (i + 1 < processor.getNumPrograms()) processor.setCurrentProgram (i + 1);
            presetLabel.setText (processor.getProgramName (processor.getCurrentProgram()), juce::dontSendNotification);
            presetLabel.setTooltip (processor.getProgramDescription (processor.getCurrentProgram()));
            presetList.updateContent();
            presetList.repaint();
        };
        initBtn.onClick = [this] {
            processor.setCurrentProgram (0);
            presetLabel.setText (processor.getProgramName (0), juce::dontSendNotification);
            presetLabel.setTooltip (processor.getProgramDescription (0));
            presetList.updateContent();
            presetList.repaint();
        };
        #include "PluginEditorPresetIO.inl"
        rebuildPresetRows();
        presetLabel.setText (processor.getProgramName (processor.getCurrentProgram()), juce::dontSendNotification);
        presetLabel.setTooltip (processor.getProgramDescription (processor.getCurrentProgram()));
    }

    {
        if (matrixPanel != nullptr) modTab.addAndMakeVisible (*matrixPanel);
        const auto C = SalekLookAndFeel::teal();
        const auto M = SalekLookAndFeel::rose();
        const auto O = juce::Colour (0xffa8c895);
        const auto V = juce::Colour (0xffc4c887);
        const auto G = juce::Colour (0xffb6a5d7);
        #include "PluginEditorModKnobs.inl"
    }

    {
        #include "PluginEditorLfoSetup.inl"
    }

    {
        const auto C = SalekLookAndFeel::teal();
        const auto M = SalekLookAndFeel::rose();
        const auto O = juce::Colour (0xffa8c895);
        const auto V = juce::Colour (0xffc4c887);
        const auto G = juce::Colour (0xffb6a5d7);
        #include "PluginEditorFxSections.inl"
    }

    {
        #include "PluginEditorMagic.inl"

    // SEQ → Magic trigger row (2x7): fire magic modes from sequencer page
    {
        static const char* names[14] = {
            "VOID","STAB","WARP","SLICE","DRONE","ACID","GLASS",
            "CRASH","ECHO","PSY","LOOP","NOISE","ALIEN","TORO"
        };
        for (int i = 0; i < 14; ++i)
        {
            if (i == 7 || i == 11 || i == 13) continue;   // CRASH, NOISE, TORO removed
            auto* b = seqMagicBtns.add (new juce::TextButton (names[i]));
            b->setColour (juce::TextButton::buttonColourId, SalekLookAndFeel::panel());
            b->setColour (juce::TextButton::textColourOffId, SalekLookAndFeel::teal());
            seqTab.addAndMakeVisible (b);
            b->onClick = [this, i]
            {
                // Mirror Magic combo behaviour
                const int modes[14] = { 4,0,3,5,0,6,2,7,2,3,0,8,3,1 };
                const float xs[14]  = { 0.85f,0.3f,0.7f,0.95f,0.2f,0.6f,0.4f,0.9f,0.55f,0.75f,0.35f,0.8f,0.65f,0.88f };
                const float ys[14]  = { 0.9f,0.5f,0.8f,0.7f,0.4f,0.85f,0.6f,0.95f,0.55f,0.9f,0.45f,0.75f,0.85f,0.92f };
                if (auto* pa = processor.getAPVTS().getParameter ("magic_on"))
                { pa->beginChangeGesture(); pa->setValueNotifyingHost (1.f); pa->endChangeGesture(); }
                if (auto* pm = dynamic_cast<juce::AudioParameterChoice*> (processor.getAPVTS().getParameter ("magic_mode")))
                { pm->beginChangeGesture(); pm->setValueNotifyingHost (pm->convertTo0to1 ((float) modes[i])); pm->endChangeGesture(); }
                auto setF = [this] (const char* id, float v) {
                    if (auto* p = processor.getAPVTS().getParameter (id)) {
                        p->beginChangeGesture();
                        p->setValueNotifyingHost (p->convertTo0to1 (v));
                        p->endChangeGesture();
                    }
                };
                setF ("magic_x", xs[i]); setF ("magic_y", ys[i]);
                processor.getMagic().setMode (modes[i]);
                processor.getMagic().setXY (xs[i], ys[i]);
                processor.getMagic().setActive (true);
            };
        }
        // Magic OFF + latch row helpers
        seqMagicOff.setButtonText ("MAGIC OFF");
        seqMagicOff.setColour (juce::TextButton::buttonColourId, SalekLookAndFeel::panel());
        seqMagicOff.setColour (juce::TextButton::textColourOffId, SalekLookAndFeel::rose());
        seqTab.addAndMakeVisible (seqMagicOff);
        seqMagicOff.onClick = [this] {
            if (auto* pt = processor.getAPVTS().getParameter ("seq_magic_target"))
            { pt->beginChangeGesture(); pt->setValueNotifyingHost (pt->convertTo0to1 (0.f)); pt->endChangeGesture(); }
            if (auto* pa = processor.getAPVTS().getParameter ("magic_on"))
            { pa->beginChangeGesture(); pa->setValueNotifyingHost (0.f); pa->endChangeGesture(); }
            processor.getMagic().setActive (false);
        };
    }

    // Explicit X/Y knobs (also LFO-modulatable)
    {
        const auto C = SalekLookAndFeel::teal();
        const auto M = SalekLookAndFeel::rose();
        addKnob (magicTab, "magic_x", "MAGIC X", C);
        addKnob (magicTab, "magic_y", "MAGIC Y", M);
    }

    }

    {
        seqTab.addAndMakeVisible (arpOn);
        seqTab.addAndMakeVisible (seqOn);
        arpOn.setButtonText ("ARP");
        seqOn.setButtonText ("SEQ");
        arpOn.setColour (juce::ToggleButton::textColourId, SalekLookAndFeel::text());
        arpOn.setColour (juce::ToggleButton::tickColourId, SalekLookAndFeel::teal());
        seqOn.setColour (juce::ToggleButton::textColourId, SalekLookAndFeel::text());
        seqOn.setColour (juce::ToggleButton::tickColourId, SalekLookAndFeel::rose());
        btnAtts.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (processor.getAPVTS(), "arp_on", arpOn));
        btnAtts.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (processor.getAPVTS(), "seq_on", seqOn));
        stepGrid = std::make_unique<StepGridComponent> (processor.getStepSequencer());
        btnAtts.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (processor.getAPVTS(), "seq_play", stepGrid->playBtn));
        btnAtts.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (processor.getAPVTS(), "seq_sync", stepGrid->syncBtn));
        seqTab.addAndMakeVisible (*stepGrid);
        const auto C = SalekLookAndFeel::teal();
        const auto M = SalekLookAndFeel::rose();
        const auto O = juce::Colour (0xffa8c895);
        const auto G = juce::Colour (0xffb6a5d7);
        addKnob (seqTab, "arp_rate", "ARP RATE", O);
        addKnob (seqTab, "arp_octaves", "ARP OCT", C);
        addKnob (seqTab, "arp_gate", "ARP GATE", M);
        addKnob (seqTab, "arp_swing", "ARP SWING", G);
        addKnob (seqTab, "seq_rate", "SEQ RATE", O);
        addKnob (seqTab, "seq_length", "SEQ STEPS", C);
        addKnob (seqTab, "seq_swing", "SEQ SWING", M);
        addKnob (seqTab, "seq_gate", "SEQ GATE", O);
        addKnob (seqTab, "seq_magic_depth", "XY DEPTH", C);
        addCombo (seqTab, seqMagicTargetBox, "seq_magic_target", { "Off", "X", "Y", "X+Y" });
        // Extra voice colour — registered last so indices of FX/MOD stay stable
        addKnob (envTab, "glide", "GLIDE", C);
        addKnob (envTab, "poly_voices", "VOICES", M);
        addKnob (envTab, "noise_level", "NOISE", O);
        addKnob (envTab, "sub_level", "SUB", G);
        for (auto n : { "White", "Pink", "Brown", "Crackle", "Hi-Hat", "Kick", "Snare" }) noiseTypeBox.addItem (n, noiseTypeBox.getNumItems() + 1);
        oscTab.addAndMakeVisible (noiseTypeBox);
        {
            static const char* wn[6] = { "SIN", "TRI", "SQR", "SAW", "BSAW", "PLS" };
            static const int wt[6]   = { 0, 1, 2, 3, 4, 24 };     // wavetable frames: Sine, Triangle, Square, Saw, Bright Saw, Pulse
            static const char* tid[3] = { "osc1_table", "osc2_table", "osc3_table" };
            for (int c = 0; c < 3; ++c)
                for (int i = 0; i < 6; ++i)
                {
                    auto& b = waveQuick[c][i];
                    b.setButtonText (wn[i]);
                    b.setTooltip (juce::String ("Set this oscillator to a pure ") + wn[i] + " wave");
                    b.setColour (juce::TextButton::buttonColourId, juce::Colour (0xff10162e));
                    b.setColour (juce::TextButton::buttonOnColourId, juce::Colour (0xff1b7f8a));
                    b.setColour (juce::TextButton::textColourOffId, juce::Colour (0xff9fd8dc));
                    b.setColour (juce::TextButton::textColourOnId, juce::Colours::white);
                    b.onClick = [this, c, i]
                    {
                        if (auto* p = processor.getAPVTS().getParameter (tid[c]))
                        {
                            p->beginChangeGesture();
                            p->setValueNotifyingHost (p->convertTo0to1 ((float) wt[i] / 127.0f));
                            p->endChangeGesture();
                        }
                    };
                    oscTab.addAndMakeVisible (b);
                }
        }
        {
            const char* onIds[5] = { "osc1_on", "osc2_on", "osc3_on", "noise_on", "sub_on" };
            for (int i = 0; i < 5; ++i)
            {
                auto& b = onBtn[i];
                b.setButtonText ("ON");
                b.setClickingTogglesState (true);
                b.setTooltip ("Power: switch this source on / off");
                b.setColour (juce::TextButton::buttonColourId, juce::Colour (0xff2a1020));
                b.setColour (juce::TextButton::buttonOnColourId, juce::Colour (0xff1fa85a));
                b.setColour (juce::TextButton::textColourOffId, juce::Colour (0xffb06070));
                b.setColour (juce::TextButton::textColourOnId, juce::Colours::white);
                oscTab.addAndMakeVisible (b);
                btnAtts.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (processor.getAPVTS(), onIds[i], b));
            }
        }
        comboAtts.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (processor.getAPVTS(), "noise_type", noiseTypeBox));
        addKnob (envTab, "noise_tone", "TONE", C); addKnob (envTab, "noise_pan", "PAN", M);
        addKnob (envTab, "sub_octave", "OCT", O); addKnob (envTab, "sub_semi", "SEMI", M); addKnob (envTab, "sub_pan", "PAN", M);
    }

    themeBox.addItem ("PERSIAN", 1);
    themeBox.addItem ("ACID", 2);
    themeBox.addItem ("NEON", 3);
    themeBox.addItem ("PATINA", 4);
    themeBox.setSelectedId (1); // default PERSIAN
    themeBox.setColour (juce::ComboBox::backgroundColourId, SalekLookAndFeel::panel());
    themeBox.setColour (juce::ComboBox::outlineColourId, SalekLookAndFeel::border());
    themeBox.setColour (juce::ComboBox::textColourId, SalekLookAndFeel::text());
    themeBox.setColour (juce::ComboBox::arrowColourId, SalekLookAndFeel::teal());
    themeBox.onChange = [this] { applyHeroFromTheme(); repaint(); };
    addAndMakeVisible (themeBox);
    bgSwapBtn.setColour (juce::TextButton::buttonColourId, SalekLookAndFeel::panel());
    bgSwapBtn.setColour (juce::TextButton::textColourOffId, SalekLookAndFeel::champagne());
    bgSwapBtn.setTooltip ("Swap background (ISATIS man+cat / SALEK 2 girls)");
    bgSwapBtn.onClick = [this]
    {
        bgIndex = (bgIndex + 1) % ((int) bgImages.size() + 8);   // pictures, solids, gradients, particles, light
        applyHeroFromTheme();
        repaint();
    };
    addAndMakeVisible (bgSwapBtn);

    charCycleBtn.setColour (juce::TextButton::buttonColourId, SalekLookAndFeel::panel());
    charCycleBtn.setColour (juce::TextButton::textColourOffId, SalekLookAndFeel::rose());
    charCycleBtn.setButtonText ("MODEL");
    charCycleBtn.setTooltip ("Change character model (left panel) — does NOT change background");
    charCycleBtn.onClick = [this]
    {
        charPortraitIdx = (charPortraitIdx + 1) % 8;
        refreshCharCache();
        repaint();
    };
    addAndMakeVisible (charCycleBtn);
    sizeBtn.setColour (juce::TextButton::buttonColourId, SalekLookAndFeel::panel());
    sizeBtn.setColour (juce::TextButton::textColourOffId, SalekLookAndFeel::teal());
    sizeBtn.setTooltip ("Window size");
    sizeBtn.onClick = [this]
    {
        juce::PopupMenu m;
        static const int pct[] = { 150, 125, 100, 75, 50, 35 };
        for (int p : pct) m.addItem (p, juce::String (p) + "%", true, p == uiScalePct);
        m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&sizeBtn), [this, alive = editorAlive] (int r)
        {
            if (! *alive) return;
            if (r <= 0) return;
            uiScalePct = r;
            sizeBtn.setButtonText (juce::String (r) + "%");
            setScaleFactor ((float) r / 100.0f);
        });
    };
    addAndMakeVisible (sizeBtn);

    // Collapse PRESET list only (hero stays visible)
    presetToggle.setButtonText (juce::CharPointer_UTF8 ("â")); // ◀
    presetToggle.setClickingTogglesState (true);
    presetToggle.setColour (juce::TextButton::buttonColourId, juce::Colour (0xff1a0a2e));
    presetToggle.setColour (juce::TextButton::buttonOnColourId, juce::Colour (0xff3a1060));
    presetToggle.setColour (juce::TextButton::textColourOffId, juce::Colour (0xff00e8ff));
    presetToggle.setColour (juce::TextButton::textColourOnId, juce::Colour (0xffffd700));
    presetToggle.setTooltip ("Collapse / expand presets");
    presetToggle.onClick = [this]
    {
        presetCollapsed = presetToggle.getToggleState();
        presetToggle.setButtonText (presetCollapsed
            ? juce::CharPointer_UTF8 ("â¶")   // ▶
            : juce::CharPointer_UTF8 ("â")); // ◀
        resized();
        repaint();
    };
    presetToggle.setComponentID ("giti_img_toggle");   // octagon crystal open/close button
    presetTab.addAndMakeVisible (presetToggle); // must be child of presetTab for correct coords

    // Knob <-> Fader switch for the tall filter column (lots of free width there)
    filterStyleBtn.setTooltip ("Switch the filter controls between knobs and faders");
    filterStyleBtn.setColour (juce::TextButton::buttonColourId, SalekLookAndFeel::panel());
    filterStyleBtn.setColour (juce::TextButton::textColourOffId, SalekLookAndFeel::champagne());
    filterStyleBtn.onClick = [this]
    {
        filterFader = ! filterFader;
        filterStyleBtn.setButtonText (filterFader ? "KNOBS" : "FADERS");
        for (auto& k : knobs)
            if (k != nullptr && (k->paramId == "filter_cutoff" || k->paramId == "filter_reso"
                                 || k->paramId == "filter_drive" || k->paramId == "filter_env"
                                 || k->paramId == "filter2_cutoff" || k->paramId == "filter2_reso"
                                 || k->paramId == "filter2_drive" || k->paramId == "filter2_env"))
                k->s.setSliderStyle (filterFader ? juce::Slider::LinearHorizontal
                                                 : juce::Slider::RotaryHorizontalVerticalDrag);
        resized();
        repaint();
    };
    filterTab.addAndMakeVisible (filterStyleBtn);

    // ---- frame tab switches: OSC 2 | OSC 3,  NOISE | SUB,  FILTER 1 | FILTER 2 ----
    {
        auto styleSw = [] (juce::TextButton& bt, const juce::String& text, juce::Colour c, int group, bool on)
        {
            bt.setButtonText (text);
            bt.setClickingTogglesState (true);
            bt.setRadioGroupId (group);
            bt.setToggleState (on, juce::dontSendNotification);
            bt.setColour (juce::TextButton::buttonColourId, SalekLookAndFeel::panel());
            bt.setColour (juce::TextButton::buttonOnColourId, c.withAlpha (0.55f));
            bt.setColour (juce::TextButton::textColourOffId, c);
            bt.setColour (juce::TextButton::textColourOnId, juce::Colours::white);
        };
        styleSw (oscSelBtn[0], "OSC 2", giti::secondaryColour(), 7421, true);
        styleSw (oscSelBtn[1], "OSC 3", giti::accentColour(),    7421, false);
        oscSelBtn[0].onClick = [this] { sel23 = 0; resized(); repaint(); };
        oscSelBtn[1].onClick = [this] { sel23 = 1; resized(); repaint(); };
        oscTab.addAndMakeVisible (oscSelBtn[0]);  oscTab.addAndMakeVisible (oscSelBtn[1]);
        styleSw (nsSelBtn[0], "NOISE", giti::primaryColour(),   7422, true);
        styleSw (nsSelBtn[1], "SUB",   giti::tertiaryColour(),  7422, false);
        nsSelBtn[0].onClick = [this] { selNS = 0; resized(); repaint(); };
        nsSelBtn[1].onClick = [this] { selNS = 1; resized(); repaint(); };
        oscTab.addAndMakeVisible (nsSelBtn[0]);  oscTab.addAndMakeVisible (nsSelBtn[1]);
        for (int i = 0; i < 2; ++i)
        {
            advBtn[i].setButtonText ("- LESS");
            advBtn[i].setColour (juce::TextButton::buttonColourId, SalekLookAndFeel::panel());
            advBtn[i].setColour (juce::TextButton::textColourOffId, SalekLookAndFeel::champagne());
            advBtn[i].setTooltip ("Show / hide pitch + unison + phase controls");
            advBtn[i].onClick = [this, i]
            {
                advOpen[i] = ! advOpen[i];
                advBtn[i].setButtonText (advOpen[i] ? "- LESS" : "+ MORE");
                resized(); repaint();
            };
            oscTab.addAndMakeVisible (advBtn[i]);
        }
        styleSw (filterTabBtn[0], "FILTER 1", giti::primaryColour(),   7423, true);
        styleSw (filterTabBtn[1], "FILTER 2", giti::secondaryColour(), 7423, false);
        filterTabBtn[0].onClick = [this] { filterSel = 0; if (filterDisplay) filterDisplay->setFilterIndex (0); syncFilterLamps(); resized(); repaint(); };
        filterTabBtn[1].onClick = [this] { filterSel = 1; if (filterDisplay) filterDisplay->setFilterIndex (1); syncFilterLamps(); resized(); repaint(); };
        filterTab.addAndMakeVisible (filterTabBtn[0]);  filterTab.addAndMakeVisible (filterTabBtn[1]);

        const char* ledNames[5] = { "OSC 1", "OSC 2", "OSC 3", "NOISE", "SUB" };
        const juce::Colour ledCols[5] = { giti::primaryColour(), giti::secondaryColour(), giti::accentColour(),
                                          juce::Colour (0xff35f0d0), giti::tertiaryColour().brighter (0.3f) };
        for (int i = 0; i < 5; ++i)
        {
            auto& led = filterLed[i];
            led.setComponentID ("giti_led");
            led.setButtonText (ledNames[i]);
            led.getProperties().set ("led_col", (juce::int64) ledCols[i].getARGB());
            led.setClickingTogglesState (false);
            led.setTooltip ("Apply the selected filter to this source");
            led.onClick = [this, i]
            {
                const char* pid = filterSel == 0 ? "filter1_src" : "filter2_src";
                auto& apvts = processor.getAPVTS();
                if (auto* par = apvts.getParameter (pid))
                    if (auto* raw = apvts.getRawParameterValue (pid))
                    {
                        int mask = (int) std::lround (raw->load());
                        mask ^= (1 << i);
                        par->beginChangeGesture();
                        par->setValueNotifyingHost (par->convertTo0to1 ((float) mask));
                        par->endChangeGesture();
                    }
                syncFilterLamps();
            };
            filterTab.addAndMakeVisible (led);
        }
        addCombo (filterTab, filter2Mode, "filter2_mode", {
            "LP12","LP24","HP12","HP24","BP","Notch","Peak","AllPass",
            "AcidLP","Ladder","Comb","Formant","BandRej","LoShelf","HiShelf","PhaserN",
            "DiodeLP","Sallen","Vocal","RingMod","BP-Q","LP+HP","Notch2","Wide" });
        filter2Mode.setColour (juce::ComboBox::textColourId, SalekLookAndFeel::rose());
        addKnob (filterTab, "filter2_cutoff", "CUTOFF", SalekLookAndFeel::rose());
        addKnob (filterTab, "filter2_reso",   "RESO",   SalekLookAndFeel::purple());
        addKnob (filterTab, "filter2_drive",  "F DRIVE", SalekLookAndFeel::champagne());
        addKnob (filterTab, "filter2_env",    "F ENV",  SalekLookAndFeel::teal());
        addKnob (filterTab, "filter1_mix",    "MIX",    SalekLookAndFeel::champagne());
        addKnob (filterTab, "filter2_mix",    "MIX",    SalekLookAndFeel::champagne());
        filterRouteBox.setVisible (false);    // legacy route box replaced by the source lamps
    }
    addAndMakeVisible (visualizer);          // visualizer now lives top-right (header)
    fxTab.addAndMakeVisible (fxAmbient);     fxAmbient.toBack();
    aboutTab.addAndMakeVisible (aboutAmbient); aboutAmbient.toBack();

    // hover tracking for the preset browser rows
    presetHoverListener.list = &presetList;
    presetHoverListener.row  = &presetHoverRow;
    presetList.addMouseListener (&presetHoverListener, true);

    // Bilingual UI: EN (default) <-> FA
    langToggle.setButtonText ("EN");
    langToggle.setColour (juce::TextButton::buttonColourId, juce::Colour (0xff12081c));
    langToggle.setColour (juce::TextButton::textColourOffId, juce::Colour (0xffffd700));
    langToggle.setTooltip ("UI language EN / FA");
    langToggle.onClick = [this]
    {
        uiLangFa = ! uiLangFa;
        langToggle.setButtonText (uiLangFa ? "FA" : "EN");
        applyUiLanguage();
    };
    addAndMakeVisible (langToggle);

    applyHeroFromTheme();
    applyUiLanguage();
    rebuildPresetRows();
    // Start with categories folded — click [+] to expand (Serum/Vital style browser)
    {
        juce::StringArray cats;
        const int n = processor.getNumPrograms();
        for (int i = 0; i < n; ++i)
        {
            auto name = processor.getProgramName (i);
            auto cat = getPresetCategory (name);
            if (cat == "GITI") continue; // open the 50 identity voices on first launch
            if (! cats.contains (cat)) cats.add (cat);
        }
        collapsedCats = cats;
        rebuildPresetRows();
    }

    // Set the initial size only after every child used by resized() exists.
    // Component::setSize may synchronously call resized(); doing this earlier
    // dereferenced the not-yet-created speed monitor and About panel.
    setResizable (true, true);
    setResizeLimits (1020, 700, 1700, 1100);
    setSize (1280, 820);
}

SalekHightechAudioProcessorEditor::~SalekHightechAudioProcessorEditor()
{
    *editorAlive = false;
    // release the parameter attachments BEFORE the controls they point to (member destruction order is not safe)
    btnAtts.clear();
    comboAtts.clear();
    stepGrid.reset();
    lfoDisplay.reset();
    knobs.clear();
    setLookAndFeel (nullptr);
}

SalekHightechAudioProcessorEditor::Knob& SalekHightechAudioProcessorEditor::addKnob (
    juce::Component& parent, const char* id, const char* label, juce::Colour c)
{
    auto k = std::make_unique<Knob>();
    k->paramId = id;
    k->s.getProperties().set ("pid", juce::String (id));
    k->s.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    k->s.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 52, 14);
    k->s.setNumDecimalPlacesToDisplay (1);   // short numbers (fixes "هزار رقمی")
    const auto knobAccent = c.withMultipliedSaturation (1.28f).brighter (0.08f);
    k->s.setColour (juce::Slider::rotarySliderFillColourId, knobAccent);
    k->s.setColour (juce::Slider::rotarySliderOutlineColourId, SalekLookAndFeel::border());
    k->s.setColour (juce::Slider::textBoxTextColourId, SalekLookAndFeel::text());
    k->s.setColour (juce::Slider::textBoxBackgroundColourId, SalekLookAndFeel::panel());
    k->s.setColour (juce::Slider::textBoxOutlineColourId, SalekLookAndFeel::border());
    k->s.setColour (juce::Slider::textBoxHighlightColourId, knobAccent.withAlpha (0.45f));
    k->s.setScrollWheelEnabled (true);
    k->s.setMouseDragSensitivity (180);
    // Cleaner value text: max 2 decimals, integers without .00
    k->s.textFromValueFunction = [] (double v) {
        if (std::abs (v) >= 1000.0) return juce::String ((int) std::round (v));
        if (std::abs (v - std::round (v)) < 1e-4) return juce::String ((int) std::round (v));
        if (std::abs (v) >= 100.0) return juce::String (v, 0);
        if (std::abs (v) >= 10.0) return juce::String (v, 1);
        return juce::String (v, 2);
    };
    parent.addAndMakeVisible (k->s);
    atts.push_back (std::make_unique<SAtt> (processor.getAPVTS(), id, k->s));
    k->name.setText (label, juce::dontSendNotification);
    k->name.setJustificationType (juce::Justification::centred);
    k->name.setFont (juce::FontOptions (9.5f, juce::Font::bold));
    k->name.setColour (juce::Label::textColourId, SalekLookAndFeel::mutedText());
    parent.addAndMakeVisible (k->name);

    // Vital-style: arm LFO1/2/3 then click knob name to assign
    struct ModHook : public juce::MouseListener
    {
        SalekHightechAudioProcessorEditor* ed = nullptr;
        juce::String pid;
        void mouseDown (const juce::MouseEvent& e) override
        {
            if (ed == nullptr) return;
            if (e.mods.isPopupMenu() && ed->armedModSource < 0) { ed->showModMenu (pid); return; }   // right-click: remove modulation
            if (ed->armedModSource < 0) return;
            float amt = 0.5f;
            if (e.mods.isShiftDown()) amt = 1.0f;
            if (e.mods.isAltDown())   amt = -0.5f;
            if (e.mods.isCommandDown() || e.mods.isCtrlDown()) amt = 0.25f;
            if (e.mods.isRightButtonDown()) amt = 0.f;
            ed->assignModToParam (pid, amt);
        }
        void mouseUp (const juce::MouseEvent& e) override
        {
            // (armed mode: a simple click assigns; turning the knob must NOT assign by accident)
            juce::ignoreUnused (e);
        }
    };
    auto hook = std::make_unique<ModHook>();
    hook->ed = this;
    hook->pid = id;
    k->name.addMouseListener (hook.get(), false);
    k->s.addMouseListener (hook.get(), false);
    modHookListeners.push_back (std::move (hook));

    // Real DragAndDropTarget over the knob (Serum/Vital style drop zone)
    {
        auto dt = std::make_unique<KnobDropTarget>();
        dt->ed = this;
        dt->paramId = id;
        dt->setInterceptsMouseClicks (true, false);
        parent.addAndMakeVisible (*dt);
        dt->toFront (false); // above slider; hitTest false unless dragging
        knobDropTargets.push_back (std::move (dt));
    }

    knobs.push_back (std::move (k));
    return *knobs.back();
}

bool SalekHightechAudioProcessorEditor::resolveModDest (const juce::String& id, salek::ModMatrix::Dest& dest)
{
    using D = salek::ModMatrix::Dest;
    if (salek::paramIdToDest (id, dest)) return true;
    else if (id == "filter_cutoff") dest = D::FilterCutoff;
    else if (id == "filter_reso" || id == "filter_res") dest = D::FilterReso;
    else if (id == "filter_env") dest = D::FilterEnv;
    else if (id == "osc1_level") dest = D::Osc1Level;
    else if (id == "osc2_level") dest = D::Osc2Level;
    else if (id == "osc3_level") dest = D::Osc3Level;
    else if (id == "osc1_table" || id == "osc1_wtpos") dest = D::Osc1Table;
    else if (id == "osc2_table" || id == "osc2_wtpos") dest = D::Osc2Table;
    else if (id == "osc3_table" || id == "osc3_wtpos") dest = D::Osc3Table;
    else if (id == "osc1_warp") dest = D::Osc1Warp;
    else if (id == "osc2_warp") dest = D::Osc2Warp;
    else if (id == "osc3_warp") dest = D::Osc3Warp;
    else if (id == "osc1_fold") dest = D::Osc1Fold;
    else if (id == "osc2_fold") dest = D::Osc2Fold;
    else if (id == "osc3_fold") dest = D::Osc3Fold;
    else if (id == "osc1_pan") dest = D::Osc1Pan;
    else if (id == "osc2_pan") dest = D::Osc2Pan;
    else if (id == "osc3_pan") dest = D::Osc3Pan;
    else if (id == "osc1_drive") dest = D::Osc1Drive;
    else if (id == "osc2_drive") dest = D::Osc2Drive;
    else if (id == "osc3_drive") dest = D::Osc3Drive;
    else if (id == "fm_2to1" || id == "osc1_fm") dest = D::Fm2to1;
    else if (id == "fm_3to1") dest = D::Fm3to1;
    else if (id == "delay_mix") dest = D::DelayMix;
    else if (id == "reverb_mix") dest = D::ReverbMix;
    else if (id == "dist_drive") dest = D::DistDrive;
    else if (id == "dist_mix") dest = D::DistMix;
    else if (id == "chorus_mix") dest = D::ChorusMix;
    else if (id == "phaser_mix") dest = D::PhaserMix;
    else if (id == "bassify") dest = D::Bassify;
    else if (id == "magic_x") dest = D::MagicX;
    else if (id == "magic_y") dest = D::MagicY;
    else if (id == "master_gain" || id == "amp_level") dest = D::Amp;
    else if (id == "osc1_fine" || id == "osc2_fine" || id == "osc3_fine"
        || id == "osc1_detune" || id == "osc2_detune" || id == "osc3_detune") dest = D::Pitch;
    else if (id == "noise_level") dest = D::NoiseLevel;
    else if (id == "sub_level") dest = D::SubLevel;
    else if (id == "master_drive") dest = D::MasterDrive;
    else if (id == "sub_level") dest = D::Osc1Level;
    else if (id == "noise_level") dest = D::Osc3Level;
    else return false;
    return true;
}

void SalekHightechAudioProcessorEditor::showModMenu (const juce::String& paramId)
{
    salek::ModMatrix::Dest d = salek::ModMatrix::Dest::NumDests;
    if (! resolveModDest (paramId, d)) return;
    auto& mm = processor.getModMatrix();
    juce::PopupMenu m;
    std::vector<std::pair<int, juce::String>> items;       // slot, text
    for (int i = 0; i < salek::ModMatrix::MaxRoutes; ++i)
    {
        auto& r = mm.getRoute (i);
        if (! r.active.load() || r.dest.load() != d) continue;
        items.push_back ({ i, juce::String (salek::ModMatrix::sourceName (r.source.load())) + "  >  " + salek::ModMatrix::destName (d)
                               + "   (" + juce::String (juce::roundToInt (r.amount.load() * 100.f)) + "%)" });
    }
    if (items.empty()) { m.addItem (0, "No modulation on this knob", false); }
    else
    {
        for (size_t k = 0; k < items.size(); ++k) m.addItem ((int) k + 1, "Remove  " + items[k].second);
        if (items.size() > 1) { m.addSeparator(); m.addItem (1000, "Remove ALL modulation from this knob"); }
    }
    m.showMenuAsync (juce::PopupMenu::Options(), [this, alive = editorAlive, items] (int r)
    {
        if (! *alive) return;
        if (r <= 0) return;
        processor.pushUndoPoint();
        auto& mat = processor.getModMatrix();
        if (r == 1000) { for (auto& it : items) mat.removeRoute (it.first); }
        else if (r <= (int) items.size()) mat.removeRoute (items[(size_t) r - 1].first);
        repaint();
    });
}

void SalekHightechAudioProcessorEditor::assignModToParam (const juce::String& paramId, float amount)
{
    processor.pushUndoPoint();
    if (armedModSource < 0 || armedModSource > 2) return;

    using D = salek::ModMatrix::Dest;
    using S = salek::ModMatrix::Source;
    D dest = D::NumDests;
    if (! resolveModDest (paramId, dest)) return;

    S src = (armedModSource == 0) ? S::LFO1 : (armedModSource == 1) ? S::LFO2 : S::LFO3;
    if (std::abs (amount) < 1e-4f)
        processor.getModMatrix().removeRoute (src, dest);
    else
        processor.getModMatrix().addRoute (src, dest, juce::jlimit (-1.f, 1.f, amount));

    if (matrixPanel != nullptr)
        matrixPanel->repaint();
    repaint();
}

void SalekHightechAudioProcessorEditor::addCombo (juce::Component& parent, juce::ComboBox& box,
                                                   const char* id, juce::StringArray items)
{
    box.addItemList (items, 1);
    box.setColour (juce::ComboBox::backgroundColourId, SalekLookAndFeel::panel());
    box.setColour (juce::ComboBox::outlineColourId, SalekLookAndFeel::border());
    box.setColour (juce::ComboBox::textColourId, SalekLookAndFeel::text());
    box.setColour (juce::ComboBox::arrowColourId, SalekLookAndFeel::teal());
    parent.addAndMakeVisible (box);
    if (processor.getAPVTS().getParameter (id) != nullptr)
        comboAtts.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (
            processor.getAPVTS(), id, box));
}

juce::String SalekHightechAudioProcessorEditor::getPresetCategory (const juce::String& programName) const
{
    if (programName.startsWithIgnoreCase ("GITI/"))
        return "GITI";
    if (programName.startsWith ("USER/"))
    {   // USER/Bank/Folder/.../Name  ->  the bank is the category
        const auto p = programName.fromFirstOccurrenceOf ("/", false, false);
        return p.containsChar ('/') ? p.upToFirstOccurrenceOf ("/", false, false) : juce::String ("USER");
    }

    auto category = programName.upToFirstOccurrenceOf ("/", false, false);
    return category == programName || category.isEmpty() ? juce::String ("OTHER") : category;
}

void SalekHightechAudioProcessorEditor::rebuildPresetRows()
{
    presetRows.clear();
    juce::StringArray cats;
    juce::Array<int> matchingPrograms;
    const int n = processor.getNumPrograms();
    const int selectedFilter = presetFilterBox.getSelectedId();
    const auto filterCategory = selectedFilter > 2 ? presetFilterBox.getText() : juce::String();
    const auto query = presetSearchBox.getText().trim();

    for (int i = 0; i < n; ++i)
    {
        auto name = processor.getProgramName (i);
        const auto category = getPresetCategory (name);
        if (selectedFilter == 2 && category != "GITI") continue;
        if (selectedFilter > 2 && ! category.equalsIgnoreCase (filterCategory)) continue;

        if (query.isNotEmpty())
        {
            const auto searchable = name + " " + processor.getProgramDescription (i);
            if (! searchable.containsIgnoreCase (query)) continue;
        }

        matchingPrograms.add (i);
        if (! cats.contains (category, false))
            cats.add (category);
    }

    const juce::StringArray preferred { "GITI","OTHER","KICK","BASS","LEAD","SYNTH","PLUCK","PAD","ATMOSPHERE","HIGHTECH","FX","ACID","FM","RETRO","SQUEEK","KEYS","ARP","SALEK","AMBIENT","USER" };
    juce::StringArray ordered;
    for (auto& p : preferred)
        if (cats.contains (p, false)) ordered.add (p);
    for (auto& c : cats)
        if (! ordered.contains (c, false)) ordered.add (c);

    for (auto& cat : ordered)
    {
        PresetRow h;
        h.isHeader = true;
        h.label = cat == "GITI" ? "GITI GENESIS" : cat.toUpperCase();
        h.programIndex = -1;
        h.category = cat;
        h.itemCount = (int) std::count_if (matchingPrograms.begin(), matchingPrograms.end(), [&] (int programIndex)
        {
            return getPresetCategory (processor.getProgramName (programIndex)) == cat;
        });
        presetRows.add (h);
        if (collapsedCats.contains (cat))
            continue;
        struct Item { int idx; juce::String folder, label; };
        std::vector<Item> items;
        juce::StringArray folders;
        for (const int i : matchingPrograms)
        {
            auto name = processor.getProgramName (i);
            if (getPresetCategory (name) != cat) continue;
            auto path = (name.startsWith ("USER/") && name.fromFirstOccurrenceOf ("/", false, false).containsChar ('/'))
                            ? name.fromFirstOccurrenceOf ("/", false, false) : name;
            auto rest = path.fromFirstOccurrenceOf ("/", false, false);
            if (rest.isEmpty()) rest = path;
            Item it { i, {}, rest };
            if (rest.containsChar ('/'))
            {
                it.folder = rest.upToFirstOccurrenceOf ("/", false, false);
                it.label = rest.fromFirstOccurrenceOf ("/", false, false);
                if (! folders.contains (it.folder)) folders.add (it.folder);
            }
            items.push_back (it);
        }
        auto emit = [&] (const Item& it)
        {
            PresetRow r; r.isHeader = false;
            r.label = it.label; r.programIndex = it.idx; r.category = cat;
            presetRows.add (r);
        };
        for (auto& it : items) if (it.folder.isEmpty()) emit (it);
        for (auto& f : folders)
        {   // sub-folder header (click to fold), then its presets
            PresetRow fh; fh.isHeader = true; fh.programIndex = -1;
            fh.label = "   > " + f.toUpperCase();
            fh.category = cat + "/" + f;
            fh.itemCount = (int) std::count_if (items.begin(), items.end(), [&] (const Item& x) { return x.folder == f; });
            presetRows.add (fh);
            if (collapsedCats.contains (fh.category)) continue;
            for (auto& it : items) if (it.folder == f) emit (it);
        }
    }

    if (matchingPrograms.isEmpty() && query.isNotEmpty())
    {
        PresetRow empty;
        empty.isHeader = true;
        empty.label = "NO MATCH  ·  REFINE SEARCH";
        empty.category = "NO MATCH";
        empty.itemCount = -1;
        presetRows.add (empty);
    }

    presetList.updateContent();
    presetList.repaint();
}


void SalekHightechAudioProcessorEditor::tryAssignModAt (juce::Point<int> editorPos, float amount, const juce::ModifierKeys&)
{
    if (armedModSource < 0) return;

    if (auto* hit = getComponentAt (editorPos))
    {
        for (auto* c = hit; c != nullptr && c != this; c = c->getParentComponent())
        {
            for (auto& k : knobs)
            {
                if (k == nullptr) continue;
                if (c == &k->s || c == &k->name)
                {
                    assignModToParam (k->paramId, amount);
                    return;
                }
            }
        }
    }

    for (auto& k : knobs)
    {
        if (k == nullptr || ! k->s.isShowing()) continue;
        auto r = getLocalArea (&k->s, k->s.getLocalBounds()).expanded (6);
        auto rn = getLocalArea (&k->name, k->name.getLocalBounds()).expanded (4);
        if (r.contains (editorPos) || rn.contains (editorPos))
        {
            assignModToParam (k->paramId, amount);
            return;
        }
    }
}

juce::Point<int> SalekHightechAudioProcessorEditor::currentMousePositionInEditor() const
{
    const auto screen = juce::Desktop::getInstance().getMainMouseSource().getScreenPosition().roundToInt();
    return getLocalPoint (nullptr, screen);
}

void SalekHightechAudioProcessorEditor::mouseDrag (const juce::MouseEvent& e)
{
    juce::AudioProcessorEditor::mouseDrag (e);
}
void SalekHightechAudioProcessorEditor::mouseUp (const juce::MouseEvent& e)
{
    // Fallback: if LFO armed and release over a knob, assign (even without DnD target hit)
    if (armedModSource >= 0 && e.mouseWasDraggedSinceMouseDown())
    {
        auto pos = currentMousePositionInEditor();
        float amt = 0.5f;
        if (e.mods.isShiftDown()) amt = 1.0f;
        if (e.mods.isAltDown()) amt = -0.5f;
        tryAssignModAt (pos, amt, e.mods);
    }
    juce::AudioProcessorEditor::mouseUp (e);
}
