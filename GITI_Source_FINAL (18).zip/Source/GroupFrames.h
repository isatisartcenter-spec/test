#pragma once
// Framed, labelled groups drawn over a tab (behind its controls). Non-interactive; the editor keeps its bounds in sync.
#include <juce_gui_basics/juce_gui_basics.h>

class GroupFrames : public juce::Component
{
public:
    GroupFrames (const juce::Rectangle<int>* b, int n, std::vector<juce::String> t, std::vector<juce::Colour> c)
        : boxes (b), count (n), titles (std::move (t)), cols (std::move (c))
    {
        setInterceptsMouseClicks (false, false);
    }

    void paint (juce::Graphics& g) override
    {
        for (int i = 0; i < count; ++i)
        {
            if (boxes[i].isEmpty()) continue;
            const juce::Colour col = cols[(size_t) juce::jmin (i, (int) cols.size() - 1)];
            auto rr = boxes[i].toFloat().reduced (1.f);
            g.setColour (col.withAlpha (0.07f)); g.fillRoundedRectangle (rr, 8.f);
            g.setColour (col.withAlpha (0.75f)); g.drawRoundedRectangle (rr, 8.f, 1.4f);
            g.setFont (juce::FontOptions (9.f, juce::Font::bold));
            g.setColour (col);
            g.drawText (titles[(size_t) i], rr.removeFromTop (16.f).toNearestInt().reduced (8, 0), juce::Justification::centredLeft);
        }
    }

private:
    const juce::Rectangle<int>* boxes;
    int count;
    std::vector<juce::String> titles;
    std::vector<juce::Colour> cols;
};
