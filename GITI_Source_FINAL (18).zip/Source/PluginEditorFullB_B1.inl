void SalekHightechAudioProcessorEditor::resized()
{
    auto full = getLocalBounds();
    // DAWs can briefly report a minimized/zero client area while hiding and
    // restoring an editor. Keep the last valid layout until real bounds return.
    if (full.getWidth() < 900 || full.getHeight() < 600)
        return;

    auto place = [this] (juce::Rectangle<int> area, auto& arr, int start, int count, int cols, int maxCell = 0)
    {
        if (count <= 0 || cols <= 0) return;
        const int rows = (count + cols - 1) / cols;
        const int cw = juce::jmax (1, area.getWidth() / cols);
        const int rh = juce::jmax (1, area.getHeight() / rows);
        for (int i = 0; i < count; ++i)
        {
            const int idx = start + i;
            if (idx < 0 || idx >= (int) arr.size()) break;
            auto* k = arr[(size_t) idx].get();
            const int c = i % cols, r = i / cols;
            auto cell = juce::Rectangle<int> (area.getX() + c * cw, area.getY() + r * rh, cw, rh).reduced (2);
            if (maxCell > 0 && cell.getWidth() > maxCell)
            {
                const int pad = (cell.getWidth() - maxCell) / 2;
                cell = cell.withTrimmedLeft (pad).withTrimmedRight (pad);
            }
            k->name.setBounds (cell.removeFromBottom (14));
            k->name.setJustificationType (juce::Justification::centred);
            k->name.setVisible (true);
            k->s.setTextBoxStyle (juce::Slider::TextBoxBelow, false, juce::jmax (36, cell.getWidth() - 8), 12);
            k->s.setNumDecimalPlacesToDisplay (2);
            k->s.textFromValueFunction = [] (double v)
                {
                    if (std::abs (v) >= 1000.0)
                        return juce::String ((int) std::round (v));
                    if (std::abs (v - std::round (v)) < 1e-3)
                        return juce::String ((int) std::round (v));
                    if (std::abs (v) >= 100.0)
                        return juce::String (v, 0);
                    if (std::abs (v) >= 10.0)
                        return juce::String (v, 1);
                    return juce::String (v, 2);
                };
            k->s.setBounds (cell);
            k->s.setVisible (true);
        }
    };

    {
        // ONLY place for model strip: above keyboard (never over knobs)
        auto bottom = full.removeFromBottom (64);
        auto strip = juce::Rectangle<int>();
        // Character carousel removed from the keyboard area: the selected hero is now shown only in the large left panel.
        modelStripBounds = {};
        modelStripTitle.setBounds (0, 0, 0, 0);
        modelStripTitle.setVisible (false);
        for (auto* ic : modelStrip) if (ic) { ic->setBounds (0, 0, 0, 0); ic->setVisible (false); }
        const int n = 0;
        if (n > 0)
        {
            const int cell = juce::jmax (12, strip.getWidth() / n);
            for (int i = 0; i < n; ++i)
            {
                if (auto* ic = modelStrip[i])
                {
                    ic->setBounds (strip.getX() + i * cell + 3, strip.getY() + 2, cell - 6, strip.getHeight() - 4);
                    ic->setVisible (true);
                    ic->toFront (false);
                }
            }
        }
        auto kb = bottom.reduced (2, 1);
        keyboard.setKeyWidth ((float) juce::jmax (10, kb.getWidth() / 52));
        keyboard.setBounds (kb);
        keyboard.toFront (false);
    }
    full.removeFromBottom (2);

    {
        const int presetW = presetCollapsed ? 28 : 260; // room for preset names
        auto leftStrip = full.removeFromLeft (presetW);
        const int logoPad = 8; // presets start near top of left strip
        // Preset ~32%, big character model gets remaining left column
        const int presetH = juce::jmax (170, (int) ((leftStrip.getHeight() - logoPad) * 0.50f)); // browser on top, character models below
        presetTab.setBounds (leftStrip.getX(), leftStrip.getY() + logoPad, leftStrip.getWidth(), presetH);
        presetTab.toFront (false);
        // Character PNG slot under presets (always visible when not collapsed)
        {
            if (presetCollapsed)
            {
                charSlotBounds = juce::Rectangle<int> (
                    leftStrip.getX() + 2, leftStrip.getY() + logoPad,
                    leftStrip.getWidth() - 4, juce::jmax (100, leftStrip.getHeight() - logoPad - 8));
            }
            else
            {
                const int cy = leftStrip.getY() + logoPad + presetH + 4;
                const int ch = juce::jmax (120, leftStrip.getBottom() - cy - 4);
                charSlotBounds = juce::Rectangle<int> (leftStrip.getX() + 2, cy, leftStrip.getWidth() - 4, ch);
            }
        }
        auto pb = presetTab.getLocalBounds().reduced (2);
        // Two-line toolbar — bigger hit targets
        auto row1 = pb.removeFromTop (38);
        presetToggle.setBounds (row1.removeFromLeft (38).reduced (1, 1));
        if (! presetCollapsed)
        {
            prevPreset.setBounds (row1.removeFromLeft (38).reduced (1, 3));
            nextPreset.setBounds (row1.removeFromLeft (38).reduced (1, 3));
            initBtn.setBounds (row1.removeFromLeft (row1.getWidth()).reduced (1, 1));
            auto row2 = pb.removeFromTop (30);
            savePresetBtn.setBounds (row2.removeFromLeft (row2.getWidth() / 3).reduced (1, 1));
            loadPresetBtn.setBounds (row2.removeFromLeft (row2.getWidth() / 2).reduced (1, 1));
            bankBtn.setBounds (row2.reduced (1, 1));
            auto browserRow = pb.removeFromTop (28);
            presetSearchBox.setBounds (browserRow.removeFromLeft (browserRow.getWidth() * 2 / 3).reduced (1));
            presetFilterBox.setBounds (browserRow.reduced (1));
            presetLabel.setBounds (pb.removeFromTop (16).reduced (2, 0));
            presetList.setBounds (pb);
            presetList.setOpaque (false);
            presetTab.setOpaque (false);
            presetList.setVisible (true);
            presetSearchBox.setVisible (true); presetFilterBox.setVisible (true);
            prevPreset.setVisible (true); nextPreset.setVisible (true);
            initBtn.setVisible (true); savePresetBtn.setVisible (true);
            loadPresetBtn.setVisible (true); bankBtn.setVisible (true);
            presetLabel.setVisible (true);
        }
        else
        {
            presetList.setVisible (false); prevPreset.setVisible (false);
            nextPreset.setVisible (false); initBtn.setVisible (false);
            savePresetBtn.setVisible (false); loadPresetBtn.setVisible (false);
            bankBtn.setVisible (false); presetLabel.setVisible (false);
            presetSearchBox.setVisible (false); presetFilterBox.setVisible (false);
        }
    }

    auto header = full.removeFromTop (112);
    {   // header: sci-fi scene on the left, square logo + holographic visualizer on the right
        const int sq = 196;
        auto sceneR = header.withTrimmedRight (sq + 6).reduced (2, 2);
        auto squareR = header.removeFromRight (sq).reduced (2, 2);
        spaceScene.setBounds (sceneR);
        visualizer.setBounds (squareR);
        visualizer.toFront (false);
        stageLogo.setBounds (squareR.withSizeKeepingCentre (squareR.getWidth() - 20, 54).translated (0, 6));
        stageLogo.toFront (false);
        stageLogo.setVisible (true);
        logoOverlay.setVisible (false);
        masterGainSlider.setBounds (squareR.getX() - 58, header.getY() + 30, 50, 50);   // inside the header, above the scene: always clickable
        masterGainSlider.setAlwaysOnTop (true);
        masterGainSlider.toFront (false);
    }
    modSrcLfo1.setButtonText ("LFO1");
    modSrcLfo2.setButtonText ("LFO2");
    modSrcLfo3.setButtonText ("LFO3");

    // Keep drop targets aligned with knob sliders
    for (size_t i = 0; i < knobDropTargets.size() && i < knobs.size(); ++i)
    {
        if (knobs[i] != nullptr && knobDropTargets[i] != nullptr)
        {
            auto r = knobs[i]->s.getBounds();
            // parent of drop may differ — convert
            if (auto* p = knobDropTargets[i]->getParentComponent())
            {
                if (auto* sp = knobs[i]->s.getParentComponent())
                {
                    auto topLeft = p->getLocalPoint (sp, r.getTopLeft());
                    knobDropTargets[i]->setBounds (topLeft.x, topLeft.y, r.getWidth(), r.getHeight());
                }
            }
            knobDropTargets[i]->setVisible (knobs[i]->s.isVisible());
        }
    }

    // Remove top scopes / spectrum / wt strip (user X)
    spectrum.setBounds (0, 0, 0, 0); spectrum.setVisible (false);
    scope.setBounds (0, 0, 0, 0); scope.setVisible (false);
    if (wtDisplay != nullptr) { wtDisplay->setBounds (0, 0, 0, 0); wtDisplay->setVisible (false); }

    tabs.setBounds (full);
    tabs.toFront (false);
    {
        auto row = juce::Rectangle<int> (full.getRight() - 56 - 690, full.getY() + 1, 690, 26);
        sizeBtn.setBounds (row.removeFromRight (48).reduced (1, 0));
        redoBtn.setBounds (row.removeFromRight (42).reduced (1, 0));
        // the header buttons sit on the same line as the tab bar: keep them above it so they get the clicks
        undoBtn.toFront (false); redoBtn.toFront (false); drawWaveBtn.toFront (false);
        sizeBtn.toFront (false); storeBtn.toFront (false); updateBtn.toFront (false);
        undoBtn.setBounds (row.removeFromRight (46).reduced (1, 0));
        updateBtn.setBounds (row.removeFromRight (62).reduced (1, 0));
        storeBtn.setBounds (row.removeFromRight (58).reduced (1, 0));
        drawWaveBtn.setBounds (row.removeFromRight (58).reduced (1, 0));
        ecoBtn.setBounds (row.removeFromRight (50).reduced (1, 0));
        phoneBtn.setBounds (row.removeFromRight (64).reduced (1, 0));
        phoneBtn.toFront (false);
        ecoBtn.toFront (false);
        storeBtn.toFront (false);
        updateBtn.toFront (false);
        sizeBtn.toFront (false);
        langToggle.setBounds (row.removeFromRight (38).reduced (1, 0));
        themeBox.setBounds (row.removeFromRight (96).reduced (1, 0));
        bgSwapBtn.setBounds (row.removeFromRight (40).reduced (1, 0));
        charCycleBtn.setBounds (row.removeFromRight (56).reduced (1, 0));
        charCycleBtn.setVisible (true);
        for (auto* c : { (juce::Component*) &langToggle, (juce::Component*) &themeBox, (juce::Component*) &bgSwapBtn, (juce::Component*) &charCycleBtn })
            c->toFront (false);
        visualizer.toFront (false);
    }

    // MAIN — place ALL knobs by PARAMETER ID (never by fragile array index)
    {
        auto byId = [this] (const char* id) -> Knob*
        {
            for (auto& k : knobs)
                if (k != nullptr && k->paramId == id)
                    return k.get();
            return nullptr;
        };
        auto placeId = [&] (juce::Rectangle<int> box, const char* id)
        {
            if (auto* k = byId (id))
            {
                k->name.setBounds (box.removeFromBottom (14));
                k->name.setJustificationType (juce::Justification::centred);
                k->name.setVisible (true);
                k->s.setTextBoxStyle (juce::Slider::TextBoxBelow, false, juce::jmax (36, box.getWidth() - 8), 12);
                k->s.setNumDecimalPlacesToDisplay (2);
                k->s.textFromValueFunction = [] (double v)
                {
                    if (std::abs (v) >= 1000.0)
                        return juce::String ((int) std::round (v));
                    if (std::abs (v - std::round (v)) < 1e-3)
                        return juce::String ((int) std::round (v));
                    if (std::abs (v) >= 100.0)
                        return juce::String (v, 0);
                    if (std::abs (v) >= 10.0)
                        return juce::String (v, 1);
                    return juce::String (v, 2);
                };
                k->s.setBounds (box);
                k->s.setVisible (true);
            }
        };

        auto b = mainTab.getLocalBounds().reduced (2);
        // FL Studio sometimes reports 0-size mid-session — skip only MAIN placement
        if (b.getWidth() >= 200 && b.getHeight() >= 120)
        {
        // ===== NEW MAIN LAYOUT: [OSC 1] [OSC 2 | OSC 3] [NOISE | SUB]  +  FILTER 1|2 column  +  ADSR / VOICE frames =====
        envTab.setBounds (b.removeFromBottom (138));
        filterTab.setBounds (b.removeFromRight (252));
        b.removeFromRight (6);
        oscTab.setBounds (b);
        stageTopEd = getLocalArea (&filterTab, juce::Rectangle<int> (0, 4 + 20 + 26 + 3 + 46 + 3 + 24 + 3 + 58 + 4 + 2 * 58 + 6, 1, 1)).getY();
        oscTab.setVisible (true);
        filterTab.setVisible (true);
        envTab.setVisible (true);
        mainTab.setVisible (true);

        // legacy decorative section icons are retired (the new frames carry their own headers)
        for (auto& ic : tabSectionIcons) if (ic) ic->setVisible (false);

        juce::Component* mons[3] = { oscMon1.get(), oscMon2.get(), oscMon3.get() };
        juce::ComboBox* shapes[3] = { &osc1ShapeBox, &osc2ShapeBox, &osc3ShapeBox };
        const char* idsLvl[3]   = { "osc1_level", "osc2_level", "osc3_level" };
        const char* idsTbl[3]   = { "osc1_table", "osc2_table", "osc3_table" };
        const char* idsWarp[3]  = { "osc1_warp", "osc2_warp", "osc3_warp" };
        const char* idsFold[3]  = { "osc1_fold", "osc2_fold", "osc3_fold" };
        const char* idsDrive[3] = { "osc1_drive", "osc2_drive", "osc3_drive" };
        const char* idsOct[3]   = { "osc1_octave", "osc2_octave", "osc3_octave" };
        const char* idsSemi[3]  = { "osc1_semi", "osc2_semi", "osc3_semi" };
        const char* idsCoarse[3] = { "osc1_coarse", "osc2_coarse", "osc3_coarse" };
        const char* idsFine[3] = { "osc1_fine", "osc2_fine", "osc3_fine" };
        const char* idsDetune[3] = { "osc1_detune", "osc2_detune", "osc3_detune" };
        const char* idsUni[3]   = { "osc1_unison", "osc2_unison", "osc3_unison" };
        const char* idsDet[3]   = { "osc1_udet", "osc2_udet", "osc3_udet" };
        const char* idsSpr[3]   = { "osc1_uspread", "osc2_uspread", "osc3_uspread" };
        const char* idsPh[3]    = { "osc1_phase", "osc2_phase", "osc3_phase" };
        const char* idsRnd[3]   = { "osc1_rand", "osc2_rand", "osc3_rand" };
        const char* idsPan[3]   = { "osc1_pan", "osc2_pan", "osc3_pan" };

        // noise / sub knobs were created in the envelope strip: move them into the oscillator zone
        for (size_t ki = 0; ki < knobs.size(); ++ki)
            if (knobs[ki] != nullptr && (knobs[ki]->paramId.startsWith ("noise_") || knobs[ki]->paramId.startsWith ("sub_")))
            {
                if (knobs[ki]->s.getParentComponent() != &oscTab)
                {
                    oscTab.addAndMakeVisible (knobs[ki]->s);
                    oscTab.addAndMakeVisible (knobs[ki]->name);
                    if (ki < knobDropTargets.size() && knobDropTargets[ki] != nullptr)
                        oscTab.addAndMakeVisible (*knobDropTargets[ki]);
                }
            }

        // ---- three oscillator-zone frames ----
        {
            auto zone = oscTab.getLocalBounds().reduced (2);
            const int wA = zone.getWidth() * 41 / 100, wB = zone.getWidth() * 35 / 100;
            oscFrameRect[0] = zone.removeFromLeft (wA);   zone.removeFromLeft (6);
            oscFrameRect[1] = zone.removeFromLeft (wB);   zone.removeFromLeft (6);
            oscFrameRect[2] = zone;
        }
        auto layoutOscCol = [&] (juce::Rectangle<int> frame, int c, bool adv, juce::TextButton& advB, juce::Rectangle<int>* selRowOut)
        {
            auto col = frame.reduced (8, 4).withTrimmedTop (20);
            if (selRowOut != nullptr) { *selRowOut = col.removeFromTop (28); col.removeFromTop (3); }
            const int monH = juce::jlimit (34, 54, col.getHeight() / 7);
            if (mons[c] != nullptr) mons[c]->setBounds (col.removeFromTop (monH).reduced (1));
            shapes[c]->setBounds (col.removeFromTop (22).reduced (1));
            {   // quick basic-waveform buttons
                auto wr = col.removeFromTop (20);
                const int bw = juce::jmax (1, wr.getWidth() / 6);
                for (int i = 0; i < 6; ++i) waveQuick[c][i].setBounds (wr.removeFromLeft (bw).reduced (1, 0));
            }
            col.removeFromTop (3);
            advB.setBounds (col.removeFromBottom (24).reduced (2, 1));
            juce::Rectangle<int> advArea;
            if (adv) advArea = col.removeFromBottom (juce::jmin (col.getHeight() * 52 / 100, 156));
            auto r1 = col.removeFromTop (col.getHeight() / 2), r2 = col;
            placeId (r1.removeFromLeft (r1.getWidth() / 2).reduced (3), idsLvl[c]);  placeId (r1.reduced (3), idsTbl[c]);
            placeId (r2.removeFromLeft (r2.getWidth() / 2).reduced (3), idsWarp[c]); placeId (r2.reduced (3), idsFold[c]);
            if (adv)
            {
                auto a1 = advArea.removeFromTop (advArea.getHeight() / 2), a2 = advArea;
                const char* rowA[6] = { idsDrive[c], idsOct[c], idsSemi[c], idsCoarse[c], idsFine[c], idsDetune[c] };
                const char* rowB[6] = { idsUni[c], idsDet[c], idsSpr[c], idsPh[c], idsRnd[c], idsPan[c] };
                const int cw = juce::jmax (1, a1.getWidth() / 6);
                for (int i = 0; i < 6; ++i)
                {
                    placeId (juce::Rectangle<int> (a1.getX() + i * cw, a1.getY(), cw, a1.getHeight()).reduced (1), rowA[i]);
                    placeId (juce::Rectangle<int> (a2.getX() + i * cw, a2.getY(), cw, a2.getHeight()).reduced (1), rowB[i]);
                }
            }
        };
        layoutOscCol (oscFrameRect[0], 0, advOpen[0], advBtn[0], nullptr);
        {
            juce::Rectangle<int> selRow;
            layoutOscCol (oscFrameRect[1], 1 + sel23, advOpen[1], advBtn[1], &selRow);
            {
                auto pw = [&] (const juce::Rectangle<int>& fr) { return juce::Rectangle<int> (fr.getRight() - 118, fr.getY() + 3, 38, 16); };
                onBtn[0].setBounds (pw (oscFrameRect[0]));
                onBtn[1].setBounds (pw (oscFrameRect[1]));
                onBtn[2].setBounds (pw (oscFrameRect[1]));
                onBtn[3].setBounds (pw (oscFrameRect[2]).translated (22, 0).withWidth (34));
                onBtn[4].setBounds (pw (oscFrameRect[2]).translated (22, 0).withWidth (34));
                onBtn[1].setVisible (sel23 == 0); onBtn[2].setVisible (sel23 == 1);
                onBtn[3].setVisible (selNS == 0); onBtn[4].setVisible (selNS == 1);
                for (auto& ob : onBtn) ob.toFront (false);
            }
            for (int s = 0; s < 3; ++s)
            {
                const bool vis = (s == 0) || (s == 1 + sel23);
                for (int i = 0; i < 6; ++i) { waveQuick[s][i].setVisible (vis); if (vis) waveQuick[s][i].toFront (false); }
            }
            oscSelBtn[0].setBounds (selRow.removeFromLeft (selRow.getWidth() / 2).reduced (2, 0));
            oscSelBtn[1].setBounds (selRow.reduced (2, 0));
        }
        {
            auto col = oscFrameRect[2].reduced (8, 4).withTrimmedTop (20);
            {   // lower part of this column belongs to the big visualizer stage
                const int stageTopLocal = oscTab.getLocalPoint (this, juce::Point<int> (0, stageTopEd)).y;
                col.setBottom (juce::jmax (col.getY() + 150, juce::jmin (col.getBottom(), stageTopLocal - 8)));
            }
            auto sel = col.removeFromTop (28);
            nsSelBtn[0].setBounds (sel.removeFromLeft (sel.getWidth() / 2).reduced (2, 0));
            nsSelBtn[1].setBounds (sel.reduced (2, 0));
            col.removeFromTop (6);
            nsScopeRect = juce::Rectangle<int>();   // monitor removed: space goes to controls
            col.removeFromTop (6);
            {
                const char* nIds[3] = { "noise_level", "noise_tone", "noise_pan" };
                const char* sIds[4] = { "sub_level", "sub_octave", "sub_semi", "sub_pan" };
                const int cnt = selNS == 0 ? 3 : 4;
                auto g1 = col.reduced (4, 2);
                auto rowTop = g1.removeFromTop (g1.getHeight() / 2), rowBot = g1;
                for (int i = 0; i < cnt; ++i)
                {
                    auto& row = i < 2 ? rowTop : rowBot;
                    auto cell = juce::Rectangle<int> (row.getX() + (i % 2) * (row.getWidth() / 2), row.getY(), row.getWidth() / 2, row.getHeight());
                    placeId (cell.reduced (3), selNS == 0 ? nIds[i] : sIds[i]);
                }
                {
                    auto& row = rowBot;
                    auto cell = juce::Rectangle<int> (row.getX() + (row.getWidth() / 2), row.getY(), row.getWidth() / 2, row.getHeight());
                    noiseTypeBox.setBounds (cell.withSizeKeepingCentre (cell.getWidth() - 8, 26).translated (0, -8));
                    noiseTypeBox.setVisible (selNS == 0);
                }
            }
        }

        // ---- FILTER 1 | FILTER 2 column ----
        {
            auto fr = filterTab.getLocalBounds().reduced (6, 4);
            fr.removeFromTop (20);
            auto tabsRow = fr.removeFromTop (26);
            filterTabBtn[0].setBounds (tabsRow.removeFromLeft (tabsRow.getWidth() / 2).reduced (2, 0));
            filterTabBtn[1].setBounds (tabsRow.reduced (2, 0));
            fr.removeFromTop (3);
            if (filterDisplay != nullptr) filterDisplay->setBounds (fr.removeFromTop (46).reduced (1));
            fr.removeFromTop (3);
            auto modeRow = fr.removeFromTop (24).reduced (1);
            filterMode.setBounds (modeRow);
            filter2Mode.setBounds (modeRow);
            fr.removeFromTop (3);
            {   // source lamps (which sources go through THIS filter): 3 + 2
                auto lamps = fr.removeFromTop (58);
                auto l1 = lamps.removeFromTop (29), l2 = lamps;
                for (int i = 0; i < 3; ++i) filterLed[i].setBounds (l1.removeFromLeft (l1.getWidth() / (3 - i)).reduced (1));
                for (int i = 3; i < 5; ++i) filterLed[i].setBounds (l2.removeFromLeft (l2.getWidth() / (5 - i)).reduced (1));
            }
            fr.removeFromTop (4);
            auto k1 = fr.removeFromTop (58), k2 = fr.removeFromTop (58);   // compact rows: space under them goes to the stage
            const char* rowA[2][3] = { { "filter_cutoff", "filter_reso", "filter_drive" },
                                       { "filter2_cutoff", "filter2_reso", "filter2_drive" } };
            const char* rowB[2][2] = { { "filter_env", "filter1_mix" }, { "filter2_env", "filter2_mix" } };
            const int cw = juce::jmax (1, k1.getWidth() / 3);
            for (int f = 0; f < 2; ++f)
            {
                for (int i = 0; i < 3; ++i)
                    placeId (juce::Rectangle<int> (k1.getX() + i * cw, k1.getY(), cw, k1.getHeight()).reduced (2), rowA[f][i]);
                for (int i = 0; i < 2; ++i)
                    placeId (juce::Rectangle<int> (k2.getX() + i * cw, k2.getY(), cw, k2.getHeight()).reduced (2), rowB[f][i]);
            }
            filterStyleBtn.setBounds (juce::Rectangle<int> (k2.getX() + 2 * cw, k2.getY(), cw, k2.getHeight()).withSizeKeepingCentre (cw - 6, 26));
            if (filterFader)
                for (auto* fid : { "filter_cutoff", "filter_reso", "filter_drive", "filter_env", "filter1_mix",
                                   "filter2_cutoff", "filter2_reso", "filter2_drive", "filter2_env", "filter2_mix" })
                    if (auto* k = byId (fid))
                        k->s.setBounds (k->s.getBounds().withSizeKeepingCentre (k->s.getWidth(), juce::jmin (44, k->s.getHeight())));
        }

        // ---- bottom strip: ADSR (+ monitor) frame | VOICE (poly/mono/legato, glide) frame ----
        {
            auto er = envTab.getLocalBounds().reduced (3);
            {   // the area right of ADSR/VOICE is the visualizer stage
                const int nl = envTab.getLocalPoint (&oscTab, oscFrameRect[2].getPosition()).x;
                er.setRight (juce::jmax (er.getX() + 300, nl - 6));
            }
            envFrameRect[0] = er.removeFromLeft (er.getWidth() * 60 / 100);
            er.removeFromLeft (6);
            envFrameRect[1] = er;
            auto a = envFrameRect[0].reduced (8, 4).withTrimmedTop (20);
            if (adsrDisplay != nullptr) adsrDisplay->setBounds (a.removeFromLeft (juce::jmin (150, a.getWidth() / 3)).reduced (2));
            const int aw = juce::jmax (1, a.getWidth() / 4);
            const char* adsr[4] = { "amp_attack", "amp_decay", "amp_sustain", "amp_release" };
            for (int i = 0; i < 4; ++i)
                placeId (juce::Rectangle<int> (a.getX() + i * aw, a.getY(), aw, a.getHeight()).reduced (4, 2), adsr[i]);
            auto v = envFrameRect[1].reduced (8, 4).withTrimmedTop (20);
            voiceModeBox.setBounds (v.removeFromTop (24).reduced (2, 0));
            const int vw = juce::jmax (1, v.getWidth() / 2);
            placeId (v.removeFromLeft (vw).reduced (3, 2), "glide");
            placeId (v.reduced (3, 2), "poly_voices");
        }

        // ---- big visualizer stage: lower Noise|Sub + under Filter + right of ADSR (MAIN tab only) ----
        {
            stageOnMain = (tabs.getCurrentTabIndex() == 0);
            if (stageOnMain)
            {
                const auto nf = getLocalArea (&oscTab, oscFrameRect[2]);
                const auto ft = getLocalArea (&filterTab, filterTab.getLocalBounds());
                const auto ev = getLocalArea (&envTab, envTab.getLocalBounds());
                const int filterUsed = 4 + 20 + 26 + 3 + 46 + 3 + 24 + 3 + 58 + 4 + 2 * 58 + 6;
                (void) filterUsed;
                const int top = stageTopEd;
                auto stage = juce::Rectangle<int> (nf.getX(), top, ft.getRight() - nf.getX(), ev.getBottom() - top).reduced (2);
                modStage.setBounds (stage);
                const auto c = stage.withTrimmedTop (32).reduced (8, 6);
                juce::TextButton* orb[3] = { &modSrcLfo1, &modSrcLfo2, &modSrcLfo3 };
                for (int n = 0; n < 3; ++n)
                {
                    const bool on = modStage.sel == n;
                    if (quickLfo[n] != nullptr) { quickLfo[n]->setVisible (on); quickLfo[n]->setBounds (c.withTrimmedLeft (100)); }
                    orb[n]->setVisible (on);
                    orb[n]->setBounds (juce::Rectangle<int> (c.getX(), c.getY() + 6, 92, 112));
                    if (on) orb[n]->toFront (false);
                }
                const bool rnd = modStage.sel == 3;
                inspireBtn.setVisible (rnd);
                randomZones.setVisible (rnd);
                inspireBtn.setBounds (juce::Rectangle<int> (c.getCentreX() - 60, c.getY() + 4, 120, 140));
                randomZones.setBounds (juce::Rectangle<int> (c.getX() + 4, c.getBottom() - 70, c.getWidth() - 8, 56));
                if (rnd) { inspireBtn.toFront (false); randomZones.toFront (false); }
                modStage.setVisible (true);
                modStage.toFront (false);
                for (int n = 0; n < 3; ++n) { if (quickLfo[n] != nullptr && modStage.sel == n) quickLfo[n]->toFront (false); if (modStage.sel == n) orb[n]->toFront (false); }
                if (rnd) { inspireBtn.toFront (false); randomZones.toFront (false); }
            }
            else
            {
                modStage.setVisible (false);
                for (auto& q : quickLfo) if (q != nullptr) q->setVisible (false);
                // other tabs (FX, MOD, LFO...): the three LFO sources sit in the header, so you can drag them onto any knob
                juce::TextButton* orb[3] = { &modSrcLfo1, &modSrcLfo2, &modSrcLfo3 };
                for (int n = 0; n < 3; ++n)
                {
                    orb[n]->setBounds (header.getX() + header.getWidth() * 12 / 100 + n * 58, header.getY() + 14, 54, 66);
                    orb[n]->setVisible (true);
                    orb[n]->toFront (false);
                }
                inspireBtn.setVisible (false); randomZones.setVisible (false);
            }
        }

        // ---- final visibility pass (selected oscillator, advanced rows, filter 1/2, noise/sub) + drop targets ----
        {
            auto isAdv = [] (const juce::String& id)
            {
                for (auto* suf : { "_drive", "_octave", "_semi", "_coarse", "_fine", "_detune", "_unison", "_udet", "_uspread", "_phase", "_rand", "_pan" })
                    if (id.endsWith (suf)) return true;
                return false;
            };
            for (int c = 0; c < 3; ++c)
            {
                const bool vis = (c == 0) || (c == 1 + sel23);
                if (mons[c] != nullptr) mons[c]->setVisible (vis);
                shapes[c]->setVisible (vis);
            }
            for (size_t ki = 0; ki < knobs.size(); ++ki)
            {
                auto* k = knobs[ki].get();
                if (k == nullptr) continue;
                const auto& id = k->paramId;
                bool vis = true, decided = false;
                for (int c = 0; c < 3 && ! decided; ++c)
                    if (id.startsWith ("osc" + juce::String (c + 1) + "_"))
                    {
                        decided = true;
                        vis = (c == 0 || c == 1 + sel23) && (! isAdv (id) || advOpen[c == 0 ? 0 : 1]);
                    }
                if (! decided)
                {
                    if (id.startsWith ("noise_")) vis = (selNS == 0);
                    else if (id.startsWith ("sub_")) vis = (selNS == 1);
                    else if (id == "filter_cutoff" || id == "filter_reso" || id == "filter_drive" || id == "filter_env" || id == "filter1_mix") vis = (filterSel == 0);
                    else if (id.startsWith ("filter2_") || id == "filter2_mix") vis = (filterSel == 1);
                }
                k->s.setVisible (vis);
                k->name.setVisible (vis);
                if (ki < knobDropTargets.size() && knobDropTargets[ki] != nullptr)
                {
                    auto r = k->s.getBounds();
                    auto* dp = knobDropTargets[ki]->getParentComponent();
                    auto* sp = k->s.getParentComponent();
                    if (dp != nullptr && sp != nullptr)
                    {
                        auto tl = dp->getLocalPoint (sp, r.getTopLeft());
                        knobDropTargets[ki]->setBounds (tl.x, tl.y, r.getWidth(), r.getHeight());
                    }
                    knobDropTargets[ki]->setVisible (vis);
                }
            }
            filterMode.setVisible (filterSel == 0);
            filter2Mode.setVisible (filterSel == 1);
            filterRouteBox.setVisible (false);
            oscSelBtn[2].setVisible (false);
            for (auto* ac : { (juce::Component*) &filterStyleBtn }) ac->toFront (false);
        }
    }


        } // end valid MAIN size
    // FL recovery: never leave MAIN knobs invisible after tab switch / host resize
    {
        auto forceVis = [] (juce::Component& c)
        {
            // Only the tab container itself. Forcing every child visible here used to override the
            // OSC2/OSC3, NOISE/SUB, FILTER 1/2 and MORE/LESS selection done in the visibility pass above.
            c.setVisible (true);
        };
        forceVis (oscTab);
        forceVis (filterTab);
        forceVis (envTab);
        forceVis (mainTab);
    }

    // MOD — matrix left; clean FM grid + macros right (hide stray knobs)
    {

        // MOD icons: MATRIX / MACRO / FM
        if (tabSectionIcons.size() >= 11)
        {
            auto top = modTab.getLocalBounds().removeFromTop (32).reduced (4, 2);
            for (int i = 0; i < 3; ++i)
            {
                auto* ic = tabSectionIcons[8 + i];
                ic->setBounds (top.removeFromLeft (42).reduced (2));
                if (ic->getParentComponent() != &modTab)
                    modTab.addAndMakeVisible (*ic);
                ic->setVisible (true);
                ic->toFront (false);
            }
        }

        auto r = modTab.getLocalBounds().reduced (4);
        auto right = r.removeFromRight (juce::jmin (300, r.getWidth() * 34 / 100));

        // Only hide MOD-owned params (never touch osc/filter/env parents)
        static const char* modOnly[] = {
            "fm_2to1","fm_3to1","fm_3to2","pm_2to1","rm_2to1","am_2to1",
            "macro1","macro2","macro3","macro4","macro5","macro6","macro7","macro8","lfo_rate","lfo_amount"
        };
        for (auto& kk : knobs)
        {
            if (kk == nullptr) continue;
            bool isMod = false;
            for (auto* id : modOnly)
                if (kk->paramId == id) { isMod = true; break; }
            if (isMod)
            {
                kk->s.setVisible (false);
                kk->name.setVisible (false);
            }
        }

        auto byId = [this] (const char* id) -> Knob*
        {
            for (auto& k : knobs)
                if (k != nullptr && k->paramId == id) return k.get();
            return nullptr;
        };
        auto placeOne = [&] (juce::Rectangle<int> cell, const char* id)
        {
            auto* k = byId (id);
            if (k == nullptr) return;
            k->name.setBounds (cell.removeFromBottom (14));
            k->name.setJustificationType (juce::Justification::centred);
            k->name.setFont (juce::FontOptions (10.f, juce::Font::bold));
            k->name.setVisible (true);
            k->s.setTextBoxStyle (juce::Slider::TextBoxBelow, false, juce::jmax (40, cell.getWidth() - 8), 13);
            k->s.setNumDecimalPlacesToDisplay (2);
            k->s.setBounds (cell);
            k->s.setVisible (true);
        };

        // ---- right rail: six framed groups: FM (3) | AM | PM | RM | MACRO built-in (4) | MACRO user (4) ----
        auto rail = right.reduced (2, 2);
        const int RH = rail.getHeight();
        modBox[0] = rail.removeFromTop (RH * 27 / 100);
        auto smallRow = rail.removeFromTop (RH * 22 / 100);
        const int sw = smallRow.getWidth() / 3;
        modBox[1] = smallRow.removeFromLeft (sw).reduced (2, 0);   // AM
        modBox[2] = smallRow.removeFromLeft (sw).reduced (2, 0);   // PM
        modBox[3] = smallRow.reduced (2, 0);                       // RM
        modBox[4] = rail.removeFromTop (rail.getHeight() / 2).reduced (0, 3);
        modBox[5] = rail.reduced (0, 3);
        auto placeIn = [&] (const juce::Rectangle<int>& box, std::initializer_list<const char*> ids)
        {
            auto area = box.reduced (6, 22);     // title strip on top of each frame
            const int n = juce::jmax (1, (int) ids.size()), w = area.getWidth() / n;
            int i = 0;
            for (auto* id : ids) { placeOne (juce::Rectangle<int> (area.getX() + i * w, area.getY(), w, area.getHeight()).reduced (3, 2), id); ++i; }
        };
        placeIn (modBox[0], { "fm_2to1", "fm_3to1", "fm_3to2" });
        placeIn (modBox[1], { "am_2to1" });
        placeIn (modBox[2], { "pm_2to1" });
        placeIn (modBox[3], { "rm_2to1" });
        placeIn (modBox[4], { "macro1", "macro2", "macro3", "macro4" });
        placeIn (modBox[5], { "macro5", "macro6", "macro7", "macro8" });

        if (matrixPanel != nullptr)
            matrixPanel->setBounds (r.reduced (2));
    }

    // LFO
    {

        // LFO tab icons (LFO / SYNC / RND)
        if (tabSectionIcons.size() >= 8)
        {
            auto top = lfoTab.getLocalBounds().removeFromTop (42).reduced (4, 2);
            for (int i = 0; i < 3; ++i)
            {
                auto* ic = tabSectionIcons[5 + i];
                ic->setBounds (top.removeFromLeft (32).reduced (2));
                if (ic->getParentComponent() != &lfoTab)
                    lfoTab.addAndMakeVisible (*ic);
                ic->setVisible (true);
                ic->toFront (false);
            }
        }

        auto r = lfoTab.getLocalBounds().reduced (6);
        if (lfoDisplay != nullptr) lfoDisplay->setBounds (r.removeFromTop (56).reduced (1));
        auto presetRow = r.removeFromTop (24);
        const int bw = presetRow.getWidth() / 12;
        juce::TextButton* presets[] = {
            &lfoPresetSine, &lfoPresetTri, &lfoPresetSaw, &lfoPresetSqr,
            &lfoPresetPulse, &lfoPresetExp, &lfoPresetLog, &lfoPresetBell,
            &lfoPresetWob, &lfoPresetChaos, &lfoPresetGate, &lfoPresetCustom
        };
        for (auto* b : presets) b->setBounds (presetRow.removeFromLeft (bw).reduced (1));
        auto waveRow = r.removeFromTop (24);
        lfo1WaveBox.setBounds (waveRow.removeFromLeft (waveRow.getWidth() / 3).reduced (2));
        lfo2WaveBox.setBounds (waveRow.removeFromLeft (waveRow.getWidth() / 2).reduced (2));
        lfo3WaveBox.setBounds (waveRow.reduced (2));
        auto bankRow = r.removeFromTop (24);
        lfoPointsBox.setBounds (bankRow.removeFromRight (90).reduced (2));
        lfoShapeBank.setBounds (bankRow.reduced (2));
        auto copyRow = r.removeFromTop (22);
        const int cw = copyRow.getWidth() / 9;
        lfoCopyTo1.setBounds (copyRow.removeFromLeft (cw).reduced (1));
        lfoCopyTo2.setBounds (copyRow.removeFromLeft (cw).reduced (1));
        lfoCopyTo3.setBounds (copyRow.removeFromLeft (cw).reduced (1));
        lfoSaveA.setBounds (copyRow.removeFromLeft (cw).reduced (1));
        lfoLoadA.setBounds (copyRow.removeFromLeft (cw).reduced (1));
        lfoSaveB.setBounds (copyRow.removeFromLeft (cw).reduced (1));
        lfoLoadB.setBounds (copyRow.removeFromLeft (cw).reduced (1));
        lfoSaveC.setBounds (copyRow.removeFromLeft (cw).reduced (1));
        lfoLoadC.setBounds (copyRow.reduced (1));
        auto extraArea = r.removeFromBottom (104);
        {
            const int colW = juce::jmax (1, extraArea.getWidth() / 3);
            const char* P[3] = { "lfo", "lfo2", "lfo3" };
            for (int i = 0; i < 3; ++i)
            {
                auto col = juce::Rectangle<int> (extraArea.getX() + i * colW, extraArea.getY(), colW, extraArea.getHeight()).reduced (3, 0);
                lfoColBox[i] = col;
                auto top = col.removeFromTop (22);
                const int bw3 = top.getWidth() / 4;
                lfoSyncBtn[i].setBounds (top.removeFromLeft (bw3).reduced (1));
                lfoDivBox[i].setBounds (top.removeFromLeft (bw3).reduced (1));
                lfoBipBtn[i].setBounds (top.removeFromLeft (bw3).reduced (1));
                lfoRetrigBtn[i].setBounds (top.reduced (1));
                const juce::String p (P[i]);
                const juce::String ids[5] = { p + "_smooth", p + "_rise", p + "_delay", p + "_phase", p + "_steps" };
                const int kw = juce::jmax (1, col.getWidth() / 5);
                for (int j = 0; j < 5; ++j)
                {
                    Knob* k = nullptr;
                    for (auto& kk : knobs)
                        if (kk != nullptr && kk->paramId == ids[j]) { k = kk.get(); break; }
                    if (k == nullptr) continue;
                    auto cell = juce::Rectangle<int> (col.getX() + j * kw, col.getY(), kw, col.getHeight()).reduced (1, 1);
                    k->name.setBounds (cell.removeFromBottom (13));
                    k->name.setJustificationType (juce::Justification::centred);
                    k->name.setVisible (true);
                    k->s.setTextBoxStyle (juce::Slider::TextBoxBelow, false, juce::jmax (30, kw - 4), 12);
                    k->s.setBounds (cell);
                    k->s.setVisible (true);
                }
            }
        }
        auto knobArea = r.removeFromBottom (96);
        {
            const char* lids[] = { "lfo_rate","lfo_amount","lfo2_rate","lfo2_amount","lfo3_rate","lfo3_amount" };
            const int lfoCw = juce::jmax (1, knobArea.getWidth() / 6);
            for (int i = 0; i < 6; ++i)
            {
                Knob* k = nullptr;
                for (auto& kk : knobs)
                    if (kk != nullptr && kk->paramId == lids[i]) { k = kk.get(); break; }
                if (k == nullptr) continue;
                auto cell = juce::Rectangle<int> (knobArea.getX() + i * lfoCw, knobArea.getY(), lfoCw, knobArea.getHeight()).reduced (3, 2);
                k->name.setBounds (cell.removeFromBottom (14));
                k->name.setJustificationType (juce::Justification::centred);
                k->name.setVisible (true);
                k->s.setTextBoxStyle (juce::Slider::TextBoxBelow, false, juce::jmax (36, lfoCw - 10), 12);
                k->s.setBounds (cell);
                k->s.setVisible (true);
            }
        }
        lfoShapeEditor.setBounds (r.reduced (2));
    }

    #include "PluginEditorFullB_FxLayout.inl"

    // MAGIC: pad + combo presets only (8 mode/hold buttons removed per UX)
    {
        auto r = magicTab.getLocalBounds().reduced (6);
        // Keep HOLD visible so XY pad stays active without finger-down
        magicLoopBtn.setVisible (false);
        magicGlitchBtn.setVisible (false);
        magicFlangeBtn.setVisible (false);
        magicPsychBtn.setVisible (false);
        magicHint.setVisible (false);
        for (int c = 0; c < magicTab.getNumChildComponents(); ++c)
            if (auto* b = dynamic_cast<juce::TextButton*> (magicTab.getChildComponent (c)))
            {
                auto t = b->getButtonText();
                if (t.startsWith ("H-") || t == "LOOP" || t == "GLITCH" || t == "FLANGE" || t == "PSY")
                    b->setVisible (false);
            }
        // HOLD strip under combo row is placed with pad
        magicHold.setButtonText ("HOLD XY");
        magicHold.setVisible (true);
        magicHold.toFront (false);

        // Combo presets strip bottom
        {
            auto row = r.removeFromBottom (52).reduced (2, 1);
            const int n = 11;   // CRASH, NOISE, TORO were removed
            const int cw = juce::jmax (36, row.getWidth() / n);
            int slot = 0;
            for (int i = 0; i < 14; ++i)
                if (auto* c = magicTab.findChildWithID ("magicCombo" + juce::String (i)))
                {
                    if (i == 7 || i == 11 || i == 13) { c->setVisible (false); continue; }
                    c->setVisible (true);
                    c->setBounds (row.getX() + slot * cw, row.getY(), cw - 2, row.getHeight());
                    ++slot;
                }
        }
        // HOLD + MAGIC X/Y (hold keeps FX active so XY works continuously)
        {
            auto byId = [this] (const char* id) -> Knob* {
                for (auto& k : knobs)
                    if (k != nullptr && k->paramId == id) return k.get();
                return nullptr;
            };
            auto placeM = [&] (juce::Rectangle<int> cell, const char* id) {
                if (auto* k = byId (id))
                {
                    k->name.setBounds (cell.removeFromBottom (14));
                    k->name.setVisible (true);
                    k->s.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 48, 12);
                    k->s.setBounds (cell);
                    k->s.setVisible (true);
                }
            };
            auto xyCol = r.removeFromRight (110).reduced (4, 2);
            magicHold.setBounds (xyCol.removeFromTop (36).reduced (2));
            magicHold.setVisible (true);
            placeM (xyCol.removeFromTop (xyCol.getHeight() / 2).reduced (2), "magic_x");
            placeM (xyCol.reduced (2), "magic_y");
        }
        if (magicPad != nullptr)
        {
            magicPad->setBounds (r.reduced (4));
            magicPad->setAudioPeak (processor.getOutputPeak());
            magicPad->setVisible (true);
        }
    }

    // SEQ
    {
        auto bounds = seqTab.getLocalBounds().reduced (6);
        auto top = bounds.removeFromTop (98);   // compact: one knob row instead of two stacked rows
        auto leftControls = top.removeFromLeft (156).reduced (2, 0);
        auto toggleRow = leftControls.removeFromTop (30);
        arpOn.setBounds (toggleRow.removeFromLeft (toggleRow.getWidth() / 2).reduced (2, 1));
        seqOn.setBounds (toggleRow.reduced (2, 1));
        seqMagicTargetBox.setBounds (leftControls.removeFromTop (26).reduced (2, 1));
        seqMagicTargetBox.setTooltip ("Choose whether the running step sequence moves Magic X, Y, or both.");
        auto placeSeqKnob = [this] (juce::Rectangle<int> cell, const char* id)
        {
            for (auto& owned : knobs)
                if (owned != nullptr && owned->paramId == id)
                {
                    cell = cell.reduced (2, 0);
                    owned->name.setBounds (cell.removeFromBottom (13));
                    owned->name.setJustificationType (juce::Justification::centred);
                    owned->name.setVisible (true);
                    owned->s.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 48, 12);
                    owned->s.setBounds (cell);
                    owned->s.setVisible (true);
                    break;
                }
        };
        auto controls = top.reduced (4, 0);
        auto arpRow = controls.removeFromLeft (juce::jmin (controls.getWidth() / 2, 4 * 80));
        controls.removeFromLeft (10);
        auto seqRow = controls.removeFromLeft (juce::jmin (controls.getWidth() - 80, 4 * 80));
        placeSeqKnob (controls.removeFromLeft (80).withTrimmedLeft (4), "seq_magic_depth");
        const char* arpIds[] = { "arp_rate", "arp_octaves", "arp_gate", "arp_swing" };
        const char* seqIds[] = { "seq_rate", "seq_length", "seq_swing", "seq_gate" };
        const int controlWidth = arpRow.getWidth() / 4;
        for (int i = 0; i < 4; ++i)
        {
            placeSeqKnob ({ arpRow.getX() + i * controlWidth, arpRow.getY(), controlWidth, arpRow.getHeight() }, arpIds[i]);
            placeSeqKnob ({ seqRow.getX() + i * controlWidth, seqRow.getY(), controlWidth, seqRow.getHeight() }, seqIds[i]);
        }
        // 2 rows of Magic trigger buttons under seq strip
        {
            auto magicStrip = bounds.removeFromBottom (64).reduced (2, 1);
            seqMagicOff.setBounds (magicStrip.removeFromRight (72).reduced (2));
            seqMagicOff.setVisible (true);
            auto row1 = magicStrip.removeFromTop (30);
            auto row2 = magicStrip;
            const int n = seqMagicBtns.size();
            const int half = n / 2;
            if (half > 0)
            {
                const int cw1 = juce::jmax (28, row1.getWidth() / half);
                const int cw2 = juce::jmax (28, row2.getWidth() / juce::jmax (1, n - half));
                for (int i = 0; i < half; ++i)
                    if (auto* b = seqMagicBtns[i])
                    {
                        b->setBounds (row1.getX() + i * cw1, row1.getY(), cw1 - 2, row1.getHeight());
                        b->setVisible (true);
                    }
                for (int i = half; i < n; ++i)
                    if (auto* b = seqMagicBtns[i])
                    {
                        b->setBounds (row2.getX() + (i - half) * cw2, row2.getY(), cw2 - 2, row2.getHeight());
                        b->setVisible (true);
                    }
            }
        }
        bounds.removeFromTop (4);
        if (stepGrid != nullptr)
            stepGrid->setBounds (bounds);
    }

    if (speedMonitor != nullptr)
        speedMonitor->setBounds (speedTab.getLocalBounds().reduced (14));
    fxAmbient.setBounds (fxTab.getLocalBounds());       fxAmbient.toBack();
    aboutAmbient.setBounds (aboutTab.getLocalBounds()); aboutAmbient.toBack();
    if (aboutInfo != nullptr)
        aboutInfo->setBounds (aboutTab.getLocalBounds().reduced (8));

}
