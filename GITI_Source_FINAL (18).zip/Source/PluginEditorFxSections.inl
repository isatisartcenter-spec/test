// FX section labels + monitors + bypass + KNOBS (must exist or FX page is empty)
{
    const char* names[] = {
        "CHORUS", "DELAY", "REVERB", "BASS / SPACE",
        "COMP", "EQ", "PHASER", "DIST"
    };
    const char* bypassIds[] = {
        "chorus_bypass", "delay_bypass", "reverb_bypass", "bassify_bypass",
        "comp_bypass", "eq_bypass", "phaser_bypass", "dist_bypass"
    };
    const char* levelIds[] = {
        "chorus_mix", "delay_mix", "reverb_mix", "bassify",
        "comp_mix", nullptr, "phaser_mix", "dist_mix"
    };
    FxMonitor::Kind kinds[] = {
        FxMonitor::Chorus, FxMonitor::Delay, FxMonitor::Reverb, FxMonitor::Master,
        FxMonitor::Comp, FxMonitor::EQ, FxMonitor::Phaser, FxMonitor::Dist
    };
    juce::Colour monCols[] = {
        SalekLookAndFeel::teal(), SalekLookAndFeel::rose(), juce::Colour (0xffa8c895), SalekLookAndFeel::champagne(),
        juce::Colour (0xffd5a17b), juce::Colour (0xffb6a5d7), juce::Colour (0xff89c8b9), juce::Colour (0xffcf8e91)
    };


    // SALEK 50-icon pack → section badges (atlas indices)
    {
        const int iconIdx[8] = {
            37, // chorus
            36, // delay
            35, // reverb
            9,  // bassify ~ sub
            41, // comp
            40, // eq
            39, // phaser
            32  // dist
        };
        for (int i = 0; i < 8; ++i)
        {
            auto* ic = fxSectionIcons.add (new juce::ImageComponent ("fxIcon" + juce::String (i)));
            auto img = SalekAssets::loadIcon (iconIdx[i]);
            if (img.isValid())
            {
                ic->setImage (img);
                ic->setImagePlacement (juce::RectanglePlacement::centred);
            }
            ic->setInterceptsMouseClicks (false, false);
            fxTab.addAndMakeVisible (ic);
        }
    }

    for (int i = 0; i < 8; ++i)
    {
        auto* lab = fxSectionLabels.add (new juce::Label ("fx", names[i]));
        lab->setJustificationType (juce::Justification::centredLeft);
        lab->setFont (juce::FontOptions (11.0f, juce::Font::bold));
        lab->setColour (juce::Label::textColourId, monCols[i]);
        lab->setColour (juce::Label::backgroundColourId, SalekLookAndFeel::panel());
        fxTab.addAndMakeVisible (lab);
        auto* mon = fxMonitors.add (new FxMonitor());
        mon->setKind (kinds[i]);
        mon->setAccent (monCols[i]);
        mon->setLevel (0.4f);
        mon->bindActivitySource (processor.getFxActivityMeter (i));
        mon->bindControlSources (
            levelIds[i] != nullptr ? processor.getAPVTS().getRawParameterValue (levelIds[i]) : nullptr,
            processor.getAPVTS().getRawParameterValue (bypassIds[i]));
        if (kinds[i] == FxMonitor::EQ)
            mon->bindEqSources (processor.getAPVTS().getRawParameterValue ("eq_low"),
                                processor.getAPVTS().getRawParameterValue ("eq_mid"),
                                processor.getAPVTS().getRawParameterValue ("eq_high"));
        if (kinds[i] == FxMonitor::Comp)
        {
            if (auto* p = dynamic_cast<juce::RangedAudioParameter*> (processor.getAPVTS().getParameter ("comp_threshold")))
                mon->bindThresholdParam (p);
            mon->bindThresholdSource (processor.getAPVTS().getRawParameterValue ("comp_threshold"));
            mon->bindCompressor (&processor.getCompressor());
        }
        fxTab.addAndMakeVisible (mon);

        fxBypass[i].setButtonText (juce::CharPointer_UTF8 ("⏻"));
        fxBypass[i].setClickingTogglesState (true);
        fxBypass[i].setColour (juce::ToggleButton::textColourId, monCols[i]);
        fxBypass[i].setColour (juce::ToggleButton::tickColourId, monCols[i]);
        fxBypass[i].setColour (juce::TextButton::buttonColourId, SalekLookAndFeel::panel());
        fxBypass[i].setColour (juce::TextButton::buttonOnColourId, SalekLookAndFeel::rose().darker (0.18f));
        fxBypass[i].setTooltip ("Module power: illuminated means bypassed");
        fxTab.addAndMakeVisible (fxBypass[i]);
        btnAtts.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (
            processor.getAPVTS(), bypassIds[i], fxBypass[i]));
    }

    // ===== CREATE FX KNOBS (indices start at 58 after LFO 52-57) =====
    {
        const auto C = SalekLookAndFeel::teal();
        const auto M = SalekLookAndFeel::rose();
        const auto O = juce::Colour (0xffa8c895);
        const auto V = juce::Colour (0xffc4c887);
        const auto G = juce::Colour (0xffb6a5d7);
        // 58-60 CHORUS
        addKnob (fxTab, "chorus_mix", "CHORUS", O);
        addKnob (fxTab, "chorus_rate", "C RATE", C);
        addKnob (fxTab, "chorus_depth", "C DEPTH", M);
        // 61-63 DELAY
        addKnob (fxTab, "delay_mix", "DELAY", O);
        addKnob (fxTab, "delay_time", "D TIME", C);
        addKnob (fxTab, "delay_fb", "D FB", M);
        addKnob (fxTab, "delay_tone", "D TONE", G);
        // 64-66 REVERB
        addKnob (fxTab, "reverb_mix", "REVERB", O);
        addKnob (fxTab, "reverb_size", "R SIZE", C);
        addKnob (fxTab, "reverb_decay", "R DECAY", M);
        addKnob (fxTab, "reverb_damp", "R DAMP", G);
        // 67 BASSIFY
        addKnob (fxTab, "bassify", "BASSIFY", V);
        // COMP is a single wideband detector; its mini monitor edits C THR.
        addKnob (fxTab, "comp_threshold", "C THR", O);
        addKnob (fxTab, "comp_ratio", "C RATIO", M);
        addKnob (fxTab, "comp_mix", "C MIX", C);
        addKnob (fxTab, "comp_gain", "C GAIN", G);
        addKnob (fxTab, "comp_depth", "C DEPTH", G);
        addKnob (fxTab, "comp_attack", "C ATK", C);
        addKnob (fxTab, "comp_release", "C REL", M);
        // EQ
        addKnob (fxTab, "eq_low", "EQ LOW", G);
        addKnob (fxTab, "eq_mid", "EQ MID", O);
        addKnob (fxTab, "eq_high", "EQ HI", M);
        // 75-77 PHASER
        addKnob (fxTab, "phaser_mix", "PHASER", O);
        addKnob (fxTab, "phaser_rate", "P RATE", C);
        addKnob (fxTab, "phaser_depth", "P DEPTH", M);
        // 78-80 DIST
        addKnob (fxTab, "dist_mix", "DIST", O);
        addKnob (fxTab, "dist_drive", "DRIVE", M);
        addKnob (fxTab, "dist_crush", "CRUSH", C);
        addKnob (fxTab, "master_drive", "MASTER DRV", G);
        // Spatial (binaural)
        addKnob (fxTab, "spatial_azim", "AZIM", C);
        addKnob (fxTab, "spatial_dist", "DISTC", M);
        addKnob (fxTab, "spatial_size", "WIDTH", O);
        addKnob (fxTab, "spatial_elev", "ELEV", G);
        addKnob (fxTab, "input_mix", "IN MIX", V);
        addKnob (fxTab, "delay_time_l", "D TIME L", C);
        addKnob (fxTab, "delay_time_r", "D TIME R", M);
    }

    // Mode menus + APVTS attachment (were missing → modes never applied)
    distModeBox.clear (juce::dontSendNotification);
    distModeBox.addItemList ({ "Tube", "Sat", "Hard", "Fold", "Bit", "Rect" }, 1);
    distModeBox.setSelectedItemIndex (0, juce::dontSendNotification);
    reverbModeBox.clear (juce::dontSendNotification);
    reverbModeBox.addItemList ({ "Room", "Hall", "Plate", "Chamber", "Spring" }, 1);
    reverbModeBox.setSelectedItemIndex (0, juce::dontSendNotification);
    fxTab.addAndMakeVisible (distModeBox);
    fxTab.addAndMakeVisible (reverbModeBox);
    delayModeBox.clear (juce::dontSendNotification);
    delayModeBox.addItemList ({ "Stereo", "PingPong", "Mono" }, 1);
    delayModeBox.setSelectedItemIndex (0, juce::dontSendNotification);
    fxTab.addAndMakeVisible (delayModeBox);
    comboAtts.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (
        processor.getAPVTS(), "delay_mode", delayModeBox));
    comboAtts.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (
        processor.getAPVTS(), "dist_mode", distModeBox));
    comboAtts.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (
        processor.getAPVTS(), "reverb_mode", reverbModeBox));
}

