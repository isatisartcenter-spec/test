#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <array>
#include <functional>
#include <cmath>

// Animated cyber-Persian sci-fi scene for the header: stars, planet, saucers with beams, rocket,
// aliens, Milad/Azadi skyline and a neon grid. Procedural (no images), ~30 fps, audio reactive.
class SpaceScene : public juce::Component, private juce::Timer
{
public:
    std::function<float()> getLevel;
    juce::Image drone, robot, logo;
    SpaceScene()
    {
        setInterceptsMouseClicks (false, false);
        juce::Random r (7);
        for (auto& s : stars) s = { r.nextFloat(), r.nextFloat() * 0.8f, r.nextFloat() * 6.28f, 0.5f + r.nextFloat() * 1.5f };
        startTimerHz (30);
    }
    void paint (juce::Graphics& g) override
    {
        const auto b = getLocalBounds().toFloat();
        const float W = b.getWidth(), H = b.getHeight();
        if (W < 20.f) return;
        const float lv = level;
        g.reduceClipRegion (getLocalBounds());
        // sky
        juce::ColourGradient sky (juce::Colour (0xff06041a), 0, 0, juce::Colour (0xff3b1160), 0, H, false);
        sky.addColour (0.72, juce::Colour (0xff6a1b7a));
        g.setGradientFill (sky); g.fillRect (b);
        // horizon glow
        g.setGradientFill (juce::ColourGradient (juce::Colour (0xffff5a3c).withAlpha (0.25f + lv * 0.35f), W * 0.5f, H * 0.82f,
                                                 juce::Colours::transparentBlack, W * 0.5f, H * 0.2f, false));
        g.fillRect (b);
        // stars
        for (auto& s : stars)
        {
            g.setColour (juce::Colours::white.withAlpha (0.35f + 0.6f * std::abs (std::sin (t * 1.4f + s.ph))));
            g.fillEllipse (s.x * W, s.y * H, s.r, s.r);
        }
        // ringed planet
        const float px = W * 0.78f, py = H * 0.34f, pr = H * 0.22f;
        g.setGradientFill (juce::ColourGradient (juce::Colour (0xffff7ad9), px - pr * 0.4f, py - pr * 0.4f, juce::Colour (0xff3a0f6e), px + pr, py + pr, true));
        g.fillEllipse (px - pr, py - pr, pr * 2.f, pr * 2.f);
        g.setColour (juce::Colour (0xff35e6ff).withAlpha (0.8f));
        juce::Path ring; ring.addEllipse (px - pr * 1.7f, py - pr * 0.35f, pr * 3.4f, pr * 0.7f);
        g.strokePath (ring, juce::PathStrokeType (1.6f), juce::AffineTransform::rotation (-0.35f, px, py));
        // red moon
        g.setColour (juce::Colour (0xffff3a3a).withAlpha (0.8f));
        g.fillEllipse (W * 0.12f, H * 0.12f, H * 0.2f, H * 0.2f);
        const float gy = H * 0.78f;   // horizon line
        // neon floor grid
        g.setColour (juce::Colour (0xffff3ccf).withAlpha (0.35f + lv * 0.4f));
        for (int i = 0; i < 8; ++i)
        {
            const float yy = gy + (H - gy) * std::pow ((float) i / 7.f + std::fmod (t * 0.2f, 1.f / 7.f), 1.7f);
            g.drawHorizontalLine ((int) yy, 0.f, W);
        }
        for (int i = -10; i <= 10; ++i) g.drawLine (W * 0.5f + (float) i * 6.f, gy, W * 0.5f + (float) i * W * 0.1f, H, 1.f);
        // saucers with beams
        for (int k = 0; k < 2; ++k)
        {
            const float sx = std::fmod (t * (14.f + 9.f * (float) k) + (float) k * W * 0.45f, W + 120.f) - 60.f;
            const float sy = H * (0.2f + 0.14f * (float) k) + std::sin (t * 1.3f + (float) k) * 4.f;
            juce::Path beam; beam.startNewSubPath (sx, sy + 5.f); beam.lineTo (sx - 16.f, gy); beam.lineTo (sx + 16.f, gy); beam.closeSubPath();
            g.setGradientFill (juce::ColourGradient (juce::Colour (0xffb6ff5a).withAlpha (0.25f + lv * 0.4f), sx, sy, juce::Colours::transparentBlack, sx, gy, false));
            g.fillPath (beam);
            g.setColour (juce::Colour (0xff9aa6c8)); g.fillEllipse (sx - 16.f, sy - 3.f, 32.f, 10.f);
            g.setColour (juce::Colour (0xff35e6ff)); g.fillEllipse (sx - 7.f, sy - 8.f, 14.f, 10.f);
        }
        // rocket with exhaust
        const float rp = std::fmod (t * 0.07f, 1.f);
        const float rx = W * (0.05f + 0.9f * rp), ry = H * (0.85f - 0.75f * rp);
        const juce::AffineTransform rot = juce::AffineTransform::rotation (0.9f, rx, ry);
        for (int i = 0; i < 12; ++i)
        {
            g.setColour (juce::Colour (0xffffb000).withAlpha (0.5f * (1.f - (float) i / 12.f)));
            g.fillEllipse (rx - (float) i * 3.5f - 2.f, ry + (float) i * 3.2f - 2.f, 5.f - (float) i * 0.3f, 5.f - (float) i * 0.3f);
        }
        juce::Path rk; rk.addRoundedRectangle (rx - 3.f, ry - 12.f, 6.f, 20.f, 2.f); rk.addTriangle (rx - 3.f, ry - 12.f, rx + 3.f, ry - 12.f, rx, ry - 20.f);
        g.setColour (juce::Colours::white); g.fillPath (rk, rot);
        // artwork: drone (left), robot (right), big GITI logo (centre)
        if (drone.isValid())
        {
            const float dh = H * 0.62f, dw = dh * (float) drone.getWidth() / (float) drone.getHeight();
            g.drawImage (drone, juce::Rectangle<float> (W * 0.03f, H * 0.12f + std::sin (t * 1.1f) * 3.f, dw, dh), juce::RectanglePlacement::centred);
        }
        if (robot.isValid())
        {
            const float rh = H * 0.74f, rw = rh * (float) robot.getWidth() / (float) robot.getHeight();
            g.drawImage (robot, juce::Rectangle<float> (W - rw - W * 0.03f, H * 0.12f + std::sin (t * 0.9f + 1.f) * 3.f, rw, rh), juce::RectanglePlacement::centred);
        }
        if (logo.isValid())
        {
            const float lh = H * 0.94f, lw = lh * (float) logo.getWidth() / (float) logo.getHeight();
            auto box = juce::Rectangle<float> (W * 0.5f - lw * 0.5f, H * 0.03f, lw, lh);
            g.setGradientFill (juce::ColourGradient (juce::Colour (0xff35e6ff).withAlpha (0.10f + lv * 0.25f), box.getCentreX(), box.getCentreY(),
                                                     juce::Colours::transparentBlack, box.getCentreX() + lw * 0.7f, box.getCentreY(), true));
            g.fillRect (b);
            g.setOpacity (1.f);
            g.drawImage (logo, box.withSizeKeepingCentre (lw * (1.f + lv * 0.03f), lh * (1.f + lv * 0.03f)), juce::RectanglePlacement::centred);
        }
        // frame
        g.setColour (juce::Colour (0xff73c9c5).withAlpha (0.6f)); g.drawRect (b, 1.f);
    }
private:
    struct Star { float x, y, ph, r; };
    void timerCallback() override
    {
        if (! isShowing()) return;
        t += 0.033f;
        const float tgt = getLevel ? juce::jlimit (0.f, 1.f, getLevel() * 5.f) : 0.f;
        level += (tgt - level) * (tgt > level ? 0.4f : 0.1f);
        repaint();
    }
    std::array<Star, 90> stars;
    float t = 0.f, level = 0.f;
};
