// (included by PluginProcessor.cpp)

std::unique_ptr<juce::XmlElement> SalekHightechAudioProcessor::matrixWithExtras()
{
    std::unique_ptr<juce::XmlElement> m = modMatrix.toXml();
    if (m == nullptr) m = std::make_unique<juce::XmlElement> ("MOD_MATRIX");
    if (auto* old = m->getChildByName ("EXTRAS")) m->removeChildElement (old, true);
    auto* ex = m->createNewChildElement ("EXTRAS");

    auto* seq = ex->createNewChildElement ("SEQ");
    seq->setAttribute ("len", stepSequencer.getPatternLength());
    for (int i = 0; i < 16; ++i)
    {
        const auto& st = stepSequencer.getStep (i);
        auto* e = seq->createNewChildElement ("S");
        e->setAttribute ("i", i);
        e->setAttribute ("off", st.noteOffset.load());
        e->setAttribute ("vel", (double) st.velocity.load());
        e->setAttribute ("gate", (double) st.gate.load());
        e->setAttribute ("prob", (double) st.probability.load());
        e->setAttribute ("mod", (double) st.modValue.load());
        e->setAttribute ("act", st.active.load() ? 1 : 0);
        e->setAttribute ("acc", st.accent.load() ? 1 : 0);
    }

    const salek::LFO* lfos[3] = { &lfo1, &lfo2, &lfo3 };
    for (int n = 0; n < 3; ++n)
    {
        auto* L = ex->createNewChildElement ("LFO");
        L->setAttribute ("n", n);
        juce::String vals;
        for (int k = 0; k < salek::LFO::TableSize; ++k)
            vals << juce::String (lfos[n]->getCustomPoint (k), 5) << ',';
        L->setAttribute ("v", vals);
    }
    return m;
}

void SalekHightechAudioProcessor::applyExtras (const juce::XmlElement* matrixXml)
{
    if (matrixXml == nullptr) return;
    const auto* ex = matrixXml->getChildByName ("EXTRAS");
    if (ex == nullptr) return;   // older saves: keep the current pattern / shapes

    if (const auto* seq = ex->getChildByName ("SEQ"))
    {
        stepSequencer.setPatternLength (seq->getIntAttribute ("len", 16));
        for (auto* e : seq->getChildIterator())
        {
            if (! e->hasTagName ("S")) continue;
            const int i = e->getIntAttribute ("i", -1);
            if (i < 0 || i >= 16) continue;
            auto& st = stepSequencer.getStep (i);
            st.noteOffset.store (e->getIntAttribute ("off", 0));
            st.velocity.store ((float) e->getDoubleAttribute ("vel", 0.8));
            st.gate.store ((float) e->getDoubleAttribute ("gate", 0.7));
            st.probability.store ((float) e->getDoubleAttribute ("prob", 1.0));
            st.modValue.store ((float) e->getDoubleAttribute ("mod", 0.0));
            st.active.store (e->getIntAttribute ("act", 0) != 0);
            st.accent.store (e->getIntAttribute ("acc", 0) != 0);
        }
    }

    salek::LFO* lfos[3] = { &lfo1, &lfo2, &lfo3 };
    for (auto* L : ex->getChildIterator())
    {
        if (! L->hasTagName ("LFO")) continue;
        const int n = L->getIntAttribute ("n", -1);
        if (n < 0 || n > 2) continue;
        const auto parts = juce::StringArray::fromTokens (L->getStringAttribute ("v"), ",", "");
        const int count = juce::jmin (parts.size(), salek::LFO::TableSize);
        for (int k = 0; k < count; ++k)
            lfos[n]->setCustomPoint (k, juce::jlimit (-1.f, 1.f, (float) parts[k].getDoubleValue()));
    }
}
