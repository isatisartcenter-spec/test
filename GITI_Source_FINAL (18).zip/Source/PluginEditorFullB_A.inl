int SalekHightechAudioProcessorEditor::getNumRows() { return presetRows.size(); }

void SalekHightechAudioProcessorEditor::paintListBoxItem (int row, juce::Graphics& g, int width, int height, bool selected)
{
    if (! juce::isPositiveAndBelow (row, presetRows.size())) return;
    const auto& pr = presetRows.getReference (row);

    if (pr.isHeader)
    {
        auto cat = pr.category.toUpperCase();
        juce::Colour catCol (0xffff2ec8);
        juce::String icon = "*";
        if (cat.contains ("BASS"))      { catCol = juce::Colour (0xff66ff99); icon = "B"; }
        else if (cat.contains ("KICK")) { catCol = juce::Colour (0xffffab40); icon = "K"; }
        else if (cat.contains ("LEAD")) { catCol = juce::Colour (0xff00e8ff); icon = "L"; }
        else if (cat.contains ("PAD"))  { catCol = juce::Colour (0xffb388ff); icon = "P"; }
        else if (cat.contains ("ACID")) { catCol = juce::Colour (0xffffcc44); icon = "A"; }
        else if (cat.contains ("FM"))   { catCol = juce::Colour (0xffff66cc); icon = "F"; }
        else if (cat.contains ("FX"))   { catCol = juce::Colour (0xffff5252); icon = "X"; }
        else if (cat.contains ("ARP"))  { catCol = juce::Colour (0xff69f0ae); icon = "R"; }
        else if (cat == "GITI") { catCol = juce::Colour (0xffffd86b); icon = "✦"; }
        else if (cat.contains ("SALEK")) { catCol = juce::Colour (0xffffd700); icon = "S"; }
        else if (cat.contains ("USER")) { catCol = juce::Colour (0xffffaa00); icon = "U"; }
        else if (cat.contains ("RETRO")){ catCol = juce::Colour (0xffa0a0ff); icon = "R"; }
        else if (cat.contains ("OTHER")){ catCol = juce::Colour (0xff90a4ae); icon = "."; }

        g.setGradientFill (juce::ColourGradient (catCol.withAlpha (0.28f), 0.f, 0.f, juce::Colour (0xee080a1c), 0.f, (float) height, false));
        g.fillRoundedRectangle (1.f, 1.f, (float) width - 2.f, (float) height - 2.f, 6.f);
        g.setColour (juce::Colours::white.withAlpha (row == presetHoverRow ? 0.16f : 0.08f));
        g.drawLine (8.f, 2.f, (float) width - 8.f, 2.f, 1.f);
        g.setColour (catCol.withAlpha (0.55f));
        g.drawRoundedRectangle (1.5f, 1.5f, (float) width - 3.f, (float) height - 3.f, 6.f, 1.2f);

        auto badge = juce::Rectangle<float> (6.f, (float) height * 0.15f, (float) height * 0.7f, (float) height * 0.7f);
        g.setColour (catCol.withAlpha (0.25f));
        g.fillEllipse (badge);
        g.setColour (catCol);
        g.drawEllipse (badge, 1.2f);
        g.setFont (juce::FontOptions (badge.getHeight() * 0.55f, juce::Font::bold));
        g.drawText (icon, badge.toNearestInt(), juce::Justification::centred);

        const bool folded = collapsedCats.contains (pr.category);
        g.setColour (catCol.brighter (0.2f));
        g.setFont (juce::FontOptions (11.5f, juce::Font::bold));
        juce::String mark = folded ? "> " : "v ";
        const auto headerText = pr.itemCount >= 0
            ? pr.label + "   ·   " + juce::String (pr.itemCount).paddedLeft ('0', 2) + " PRESETS"
            : pr.label;
        g.drawText (mark + headerText, (int) badge.getRight() + 6, 0, width - (int) badge.getRight() - 10, height,
                    juce::Justification::centredLeft);
        return;
    }

    const bool hovered = (row == presetHoverRow) && ! selected;
    {
        const auto face = juce::Rectangle<float> (3.f, 1.5f, (float) width - 6.f, (float) height - 3.f);
        const auto teal = SalekLookAndFeel::teal(), rose = SalekLookAndFeel::rose();
        // 3D base: lit top edge, darker bottom edge
        const juce::Colour top = selected ? teal.withAlpha (0.30f) : (hovered ? juce::Colour (0xff25306a) : ((row & 1) == 0 ? juce::Colour (0xff111633) : juce::Colour (0xff0d1128)));
        const juce::Colour bot = selected ? rose.withAlpha (0.22f) : (hovered ? juce::Colour (0xff171d48) : juce::Colour (0xff080a1c));
        if (selected || hovered)   // outer glow
        {
            g.setColour ((selected ? teal : rose).withAlpha (selected ? 0.20f : 0.12f));
            g.fillRoundedRectangle (face.expanded (2.f), 7.f);
        }
        g.setColour (juce::Colours::black.withAlpha (0.45f));
        g.fillRoundedRectangle (face.translated (0.f, 1.5f), 5.f);                       // drop shadow
        g.setGradientFill (juce::ColourGradient (top, face.getX(), face.getY(), bot, face.getX(), face.getBottom(), false));
        g.fillRoundedRectangle (face, 5.f);
        g.setColour (juce::Colours::white.withAlpha (selected ? 0.20f : (hovered ? 0.14f : 0.07f)));
        g.drawLine (face.getX() + 6.f, face.getY() + 1.f, face.getRight() - 6.f, face.getY() + 1.f, 1.f);   // top bevel
        g.setColour ((selected ? teal : (hovered ? rose : SalekLookAndFeel::border())).withAlpha (selected ? 0.95f : (hovered ? 0.70f : 0.28f)));
        g.drawRoundedRectangle (face, 5.f, selected ? 1.3f : 1.f);
        if (selected)
        {
            g.setColour (teal);
            g.fillRoundedRectangle (face.getX() + 1.5f, face.getY() + 4.f, 3.f, face.getHeight() - 8.f, 1.5f);
        }
        // index number (muted) + hover chevron
        g.setColour (juce::Colour (0xff7f8fc4).withAlpha (selected ? 0.95f : 0.65f));
        g.setFont (juce::FontOptions (9.5f, juce::Font::bold));
        g.drawText (juce::String (pr.programIndex + 1).paddedLeft ('0', 3), (int) face.getX() + 8, 0, 26, height, juce::Justification::centredLeft);
        if (hovered || selected)
        {
            juce::Path chev;
            const float cx = face.getRight() - 12.f, cy = face.getCentreY();
            chev.startNewSubPath (cx - 2.5f, cy - 4.f); chev.lineTo (cx + 2.f, cy); chev.lineTo (cx - 2.5f, cy + 4.f);
            g.setColour ((selected ? teal : rose).withAlpha (0.95f));
            g.strokePath (chev, juce::PathStrokeType (1.8f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }
    }

    juce::Colour tc = selected ? juce::Colour (0xffbff6ff) : juce::Colour (0xffd3dce7);
    auto fullName = processor.getProgramName (pr.programIndex);
    if (fullName.startsWith ("Acid"))  tc = selected ? tc : juce::Colour (0xffffcc44);
    if (fullName.startsWith ("Bass"))  tc = selected ? tc : juce::Colour (0xff66ff99);
    if (fullName.startsWith ("Lead"))  tc = selected ? tc : juce::Colour (0xff00f0ff);
    if (fullName.startsWith ("Kick"))  tc = selected ? tc : juce::Colour (0xffffab40);
    if (fullName.startsWith ("FM"))    tc = selected ? tc : juce::Colour (0xffff66cc);
    if (fullName.startsWith ("Retro")) tc = selected ? tc : juce::Colour (0xffa0a0ff);
    if (fullName.startsWith ("SALEK")) tc = selected ? tc : juce::Colour (0xffffd700);
    if (pr.category == "GITI") tc = selected ? tc : juce::Colour (0xffffd86b);
    if (fullName.startsWith ("USER"))  tc = selected ? tc : juce::Colour (0xffffaa00);
    if (pr.category == "GITI" && ! selected)
    {
        const auto description = processor.getProgramDescription (pr.programIndex);
        if (description.contains ("/ Breath"))       tc = juce::Colour (0xff50e6ff);
        else if (description.contains ("/ Strings")) tc = juce::Colour (0xffb69cff);
        else if (description.contains ("/ Voice"))   tc = juce::Colour (0xffff7cc8);
        else if (description.contains ("/ Pulse"))   tc = juce::Colour (0xffffad66);
        else if (description.contains ("/ Earth & Water")) tc = juce::Colour (0xff70e6b0);
    }

    g.setColour (tc);
    g.setFont (juce::FontOptions (selected ? 13.0f : 12.2f, selected ? juce::Font::bold : juce::Font::plain));
    g.drawText (pr.label, 38 + (hovered ? 2 : 0), 0, width - 58, height, juce::Justification::centredLeft);
}

void SalekHightechAudioProcessorEditor::listBoxItemClicked (int row, const juce::MouseEvent& e)
{
    if (! juce::isPositiveAndBelow (row, presetRows.size())) return;
    const auto pr = presetRows.getReference (row);
    if (e.mods.isPopupMenu())
    {   // right-click: delete a bank / folder (or one of your own presets)
        juce::PopupMenu m;
        if (pr.isHeader)
        {
            const auto path = pr.category;
            m.addItem (1, "Delete this " + juce::String (path.containsChar ('/') ? "folder" : "bank") + "  (" + path + ")");
            m.showMenuAsync (juce::PopupMenu::Options(), [this, alive = editorAlive, path] (int r)
            {
                if (! *alive) return;
                if (r != 1) return;
                juce::AlertWindow::showOkCancelBox (juce::MessageBoxIconType::WarningIcon, "Delete presets",
                    "Delete \"" + path + "\" and all its presets?\n(a purchased bank file is removed from this computer; you can install it again later)",
                    "Delete", "Cancel", nullptr,
                    juce::ModalCallbackFunction::create ([this, alive = editorAlive, path] (int ok)
                    {
                        if (! *alive) return;
                        if (ok != 1) return;
                        const int n = processor.deletePresets (path);
                        presetLabel.setText ("Deleted " + juce::String (n) + " presets", juce::dontSendNotification);
                        rebuildPresetRows(); presetList.updateContent(); presetList.repaint();
                    }));
            });
            return;
        }
        if (pr.programIndex > 0)
        {
            const bool user = processor.getProgramName (pr.programIndex).startsWith ("USER/");
            m.addItem (2, user ? "Delete this preset" : "Delete the folder or bank instead (right-click its header)", user);
            const int idx = pr.programIndex;
            m.showMenuAsync (juce::PopupMenu::Options(), [this, alive = editorAlive, idx] (int r)
            {
                if (! *alive) return;
                if (r != 2) return;
                if (processor.deleteUserPreset (idx)) { rebuildPresetRows(); presetList.updateContent(); presetList.repaint(); }
            });
        }
        return;
    }
    if (pr.isHeader)
    {
        if (collapsedCats.contains (pr.category))
            collapsedCats.removeString (pr.category);
        else
            collapsedCats.add (pr.category);
        rebuildPresetRows();
        return;
    }
    if (pr.programIndex < 0) return;
    processor.setCurrentProgram (pr.programIndex);
    presetLabel.setText (processor.getProgramName (pr.programIndex), juce::dontSendNotification);
    presetLabel.setTooltip (processor.getProgramDescription (pr.programIndex));
}

#include "PluginEditorPaint.inl"

void SalekHightechAudioProcessorEditor::syncFilterLamps()
{
    const char* pid = filterSel == 0 ? "filter1_src" : "filter2_src";
    if (auto* raw = processor.getAPVTS().getRawParameterValue (pid))
    {
        const int mask = (int) std::lround (raw->load());
        for (int i = 0; i < 5; ++i)
        {
            const bool on = ((mask >> i) & 1) != 0;
            if (filterLed[i].getToggleState() != on)
                filterLed[i].setToggleState (on, juce::dontSendNotification);
        }
    }
}

void SalekHightechAudioProcessorEditor::updateModBadges()
{
    const auto& routes = processor.getModMatrix().getRoutes();
    for (auto& k : knobs)
    {
        if (k == nullptr) continue;
        salek::ModMatrix::Dest d;
        int mask = 0;
        if (salek::paramIdToDest (k->paramId, d))
            for (auto& r : routes)
                if (r.active.load() && r.dest.load() == d && std::abs (r.amount.load()) > 1.0e-4f)
                {
                    const int s = (int) r.source.load();
                    if (s >= 0 && s < 3) mask |= (1 << s);
                }
        const int old = (int) k->s.getProperties().getWithDefault ("mod_mask", 0);
        if (old != mask)
        {
            k->s.getProperties().set ("mod_mask", mask);
            k->s.repaint();
        }
    }
}

void SalekHightechAudioProcessorEditor::timerCallback()
{
    ++layoutRecoveryTicks;
    if ((layoutRecoveryTicks % 3) == 0) { syncFilterLamps(); updateModBadges(); }
    if ((layoutRecoveryTicks % 2) == 0) logoOverlay.repaint();
    // Some DAWs hide the editor during minimize/restore without sending a
    // resize. Detect the visibility transition and rebuild once bounds settle.
    const bool showing = isShowing();
    const bool oscMonitorsShowing = showing && oscTab.isShowing();
    if (oscMon1 != nullptr) oscMon1->setMonitoringActive (oscMonitorsShowing);
    if (oscMon2 != nullptr) oscMon2->setMonitoringActive (oscMonitorsShowing);
    if (oscMon3 != nullptr) oscMon3->setMonitoringActive (oscMonitorsShowing);
    if (showing && ! editorWasShowing)
        restoreLayoutDelay = 1;
    editorWasShowing = showing;
    if (showing && restoreLayoutDelay > 0 && getWidth() >= 900 && getHeight() >= 600)
    {
        --restoreLayoutDelay;
        if (restoreLayoutDelay == 0)
        {
            resized();
            repaint();
        }
    }
    // Slow safety net if the host drops child bounds but keeps the top-level
    // editor visible. Avoid running it during an active mouse gesture.
    if ((layoutRecoveryTicks % 15) == 0 && showing && getWidth() >= 900 && getHeight() >= 600
        && ! juce::Desktop::getInstance().getMainMouseSource().isDragging())
    {
        const int tab = tabs.getCurrentTabIndex();
        const juce::Component* active = tab == 0 ? &mainTab : tab == 1 ? &modTab
            : tab == 2 ? &lfoTab : tab == 3 ? &fxTab : tab == 4 ? &magicTab
            : tab == 5 ? &seqTab : tab == 6 ? &speedTab : &aboutTab;
        if (tabs.getWidth() < 500 || tabs.getHeight() < 300
            || active->getWidth() < 400 || active->getHeight() < 250)
            resized();
    }
    animPhase += 0.02f;
    if (lfoFrames) { lfoFrames->setBounds (lfoTab.getLocalBounds()); lfoFrames->toBack(); lfoFrames->repaint(); }
    if (modFrames) { modFrames->setBounds (modTab.getLocalBounds()); modFrames->toBack(); modFrames->repaint(); }
    magicRndBtn.setBounds (magicTab.getWidth() - 124, 6, 116, 26);
    magicRndBtn.toFront (false);
    processor.updateCustomWavetableIfChanged();
    if (magicPad) magicPad->setAudioPeak (processor.getOutputPeak());
    if ((int) (animPhase * 50.f) % 6 == 0)
    {   // highlight the basic-waveform button that matches each oscillator's current table
        static const char* tid[3] = { "osc1_table", "osc2_table", "osc3_table" };
        static const int wt[6] = { 0, 1, 2, 3, 4, 24 };
        for (int c = 0; c < 3; ++c)
            if (auto* v = processor.getAPVTS().getRawParameterValue (tid[c]))
                for (int i = 0; i < 6; ++i)
                {
                    const bool on = std::abs (v->load() - (float) wt[i] / 127.0f) < 0.0035f;
                    if (waveQuick[c][i].getToggleState() != on) waveQuick[c][i].setToggleState (on, juce::dontSendNotification);
                }
    }
    if ((armedModSource >= 0 || isModDragging) && ! juce::ModifierKeys::getCurrentModifiersRealtime().isAnyMouseButtonDown())
    {   // a drag-and-drop ended: never stay armed (otherwise every later click would connect)
        armedModSource = -1;
        isModDragging = false;
        modSrcLfo1.setToggleState (false, juce::dontSendNotification);
        modSrcLfo2.setToggleState (false, juce::dontSendNotification);
        modSrcLfo3.setToggleState (false, juce::dontSendNotification);
        repaint();
    }
    if (auto* mo = processor.getAPVTS().getRawParameterValue ("magic_on"))
    {   // keep HOLD in step with the real Magic state, so one click always turns it off
        const bool on = mo->load() > 0.5f;
        if (magicHold.getToggleState() != on) magicHold.setToggleState (on, juce::dontSendNotification);
        if (! on)
            for (int i = 0; i < 4; ++i)
            {
                holdOn[i] = false;
                if (auto* hb = dynamic_cast<juce::Button*> (magicTab.findChildWithID ("mhold" + juce::String (i))))
                    if (hb->getToggleState()) hb->setToggleState (false, juce::dontSendNotification);
            }
    }
    if ((tabs.getCurrentTabIndex() == 0) != stageOnMain) resized();   // move the big visualizer between MAIN stage and header

    // Keep the frame selectors in step with host automation and preset loads.
    {
        juce::ComboBox* selectors[] = { &osc1ShapeBox, &osc2ShapeBox, &osc3ShapeBox };
        const char* tableIds[] = { "osc1_table", "osc2_table", "osc3_table" };
        for (int i = 0; i < 3; ++i)
        {
            if (selectors[i]->isPopupActive()) continue;
            if (auto* p = processor.getAPVTS().getRawParameterValue (tableIds[i]))
            {
                const int lastFrame = juce::jmax (0, salek::SynthVoice::getSharedWavetable().getNumFrames() - 1);
                const int frame = juce::roundToInt (juce::jlimit (0.f, 1.f, p->load())
                                                     * (float) lastFrame);
                if (selectors[i]->getSelectedItemIndex() != frame)
                    selectors[i]->setSelectedItemIndex (frame, juce::dontSendNotification);
            }
        }
    }

    // FX mini-monitors read their atomic parameter/activity sources directly at
    // 30 Hz, so their response no longer waits for this light editor timer.
    // NEVER full-editor repaint every tick — was freezing multi-instance FL
    // Light pulse only for mod source glow
    // Pulse LFO pills only when armed
    if (armedModSource >= 0 && (layoutRecoveryTicks % 4) == 0)
    {
        if (armedModSource == 0) modSrcLfo1.repaint();
        if (armedModSource == 1) modSrcLfo2.repaint();
        if (armedModSource == 2) modSrcLfo3.repaint();
    }
}
