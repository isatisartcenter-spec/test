#pragma once
#include "PluginProcessor.h"
#include "UpdateConfig.h"
#include <functional>
#include <memory>
#include <vector>

// GITI STORE: the customer enters the e-mail used for the purchase ("ACTIVATE"); the plugin then asks the
// store address for the packs of that e-mail and can download + install them (.gitibank).
// Server answer (JSON):
//   { "packs": [ { "id":"bass1", "name":"Psy Bass Vol.1", "desc":"40 presets", "price":"$9",
//                  "owned": true,  "url":"https://.../bass1.gitibank",  "buy":"https://.../buy/bass1" } ] }
class StorePanel : public juce::Component
{
public:
    StorePanel (SalekHightechAudioProcessor& p, std::function<void()> onChanged) : proc (p), changed (std::move (onChanged))
    {
        setSize (580, 470);
        auto style = [this] (juce::Label& l, float sz, juce::Colour c, bool bold = false)
        { l.setFont (juce::FontOptions (sz, bold ? juce::Font::bold : juce::Font::plain)); l.setColour (juce::Label::textColourId, c); addAndMakeVisible (l); };
        style (head, 20.f, juce::Colour (0xff35e6ff), true);   head.setText ("GITI STORE", juce::dontSendNotification);
        style (hint, 12.f, juce::Colour (0xffb8c4e8));
        hint.setText ("Enter the e-mail you bought with. Your packs unlock for that e-mail only.", juce::dontSendNotification);
        style (status, 12.f, juce::Colour (0xffffc861));
        emailBox.setText (proc.getAccountEmail(), false);
        emailBox.setTextToShowWhenEmpty ("you@example.com", juce::Colours::grey);
        addAndMakeVisible (emailBox);
        activateBtn.setButtonText ("ACTIVATE"); addAndMakeVisible (activateBtn);
        refreshBtn.setButtonText ("REFRESH STORE"); addAndMakeVisible (refreshBtn);
        installBtn.setButtonText ("INSTALL FROM FILE..."); addAndMakeVisible (installBtn);
        viewport.setViewedComponent (&list, false); viewport.setScrollBarsShown (true, false); addAndMakeVisible (viewport);
        activateBtn.onClick = [this]
        {
            proc.setAccountEmail (emailBox.getText());
            status.setText (emailBox.getText().isEmpty() ? "E-mail cleared." : "Activated for " + emailBox.getText().trim() + ". Installed packs were re-checked.", juce::dontSendNotification);
            if (changed) changed();
            refresh();
        };
        refreshBtn.onClick = [this] { refresh(); };
        installBtn.onClick = [this]
        {
            chooser = std::make_shared<juce::FileChooser> ("Install a GITI bank", juce::File::getSpecialLocation (juce::File::userDocumentsDirectory), "*.gitibank");
            chooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles, [this, alive = alive] (const juce::FileChooser& fc)
            {
                if (! *alive) return;
                auto f = fc.getResult();
                if (f != juce::File()) report (proc.installEncryptedBank (f));
            });
        };
        refresh();
    }

    void paint (juce::Graphics& g) override
    {
        g.fillAll (juce::Colour (0xff0b0d26));
        g.setColour (juce::Colour (0xff35e6ff).withAlpha (0.4f));
        g.drawRect (getLocalBounds(), 1);
    }

    void resized() override
    {
        auto r = getLocalBounds().reduced (16);
        head.setBounds (r.removeFromTop (28));
        hint.setBounds (r.removeFromTop (20));
        r.removeFromTop (6);
        auto row = r.removeFromTop (30);
        activateBtn.setBounds (row.removeFromRight (110).reduced (2, 0));
        emailBox.setBounds (row.reduced (2, 0));
        r.removeFromTop (6);
        auto row2 = r.removeFromTop (28);
        refreshBtn.setBounds (row2.removeFromLeft (150).reduced (2, 0));
        installBtn.setBounds (row2.removeFromLeft (190).reduced (2, 0));
        status.setBounds (r.removeFromBottom (36));
        r.removeFromTop (6);
        viewport.setBounds (r);
        layoutList();
    }

private:
    struct PackRow : public juce::Component
    {
        juce::Label name, desc, price;
        juce::TextButton btn;
        juce::String url, buy; bool owned = false;
        PackRow()
        {
            name.setFont (juce::FontOptions (15.f, juce::Font::bold)); name.setColour (juce::Label::textColourId, juce::Colours::white);
            desc.setFont (juce::FontOptions (12.f)); desc.setColour (juce::Label::textColourId, juce::Colour (0xffb8c4e8));
            price.setFont (juce::FontOptions (13.f, juce::Font::bold)); price.setColour (juce::Label::textColourId, juce::Colour (0xffffc861));
            price.setJustificationType (juce::Justification::centredRight);
            addAndMakeVisible (name); addAndMakeVisible (desc); addAndMakeVisible (price); addAndMakeVisible (btn);
        }
        void paint (juce::Graphics& g) override
        {
            g.setColour (juce::Colour (0xff141838)); g.fillRoundedRectangle (getLocalBounds().toFloat().reduced (2.f), 6.f);
            g.setColour (juce::Colour (0xff73c9c5).withAlpha (0.35f)); g.drawRoundedRectangle (getLocalBounds().toFloat().reduced (2.f), 6.f, 1.f);
        }
        void resized() override
        {
            auto r = getLocalBounds().reduced (10, 6);
            btn.setBounds (r.removeFromRight (110).withSizeKeepingCentre (110, 30));
            price.setBounds (r.removeFromRight (70));
            name.setBounds (r.removeFromTop (22));
            desc.setBounds (r);
        }
    };

    void layoutList()
    {
        const int w = juce::jmax (100, viewport.getWidth() - (viewport.isVerticalScrollBarShown() ? 14 : 2));
        int y = 0;
        for (auto& r : rows) { r->setBounds (0, y, w, 64); y += 68; }
        list.setSize (w, juce::jmax (y, 10));
    }

    void report (int n)
    {
        if (n > 0)      status.setText ("Installed " + juce::String (n) + " presets.", juce::dontSendNotification);
        else if (n == -2) status.setText ("This bank is locked to another e-mail. Enter your purchase e-mail and press ACTIVATE.", juce::dontSendNotification);
        else            status.setText ("Invalid or damaged bank file.", juce::dontSendNotification);
        if (changed) changed();
    }

    void refresh()
    {
        status.setText ("Contacting the store...", juce::dontSendNotification);
        juce::Component::SafePointer<StorePanel> safe (this);
        const auto email = emailBox.getText().trim();
        juce::Thread::launch ([safe, email]
        {
            auto text = juce::URL (GITI_STORE_URL).withParameter ("email", email).readEntireTextStream (false);
            auto info = juce::JSON::parse (text);
            juce::MessageManager::callAsync ([safe, info]
            {
                if (safe == nullptr) return;
                safe->showPacks (info);
            });
        });
    }

    void showPacks (const juce::var& info)
    {
        rows.clear(); list.removeAllChildren();
        auto* packs = info.isObject() ? info.getProperty ("packs", juce::var()).getArray() : nullptr;
        if (packs == nullptr)
        {
            status.setText ("Could not reach the store (check internet or the store address). You can still INSTALL FROM FILE.", juce::dontSendNotification);
            layoutList(); return;
        }
        for (auto& p : *packs)
        {
            auto row = std::make_unique<PackRow>();
            row->name.setText (p.getProperty ("name", "").toString(), juce::dontSendNotification);
            row->desc.setText (p.getProperty ("desc", "").toString(), juce::dontSendNotification);
            row->price.setText (p.getProperty ("price", "").toString(), juce::dontSendNotification);
            row->owned = (bool) p.getProperty ("owned", false);
            row->url = p.getProperty ("url", "").toString();
            row->buy = p.getProperty ("buy", "").toString();
            row->btn.setButtonText (row->owned ? "INSTALL" : "BUY");
            auto* rp = row.get();
            row->btn.onClick = [this, rp]
            {
                if (! rp->owned) { if (rp->buy.isNotEmpty()) juce::URL (rp->buy).launchInDefaultBrowser(); return; }
                download (rp->url);
            };
            list.addAndMakeVisible (*row);
            rows.push_back (std::move (row));
        }
        status.setText (rows.empty() ? "No packs available yet." : juce::String ((int) rows.size()) + " packs.", juce::dontSendNotification);
        layoutList();
    }

    void download (const juce::String& link)
    {
        if (link.isEmpty()) return;
        status.setText ("Downloading...", juce::dontSendNotification);
        juce::Component::SafePointer<StorePanel> safe (this);
        const auto email = emailBox.getText().trim();
        juce::Thread::launch ([safe, link, email]
        {
            juce::MemoryBlock data;
            bool ok = false;
            auto stream = juce::URL (link).withParameter ("email", email).createInputStream (
                juce::URL::InputStreamOptions (juce::URL::ParameterHandling::inAddress).withConnectionTimeoutMs (20000));
            if (stream != nullptr) { stream->readIntoMemoryBlock (data); ok = data.getSize() > 64; }
            juce::MessageManager::callAsync ([safe, data, ok]
            {
                if (safe == nullptr) return;
                if (! ok) { safe->status.setText ("Download failed.", juce::dontSendNotification); return; }
                auto tmp = juce::File::getSpecialLocation (juce::File::tempDirectory).getChildFile ("giti_download_" + juce::String (juce::Time::currentTimeMillis()) + ".gitibank");
                tmp.replaceWithData (data.getData(), data.getSize());
                safe->report (safe->proc.installEncryptedBank (tmp));
                tmp.deleteFile();
            });
        });
    }

    SalekHightechAudioProcessor& proc;
    std::function<void()> changed;
    juce::Label head, hint, status;
    juce::TextEditor emailBox;
    juce::TextButton activateBtn, refreshBtn, installBtn;
    juce::Viewport viewport;
    juce::Component list;
    std::vector<std::unique_ptr<PackRow>> rows;
    std::shared_ptr<juce::FileChooser> chooser;
    std::shared_ptr<bool> alive = std::make_shared<bool> (true);   // false when the panel is closed (async callbacks check it)
    ~StorePanel() override { *alive = false; }
};
