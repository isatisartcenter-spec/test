#pragma once
#include <JuceHeader.h>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdint>

namespace salek
{

class StepSequencer
{
public:
    static constexpr int NumSteps = 16;

    struct Step
    {
        // These fields are edited by the UI while the audio thread reads them.
        // Atomics avoid racing on the live pattern without locking the callback.
        std::atomic<int> noteOffset { 0 };
        std::atomic<float> velocity { 0.8f };
        std::atomic<float> gate { 0.7f };
        std::atomic<float> probability { 1.0f };
        std::atomic<float> modValue { 0.0f };
        std::atomic<bool> active { false };
        std::atomic<bool> accent { false };
    };

    void prepare (double sampleRate)
    {
        sr = sampleRate > 0.0 ? sampleRate : 44100.0;
        updateTiming();
    }

    void setBpm (double b) noexcept
    {
        bpm = juce::jlimit (20.0, 300.0, b);
        updateTiming();
    }

    void setRateDivisor (int div) noexcept
    {
        rateDivisor = juce::jlimit (1, 16, div);
        updateTiming();
    }

    int  getPatternLength() const noexcept { return patternLength; }
    void setPatternLength (int length) noexcept { patternLength = juce::jlimit (1, NumSteps, length); }
    void setSwing (float amount) noexcept { swing = juce::jlimit (0.0f, 0.75f, amount); }
    void setGate (float amount) noexcept { gateAmount = juce::jlimit (0.05f, 1.0f, amount); }

    bool isEnabled() const noexcept { return enabled.load (std::memory_order_relaxed); }

    void setEnabled (bool e) noexcept
    {
        const bool wasEnabled = enabled.exchange (e, std::memory_order_relaxed);
        if (e && ! wasEnabled)
        {
            // process() advances before emitting; start one step before zero so
            // the first event after enabling is step 0.
            currentStep.store (patternLength - 1, std::memory_order_relaxed);
            samplesUntilNext = 0.0;
        }
    }

    /** Stop cleanly and release any generated note before disabling. */
    void stop (juce::MidiBuffer& outMidi, int samplePosition = 0) noexcept
    {
        if (currentNote >= 0)
            outMidi.addEvent (juce::MidiMessage::noteOff (1, currentNote), samplePosition);
        currentNote = -1;
        pendingNoteOff = -1;
        gateSamplesLeft = 0;
        hasRoot = false;
        currentMod.store (0.0f, std::memory_order_relaxed);
        enabled.store (false, std::memory_order_relaxed);
    }

    void setRootNote (int n) noexcept { rootNote = juce::jlimit (0, 127, n); hasRoot = true; }

    Step& getStep (int i) noexcept
    {
        return steps[static_cast<size_t> (juce::jlimit (0, NumSteps - 1, i))];
    }
    const Step& getStep (int i) const noexcept
    {
        return steps[static_cast<size_t> (juce::jlimit (0, NumSteps - 1, i))];
    }

    int getCurrentStep() const noexcept { return currentStep.load (std::memory_order_relaxed); }
    float getCurrentMod() const noexcept { return currentMod.load (std::memory_order_relaxed); }

    // Play / pause without losing the position (notes are released on pause)
    void setRunning (bool r, juce::MidiBuffer& outMidi) noexcept
    {
        if (running && ! r && currentNote >= 0)
            outMidi.addEvent (juce::MidiMessage::noteOff (1, currentNote), 0);
        if (running && ! r) { currentNote = -1; pendingNoteOff = -1; gateSamplesLeft = 0; }
        running = r;
    }
    bool isRunning() const noexcept { return running; }

    /** Jump to the step that belongs to this DAW position (quarter notes). Keeps the grid locked to the timeline. */
    void lockToPpq (double ppq) noexcept
    {
        const double stepsPerBeat = 4.0 * (double) juce::jmax (1, rateDivisor);
        const double sp = ppq * stepsPerBeat;
        const long long idx = (long long) std::floor (sp);
        const double frac = sp - (double) idx;
        const int k = (int) (((idx % patternLength) + patternLength) % patternLength);
        if (frac < 0.02) { currentStep.store ((k + patternLength - 1) % patternLength, std::memory_order_relaxed); samplesUntilNext = 0.0; }
        else             { currentStep.store (k, std::memory_order_relaxed); samplesUntilNext = (1.0 - frac) * samplesPerStep; }
    }

    void process (int numSamples, juce::MidiBuffer& outMidi)
    {
        if (! enabled.load (std::memory_order_relaxed) || ! running)
        {
            if (pendingNoteOff >= 0)
            {
                outMidi.addEvent (juce::MidiMessage::noteOff (1, pendingNoteOff), 0);
                pendingNoteOff = -1;
                currentNote = -1;
            }
            return;
        }

        for (int i = 0; i < numSamples; ++i)
        {
            if (gateSamplesLeft > 0)
            {
                --gateSamplesLeft;
                if (gateSamplesLeft == 0 && currentNote >= 0)
                {
                    outMidi.addEvent (juce::MidiMessage::noteOff (1, currentNote), i);
                    pendingNoteOff = -1;
                    currentNote = -1;
                }
            }

            samplesUntilNext -= 1.0;
            if (samplesUntilNext <= 0.0)
            {
                if (currentNote >= 0)
                {
                    outMidi.addEvent (juce::MidiMessage::noteOff (1, currentNote), i);
                    currentNote = -1;
                }

                const int nextStep = (currentStep.load (std::memory_order_relaxed) + 1) % patternLength;
                currentStep.store (nextStep, std::memory_order_relaxed);
                const bool oddStep = (nextStep & 1) != 0;
                samplesUntilNext += samplesPerStep * (oddStep ? (1.0 - swing) : (1.0 + swing));

                const auto& st = steps[static_cast<size_t> (nextStep)];
                const float stepMod = st.modValue.load (std::memory_order_relaxed);
                const bool stepActive = st.active.load (std::memory_order_relaxed);
                const float probability = st.probability.load (std::memory_order_relaxed);
                const int noteOffset = st.noteOffset.load (std::memory_order_relaxed);
                const float stepVelocity = st.velocity.load (std::memory_order_relaxed);
                const float stepGate = st.gate.load (std::memory_order_relaxed);
                const bool stepAccent = st.accent.load (std::memory_order_relaxed);
                currentMod.store (stepMod, std::memory_order_relaxed);

                if (hasRoot && stepActive && nextRandom() < probability)
                {
                    int note = juce::jlimit (0, 127, rootNote + noteOffset);
                    float vel = juce::jlimit (0.0f, 1.0f, stepAccent ? juce::jmin (1.0f, stepVelocity * 1.35f) : stepVelocity);
                    outMidi.addEvent (juce::MidiMessage::noteOn (1, note, vel), i);
                    currentNote = note;
                    pendingNoteOff = note;
                    gateSamplesLeft = (int) (samplesPerStep * juce::jlimit (0.05f, 1.0f, stepGate * gateAmount));
                }
            }
        }
    }

    void initDefaultPattern() { reset(); }

    void reset()
    {
        for (int i = 0; i < NumSteps; ++i)
        {
            steps[static_cast<size_t>(i)].active.store (false, std::memory_order_relaxed);
            steps[static_cast<size_t>(i)].noteOffset.store (0, std::memory_order_relaxed);
            steps[static_cast<size_t>(i)].velocity.store (0.8f, std::memory_order_relaxed);
            steps[static_cast<size_t>(i)].accent.store (false, std::memory_order_relaxed);
            steps[static_cast<size_t>(i)].gate.store (0.7f, std::memory_order_relaxed);
            steps[static_cast<size_t>(i)].probability.store (1.0f, std::memory_order_relaxed);
            steps[static_cast<size_t>(i)].modValue.store ((float) i / (float) juce::jmax (1, NumSteps - 1), std::memory_order_relaxed);
        }
        currentStep.store (0, std::memory_order_relaxed);
        currentMod.store (0.0f, std::memory_order_relaxed);
        samplesUntilNext = 0.0;
        currentNote = -1;
        pendingNoteOff = -1;
        gateSamplesLeft = 0;
    }

private:
    float nextRandom() noexcept
    {
        randomState ^= randomState << 13;
        randomState ^= randomState >> 17;
        randomState ^= randomState << 5;
        return static_cast<float> (randomState & 0x00ffffffu) / 16777216.0f;
    }

    void updateTiming()
    {
        // rateDivisor: 1 → 16th (4 steps/beat), 2 → 32nd (8 steps/beat), ...
        const double beatsPerSec = juce::jmax (1.0, bpm) / 60.0;
        const double stepsPerBeat = 4.0 * (double) juce::jmax (1, rateDivisor);
        samplesPerStep = sr / (beatsPerSec * stepsPerBeat);
        samplesPerStep = juce::jmax (1.0, samplesPerStep);
    }

    std::array<Step, NumSteps> steps {};
    double sr = 44100.0;
    double bpm = 120.0;
    int rateDivisor = 1;
    int patternLength = NumSteps;
    double swing = 0.0;
    float gateAmount = 1.0f;
    double samplesPerStep = 5512.5;
    double samplesUntilNext = 0.0;
    std::atomic<int> currentStep { 0 };
    int currentNote = -1;
    int pendingNoteOff = -1;
    int gateSamplesLeft = 0;
    int rootNote = 60;
    bool running = true;
    bool hasRoot = false;
    std::atomic<bool> enabled { false };
    std::atomic<float> currentMod { 0.0f };
    std::uint32_t randomState = 0x9e3779b9u;
};

} // namespace salek
