#pragma once

#include <JuceHeader.h>
#include <cmath>
#include <array>

namespace salek
{

/** Multi-mode filter bank — SVF core + cascade / comb / formant approximations.
    Real-time safe. Modes 0..23 selectable from the MAIN UI. */
class StateVariableFilter
{
public:
    enum class Mode
    {
        LowPass12 = 0,
        LowPass24,
        HighPass12,
        HighPass24,
        BandPass,
        Notch,
        Peak,
        AllPass,
        AcidLP,       // high-res LP with extra drive
        LadderSoft,   // softer 24dB-ish
        Comb,
        Formant,      // dual-peak vocal-ish
        BandReject,
        LowShelf,
        HighShelf,
        PhaserNotch,  // 15
        DiodeLP,       // 16 soft diode ladder colour
        SallenKey,     // 17
        Vocal,         // 18 formant-ish stronger
        RingMod,       // 19 AM with cutoff as carrier-ish
        BandPassQ,     // 20 narrow BP
        LpHpParallel,  // 21
        NotchDeep,     // 22
        WideShelf      // 23
    };

    void prepare (double sampleRate)
    {
        sr = sampleRate > 0.0 ? sampleRate : 44100.0;
        reset();
    }

    void reset() noexcept
    {
        ic1eq = ic2eq = 0.0f;
        ic1b = ic2b = 0.0f;
        combPos = 0;
        for (auto& s : combBuf) s = 0.f;
    }

    void setCutoff (float hz) noexcept
    {
        cutoff = juce::jlimit (10.0f, static_cast<float> (sr * 0.45), hz);
        update();
    }

    void setResonance (float res) noexcept
    {
        resonance = juce::jlimit (0.0f, 1.0f, res);
        update();
    }

    void setMode (Mode m) noexcept { mode = m; }
    void setModeIndex (int m) noexcept
    {
        mode = static_cast<Mode> (juce::jlimit (0, 23, m));
    }

    void setDrive (float d) noexcept
    {
        drive = juce::jlimit (0.0f, 1.0f, d);
    }

    float process (float x) noexcept
    {
        if (!std::isfinite (x)) x = 0.0f;
        x = juce::jlimit (-8.0f, 8.0f, x);
        // Pre-drive (stronger / more saturated for Acid & Ladder)
        float preDrive = drive;
        if (mode == Mode::AcidLP)
            preDrive = juce::jmin (1.f, drive + 0.35f + resonance * 0.2f);
        else if (mode == Mode::LadderSoft)
            preDrive = juce::jmin (1.f, drive + 0.22f);

        if (preDrive > 1.0e-4f)
        {
            const float g = 1.0f + preDrive * 5.5f;
            x = std::tanh (x * g) / g;
        }

        if (mode == Mode::Comb)
            return processComb (x);

        // Acid: inject nonlinear resonance feedback into input for classic squelch
        if (mode == Mode::AcidLP && resonance > 0.15f)
        {
            float fb = v2last * (resonance * resonance * 1.15f);
            fb = std::tanh (fb * 1.4f);
            x += fb * 0.55f;
        }

        // Primary SVF tick
        float y = tickSvf (x, ic1eq, ic2eq, a1, a2, a3, k);

        switch (mode)
        {
            case Mode::LowPass12:
                y = v2last; break;
            case Mode::AcidLP:
            {
                // 12dB core + soft diode-like soft clip on resonance peak
                y = v2last;
                float sat = 1.f + resonance * 1.6f + drive * 0.8f;
                y = std::tanh (y * sat) / sat;
                break;
            }
            case Mode::LowPass24:
            case Mode::LadderSoft:
            {
                // cascade second stage — Ladder uses asymmetric blend for 24dB-ish slope
                float y2 = tickSvf (v2last, ic1b, ic2b, a1b, a2b, a3b, k);
                if (mode == Mode::LadderSoft)
                {
                    y = v2last * 0.28f + y2 * 0.72f;
                    // soft ladder saturation
                    float sat = 1.f + resonance * 0.9f + drive * 0.5f;
                    y = std::tanh (y * sat) / sat;
                }
                else
                    y = y2;
                break;
            }
            case Mode::HighPass12:
                y = x - k * v1last - v2last; break;
            case Mode::HighPass24:
            {
                const float hp1 = x - k * v1last - v2last;
                // Reuse the same stable SVF state for the second high-pass
                // stage. Its high-pass output is x - k*v1 - v2; calling the
                // stage twice per sample advances its state at double speed.
                (void) tickSvf (hp1, ic1b, ic2b, a1b, a2b, a3b, k);
                y = hp1 - k * v1lastb - v2lastb;
                break;
            }
            case Mode::BandPass:
                y = v1last; break;
            case Mode::Notch:
            case Mode::BandReject:
                y = x - k * v1last; break;
            case Mode::Peak:
                y = x + v1last * (0.5f + resonance); break;
            case Mode::AllPass:
                // Sum the SVF high-pass and low-pass branches, then subtract
                // the damping term once more to produce a unity-magnitude AP.
                y = x - 2.f * k * v1last;
                break;
            case Mode::Formant:
            {
                // dual band peaks around cut and 1.6*cut
                float p1 = v1last;
                float y2 = tickSvf (x, ic1b, ic2b, a1b, a2b, a3b, k);
                y = (p1 + v1lastb) * (0.55f + resonance * 0.4f);
                juce::ignoreUnused (y2);
                break;
            }
            case Mode::LowShelf:
                y = x * (1.f - 0.4f * resonance) + v2last * (0.5f + resonance * 0.5f);
                break;
            case Mode::HighShelf:
                y = x * (0.5f + resonance * 0.4f) + (x - v2last) * 0.5f;
                break;
            case Mode::PhaserNotch:
                y = x - k * v1last - 0.35f * v2last;
                break;
            case Mode::DiodeLP:
                y = v2last;
                y = y / (1.f + std::abs (y) * (0.3f + resonance * 0.8f));
                break;
            case Mode::SallenKey:
                y = v2last * 0.7f + v1last * 0.3f;
                break;
            case Mode::Vocal:
            {
                float p1 = v1last;
                (void) tickSvf (x, ic1b, ic2b, a1b, a2b, a3b, k);
                y = (p1 * 0.6f + v1lastb * 0.8f) * (0.5f + resonance * 0.5f);
                break;
            }
            case Mode::RingMod:
                ringPhase += cutoff / static_cast<float> (sr);
                if (ringPhase >= 1.0f) ringPhase -= 1.0f;
                y = x * std::sin (ringPhase * juce::MathConstants<float>::twoPi);
                break;
            case Mode::BandPassQ:
                y = v1last * (1.f + resonance * 1.5f);
                break;
            case Mode::LpHpParallel:
                y = 0.5f * v2last + 0.5f * (x - k * v1last - v2last);
                break;
            case Mode::NotchDeep:
                y = x - k * v1last * (1.2f + resonance);
                break;
            case Mode::WideShelf:
                y = x * 0.4f + v2last * (0.6f + resonance * 0.3f);
                break;
            default:
                y = v2last; break;
        }

        // Resonance changes the filter response; it must not add a second,
        // broadband gain stage after the filter. Keep clean modes linear when
        // DRIVE is zero and add level-normalised saturation only on request.
        if (drive > 1.0e-4f && mode != Mode::AcidLP && mode != Mode::LadderSoft)
        {
            const float saturation = 1.0f + drive * 0.8f;
            y = std::tanh (y * saturation) / saturation;
        }
        return std::isfinite (y) ? juce::jlimit (-2.0f, 2.0f, y) : 0.0f;
    }

private:
    float tickSvf (float x, float& i1, float& i2,
                   float aa1, float aa2, float aa3, float kk) noexcept
    {
        const float v3 = x - i2;
        const float v1 = aa1 * i1 + aa2 * v3;
        const float v2 = i2 + aa2 * i1 + aa3 * v3;
        i1 = juce::jlimit (-8.0f, 8.0f, 2.0f * v1 - i1);
        i2 = juce::jlimit (-8.0f, 8.0f, 2.0f * v2 - i2);
        v1last = v1;
        v2last = v2;
        // secondary last for stage B tracked when using ic1b
        if (&i1 == &ic1b) { v1lastb = v1; v2lastb = v2; }
        juce::ignoreUnused (kk);
        return v2;
    }

    float processComb (float x) noexcept
    {
        const int maxD = (int) combBuf.size() - 1;
        int d = juce::jlimit (1, maxD, (int) (sr / juce::jmax (30.f, cutoff)));
        float delayed = combBuf[(size_t) ((combPos - d + (int) combBuf.size()) % (int) combBuf.size())];
        float fb = 0.2f + resonance * 0.75f;
        float y = x + delayed * fb;
        combBuf[(size_t) combPos] = y * 0.95f;
        combPos = (combPos + 1) % (int) combBuf.size();
        return std::tanh (y * (1.f + drive));
    }

    void update() noexcept
    {
        const float g = std::tan (juce::MathConstants<float>::pi * cutoff / static_cast<float> (sr));
        k = 2.0f - 1.92f * resonance;
        if (k < 0.08f) k = 0.08f;
        a1 = 1.0f / (1.0f + g * (g + k));
        a2 = g * a1;
        a3 = g * a2;

        // second stage slightly offset for 24dB / formant
        float cut2 = juce::jmin (static_cast<float> (sr * 0.45), cutoff * 1.35f);
        const float g2 = std::tan (juce::MathConstants<float>::pi * cut2 / static_cast<float> (sr));
        a1b = 1.0f / (1.0f + g2 * (g2 + k));
        a2b = g2 * a1b;
        a3b = g2 * a2b;
    }

    double sr = 44100.0;
    float cutoff = 1000.0f;
    float resonance = 0.2f;
    float drive = 0.0f;
    Mode mode = Mode::LowPass12;
    float ic1eq = 0.0f, ic2eq = 0.0f;
    float ic1b = 0.0f, ic2b = 0.0f;
    float k = 0.0f, a1 = 0.0f, a2 = 0.0f, a3 = 0.0f;
    float a1b = 0.0f, a2b = 0.0f, a3b = 0.0f;
    float v1last = 0.f, v2last = 0.f, v1lastb = 0.f, v2lastb = 0.f;
    float ringPhase = 0.0f;
    std::array<float, 2048> combBuf {};
    int combPos = 0;
};

} // namespace salek
