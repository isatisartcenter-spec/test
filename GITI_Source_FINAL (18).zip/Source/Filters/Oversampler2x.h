#pragma once
// 2x oversampling around a non-linear stage: zero-stuffed upsampling and half-band decimation
// (windowed-sinc, 31 taps, Blackman). The filter runs at 2x the host rate, so its tanh stages alias far less.
#include <array>
#include <cmath>

class Oversampler2x
{
public:
    Oversampler2x()
    {
        const int N = 31, M = (N - 1) / 2;
        float sum = 0.f;
        for (int n = 0; n < N; ++n)
        {
            const float k = (float) (n - M);
            const float sinc = (k == 0.f) ? 0.5f : std::sin (3.14159265f * 0.5f * k) / (3.14159265f * k);
            const float w = 0.42f - 0.5f * std::cos (2.f * 3.14159265f * (float) n / (float) (N - 1)) + 0.08f * std::cos (4.f * 3.14159265f * (float) n / (float) (N - 1));
            h[(size_t) n] = sinc * w;
            sum += h[(size_t) n];
        }
        for (auto& c : h) c /= sum;      // DC gain 1
    }

    void reset() noexcept { hist.fill (0.f); pos = 0; }

    // x: one base-rate sample. filt: any object with float process(float) that runs at 2x the rate.
    template <typename Filter>
    float process (float x, Filter& filt) noexcept
    {
        const float y0 = filt.process (fir (2.f * x));   // stuffed sample (gain 2 from zero stuffing)
        const float y1 = filt.process (fir (0.f));       // the odd (zero) sample
        fir (y0);                                        // decimation: only the odd output is kept
        return fir (y1);
    }

private:
    float fir (float in) noexcept
    {
        hist[(size_t) pos] = in;
        float acc = 0.f;
        int idx = pos;
        for (int n = 0; n < Taps; ++n)
        {
            acc += h[(size_t) n] * hist[(size_t) idx];
            idx = (idx == 0) ? Taps - 1 : idx - 1;
        }
        pos = (pos + 1) % Taps;
        return acc;
    }

    static constexpr int Taps = 31;
    std::array<float, Taps> h {};
    std::array<float, Taps> hist {};
    int pos = 0;
};
