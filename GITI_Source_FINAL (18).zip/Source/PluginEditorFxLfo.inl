#pragma once
#include <array>
#include "Modulation/LFO.h"
#include "FX/SimpleCompressor.h"

/** Mini live monitor for each FX section row */
class FxMonitor : public juce::Component, private juce::Timer
{
public:
    enum Kind { Chorus, Delay, Reverb, Master, Comp, EQ, Phaser, Dist };
    FxMonitor() { peakHistory.fill (0.f); startTimerHz (90); }
    void setKind (Kind k) { kind = k; }
    void setLevel (float v) { level = juce::jlimit (0.f, 1.f, v); }
    float getLevel() const noexcept { return level; }
    void setActive (bool shouldBeActive) { active = shouldBeActive; }
    void setAccent (juce::Colour c) { accent = c; }
    void bindActivitySource (std::atomic<float>* source) { activitySource = source; }
    void bindControlSources (std::atomic<float>* mixValue, std::atomic<float>* bypass)
    {
        levelSource = mixValue;
        bypassSource = bypass;
    }
    void bindEqSources (std::atomic<float>* low, std::atomic<float>* mid, std::atomic<float>* high)
    {
        eqSources = { low, mid, high };
    }
    void bindThresholdSource (std::atomic<float>* source) { thresholdSource = source; }
    void setEqBands (float lo, float mid, float hi)
    {
        eqBand[0] = juce::jlimit (-1.f, 1.f, lo);
        eqBand[1] = juce::jlimit (-1.f, 1.f, mid);
        eqBand[2] = juce::jlimit (-1.f, 1.f, hi);
    }
    void setThresholdNorm (float t)
    {
        if (draggingBand < 0)
            thrNorm[1] = juce::jlimit (0.f, 1.f, t);
    }
    void bindThresholdParam (juce::RangedAudioParameter* p) { thrParam = p; }
    void bindCompressor (salek::SimpleCompressor* c) { comp = c; }

    void mouseDown (const juce::MouseEvent& e) override
    {
        if (kind != Comp) return;
        auto plot = getLocalBounds().toFloat().reduced (5.f, 4.f);
        auto thresholdRow = plot.removeFromBottom (juce::jmax (10.f, plot.getHeight() * 0.42f));
        if (! thresholdRow.contains (e.position)) return;
        draggingBand = 1;
        if (thrParam != nullptr) thrParam->beginChangeGesture();
        setBandFromX (e.position.x, thresholdRow);
    }
    void mouseDrag (const juce::MouseEvent& e) override
    {
        if (draggingBand < 0) return;
        auto plot = getLocalBounds().toFloat().reduced (5.f, 4.f);
        auto thresholdRow = plot.removeFromBottom (juce::jmax (10.f, plot.getHeight() * 0.42f));
        setBandFromX (e.position.x, thresholdRow);
        repaint();
    }
    void mouseUp (const juce::MouseEvent&) override
    {
        if (draggingBand >= 0 && thrParam != nullptr)
            thrParam->endChangeGesture();
        draggingBand = -1;
    }

    void paint (juce::Graphics& g) override
    {
        auto r = getLocalBounds().toFloat().reduced (1.f);
        g.setColour (juce::Colour (0xff0a0614));
        g.fillRoundedRectangle (r, 5.f);
        g.setColour (accent.withAlpha (0.45f));
        g.drawRoundedRectangle (r, 5.f, 1.f);

        auto plot = r.reduced (4.f, 3.f);

        if (kind == Comp)
        {
            const auto thresholdRow = plot.removeFromBottom (juce::jmax (10.f, plot.getHeight() * 0.42f)).reduced (1.f, 1.f);
            auto grRow = plot.reduced (1.f, 1.f);
            const float gr = juce::jlimit (0.f, 1.f, dispGR[1]);
            g.setColour (accent.withAlpha (0.16f));
            g.fillRoundedRectangle (grRow, 2.f);
            g.setColour (accent.withAlpha (active ? 0.92f : 0.32f));
            g.fillRoundedRectangle (grRow.withWidth (grRow.getWidth() * gr), 2.f);
            g.setFont (juce::FontOptions (8.f, juce::Font::bold));
            g.setColour (juce::Colours::white.withAlpha (0.88f));
            const float reductionDb = comp != nullptr && active ? comp->getGainReduction() : 0.f;
            g.drawText ("GR " + juce::String (reductionDb, 1) + " dB",
                        grRow.toNearestInt().reduced (3, 0), juce::Justification::centredLeft);

            g.setColour (accent.withAlpha (0.20f));
            g.fillRoundedRectangle (thresholdRow, 2.f);
            const float tx = thresholdRow.getX() + thrNorm[1] * thresholdRow.getWidth();
            g.setColour (juce::Colours::white.withAlpha (draggingBand == 1 ? 1.f : 0.86f));
            g.drawVerticalLine ((int) tx, thresholdRow.getY(), thresholdRow.getBottom());
            g.setColour (accent);
            g.fillEllipse (tx - 3.5f, thresholdRow.getCentreY() - 3.5f, 7.f, 7.f);
            const float thresholdDb = juce::jmap (thrNorm[1], 0.f, 1.f, -40.f, 0.f);
            g.setColour (juce::Colours::white.withAlpha (0.84f));
            g.drawText ("THR " + juce::String (thresholdDb, 1) + " dB",
                        thresholdRow.toNearestInt().reduced (3, 0), juce::Justification::centredLeft);
            return;
        }

        if (kind == EQ)
        {
            const float gap = 3.f;
            const float bw = (plot.getWidth() - gap * 2.f) / 3.f;
            const float midY = plot.getCentreY();
            const float maxH = plot.getHeight() * 0.42f;
            juce::Colour cols[3] = {
                juce::Colour (0xff73c9c5), juce::Colour (0xff39ff14), juce::Colour (0xffff2d9b)
            };
            const char* labs[3] = { "LO", "MID", "HI" };
            g.setColour (juce::Colours::white.withAlpha (0.15f));
            g.drawHorizontalLine ((int) midY, plot.getX(), plot.getRight());
            for (int b = 0; b < 3; ++b)
            {
                float v = eqBand[(size_t) b];
                float h = std::abs (v) * maxH;
                float x = plot.getX() + b * (bw + gap);
                auto bar = v >= 0.f
                    ? juce::Rectangle<float> (x, midY - h, bw, h)
                    : juce::Rectangle<float> (x, midY, bw, h);
                g.setColour (cols[b].withAlpha (0.85f));
                g.fillRoundedRectangle (bar, 2.f);
                g.setFont (juce::FontOptions (8.f, juce::Font::bold));
                g.setColour (cols[b]);
                g.drawText (labs[b], (int) x, (int) plot.getBottom() - 10, (int) bw, 10,
                            juce::Justification::centred);
            }
            return;
        }

        // This is a rolling peak trace from the actual audio after this stage.
        for (int line = 1; line <= 2; ++line)
        {
            const float y = plot.getY() + plot.getHeight() * (float) line / 3.f;
            g.setColour (juce::Colours::white.withAlpha (0.08f));
            g.drawHorizontalLine ((int) y, plot.getX(), plot.getRight());
        }
        juce::Path trace, area;
        const int points = (int) peakHistory.size();
        for (int i = 0; i < points; ++i)
        {
            const int slot = (historyWrite + i) % points;
            const float x = plot.getX() + (float) i / (float) (points - 1) * plot.getWidth();
            const float y = plot.getBottom() - peakHistory[(size_t) slot] * plot.getHeight();
            if (i == 0) { trace.startNewSubPath (x, y); area.startNewSubPath (x, plot.getBottom()); area.lineTo (x, y); }
            else { trace.lineTo (x, y); area.lineTo (x, y); }
        }
        area.lineTo (plot.getRight(), plot.getBottom());
        area.closeSubPath();
        const float alpha = active ? 0.9f : 0.28f;
        g.setColour (accent.withAlpha (0.15f * alpha));
        g.fillPath (area);
        g.setColour (accent.withAlpha (alpha));
        g.strokePath (trace, juce::PathStrokeType (1.4f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        const float db = juce::Decibels::gainToDecibels (latestPeak, -72.f);
        g.setFont (juce::FontOptions (8.f, juce::Font::bold));
        g.setColour (juce::Colours::white.withAlpha (0.82f));
        g.drawText ("OUT " + juce::String (db, 0) + " dB", plot.toNearestInt().reduced (3, 0),
                    juce::Justification::centredRight);
        g.setColour (accent.withAlpha (active ? 0.85f : 0.3f));
        g.fillRect (plot.getX(), plot.getBottom() - 2.f, plot.getWidth() * level, 2.f);
    }
    void timerCallback() override
    {
        if (! isShowing()) return;
        if (levelSource != nullptr)
            level = juce::jlimit (0.f, 1.f, levelSource->load (std::memory_order_relaxed));
        if (bypassSource != nullptr)
            active = bypassSource->load (std::memory_order_relaxed) < 0.5f
                  && (levelSource == nullptr || level > 1.0e-4f);
        if (thresholdSource != nullptr)
            thrNorm[1] = juce::jlimit (0.f, 1.f,
                (thresholdSource->load (std::memory_order_relaxed) + 40.f) / 40.f);
        if (kind == EQ)
        {
            for (int i = 0; i < 3; ++i)
                if (eqSources[(size_t) i] != nullptr)
                    eqBand[(size_t) i] = juce::jlimit (-1.f, 1.f,
                        eqSources[(size_t) i]->load (std::memory_order_relaxed) / 12.f);
            level = juce::jmax (std::abs (eqBand[0]), std::abs (eqBand[1]), std::abs (eqBand[2]));
            if (bypassSource != nullptr)
                active = bypassSource->load (std::memory_order_relaxed) < 0.5f && level > 1.0e-4f;
        }
        latestPeak = activitySource != nullptr ? juce::jlimit (0.f, 4.f, activitySource->load (std::memory_order_relaxed)) : 0.f;
        const float db = juce::Decibels::gainToDecibels (latestPeak, -72.f);
        const float normalized = juce::jlimit (0.f, 1.f, (db + 72.f) / 72.f);
        peakHistory[historyWrite] = normalized;
        historyWrite = (historyWrite + 1) % (int) peakHistory.size();
        const float gr = kind == Comp && comp != nullptr && active
            ? juce::jlimit (0.f, 1.f, comp->getGainReduction() / 24.f) : 0.f;
        dispGR[1] = gr > dispGR[1] ? dispGR[1] + 0.72f * (gr - dispGR[1]) : dispGR[1] * 0.78f;
        repaint();
    }

private:
    void setBandFromX (float x, juce::Rectangle<float> plot)
    {
        if (draggingBand < 0 || draggingBand > 2) return;
        thrNorm[draggingBand] = juce::jlimit (0.f, 1.f,
            (x - plot.getX()) / juce::jmax (1.f, plot.getWidth()));
        const float db = juce::jmap (thrNorm[draggingBand], 0.f, 1.f, -40.f, 0.f);
        // The compressor is wideband. The draggable threshold is the same host
        // parameter that controls its audio detector; there are no fake bands.
        if (thrParam != nullptr)
            thrParam->setValueNotifyingHost (thrParam->convertTo0to1 (db));
    }

    Kind kind = Chorus;
    float level = 0.35f;
    float bandGR[3] {}, dispGR[3] {}, eqBand[3] {};
    float thrNorm[3] { 0.45f, 0.55f, 0.65f };
    int draggingBand = -1;
    bool active = true;
    std::atomic<float>* activitySource = nullptr;
    std::atomic<float>* levelSource = nullptr;
    std::atomic<float>* bypassSource = nullptr;
    std::atomic<float>* thresholdSource = nullptr;
    std::array<std::atomic<float>*, 3> eqSources {};
    std::array<float, 40> peakHistory {};
    int historyWrite = 0;
    float latestPeak = 0.f;
    juce::RangedAudioParameter* thrParam = nullptr;
    salek::SimpleCompressor* comp = nullptr;
    juce::Colour accent { 0xff73c9c5 };
};

/** Editable LFO shape — freehand paint (Serum 2 style)
 *  activePoints = 8 / 16 / 32 controls how many editable vertices (Shift-draw friendly).
 *  Full TableSize (32) is always written to the LFO via linear stretch. */
class LfoShapeEditor : public juce::Component, private juce::Timer
{
public:
    static constexpr int N = salek::LFO::TableSize;

    LfoShapeEditor()
    {
        startTimerHz (30);
        for (int i = 0; i < N; ++i)
        {
            float t = (float) i / (float) (N - 1);
            points[i] = std::sin (t * juce::MathConstants<float>::twoPi);
        }
    }

    void setLfo (salek::LFO* l) { lfo = l; if (lfo) syncFromLfo(); }
    salek::LFO* getLfo() const noexcept { return lfo; }

    /** 8 / 16 / 32 editable points */
    void setActivePoints (int n)
    {
        if (n <= 8)       activePoints = 8;
        else if (n <= 16) activePoints = 16;
        else              activePoints = 32;
        repaint();
    }
    int getActivePoints() const noexcept { return activePoints; }

    void syncFromLfo()
    {
        if (! lfo) return;
        for (int i = 0; i < N; ++i)
            points[i] = lfo->getCustomPoint (i);
        repaint();
    }

    void applyTo (salek::LFO& dest)
    {
        pushToLfo (dest);
    }

    void saveSlot (int slot)
    {
        if (slot < 0 || slot > 2) return;
        for (int i = 0; i < N; ++i)
            bank[(size_t) slot][(size_t) i] = points[i];
        bankValid[(size_t) slot] = true;
    }

    void loadSlot (int slot)
    {
        if (slot < 0 || slot > 2 || ! bankValid[(size_t) slot]) return;
        for (int i = 0; i < N; ++i)
            points[i] = bank[(size_t) slot][(size_t) i];
        pushAndNotify();
        repaint();
    }

    void paint (juce::Graphics& g) override
    {
        auto r = getLocalBounds().toFloat().reduced (2.f);
        g.setColour (juce::Colour (0xff0b0f17));
        g.fillRoundedRectangle (r, 8.f);
        g.setColour (juce::Colour (0xff73c9c5).withAlpha (0.45f));
        g.drawRoundedRectangle (r, 8.f, 1.4f);

        auto plot = r.reduced (8.f, 18.f);
        const int AP = activePoints;
        // Grid matches active point density
        g.setColour (juce::Colour (0xff73c9c5).withAlpha (0.10f));
        for (int i = 1; i < AP; ++i)
        {
            float x = plot.getX() + plot.getWidth() * (float) i / (float) AP;
            g.drawVerticalLine ((int) x, plot.getY(), plot.getBottom());
        }
        for (int j = 1; j < 8; ++j)
        {
            float y = plot.getY() + plot.getHeight() * (float) j / 8.f;
            g.drawHorizontalLine ((int) y, plot.getX(), plot.getRight());
        }
        g.setColour (juce::Colour (0xff73c9c5).withAlpha (0.28f));
        g.drawHorizontalLine ((int) plot.getCentreY(), plot.getX(), plot.getRight());

        // Vertex dots at active resolution
        g.setColour (juce::Colour (0xff73c9c5).withAlpha (0.75f));
        for (int i = 0; i < AP; ++i)
        {
            float x = plot.getX() + (float) i / (float) (AP - 1) * plot.getWidth();
            float y = plot.getCentreY() - sampleAtActive (i) * plot.getHeight() * 0.45f;
            g.fillEllipse (x - 3.f, y - 3.f, 6.f, 6.f);
        }

        juce::Path fill, wave;
        for (int i = 0; i < AP; ++i)
        {
            float x = plot.getX() + (float) i / (float) (AP - 1) * plot.getWidth();
            float y = plot.getCentreY() - sampleAtActive (i) * plot.getHeight() * 0.45f;
            if (i == 0) { wave.startNewSubPath (x, y); fill.startNewSubPath (x, plot.getBottom()); fill.lineTo (x, y); }
            else
            {   // draw each segment the way it is set: LINE / STEP (square) / CURVE (smooth S)
                const int sm = segMode[juce::jlimit (0, 63, i - 1)];
                const float xPrev = plot.getX() + (float) (i - 1) / (float) (AP - 1) * plot.getWidth();
                const float yPrev = plot.getCentreY() - sampleAtActive (i - 1) * plot.getHeight() * 0.45f;
                if (sm == 1)
                {
                    wave.lineTo (x, yPrev);  wave.lineTo (x, y);
                    fill.lineTo (x, yPrev);  fill.lineTo (x, y);
                }
                else if (sm == 2)
                {
                    for (int s = 1; s <= 14; ++s)
                    {
                        const float t = (float) s / 14.f, ss = t * t * (3.f - 2.f * t);
                        const float xs = xPrev + (x - xPrev) * t, ys = yPrev + (y - yPrev) * ss;
                        wave.lineTo (xs, ys); fill.lineTo (xs, ys);
                    }
                }
                else { wave.lineTo (x, y); fill.lineTo (x, y); }
            }
        }
        fill.lineTo (plot.getRight(), plot.getBottom());
        fill.closeSubPath();
        g.setColour (juce::Colour (0xff73c9c5).withAlpha (0.12f));
        g.fillPath (fill);
        g.setColour (juce::Colour (0xff73c9c5));
        g.strokePath (wave, juce::PathStrokeType (2.2f, juce::PathStrokeType::mitered, juce::PathStrokeType::butt));

        // output preview when STEPS is active (what the LFO really sends)
        if (lfo != nullptr && lfo->getSteps() >= 2)
        {
            const int st = lfo->getSteps();
            juce::Path sp;
            for (int i = 0; i <= 160; ++i)
            {
                const float t = (float) i / 160.f;
                const float ft = t * (float) (N - 1);
                const int i0 = juce::jlimit (0, N - 1, (int) ft), i1 = juce::jmin (N - 1, i0 + 1);
                float v = points[i0] + (points[i1] - points[i0]) * (ft - (float) i0);
                const float u = juce::jlimit (0.f, 1.f, v * 0.5f + 0.5f);
                v = std::round (u * (float) (st - 1)) / (float) (st - 1) * 2.f - 1.f;
                const float x = plot.getX() + t * plot.getWidth(), y = plot.getCentreY() - v * plot.getHeight() * 0.45f;
                if (i == 0) sp.startNewSubPath (x, y); else sp.lineTo (x, y);
            }
            g.setColour (juce::Colour (0xffff3ccf).withAlpha (0.9f));
            g.strokePath (sp, juce::PathStrokeType (1.6f));
        }

        // live playhead + current value dot
        if (lfo != nullptr)
        {
            const float pos = lfo->getPlayPosition();
            const float x = plot.getX() + pos * plot.getWidth();
            const float ft = pos * (float) (N - 1);
            const int i0 = juce::jlimit (0, N - 1, (int) ft), i1 = juce::jmin (N - 1, i0 + 1);
            const float v = points[i0] + (points[i1] - points[i0]) * (ft - (float) i0);
            const float y = plot.getCentreY() - v * plot.getHeight() * 0.45f;
            g.setColour (juce::Colours::white.withAlpha (0.35f));
            g.drawVerticalLine ((int) x, plot.getY(), plot.getBottom());
            g.setColour (juce::Colour (0xffffc861));
            g.fillEllipse (x - 4.f, y - 4.f, 8.f, 8.f);
        }

        // hover read-out
        if (hoverIdx >= 0)
        {
            const float hx = plot.getX() + (float) hoverIdx / (float) (AP - 1) * plot.getWidth();
            const float hy = plot.getCentreY() - sampleAtActive (hoverIdx) * plot.getHeight() * 0.45f;
            g.setColour (juce::Colours::white);
            g.drawEllipse (hx - 5.f, hy - 5.f, 10.f, 10.f, 1.4f);
            g.setFont (juce::FontOptions (9.f, juce::Font::bold));
            g.drawText (juce::String (sampleAtActive (hoverIdx), 2), juce::Rectangle<float> (hx - 22.f, hy - 20.f, 44.f, 12.f).toNearestInt(), juce::Justification::centred);
        }

        // header: title + tool buttons
        g.setColour (juce::Colour (0xffd5bd88));
        g.setFont (juce::FontOptions (10.f, juce::Font::bold));
        g.drawText ("LFO " + juce::String (titleIdx) + " SHAPE  pts=" + juce::String (AP) + "  |  Alt+click point = LINE/STEP/CURVE  |  Shift=snap  RClick=0",
                    getLocalBounds().removeFromTop (18).reduced (8, 0), juce::Justification::centredLeft);
        static const char* tn[] = { "INV", "FLIP", "<", ">", "SMTH", "RND", "STEP" };
        for (int i = 0; i < 7; ++i)
        {
            auto br = toolRect (i);
            g.setColour (juce::Colour (0xff73c9c5).withAlpha (0.18f));
            g.fillRoundedRectangle (br, 4.f);
            g.setColour (juce::Colour (0xff73c9c5));
            g.drawRoundedRectangle (br, 4.f, 1.f);
            g.drawText (tn[i], br.toNearestInt(), juce::Justification::centred);
        }
    }

    void timerCallback() override { if (isShowing()) repaint(); }

    juce::Rectangle<float> toolRect (int i) const
    {
        const float w = 38.f, gap = 4.f, h = 14.f;
        const float right = (float) getWidth() - 8.f;
        return { right - (7 - i) * (w + gap) + gap, 3.f, w, h };
    }

    void applyTool (int t)
    {
        if (t == 6)
        {
            bool allStep = true;
            for (int i = 0; i < activePoints - 1; ++i) if (segMode[i] != 1) allStep = false;
            for (int i = 0; i < 64; ++i) segMode[i] = allStep ? 0 : 1;
            writeActive (0, sampleAtActive (0));
            return;
        }
        if (t == 0) for (int i = 0; i < N; ++i) points[i] = -points[i];
        else if (t == 1) for (int i = 0; i < N / 2; ++i) std::swap (points[i], points[N - 1 - i]);
        else if (t == 2 || t == 3)
        {
            const int sh = juce::jmax (1, N / activePoints) * (t == 2 ? -1 : 1);
            float tmp[N];
            for (int i = 0; i < N; ++i) tmp[i] = points[((i - sh) % N + N) % N];
            for (int i = 0; i < N; ++i) points[i] = tmp[i];
        }
        else if (t == 4)
        {
            float tmp[N];
            for (int i = 0; i < N; ++i)
                tmp[i] = 0.25f * points[(i + N - 1) % N] + 0.5f * points[i] + 0.25f * points[(i + 1) % N];
            for (int i = 0; i < N; ++i) points[i] = tmp[i];
        }
        else if (t == 5)
        {
            auto& rng = juce::Random::getSystemRandom();
            for (int i = 0; i < activePoints; ++i) writeActive (i, rng.nextFloat() * 2.f - 1.f);
        }
        pushAndNotify();
        repaint();
    }

    void mouseMove (const juce::MouseEvent& e) override
    {
        auto plot = getLocalBounds().toFloat().reduced (10.f, 20.f);
        const int ni = (e.y < 20 || plot.getWidth() < 1.f) ? -1
            : juce::jlimit (0, activePoints - 1, (int) std::round ((e.position.x - plot.getX()) / plot.getWidth() * (float) (activePoints - 1)));
        if (ni != hoverIdx) { hoverIdx = ni; repaint(); }
    }
    void mouseExit (const juce::MouseEvent&) override { hoverIdx = -1; repaint(); }
    void mouseDoubleClick (const juce::MouseEvent& e) override
    {
        if (e.y < 20) return;
        for (int i = 0; i < N; ++i)
            points[i] = std::sin ((float) i / (float) (N - 1) * juce::MathConstants<float>::twoPi);
        for (auto& sgm : segMode) sgm = 0;
        pushAndNotify();
        repaint();
    }

    void mouseDown (const juce::MouseEvent& e) override
    {
        dragFromHeader = e.y < 20;
        if (dragFromHeader)
        {
            for (int i = 0; i < 7; ++i)
                if (toolRect (i).contains (e.position)) { applyTool (i); break; }
            return;
        }
        lastIdx = -1;
        if (e.mods.isAltDown())
        {
            auto plot = getLocalBounds().toFloat().reduced (10.f, 20.f);
            const int idx = juce::jlimit (0, activePoints - 2,
                (int) std::floor ((e.position.x - plot.getX()) / juce::jmax (1.f, plot.getWidth()) * (float) (activePoints - 1) + 0.5f));
            segMode[idx] = (segMode[idx] + 1) % 3;
            writeActive (0, sampleAtActive (0));
            repaint();
            return;
        }
        if (e.mods.isPopupMenu())
        {
            auto plot = getLocalBounds().toFloat().reduced (10.f, 20.f);
            const int idx = juce::jlimit (0, activePoints - 1,
                (int) std::round ((e.position.x - plot.getX()) / juce::jmax (1.f, plot.getWidth()) * (float) (activePoints - 1)));
            writeActive (idx, 0.f);
            repaint();
            return;
        }
        dragAt (e);
    }
    void mouseDrag (const juce::MouseEvent& e) override { if (! dragFromHeader && ! e.mods.isPopupMenu()) dragAt (e); }

private:
    salek::LFO* lfo = nullptr;
    float points[N] {};
    int segMode[64] {};   // per segment: 0 = line, 1 = step (square), 2 = curve
    float bank[3][N] {};
    bool bankValid[3] { false, false, false };
    int lastIdx = -1;
    int hoverIdx = -1;
    bool dragFromHeader = false;
    int activePoints = 16; // default: comfortable for Shift-draw

    float sampleAtActive (int ai) const
    {
        // Map active index → full table index
        float t = (float) ai / (float) (activePoints - 1);
        int ti = juce::jlimit (0, N - 1, (int) std::round (t * (float) (N - 1)));
        return points[ti];
    }

    void writeActive (int ai, float v)
    {
        ai = juce::jlimit (0, activePoints - 1, ai);
        v = juce::jlimit (-1.f, 1.f, v);
        // Write into the corresponding full-table slot, then interpolate neighbours
        float t = (float) ai / (float) (activePoints - 1);
        int ti = juce::jlimit (0, N - 1, (int) std::round (t * (float) (N - 1)));
        points[ti] = v;
        // Fill gaps between active vertices by linear interpolation across full table
        if (activePoints < N)
        {
            for (int i = 0; i < activePoints - 1; ++i)
            {
                float t0 = (float) i / (float) (activePoints - 1);
                float t1 = (float) (i + 1) / (float) (activePoints - 1);
                int i0 = juce::jlimit (0, N - 1, (int) std::round (t0 * (float) (N - 1)));
                int i1 = juce::jlimit (0, N - 1, (int) std::round (t1 * (float) (N - 1)));
                float v0 = points[i0], v1 = points[i1];
                for (int j = i0; j <= i1; ++j)
                {
                    float tt = (i1 == i0) ? 0.f : (float) (j - i0) / (float) (i1 - i0);
                    const int sm = segMode[juce::jlimit (0, 63, i)];
                    if (sm == 1)      points[j] = (j == i1) ? v1 : v0;                              // STEP: hold, then jump
                    else if (sm == 2) { const float s = tt * tt * (3.f - 2.f * tt); points[j] = v0 + (v1 - v0) * s; }   // CURVE: S-shaped
                    else              points[j] = v0 * (1.f - tt) + v1 * tt;                           // LINE
                }
            }
        }
        pushAndNotify();
    }

public:
    std::function<void()> onEdited;     // called after every edit (the editor switches that LFO to "Custom")
    int titleIdx = 1;
    void setTitleIndex (int i) { titleIdx = i; repaint(); }
    void pushAndNotify() { if (lfo != nullptr) { pushToLfo (*lfo); if (onEdited) onEdited(); } }
private:
    void pushToLfo (salek::LFO& dest)
    {   // the audio table is built from the VERTICES and each segment's own shape, so what you see is what the LFO plays
        const int AP = activePoints;
        for (int k = 0; k < N; ++k)
        {
            const float u = (float) k / (float) (N - 1) * (float) (AP - 1);
            const int i0 = juce::jlimit (0, AP - 1, (int) std::floor (u));
            const int i1 = juce::jmin (AP - 1, i0 + 1);
            const float fr = juce::jlimit (0.f, 1.f, u - (float) i0);
            const float v0 = sampleAtActive (i0), v1 = sampleAtActive (i1);
            const int sm = segMode[juce::jlimit (0, 63, i0)];
            float v = v0;
            if (i0 < AP - 1)
            {
                if (sm == 1)      v = v0;                                                // STEP: hold, then jump
                else if (sm == 2) v = v0 + (v1 - v0) * (fr * fr * (3.f - 2.f * fr));     // CURVE: smooth S
                else              v = v0 + (v1 - v0) * fr;                               // LINE
            }
            dest.setCustomPoint (k, juce::jlimit (-1.f, 1.f, v));
        }
        dest.setWave (salek::LFO::Wave::Custom);
    }

    void dragAt (const juce::MouseEvent& e)
    {
        auto plot = getLocalBounds().toFloat().reduced (10.f, 20.f);
        if (plot.getWidth() < 1.f) return;
        const int AP = activePoints;
        // Snap X to cubic/active grid (Serum-style: never crooked when Shift)
        int idx = juce::jlimit (0, AP - 1,
            (int) std::round ((e.position.x - plot.getX()) / plot.getWidth() * (float) (AP - 1)));
        float v = juce::jlimit (-1.f, 1.f,
            (plot.getCentreY() - e.position.y) / (plot.getHeight() * 0.45f));

        if (e.mods.isShiftDown())
        {
            // 9 horizontal levels (-1..1) like Serum grid
            v = std::round (v * 4.f) / 4.f;
            // Single-point edit only when Shift — clean corners, no smear
            writeActive (idx, v);
            // Do not soften adjacent vertices: Shift is the hard-corner / straight-edge tool.
            lastIdx = idx;
            repaint();
            return;
        }

        // Free draw: linear fill between last and current
        if (lastIdx < 0) writeActive (idx, v);
        else
        {
            int a = juce::jmin (lastIdx, idx), b = juce::jmax (lastIdx, idx);
            float va = sampleAtActive (lastIdx);
            for (int i = a; i <= b; ++i)
            {
                float tt = (b == a) ? 1.f : (float) (i - a) / (float) (b - a);
                // Linear interpolation keeps drawn edges genuinely straight; Shift remains the hard-corner/grid mode.
                float s = tt;
                float pv = (lastIdx <= idx) ? va * (1.f - s) + v * s : v * (1.f - s) + va * s;
                writeActive (i, pv);
            }
        }
        lastIdx = idx;
        repaint();
    }
};

// ---------------------------------------------------------------------------------------------
// Compact live LFO panel for the MAIN-tab stage: scrolling trace of the real LFO output + key controls
class QuickLfoPanel : public juce::Component, private juce::Timer
{
public:
    QuickLfoPanel (juce::AudioProcessorValueTreeState& apvts, salek::LFO& l, const juce::String& p, juce::Colour c)
        : lfo (l), col (c)
    {
        hist.fill (0.f);
        static const char* waveNames[6] = { "Sine", "Triangle", "Saw", "Square", "S&H", "Custom" };
        for (int i = 0; i < 6; ++i) waveBox.addItem (waveNames[i], i + 1);
        for (int d = 0; d < 12; ++d) divBox.addItem (salek::LFO::divisionName (d), d + 1);
        syncBtn.setButtonText ("SYNC");
        syncBtn.setClickingTogglesState (true);
        syncBtn.setColour (juce::TextButton::buttonOnColourId, c.darker (0.3f));
        const char* ids[5] = { "_rate", "_amount", "_smooth", "_steps", "_rise" };
        for (int i = 0; i < 5; ++i)
        {
            auto& s = sl[i];
            s.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
            s.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 54, 14);
            s.setColour (juce::Slider::rotarySliderFillColourId, c);
            s.setColour (juce::Slider::textBoxTextColourId, juce::Colours::white);
            s.setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
            addAndMakeVisible (s);
            sAtt[i] = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (apvts, p + ids[i], s);
        }
        addAndMakeVisible (waveBox); addAndMakeVisible (divBox); addAndMakeVisible (syncBtn);
        wAtt = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (apvts, p + "_wave", waveBox);
        dAtt = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (apvts, p + "_div", divBox);
        bAtt = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (apvts, p + "_sync", syncBtn);
        startTimerHz (30);
    }

    void resized() override
    {
        auto r = getLocalBounds();
        auto top = r.removeFromTop (24);
        waveBox.setBounds (top.removeFromLeft (top.getWidth() * 45 / 100).reduced (1));
        syncBtn.setBounds (top.removeFromLeft (56).reduced (1));
        divBox.setBounds (top.reduced (1));
        r.removeFromTop (4);
        auto knobs = r.removeFromBottom (92);
        plot = r.toFloat();
        const int w = juce::jmax (1, knobs.getWidth() / 5);
        for (int i = 0; i < 5; ++i)
        {
            auto cell = juce::Rectangle<int> (knobs.getX() + i * w, knobs.getY(), w, knobs.getHeight()).reduced (2, 0);
            nameRect[i] = cell.removeFromBottom (12);
            sl[i].setBounds (cell);
        }
    }

    void paint (juce::Graphics& g) override
    {
        g.setColour (juce::Colour (0xff04030c));
        g.fillRoundedRectangle (plot, 6.f);
        g.setColour (col.withAlpha (0.35f));
        g.drawRoundedRectangle (plot, 6.f, 1.f);
        g.setColour (juce::Colours::white.withAlpha (0.08f));
        for (int i = 1; i < 4; ++i) g.drawHorizontalLine ((int) (plot.getY() + plot.getHeight() * (float) i / 4.f), plot.getX() + 2, plot.getRight() - 2);
        for (int i = 1; i < 8; ++i) g.drawVerticalLine ((int) (plot.getX() + plot.getWidth() * (float) i / 8.f), plot.getY() + 2, plot.getBottom() - 2);
        const bool bip = lfo.isBipolar();
        auto yOf = [&] (float v) { const float d = bip ? v : v * 2.f - 1.f; return plot.getCentreY() - juce::jlimit (-1.f, 1.f, d) * plot.getHeight() * 0.42f; };
        juce::Path line, fill;
        const int n = (int) hist.size();
        for (int i = 0; i < n; ++i)
        {
            const float x = plot.getX() + 3.f + (plot.getWidth() - 6.f) * (float) i / (float) (n - 1);
            const float y = yOf (hist[(size_t) ((head + i) % n)]);
            if (i == 0) { line.startNewSubPath (x, y); fill.startNewSubPath (x, plot.getCentreY()); fill.lineTo (x, y); }
            else { line.lineTo (x, y); fill.lineTo (x, y); }
        }
        fill.lineTo (plot.getRight() - 3.f, plot.getCentreY()); fill.closeSubPath();
        g.setColour (col.withAlpha (0.14f)); g.fillPath (fill);
        g.setColour (col); g.strokePath (line, juce::PathStrokeType (1.8f));
        const float ex = plot.getRight() - 3.f, ey = yOf (hist[(size_t) ((head + n - 1) % n)]);
        g.setColour (juce::Colours::white); g.fillEllipse (ex - 3.5f, ey - 3.5f, 7.f, 7.f);
        static const char* nm[5] = { "RATE", "AMT", "SMOOTH", "STEPS", "RISE" };
        g.setColour (juce::Colour (0xffd5bd88)); g.setFont (juce::FontOptions (9.f, juce::Font::bold));
        for (int i = 0; i < 5; ++i) g.drawText (nm[i], nameRect[i], juce::Justification::centred);
    }

private:
    void timerCallback() override
    {
        if (! isShowing()) return;
        hist[(size_t) head] = lfo.getLastOut();
        head = (head + 1) % (int) hist.size();
        repaint (plot.toNearestInt());
    }
    salek::LFO& lfo;
    juce::Colour col;
    std::array<float, 150> hist {};
    int head = 0;
    juce::Rectangle<float> plot;
    juce::Rectangle<int> nameRect[5];
    juce::Slider sl[5];
    juce::ComboBox waveBox, divBox;
    juce::TextButton syncBtn;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> sAtt[5];
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> wAtt, dAtt;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> bAtt;
};

// Tabbed frame: LFO1 | LFO2 | LFO3 | RANDOM
struct ModStagePanel : public juce::Component
{
    juce::TextButton tabBtn[4];
    int sel = 0;
    std::function<void()> onTab;
    ModStagePanel()
    {
        const char* t[4] = { "LFO 1", "LFO 2", "LFO 3", "SPARK" };
        for (int i = 0; i < 4; ++i)
        {
            auto& b = tabBtn[i];
            b.setButtonText (t[i]);
            b.setClickingTogglesState (true);
            b.setRadioGroupId (7311);
            b.setToggleState (i == 0, juce::dontSendNotification);
            b.onClick = [this, i] { sel = i; if (onTab) onTab(); };
            addAndMakeVisible (b);
        }
    }
    juce::Rectangle<int> content() const { return getLocalBounds().withTrimmedTop (32).reduced (8, 6); }
    void resized() override
    {
        auto r = getLocalBounds().removeFromTop (28).reduced (6, 3);
        const int w = r.getWidth() / 4;
        for (int i = 0; i < 4; ++i) tabBtn[i].setBounds (r.removeFromLeft (w).reduced (2, 0));
    }
    void paint (juce::Graphics& g) override
    {
        auto r = getLocalBounds().toFloat().reduced (1.f);
        g.setColour (juce::Colour (0xff0b0d26).withAlpha (0.88f)); g.fillRoundedRectangle (r, 8.f);
        g.setColour (juce::Colour (0xff73c9c5).withAlpha (0.55f)); g.drawRoundedRectangle (r, 8.f, 1.2f);
    }
};
