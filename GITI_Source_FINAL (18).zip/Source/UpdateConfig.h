#pragma once
// ---- Online update gateway --------------------------------------------------------------
// Put the address of your update file here. It must return JSON like:
//   { "version": "1.2.0", "url": "https://your-site/giti/download", "notes": "What is new" }
// The UPDATE button in the plugin compares "version" with this build and offers the download.
#define GITI_UPDATE_URL "https://example.com/giti/update.json"

// ---- STORE gateway (packs of the customer e-mail) ----
// GET <url>?email=<customer e-mail>  ->  { "packs": [ { "id","name","desc","price","owned","url","buy" } ] }
#define GITI_STORE_URL "https://example.com/giti/store.json"
