// SALEK HIGHTECH — optimized parallax + 3D light + Iranian geometric motifs
void SalekHightechAudioProcessorEditor::paint (juce::Graphics& g)
{
    const int themeId = themeBox.getSelectedId();
    const float W = (float) getWidth();
    const float H = (float) getHeight();
    const float t = animPhase;
    SalekLookAndFeel::corePhase() = animPhase;
    const float peak  = processor.getOutputPeak();
    const float pulse = juce::jlimit (0.0f, 1.0f, peak * 5.0f);
    const auto mouse = getMouseXYRelative();
    const float mx = W > 1.f ? ((float) mouse.x / W - 0.5f) : 0.f;
    const float my = H > 1.f ? ((float) mouse.y / H - 0.5f) : 0.f;
    const float morph = 0.5f + 0.5f * std::sin (t * 0.35f);

    auto lerpCol = [] (juce::Colour a, juce::Colour b, float x) {
        return a.interpolatedWith (b, juce::jlimit (0.f, 1.f, x));
    };

    juce::Colour cyan, magenta, gold, purple, lime;
    if (themeId == 2) {
        cyan = lerpCol (juce::Colour (0xffb8ff00), juce::Colour (0xff39ff14), morph);
        magenta = lerpCol (juce::Colour (0xffff6b00), juce::Colour (0xffffaa00), morph);
        gold = juce::Colour (0xffffee00); purple = juce::Colour (0xff88ff00); lime = juce::Colour (0xff39ff14);
    } else if (themeId == 3) {
        cyan = lerpCol (juce::Colour (0xffff00dd), juce::Colour (0xffff66ff), morph);
        magenta = lerpCol (juce::Colour (0xff00ffff), juce::Colour (0xff7c4dff), morph);
        gold = juce::Colour (0xffff66ff); purple = juce::Colour (0xffaa00ff); lime = juce::Colour (0xffff2d9b);
    } else if (themeId == 4) {
        cyan = lerpCol (juce::Colour (0xff7ef9e0), juce::Colour (0xffffb0d0), morph);
        magenta = lerpCol (juce::Colour (0xffff2d9b), juce::Colour (0xffff80c0), 1.f - morph);
        gold = juce::Colour (0xffff66aa); purple = juce::Colour (0xffff80c0); lime = juce::Colour (0xffb8ff40);
    } else {
        // Mockup cyber: hot pink + electric cyan (SALEK reference art)
        // PERSIAN crystal: electric cyan, hot magenta, soft gold, deep purple
        cyan = lerpCol (giti::primaryColour(), giti::primaryColour().brighter (0.4f), morph);
        magenta = lerpCol (giti::secondaryColour(), giti::secondaryColour().brighter (0.4f), morph);
        gold = giti::accentColour(); purple = giti::tertiaryColour(); lime = juce::Colour (0xff2bd1c4);
    }

    // Light source follows mouse (3D lighting key)
    const float lx = W * (0.5f + mx * 0.6f);
    const float ly = H * (0.35f + my * 0.4f);

    // ---- L0 far gradient ----
    {
        juce::Colour c0, c1;
        if (themeId == 4)      { c0 = juce::Colour (0xff1a0c18); c1 = juce::Colour (0xff3a1830); }
        else if (themeId == 2) { c0 = juce::Colour (0xff040a02); c1 = juce::Colour (0xff1a2e08); }
        else if (themeId == 3) { c0 = juce::Colour (0xff0c0210); c1 = juce::Colour (0xff2a0838); }
        else                   { c0 = juce::Colour (0xff04050f); c1 = juce::Colour (0xff120b3a); } // deep space
        float gx = lx * 0.3f + W * 0.3f, gy = ly * 0.3f + H * 0.2f;
        juce::Colour mid = c1.interpolatedWith (purple.darker (0.2f), morph * 0.35f + pulse * 0.15f);
        juce::ColourGradient bg (c0, gx - W * 0.3f, gy - H * 0.3f, mid, gx + W * 0.5f, gy + H * 0.5f, true);
        g.setGradientFill (bg);
        g.fillAll();
    }

    // girih / stars disabled for performance
    juce::ignoreUnused (t, pulse, mx, my, morph, gold, purple, lime, lx, ly);

    // ---- background art (CACHED — rebuild only on resize/theme) ----
    {
        const int iw = (int) W, ih = (int) H;
        const bool persian = false;   // pictures are chosen by the BG button, not by the theme
        if ((persian || heroImg.isValid())
            && (cachedBgW != iw || cachedBgH != ih || cachedBgTheme != themeId * 100 + bgIndex || ! cachedBg.isValid()))
        {
            cachedBg = juce::Image (juce::Image::ARGB, juce::jmax (1, iw), juce::jmax (1, ih), true);
            juce::Graphics cg (cachedBg);
            if (persian)
            {
                // nebula glows
                juce::ColourGradient n1 (juce::Colour (0xff7b3cff).withAlpha (0.28f), iw * 0.78f, ih * 0.20f,
                                         juce::Colours::transparentBlack, iw * 0.78f, ih * 0.20f + ih * 0.55f, true);
                cg.setGradientFill (n1); cg.fillAll();
                juce::ColourGradient n2 (juce::Colour (0xff22e6ff).withAlpha (0.16f), iw * 0.18f, ih * 0.75f,
                                         juce::Colours::transparentBlack, iw * 0.18f, ih * 0.75f - ih * 0.5f, true);
                cg.setGradientFill (n2); cg.fillAll();
                // faint Persian 8-point star (rub el hizb) lattice
                const float step = 118.f;
                for (float py = step * 0.5f; py < (float) ih + step; py += step)
                    for (float px = step * 0.5f; px < (float) iw + step; px += step)
                    {
                        juce::Path star;
                        star.addStar ({ px, py }, 8, step * 0.20f, step * 0.34f, 0.f);
                        cg.setColour (juce::Colour (0xff22e6ff).withAlpha (0.045f));
                        cg.strokePath (star, juce::PathStrokeType (0.8f));
                        cg.setColour (juce::Colour (0xffe8b84a).withAlpha (0.035f));
                        cg.drawEllipse (px - step * 0.5f, py - step * 0.5f, step, step, 0.7f);
                    }
                // star dust
                juce::Random rng (11);
                for (int i = 0; i < 260; ++i)
                {
                    cg.setColour (juce::Colours::white.withAlpha (0.05f + rng.nextFloat() * 0.45f));
                    const float sz = 0.8f + rng.nextFloat() * 1.6f;
                    cg.fillEllipse (rng.nextFloat() * (float) iw, rng.nextFloat() * (float) ih, sz, sz);
                }
            }
            else
            {
                cg.drawImage (heroImg, juce::Rectangle<float> (0, 0, (float) iw, (float) ih),
                              juce::RectanglePlacement::fillDestination);
                juce::ColourGradient veil (juce::Colours::black.withAlpha (0.22f), iw * 0.5f, (float) ih,
                                          juce::Colours::transparentBlack, iw * 0.5f, ih * 0.28f, false);
                cg.setGradientFill (veil);
                cg.fillAll();
            }
            cachedBgW = iw; cachedBgH = ih; cachedBgTheme = themeId * 100 + bgIndex;
        }
        if (cachedBg.isValid())
            g.drawImageAt (cachedBg, 0, 0);
        // live backgrounds: floating particles / drifting light (the last two modes)
        const int nImg = (int) bgImages.size();
        if (bgIndex >= nImg + 6)
        {
            const float tt = animPhase;
            const float lvl = juce::jlimit (0.f, 1.f, processor.getOutputPeak() * 4.f);
            if (bgIndex == nImg + 6)
            {
                juce::Random rr (11);
                for (int i = 0; i < 90; ++i)
                {
                    const float sp = 6.f + rr.nextFloat() * 14.f, ph = rr.nextFloat() * 1000.f;
                    const float x = std::fmod (rr.nextFloat() * W + std::sin (tt * 0.3f + ph) * 20.f + W, W);
                    const float y = H - std::fmod (ph + tt * sp * 6.f, H);
                    g.setColour ((i % 3 == 0 ? magenta : (i % 3 == 1 ? cyan : purple)).withAlpha (0.18f + 0.5f * lvl * rr.nextFloat()));
                    const float sz = 1.5f + rr.nextFloat() * 3.f + lvl * 2.f;
                    g.fillEllipse (x, y, sz, sz);
                }
            }
            else
            {
                const juce::Colour cs[3] = { cyan, magenta, purple };
                for (int i = 0; i < 3; ++i)
                {
                    const float cx = W * (0.5f + 0.42f * std::sin (tt * 0.11f * (float) (i + 1) + (float) i * 2.f));
                    const float cy = H * (0.5f + 0.38f * std::cos (tt * 0.09f * (float) (i + 2) + (float) i));
                    const float rad = juce::jmax (W, H) * (0.38f + 0.1f * lvl);
                    g.setGradientFill (juce::ColourGradient (cs[i].withAlpha (0.20f + 0.18f * lvl), cx, cy, juce::Colours::transparentBlack, cx + rad, cy, true));
                    g.fillRect (0.f, 0.f, W, H);
                }
            }
        }
    }

    // Holographic Persian lotus + orbit rings behind the glass panels (reference: big centre visualizer)
    if (themeId == 1 && tabs.getCurrentTabIndex() != 0)
    {
        const float lcx = W * 0.52f, lcy = H * 0.50f, R = juce::jmin (W, H) * 0.50f;
        const float tt = animPhase;
        for (int layer = 0; layer < 3; ++layer)
        {
            const int petals = 16 - layer * 4;
            const float L = R * (1.f - 0.26f * layer), w = L * 0.22f;
            juce::Path petal;
            petal.startNewSubPath (0.f, 0.f);
            petal.cubicTo (w, -L * 0.3f, w, -L * 0.7f, 0.f, -L);
            petal.cubicTo (-w, -L * 0.7f, -w, -L * 0.3f, 0.f, 0.f);
            const juce::Colour cc = layer == 0 ? cyan : (layer == 1 ? purple : magenta);
            for (int i = 0; i < petals; ++i)
            {
                const float a = tt * 0.04f * (layer % 2 ? -1.f : 1.f) + i * juce::MathConstants<float>::twoPi / (float) petals;
                g.setColour (cc.withAlpha (0.13f));
                g.strokePath (petal, juce::PathStrokeType (1.2f), juce::AffineTransform::rotation (a).translated (lcx, lcy));
            }
        }
        for (int k = 0; k < 3; ++k)
        {
            juce::Path o;
            o.addEllipse (-R * 1.02f, -R * 0.70f, R * 2.04f, R * 1.40f);
            g.setColour ((k == 0 ? gold : (k == 1 ? cyan : magenta)).withAlpha (0.20f));
            g.strokePath (o, juce::PathStrokeType (1.8f - 0.3f * (float) k),
                          juce::AffineTransform::rotation (tt * 0.03f * (float) (k + 1) + (float) k * 1.05f).translated (lcx, lcy));
        }
    }

    // Painted perspective grid keeps the 3D backdrop in the normal JUCE layer,
    // beneath interactive child components and without an OpenGL overlay.
    if (themeId != 1)
    {
        const float horizon = H * 0.43f;
        const float centerX = W * 0.5f;
        g.setColour (cyan.withAlpha (0.032f));
        for (int i = -8; i <= 8; ++i)
        {
            const float bottomX = centerX + (float) i * W / 8.f;
            g.drawLine (centerX, horizon, bottomX, H, 0.8f);
        }
        for (int i = 0; i < 10; ++i)
        {
            const float depth = (float) (i + 1) / 10.f;
            const float y = horizon + (H - horizon) * depth * depth;
            g.setColour (cyan.withAlpha (0.018f + depth * 0.025f));
            g.drawLine (0.f, y, W, y, 0.8f);
        }
        g.setColour (magenta.withAlpha (0.065f));
        g.drawLine (0.f, horizon, W, horizon, 1.2f);
    }


    // Lightweight 3D bezel
    {
        g.setColour (SalekLookAndFeel::champagne().withAlpha (0.40f));
        g.drawRoundedRectangle (3.f, 3.f, W - 6.f, H - 6.f, 12.f, 1.2f);
        g.setColour (SalekLookAndFeel::teal().withAlpha (0.13f));
        g.drawRoundedRectangle (6.f, 6.f, W - 12.f, H - 12.f, 10.f, 0.8f);
        juce::ColourGradient top (juce::Colours::white.withAlpha (0.035f), W * 0.5f, 0.f,
                                  juce::Colours::transparentWhite, W * 0.5f, 28.f, false);
        g.setGradientFill (top);
        g.fillRect (0.f, 0.f, W, 28.f);
    }


// BG thumbnail panel REMOVED (user red-X). Use top-right BG button only.
        
    
    // Bottom model strip backdrop (above keyboard)
    if (modelStripBounds.getWidth() > 20)
    {
        auto r = modelStripBounds.toFloat();
        g.setColour (juce::Colour (0xff06040e).withAlpha (0.82f));
        g.fillRoundedRectangle (r, 8.f);
        g.setColour (juce::Colour (0xff00e8ff).withAlpha (0.25f));
        g.drawRoundedRectangle (r, 8.f, 1.f);
    }

    if (armedModSource >= 0)
    {
        const juce::Colour cols[3] = {
            SalekLookAndFeel::teal(), SalekLookAndFeel::rose(), juce::Colour (0xffa8c895)
        };
        g.setColour (cols[juce::jlimit (0, 2, armedModSource)]);
        g.setFont (juce::FontOptions (11.f, juce::Font::bold));
        g.drawText ("LFO" + juce::String (armedModSource + 1) + " ARMED — click knob",
                    8, 80, (int) W - 16, 16, juce::Justification::centred);
    }

    // FX underlay — solid dark (never pink / garbage)
    {
        const int ti = tabs.getCurrentTabIndex();
        const bool isFx = (ti >= 0 && ti < tabs.getNumTabs()
                           && tabs.getTabNames()[ti] == "FX");
        if (isFx)
        {
            auto r = getLocalArea (&fxTab, fxTab.getLocalBounds()).toFloat();
            if (r.getWidth() > 10.f)
            {
                g.setColour (SalekLookAndFeel::ink().withAlpha (0.95f));
                g.fillRoundedRectangle (r.reduced (1.f), 10.f);
                g.setColour (SalekLookAndFeel::border().withAlpha (0.78f));
                g.drawRoundedRectangle (r.reduced (1.f), 10.f, 1.f);
            }
        }
    }

// Logo drawn by logoOverlay component (always on top).

    // Glass preset-browser card, painted behind its interactive controls.
    if (! presetCollapsed && presetTab.getWidth() > 0 && presetTab.getHeight() > 0)
    {
        auto browser = getLocalArea (&presetTab, presetTab.getLocalBounds()).toFloat().reduced (1.f);
        SalekLookAndFeel::drawOrnatePanel (g, browser, SalekLookAndFeel::teal(), {}, {}, pulse);
    }

    // ---- Character PNGs LAST = top z-order (cached images, no disk IO) ----
    // Character model — ONLY in left slot under presets (does NOT change background)
    if (charImgL.isValid() && charSlotBounds.getWidth() > 20 && charSlotBounds.getHeight() > 40)
    {
        auto slot = charSlotBounds.toFloat();
        // dark panel
        g.setColour (SalekLookAndFeel::ink().withAlpha (0.80f));
        g.fillRoundedRectangle (slot, 12.f);
        g.setColour (SalekLookAndFeel::border().withAlpha (0.86f));
        g.drawRoundedRectangle (slot, 12.f, 1.1f);
        // Stepped corner accents add a restrained geometric detail.
        const float c = 12.f;
        g.setColour (SalekLookAndFeel::teal().withAlpha (0.62f));
        g.drawLine (slot.getX(), slot.getY() + c, slot.getX(), slot.getY(), 2.f);
        g.drawLine (slot.getX(), slot.getY(), slot.getX() + c, slot.getY(), 2.f);
        g.drawLine (slot.getRight(), slot.getY() + c, slot.getRight(), slot.getY(), 2.f);
        g.drawLine (slot.getRight() - c, slot.getY(), slot.getRight(), slot.getY(), 2.f);
        g.drawLine (slot.getX(), slot.getBottom() - c, slot.getX(), slot.getBottom(), 2.f);
        g.drawLine (slot.getX(), slot.getBottom(), slot.getX() + c, slot.getBottom(), 2.f);
        g.drawLine (slot.getRight(), slot.getBottom() - c, slot.getRight(), slot.getBottom(), 2.f);
        g.drawLine (slot.getRight() - c, slot.getBottom(), slot.getRight(), slot.getBottom(), 2.f);
        // BOTTOM-aligned portrait (fixes knee-up / full-body mismatch)
        g.setOpacity (0.98f);
        // the fox-girl model (#7) is drawn larger: it is allowed to scale UP to fill the panel
        g.drawImage (charImgL, slot.reduced (6.f, 8.f),
                     juce::RectanglePlacement::xMid | juce::RectanglePlacement::yBottom
                     | (charPortraitIdx == 6 ? 0 : juce::RectanglePlacement::onlyReduceInSize));
        g.setOpacity (1.f);
        if (uiLogo.isValid())   // big GITI logo over the bottom of the model panel
        {
            const float lw = slot.getWidth() * 0.96f, lh = lw * (float) uiLogo.getHeight() / (float) uiLogo.getWidth();
            g.setOpacity (0.95f);
            g.drawImage (uiLogo, juce::Rectangle<float> (slot.getX() + (slot.getWidth() - lw) * 0.5f, slot.getBottom() - lh - 4.f, lw, lh), juce::RectanglePlacement::centred);
            g.setOpacity (1.f);
        }
    }
    g.setOpacity (1.f);

    // SALEK icon badges (paint fallback — always visible if atlas loads)
    {
        if (tabs.getCurrentTabIndex() == 0)
        {
            auto drawIcon = [&] (int idx, juce::Rectangle<int> dest)
            {
                if (dest.getWidth() < 8) return;
                idx = juce::jlimit (0, 49, idx);
                auto sub = SalekAssets::loadIcon (idx);
                if (sub.isValid())
                {
                    g.setOpacity (1.f);
                    g.drawImage (sub, dest.toFloat(),
                                 juce::RectanglePlacement::centred | juce::RectanglePlacement::onlyReduceInSize);
                }
                else
                {
                    // neon fallback so icons never "missing"
                    auto d = dest.toFloat().reduced (2.f);
                    g.setColour (juce::Colour (0xff00e8ff).withAlpha (0.85f));
                    g.drawEllipse (d, 1.6f);
                    g.setColour (juce::Colour (0xffff2d9b).withAlpha (0.7f));
                    g.drawLine (d.getCentreX(), d.getY() + 4, d.getCentreX(), d.getBottom() - 4, 1.4f);
                    g.drawLine (d.getX() + 4, d.getCentreY(), d.getRight() - 4, d.getCentreY(), 1.4f);
                }
            };
            // OSC1/2/3 headers from osc monitors if present
            if (oscMon1 != nullptr)
            {
                auto r = getLocalArea (oscMon1.get(), oscMon1->getLocalBounds());
                drawIcon (0, juce::Rectangle<int> (r.getX() + 2, r.getY() + 1, 32, 32));
            }
            if (oscMon2 != nullptr && oscMon2->isVisible())
            {
                auto r = getLocalArea (oscMon2.get(), oscMon2->getLocalBounds());
                drawIcon (1, juce::Rectangle<int> (r.getX() + 2, r.getY() + 1, 32, 32));
            }
            if (oscMon3 != nullptr && oscMon3->isVisible())
            {
                auto r = getLocalArea (oscMon3.get(), oscMon3->getLocalBounds());
                drawIcon (2, juce::Rectangle<int> (r.getX() + 2, r.getY() + 1, 32, 32));
            }
            if (filterTab.isShowing())
            {
                auto r = getLocalArea (&filterTab, filterTab.getLocalBounds());
                drawIcon (11, juce::Rectangle<int> (r.getX() + 4, r.getY() + 4, 26, 26));
            }
        }
        else if (tabs.getCurrentTabIndex() == 2) // LFO
        {
            auto r = getLocalArea (&lfoTab, lfoTab.getLocalBounds());
            auto drawIcon = [&] (int idx, int x)
            {
                auto sub = SalekAssets::loadIcon (idx);
                if (! sub.isValid()) return;
                g.drawImage (sub, juce::Rectangle<float> ((float) x, (float) r.getY() + 4, 28.f, 28.f),
                             juce::RectanglePlacement::centred | juce::RectanglePlacement::onlyReduceInSize);
            };
            drawIcon (17, r.getX() + 8);
            drawIcon (18, r.getX() + 40);
            drawIcon (19, r.getX() + 72);
        }
        else if (tabs.getCurrentTabIndex() == 1) // MOD
        {
            auto r = getLocalArea (&modTab, modTab.getLocalBounds());
            auto drawIcon = [&] (int idx, int x)
            {
                auto sub = SalekAssets::loadIcon (idx);
                if (! sub.isValid()) return;
                g.drawImage (sub, juce::Rectangle<float> ((float) x, (float) r.getY() + 4, 28.f, 28.f),
                             juce::RectanglePlacement::centred | juce::RectanglePlacement::onlyReduceInSize);
            };
            drawIcon (20, r.getX() + 8);
            drawIcon (21, r.getX() + 40);
            drawIcon (5,  r.getX() + 72);
        }
        else if (tabs.getCurrentTabIndex() == 3) // FX
        {
            auto r = getLocalArea (&fxTab, fxTab.getLocalBounds());
            const int idxs[] = { 37, 36, 35, 9, 41, 40, 39, 32 };
            for (int i = 0; i < 8; ++i)
            {
                int idx = idxs[i];
                auto sub = SalekAssets::loadIcon (idx);
                if (! sub.isValid()) continue;
                float x = (float) r.getX() + 10.f + (float) (i % 2) * (r.getWidth() * 0.5f);
                float y = (float) r.getY() + 8.f + (float) (i / 2) * (r.getHeight() * 0.22f);
                g.drawImage (sub, juce::Rectangle<float> (x, y, 26.f, 26.f),
                             juce::RectanglePlacement::centred | juce::RectanglePlacement::onlyReduceInSize);
            }
        }

    }

    // ---- left panel: only show branding card when preset sidebar is collapsed ----
    if (presetCollapsed)
    {
        auto left = juce::Rectangle<float> (8.f, 48.f, 28.f, 120.f);
        g.setColour (juce::Colours::black.withAlpha (0.35f));
        g.fillRoundedRectangle (left.translated (2.f, 3.f), 8.f);
        g.setColour (juce::Colour (0xff0a0614).withAlpha (0.45f));
        g.fillRoundedRectangle (left, 8.f);
        g.setColour (cyan.withAlpha (0.5f));
        g.drawRoundedRectangle (left, 8.f, 1.2f);
        g.setColour (magenta);
        g.setFont (juce::FontOptions (10.0f, juce::Font::bold));
        g.drawText ("S", left, juce::Justification::centred);
    }
    // when preset is open, no solid card — background art stays fully visible behind the list


        // Serum-like section frames on MAIN (osc / filter / env)
        if (tabs.getCurrentTabIndex() == 0)
        {
            auto frame = [] (juce::Graphics& g, juce::Component& c, juce::Colour col, const char* title)
            {
                if (! c.isVisible() || c.getWidth() < 8) return;
                auto b = c.getBounds().toFloat();
                // convert to editor coords
                auto topLeft = c.getParentComponent()->getLocalBounds(); // wrong
                juce::ignoreUnused (topLeft);
            };
            juce::ignoreUnused (frame);
            auto drawFrame = [&] (juce::Component& c, juce::Colour col, const juce::String& title)
            {
                if (c.getWidth() < 10) return;
                auto r = getLocalArea (&c, c.getLocalBounds()).toFloat().reduced (2.f);
                juce::String fa;
                if (title == "OSCILLATORS") fa = juce::String::fromUTF8 ("موج\xe2\x80\x8c" "ساز");
                else if (title == "FILTER") fa = juce::String::fromUTF8 ("پالایه");
                else if (title == "AMP ENV") fa = juce::String::fromUTF8 ("پوشه");
                SalekLookAndFeel::drawOrnatePanel (g, r, col, title, fa, pulse);
            };
            auto frameAt = [&] (juce::Component& parent, juce::Rectangle<int> rc, juce::Colour c, const juce::String& en, const juce::String& fa)
            {
                SalekLookAndFeel::drawOrnatePanel (g, getLocalArea (&parent, rc).toFloat(), c, en, fa, pulse);
            };
            frameAt (oscTab, oscFrameRect[0], cyan,    "OSC 1",          juce::String::fromUTF8 ("اسیلاتور ۱"));
            frameAt (oscTab, oscFrameRect[1], magenta, "OSC 2  |  OSC 3", juce::String::fromUTF8 ("اسیلاتور ۲ و ۳"));
            frameAt (oscTab, oscFrameRect[2], gold,    "NOISE  |  SUB",  juce::String::fromUTF8 ("نویز و ساب"));
            drawFrame (filterTab, magenta, "FILTER");
            if (tabs.getCurrentTabIndex() == 1)   // MOD tab: framed groups
            {
                static const juce::Colour mc[6] = { juce::Colour (0xffffc861), juce::Colour (0xff73c9c5), juce::Colour (0xffff3ccf), juce::Colour (0xffa24bff), juce::Colour (0xff35e6ff), juce::Colour (0xff6cff7a) };
                static const char* mt[6] = { "FM", "AM", "PM", "RM", "MACRO 1-4  (GITI)", "MACRO 5-8" };
                for (int i = 0; i < 6; ++i)
                {
                    auto rr = getLocalArea (&modTab, modBox[i]).toFloat().reduced (1.f);
                    g.setColour (mc[i].withAlpha (0.07f)); g.fillRoundedRectangle (rr, 8.f);
                    g.setColour (mc[i].withAlpha (0.75f)); g.drawRoundedRectangle (rr, 8.f, 1.4f);
                    g.setFont (juce::FontOptions (9.f, juce::Font::bold));
                    g.drawText (mt[i], rr.removeFromTop (16.f).toNearestInt().reduced (8, 0), juce::Justification::centredLeft);
                }
            }
            if (tabs.getCurrentTabIndex() == 2)   // LFO tab: each LFO block gets its own frame, like the other sections
            {
                static const juce::Colour lc[3] = { juce::Colour (0xff35e6ff), juce::Colour (0xffff3ccf), juce::Colour (0xffffc861) };
                for (int i = 0; i < 3; ++i)
                {
                    auto rr = getLocalArea (&lfoTab, lfoColBox[i]).toFloat().reduced (1.f);
                    g.setColour (lc[i].withAlpha (0.08f)); g.fillRoundedRectangle (rr, 8.f);
                    g.setColour (lc[i].withAlpha (0.75f)); g.drawRoundedRectangle (rr, 8.f, 1.4f);
                    g.setFont (juce::FontOptions (9.f, juce::Font::bold)); g.drawText ("LFO " + juce::String (i + 1), rr.removeFromTop (14.f).toNearestInt().reduced (6, 0), juce::Justification::centredLeft);
                }
            }
            frameAt (envTab, envFrameRect[0], cyan,   "AMP ENVELOPE", juce::String::fromUTF8 ("پوشه"));
            frameAt (envTab, envFrameRect[1], purple, "VOICE  |  GLIDE", juce::String::fromUTF8 ("صدا\xe2\x80\x8cها"));
            {   // animated mini monitor for NOISE / SUB
                auto sr = getLocalArea (&oscTab, nsScopeRect).toFloat().reduced (2.f);
                if (sr.getWidth() > 20.f && sr.getHeight() > 10.f)
                {
                    const float lvl = juce::jlimit (0.05f, 1.f, processor.getAPVTS().getRawParameterValue (selNS == 0 ? "noise_level" : "sub_level")->load() * 1.4f + 0.12f);
                    g.setColour (juce::Colours::black.withAlpha (0.45f));
                    g.fillRoundedRectangle (sr, 6.f);
                    g.setColour ((selNS == 0 ? cyan : purple).withAlpha (0.55f));
                    g.drawRoundedRectangle (sr, 6.f, 1.f);
                    juce::Path wv;
                    const int nb = 46;
                    for (int i = 0; i <= nb; ++i)
                    {
                        const float x = sr.getX() + sr.getWidth() * (float) i / (float) nb;
                        float y;
                        if (selNS == 0)
                        {
                            const unsigned h = (unsigned) (i * 2654435761u) ^ (unsigned) ((int) (animPhase * 14.f) * 40503u);
                            y = sr.getCentreY() + ((float) (h % 2000u) / 1000.f - 1.f) * sr.getHeight() * 0.42f * lvl;
                        }
                        else
                            y = sr.getCentreY() + std::sin ((float) i * 0.42f + animPhase * 6.f) * sr.getHeight() * 0.42f * lvl;
                        if (i == 0) wv.startNewSubPath (x, y); else wv.lineTo (x, y);
                    }
                    g.setColour ((selNS == 0 ? cyan : purple).withAlpha (0.25f));
                    g.strokePath (wv, juce::PathStrokeType (5.f));
                    g.setColour ((selNS == 0 ? cyan : purple).brighter (0.4f));
                    g.strokePath (wv, juce::PathStrokeType (1.5f));
                }
            }
            // Vertical separators between OSC1 | OSC2 | OSC3 (user red lines)
            {
                auto orc = getLocalArea (&oscTab, oscTab.getLocalBounds()).toFloat();
                const float gap = 12.f;
                const float colW = (orc.getWidth() - gap * 2.f) / 3.f;
                (void) colW; (void) gap; (void) orc;
            }
        }

}
