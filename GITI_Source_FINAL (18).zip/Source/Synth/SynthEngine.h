#pragma once
#include <JuceHeader.h>
#include "SynthVoice.h"
#include "SynthSound.h"
#include <array>
#include <limits>

namespace salek
{

/** Synthesiser with an allocation-free mono/legato note stack.
    Poly mode keeps JUCE's normal voice allocation path. */
class VoiceModeSynthesiser final : public juce::Synthesiser
{
public:
    void setVoiceMode (int newMode)
    {
        newMode = juce::jlimit (0, 2, newMode);
        if (newMode == voiceMode) return;
        juce::Synthesiser::allNotesOff (0, false);
        heldCount = 0;
        voiceMode = newMode;
    }

    float lastPlayedHz = 0.f;
    void setPolyphony (int voiceCount) noexcept { polyphony = juce::jlimit (1, 16, voiceCount); }

    void noteOn (int midiChannel, int midiNoteNumber, float velocity) override
    {
        // POLY glide: the voice that takes this note slides from the PREVIOUS note played by the engine
        const float newHz = (float) juce::MidiMessage::getMidiNoteInHertz (midiNoteNumber);
        for (int i = 0; i < getNumVoices(); ++i)
            if (auto* sv = dynamic_cast<SynthVoice*> (getVoice (i))) sv->setPolyGlideSource (lastPlayedHz);
        lastPlayedHz = newHz;
        if (voiceMode == 0)
        {
            juce::Synthesiser::noteOn (midiChannel, midiNoteNumber, velocity);
            return;
        }

        auto sound = getSound (0);
        auto* voice = dynamic_cast<SynthVoice*> (getVoice (0));
        if (sound == nullptr || voice == nullptr || ! sound->appliesToNote (midiNoteNumber)
            || ! sound->appliesToChannel (midiChannel))
            return;

        if (heldCount >= (int) heldNotes.size())
        {
            for (int i = 1; i < heldCount; ++i) heldNotes[(size_t) i - 1] = heldNotes[(size_t) i];
            --heldCount;
        }

        if (! voice->isVoiceActive())
        {
            heldCount = 0;
            startVoice (voice, sound.get(), midiChannel, midiNoteNumber, velocity);
        }
        else
        {
            // Legato suppresses envelope retriggers inside a phrase, but a
            // fresh phrase must restart even if the previous voice is still
            // fading through its release tail.
            const bool retriggerEnvelope = voiceMode == 1 || heldCount == 0;
            voice->retargetMonoNote (midiNoteNumber, velocity, retriggerEnvelope);
            voice->setKeyDown (true);
        }

        heldNotes[(size_t) heldCount++] = { midiChannel, midiNoteNumber, velocity };
    }

    void noteOff (int midiChannel, int midiNoteNumber, float velocity, bool allowTailOff) override
    {
        if (voiceMode == 0)
        {
            juce::Synthesiser::noteOff (midiChannel, midiNoteNumber, velocity, allowTailOff);
            return;
        }

        int found = -1;
        for (int i = heldCount - 1; i >= 0; --i)
            if (heldNotes[(size_t) i].channel == midiChannel && heldNotes[(size_t) i].note == midiNoteNumber)
            { found = i; break; }
        if (found < 0) return;

        const bool wasTopNote = found == heldCount - 1;
        for (int i = found + 1; i < heldCount; ++i)
            heldNotes[(size_t) i - 1] = heldNotes[(size_t) i];
        --heldCount;

        auto* voice = dynamic_cast<SynthVoice*> (getVoice (0));
        if (voice == nullptr || ! wasTopNote) return;

        if (heldCount > 0)
        {
            const auto previous = heldNotes[(size_t) heldCount - 1];
            voice->retargetMonoNote (previous.note, previous.velocity, voiceMode == 1);
            voice->setKeyDown (true);
        }
        else if (voice->isVoiceActive())
        {
            voice->setKeyDown (false);
            stopVoice (voice, velocity, allowTailOff);
        }
    }

    void allNotesOff (int midiChannel, bool allowTailOff) override
    {
        if (midiChannel <= 0)
            heldCount = 0;
        else
        {
            int write = 0;
            for (int i = 0; i < heldCount; ++i)
                if (heldNotes[(size_t) i].channel != midiChannel)
                    heldNotes[(size_t) write++] = heldNotes[(size_t) i];
            heldCount = write;
        }
        juce::Synthesiser::allNotesOff (midiChannel, allowTailOff);
    }

protected:
    juce::SynthesiserVoice* findFreeVoice (juce::SynthesiserSound* sound,
                                           int midiChannel, int midiNoteNumber,
                                           bool stealIfNoneAvailable) const override
    {
        juce::SynthesiserVoice* oldest = nullptr;
        juce::SynthesiserVoice* released = nullptr;
        for (int i = 0; i < juce::jmin (polyphony, getNumVoices()); ++i)
        {
            auto* voice = getVoice (i);
            if (voice == nullptr || ! voice->canPlaySound (sound)) continue;
            if (! voice->isVoiceActive()) return voice;
            if (oldest == nullptr || voice->wasStartedBefore (*oldest)) oldest = voice;
            if (voice->isPlayingButReleased()
                && (released == nullptr || voice->wasStartedBefore (*released)))
                released = voice;
        }
        juce::ignoreUnused (midiChannel, midiNoteNumber);
        return stealIfNoneAvailable ? (released != nullptr ? released : oldest) : nullptr;
    }

private:
    struct HeldNote { int channel = 1, note = -1; float velocity = 0.f; };
    std::array<HeldNote, 128> heldNotes {};
    int heldCount = 0, voiceMode = 0, polyphony = 8;
};

class SynthEngine
{
public:
    // per-note PAN (0..1, 0.5 = centre) sent by the host as VST3 note expression, read by every voice
    std::array<float, 128> notePanTable = [] { std::array<float, 128> a {}; a.fill (0.5f); return a; }();
    void setNotePan (int note, float pan) noexcept { if (note >= 0 && note < 128) notePanTable[(size_t) note] = juce::jlimit (0.f, 1.f, pan); }
    SynthEngine();
    void prepareToPlay (double sampleRate, int samplesPerBlock);
    void releaseResources();
    void processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi);
    void allNotesOff();

    void setOsc1TablePos (float v); void setOsc2TablePos (float v); void setOsc3TablePos (float v);
    void setOsc1Level (float v); void setOsc2Level (float v); void setOsc3Level (float v);
    void setOsc1Pan (float v); void setOsc2Pan (float v); void setOsc3Pan (float v);
    void setOsc1Octave (int v); void setOsc2Octave (int v); void setOsc3Octave (int v);
    void setOsc1Semi (int v); void setOsc2Semi (int v); void setOsc3Semi (int v);
    void setOsc1CoarsePitch (int v); void setOsc2CoarsePitch (int v); void setOsc3CoarsePitch (int v);
    void setOsc1Fine (float v); void setOsc2Fine (float v); void setOsc3Fine (float v);
    void setOsc1Detune (float v); void setOsc2Detune (float v); void setOsc3Detune (float v);
    void setOsc1Phase (float v); void setOsc2Phase (float v); void setOsc3Phase (float v);
    void setOsc1Rand (float v); void setOsc2Rand (float v); void setOsc3Rand (float v);
    void setOsc1Warp (float v); void setOsc2Warp (float v); void setOsc3Warp (float v);
    void setOsc1Fold (float v); void setOsc2Fold (float v); void setOsc3Fold (float v);
    void setOsc1Drive (float v); void setOsc2Drive (float v); void setOsc3Drive (float v);

    void setFilterCutoff (float v); void setFilterResonance (float v);
    void setFilterDrive (float v); void setFilterMode (int v); void setFilterEnvAmt (float v);
    void setFilter2Cutoff (float v); void setFilter2Resonance (float v); void setFilter2Drive (float v);
    void setFilter2EnvAmt (float v); void setFilter1Mix (float v); void setFilter2Mix (float v);
    void setFilter2Mode (int v); void setFilter1Src (int v); void setFilter2Src (int v);
    void setSubPitchMod (float v); void setEco (bool e); void setOscStepCents (int i, float cents); void setNoiseType (int v); void setNoiseTone (float v); void setNoisePan (float v); void setSubPan (float v); void setSubOctave (int v); void setSubSemi (int v);
    void setNoiseLevel (float v); void setSubLevel (float v); void setFilterRoute (int v); void setGlide (float v);
    void setVoiceMode (int mode, int polyphony);
    void setPitchModulation (float cents);
    float getEnvelopeLevel() noexcept
    {
        float level = 0.0f;
        for (int i = 0; i < synth.getNumVoices(); ++i)
            if (const auto* voice = dynamic_cast<const SynthVoice*> (synth.getVoice (i)))
                level = juce::jmax (level, voice->getEnvelopeLevel());
        return level;
    }
    void setOsc1Unison (int v, float d, float s);
    void setOsc2Unison (int v, float d, float s);
    void setOsc3Unison (int v, float d, float s);

    void setAmpAttack (float v); void setAmpDecay (float v);
    void setAmpSustain (float v); void setAmpRelease (float v);

    void setLfoRate (float v); void setLfoAmount (float v); void setLfoWave (int v);

    void setFm2to1 (float v); void setFm3to1 (float v); void setFm3to2 (float v);
    void setPm2to1 (float v); void setPm3to1 (float v);
    void setRm2to1 (float v); void setAm2to1 (float v);

    void setUnison (int v); void setUnisonDetune (float v); void setUnisonSpread (float v);

    void setScaleMode (int m); void setKoronCents (float c);

    void labRegenerate();
    void labProcessFrames (float fold, float drive);
    void labMorph (float t);

private:
    static constexpr int maxVoices = 16;
    VoiceModeSynthesiser synth;
    // Most synth controls stay fixed for many audio blocks. Avoid pushing the
    // same values through every voice at every block boundary.
    std::array<float, 128> lastFloatParameters;
    std::array<int, 48> lastIntParameters;

    bool updateIfChanged (std::array<float, 128>& values, size_t index, float value) noexcept
    {
        if (values[index] == value) return false;
        values[index] = value;
        return true;
    }
    bool updateIfChanged (std::array<int, 48>& values, size_t index, int value) noexcept
    {
        if (values[index] == value) return false;
        values[index] = value;
        return true;
    }

    template <typename Fn>
    void forEachVoice (Fn&& fn)
    {
        for (int i = 0; i < synth.getNumVoices(); ++i)
            // SynthEngine exclusively installs SynthVoice instances above.
            fn (static_cast<SynthVoice&> (*synth.getVoice (i)));
    }
};

} // namespace salek
