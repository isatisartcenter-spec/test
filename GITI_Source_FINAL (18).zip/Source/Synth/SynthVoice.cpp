#include "SynthVoice.h"

namespace salek {

void SynthVoice::updateFrequencies()
{
    const float f1 = noteToHz (currentMidiNote, osc1Octave, osc1Semi + osc1Coarse, osc1Fine + osc1Detune);
    const float f2 = noteToHz (currentMidiNote, osc2Octave, osc2Semi + osc2Coarse, osc2Fine + osc2Detune);
    const float f3 = noteToHz (currentMidiNote, osc3Octave, osc3Semi + osc3Coarse, osc3Fine + osc3Detune);
    glideTargetHz1 = juce::jmax (1.f, f1);
    glideTargetHz2 = juce::jmax (1.f, f2);
    glideTargetHz3 = juce::jmax (1.f, f3);
    glideTargetLogHz1 = std::log (glideTargetHz1);
    glideTargetLogHz2 = std::log (glideTargetHz2);
    glideTargetLogHz3 = std::log (glideTargetHz3);
    if (! glideActive)
    {
        glideHz1 = glideTargetHz1; glideHz2 = glideTargetHz2; glideHz3 = glideTargetHz3;
        glideLogHz1 = glideTargetLogHz1; glideLogHz2 = glideTargetLogHz2; glideLogHz3 = glideTargetLogHz3;
        osc1.setFrequency (glideHz1); osc2.setFrequency (glideHz2); osc3.setFrequency (glideHz3);
    }
    uniFreqDirty = true;
}

void SynthVoice::updateGlideFrequencies() noexcept
{
    // Pitch bend and modulation are independent of note glide and are applied
    // to every audible unison oscillator, preserving each voice's tuning ratio.
    pitchBendLog += pitchBendSmoothCoeff * (targetPitchBendLog - pitchBendLog);
    pitchModLog += pitchBendSmoothCoeff * (targetPitchModLog - pitchModLog);
    pitchBendRatio = std::exp (pitchBendLog + pitchModLog);

    if (glideActive && glideAmt > 0.0001f)
    {
        const float a = glideCoeff;
        glideLogHz1 += a * (glideTargetLogHz1 - glideLogHz1);
        glideLogHz2 += a * (glideTargetLogHz2 - glideLogHz2);
        glideLogHz3 += a * (glideTargetLogHz3 - glideLogHz3);
        if (std::abs (glideTargetLogHz1 - glideLogHz1) < 0.00008f
            && std::abs (glideTargetLogHz2 - glideLogHz2) < 0.00008f
            && std::abs (glideTargetLogHz3 - glideLogHz3) < 0.00008f)
        {
            glideLogHz1 = glideTargetLogHz1; glideLogHz2 = glideTargetLogHz2; glideLogHz3 = glideTargetLogHz3;
            glideActive = false;
        }
        glideHz1 = std::exp (glideLogHz1);
        glideHz2 = std::exp (glideLogHz2);
        glideHz3 = std::exp (glideLogHz3);
    }

    const float r1 = pitchBendRatio * stepRatio[0], r2 = pitchBendRatio * stepRatio[1], r3 = pitchBendRatio * stepRatio[2];
    osc1.setFrequency (glideHz1 * r1);
    osc2.setFrequency (glideHz2 * r2);
    osc3.setFrequency (glideHz3 * r3);
    for (int u = 0; u < nUniEff1; ++u) uniOsc1[u].setFrequency (glideHz1 * uniFreqRatio1[u] * r1);
    for (int u = 0; u < nUniEff2; ++u) uniOsc2[u].setFrequency (glideHz2 * uniFreqRatio2[u] * r2);
    for (int u = 0; u < nUniEff3; ++u) uniOsc3[u].setFrequency (glideHz3 * uniFreqRatio3[u] * r3);
}

void SynthVoice::updateGlideCoefficient() noexcept
{
    // Exponential pitch motion: fine control is useful at the bottom, with
    // enough range for long psytrance slides at the top.
    const float timeMs = 12.0f + 1488.0f * glideAmt * glideAmt;
    const float sr = (float) juce::jmax (1.0, currentSampleRate);
    // Reach about 95% of the target within the selected control time.
    glideCoeff = 1.0f - std::exp (-3.0f / (0.001f * timeMs * sr));
}

void SynthVoice::setGlide (float value)
{
    glideAmt = juce::jlimit (0.f, 1.f, value);
    updateGlideCoefficient();
    if (glideAmt <= 0.0001f && glideActive)
    {
        glideActive = false;
        glideLogHz1 = glideTargetLogHz1; glideLogHz2 = glideTargetLogHz2; glideLogHz3 = glideTargetLogHz3;
        glideHz1 = glideTargetHz1; glideHz2 = glideTargetHz2; glideHz3 = glideTargetHz3;
        osc1.setFrequency (glideHz1); osc2.setFrequency (glideHz2); osc3.setFrequency (glideHz3);
        uniFreqDirty = true;
    }
}

void SynthVoice::refreshUnisonTuning() noexcept
{
    // Soft budget: if all three oscs max unison, scale down to protect CPU
    int v1 = juce::jmax (1, uniVoices1);
    int v2 = juce::jmax (1, uniVoices2);
    int v3 = juce::jmax (1, uniVoices3);
    // Silent oscs cost 0 toward budget
    const int c1 = osc1Level > 1e-5f ? v1 : 0;
    const int c2 = osc2Level > 1e-5f ? v2 : 0;
    const int c3 = osc3Level > 1e-5f ? v3 : 0;
    int total = c1 + c2 + c3;
    if (total > maxUniBudget && total > 0)
    {
        const float scale = (float) maxUniBudget / (float) total;
        if (c1 > 0) v1 = juce::jmax (1, (int) std::lround (v1 * scale));
        if (c2 > 0) v2 = juce::jmax (1, (int) std::lround (v2 * scale));
        if (c3 > 0) v3 = juce::jmax (1, (int) std::lround (v3 * scale));
    }
    nUniEff1 = osc1Level > 1e-5f ? v1 : 0;
    nUniEff2 = osc2Level > 1e-5f ? v2 : 0;
    nUniEff3 = osc3Level > 1e-5f ? v3 : 0;

    auto fill = [&] (int n, float detAmt, float spr, float* detTbl, float* freqRatio,
                     float* panTbl,
                     float* panGainL, float* panGainR,
                     WavetableOscillator* oscs, int oct, int semi, int coarse, float fine,
                     float glideHz)
    {
        float oscDetune = 0.0f;
        if (oscs == uniOsc1) oscDetune = osc1Detune;
        else if (oscs == uniOsc2) oscDetune = osc2Detune;
        else if (oscs == uniOsc3) oscDetune = osc3Detune;
        const float baseHz = juce::jmax (1.f, noteToHz (currentMidiNote, oct, semi + coarse, fine + oscDetune));
        for (int u = 0; u < maxUnison; ++u)
        {
            float det = 0.f, pan = 0.5f;
            if (n > 1 && u < n)
            {
                const float t = ((float) u / (float) (n - 1)) * 2.0f - 1.0f;
                det = t * detAmt;
                pan = 0.5f + 0.5f * t * spr;
            }
            detTbl[u] = det;
            panTbl[u] = pan;
            panGainL[u] = std::cos (pan * juce::MathConstants<float>::halfPi);
            panGainR[u] = std::sin (pan * juce::MathConstants<float>::halfPi);
            if (u < n)
            {
                const float tunedHz = noteToHz (currentMidiNote, oct, semi + coarse, fine + oscDetune + det);
                freqRatio[u] = tunedHz / baseHz;
                oscs[u].setFrequency ((glideActive ? glideHz : baseHz) * freqRatio[u] * pitchBendRatio);
            }
        }
    };
    fill (nUniEff1, uniDet1, uniSpr1, uniDetTbl1, uniFreqRatio1, uniPanTbl1, uniPanGainL1, uniPanGainR1,
          uniOsc1, osc1Octave, osc1Semi, osc1Coarse, osc1Fine, glideHz1);
    fill (nUniEff2, uniDet2 * 0.9f, uniSpr2, uniDetTbl2, uniFreqRatio2, uniPanTbl2, uniPanGainL2, uniPanGainR2,
          uniOsc2, osc2Octave, osc2Semi, osc2Coarse, osc2Fine, glideHz2);
    fill (nUniEff3, uniDet3 * 0.85f, uniSpr3, uniDetTbl3, uniFreqRatio3, uniPanTbl3, uniPanGainL3, uniPanGainR3,
          uniOsc3, osc3Octave, osc3Semi, osc3Coarse, osc3Fine, glideHz3);
    uniFreqDirty = false;
}

void SynthVoice::renderNextBlock (juce::AudioBuffer<float>& outputBuffer, int startSample, int numSamples)
{
    if (! isVoiceActive())
        return;

    auto* left  = outputBuffer.getWritePointer (0, startSample);
    auto* right = outputBuffer.getNumChannels() > 1
                    ? outputBuffer.getWritePointer (1, startSample) : nullptr;

    if (uniFreqDirty)
        refreshUnisonTuning();

    const int nUni1 = juce::jmax (0, nUniEff1);
    const int nUni2 = juce::jmax (0, nUniEff2);
    const int nUni3 = juce::jmax (0, nUniEff3);
    const float invN1 = nUni1 > 0 ? 1.0f / std::sqrt ((float) nUni1) : 0.f;
    const float invN2 = nUni2 > 0 ? 1.0f / std::sqrt ((float) nUni2) : 0.f;
    const float invN3 = nUni3 > 0 ? 1.0f / std::sqrt ((float) nUni3) : 0.f;

    for (int i = 0; i < numSamples; ++i)
    {
        updateGlideFrequencies();
        if (! adsr.isActive() && ! isNoteOn)
        {
            clearCurrentNote();
            break;
        }

        // --- OSC3 with unison (modulator) ---
        float s3L = 0.f, s3R = 0.f, s3Mono = 0.f;
        for (int u = 0; u < nUni3; ++u)
        {
            const float s = uniOsc3[u].processSample (0.0f, 1.0f);
            s3L += s * uniPanGainL3[u];
            s3R += s * uniPanGainR3[u];
            s3Mono += s;
        }
        if (nUni3 > 0) { s3L *= invN3; s3R *= invN3; s3Mono *= invN3; }

        // --- OSC2 with unison (FM from OSC3) ---
        float s2L = 0.f, s2R = 0.f, s2Mono = 0.f;
        const float pmFor2 = s3Mono * fm3to2 * 0.5f;
        for (int u = 0; u < nUni2; ++u)
        {
            const float s = uniOsc2[u].processSample (pmFor2, 1.0f);
            s2L += s * uniPanGainL2[u];
            s2R += s * uniPanGainR2[u];
            s2Mono += s;
        }
        if (nUni2 > 0) { s2L *= invN2; s2R *= invN2; s2Mono *= invN2; }

        // --- OSC1 with unison (carrier, FM/PM/AM from 2&3) ---
        // FM index: exponential feel — fine control low, aggressive high (Serum-like)
        const float fmIndex2 = fm2to1 * fm2to1 * 5.5f;
        const float fmIndex3 = fm3to1 * fm3to1 * 4.8f;
        const float pmFrom2  = s2Mono * (fmIndex2 + pm2to1 * 1.25f);
        const float pmFrom3  = s3Mono * (fmIndex3 + pm3to1 * 1.1f);
        float am = 1.0f;
        if (am2to1 > 1.0e-4f)
            am = 1.0f + (s2Mono * am2to1);
        const float pmCarrier = pmFrom2 + pmFrom3;

        float s1L = 0.f, s1R = 0.f;
        for (int u = 0; u < nUni1; ++u)
        {
            const float s = uniOsc1[u].processSample (pmCarrier, am);
            s1L += s * uniPanGainL1[u];
            s1R += s * uniPanGainR1[u];
        }
        if (nUni1 > 0) { s1L *= invN1; s1R *= invN1; }

        // Per-osc levels before filter route
        float o1L = s1L, o1R = s1R;
        float o2L = s2L, o2R = s2R;
        float o3L = s3L, o3R = s3R;
        if (rm2to1 > 1.0e-4f)
        {
            o1L = s1L * (1.0f - rm2to1) + (s1L * s2Mono) * rm2to1;
            o1R = s1R * (1.0f - rm2to1) + (s1R * s2Mono) * rm2to1;
        }
        // Sub oscillator (square-ish at -1 oct)
        float subL = 0.f, subR = 0.f;
        if (subLevel > 1.0e-4f)
        {
            const float subHz = noteToHz (currentMidiNote, subOct, subSemi, subPitchMod) * pitchBendRatio;
            subPhase += subHz / (float) getSampleRate();
            if (subPhase >= 1.f) subPhase -= 1.f;
            const float sq = subPhase < 0.5f ? 1.f : -1.f;
            subL = subR = sq * subLevel * 0.35f;
        }
        // Noise
        float nL = 0.f, nR = 0.f;
        if (noiseLevel > 1.0e-4f)
        {
            float n = (noiseRng.nextFloat() * 2.f - 1.f);
            const float w = n;
            switch (noiseType)
            {
                case 1: pinkB0 = 0.99765f * pinkB0 + w * 0.0990460f; pinkB1 = 0.96300f * pinkB1 + w * 0.2965164f;
                        pinkB2 = 0.57000f * pinkB2 + w * 1.0526913f; n = (pinkB0 + pinkB1 + pinkB2 + w * 0.1848f) * 0.25f; break;
                case 2: brownY = (brownY + 0.02f * w) / 1.02f; n = brownY * 3.5f; break;
                case 3: n = (noiseRng.nextFloat() > 0.9975f) ? w * 2.f : w * 0.02f; break;                       // vinyl crackle
                case 4: hatLP += 0.6f * (w - hatLP); n = (w - hatLP) * std::exp (-noisePh * 18.f); break;        // short hi-hat tick
                case 5: noiseEnv = std::exp (-noisePh * 9.f); n = std::sin (juce::MathConstants<float>::twoPi * (45.f + 160.f * std::exp (-noisePh * 30.f)) * noisePh) * noiseEnv * 1.4f + w * 0.15f * std::exp (-noisePh * 80.f); break;   // kick thump + click
                case 6: n = (w * std::exp (-noisePh * 14.f) + std::sin (juce::MathConstants<float>::twoPi * 190.f * noisePh) * std::exp (-noisePh * 22.f) * 0.6f); break;                                                      // snare burst
                default: break;
            }
            if (noiseType >= 4) noisePh += 1.f / (float) getSampleRate();                  // seconds since note start
            noiseLP += (0.02f + 0.98f * noiseTone * noiseTone) * (n - noiseLP);   // tone 1 = open, 0 = dark
            n = noiseLP * noiseLevel * 0.25f;
            nL = nR = n;
        }


        // Per-oscillator pan (0=L .. 1=R), preserves unison width
        const float notePanNow = (notePanTable != nullptr && currentMidiNote >= 0 && currentMidiNote < 128) ? notePanTable[currentMidiNote] : 0.5f;
        auto applyPan = [notePanNow] (float& L, float& R, float pan)
        {
            const float p = juce::jlimit (0.f, 1.f, pan + (notePanNow - 0.5f));
            const float b = (p - 0.5f) * 2.f; // -1..1
            if (b < 0.f) R *= (1.f + b);
            else         L *= (1.f - b);
        };
        applyPan (o1L, o1R, osc1Pan);
        applyPan (o2L, o2R, osc2Pan);
        applyPan (o3L, o3R, osc3Pan);
        applyPan (nL, nR, noisePan);
        applyPan (subL, subR, subPan);

        // Filter route: which oscs go through filter
        const bool f1 = (filterRoute == 0 || filterRoute == 1 || filterRoute == 4 || filterRoute == 5);
        const bool f2 = (filterRoute == 0 || filterRoute == 2 || filterRoute == 4 || filterRoute == 6);
        const bool f3 = (filterRoute == 0 || filterRoute == 3 || filterRoute == 5 || filterRoute == 6);
        float thruL = 0.f, thruR = 0.f, dryL = 0.f, dryR = 0.f, thru2L = 0.f, thru2R = 0.f;
        {
            // Per-source routing: filter 1 mask = legacy route (kept for old presets) AND new source lights; filter 2 = its own lights
            const int legacy = 31; (void) f1; (void) f2; (void) f3;   // source lamps (filter1_src / filter2_src) are authoritative now
            const int m1 = legacy & filterSrc1, m2 = filterSrc2;
            auto routeSrc = [&] (int bit, float L, float R)
            {
                const bool a = (m1 & bit) != 0, b = (m2 & bit) != 0;
                if (a) { thruL += L;  thruR += R; }
                if (b) { thru2L += L; thru2R += R; }
                if (! a && ! b) { dryL += L; dryR += R; }
            };
            routeSrc (1, o1L, o1R);   routeSrc (2, o2L, o2R);   routeSrc (4, o3L, o3R);
            routeSrc (8, nL, nR);     routeSrc (16, subL, subR);
        }

        const float env = adsr.getNextSample();
        lastEnvelopeLevel = env;
        const float lfoVal = lfo.process();
        // Filter-env opens relative to base; keep closed when base is near min
        float modCutoff = baseCutoff * std::pow (2.0f, (env * filterEnvAmt + lfoVal * 0.5f) * 2.5f);
        modCutoff = juce::jlimit (10.f, 20000.f, modCutoff);
        cutoffSmoother.setTarget (modCutoff);
        const float cutHz = cutoffSmoother.getNext();
        filterL.setCutoff (cutHz);
        filterR.setCutoff (cutHz);
        // Process L/R independently so stereo NEVER bypasses the filter
        float fL = ecoMode ? filterL.process (thruL) : osL.process (thruL, filterL);   // 2x oversampled unless Eco
        float fR = ecoMode ? filterR.process (thruR) : osR.process (thruR, filterR);
        // Extra close attenuation is only for low-pass modes. Applying this
        // after a high-pass used to mute the output when its cutoff was low.
        const bool lowPassMode = filterMode == 0 || filterMode == 1 || filterMode == 8
                              || filterMode == 9 || filterMode == 16 || filterMode == 17;
        if (lowPassMode && cutHz < 80.f)
        {
            const float close = cutHz / 80.f; // 0 at 0Hz .. 1 at 80Hz
            const float close2 = close * close;
            fL *= close2;
            fR *= close2;
        }
        fL = std::tanh (fL * 1.15f);
        fR = std::tanh (fR * 1.15f);
        // wet/dry mix of filter 1
        fL = fL * filterMix1 + thruL * (1.f - filterMix1);
        fR = fR * filterMix1 + thruR * (1.f - filterMix1);

        // ---- filter 2 (only costs CPU when at least one source feeds it) ----
        float g2L = 0.f, g2R = 0.f;
        if (filterSrc2 != 0)
        {
            float modCutoff2 = baseCutoff2 * std::pow (2.0f, (env * filterEnvAmt2 + lfoVal * 0.5f) * 2.5f);
            modCutoff2 = juce::jlimit (10.f, 20000.f, modCutoff2);
            cutoffSmoother2.setTarget (modCutoff2);
            const float cutHz2 = cutoffSmoother2.getNext();
            filter2L.setCutoff (cutHz2);
            filter2R.setCutoff (cutHz2);
            float f2L = ecoMode ? filter2L.process (thru2L) : os2L.process (thru2L, filter2L);
            float f2R = ecoMode ? filter2R.process (thru2R) : os2R.process (thru2R, filter2R);
            const bool lp2 = filterMode2 == 0 || filterMode2 == 1 || filterMode2 == 8
                          || filterMode2 == 9 || filterMode2 == 16 || filterMode2 == 17;
            if (lp2 && cutHz2 < 80.f)
            {
                const float c2 = (cutHz2 / 80.f) * (cutHz2 / 80.f);
                f2L *= c2;  f2R *= c2;
            }
            f2L = std::tanh (f2L * 1.15f);
            f2R = std::tanh (f2R * 1.15f);
            g2L = f2L * filterMix2 + thru2L * (1.f - filterMix2);
            g2R = f2R * filterMix2 + thru2R * (1.f - filterMix2);
        }
        float sampleL = fL + g2L + dryL;
        float sampleR = fR + g2R + dryR;
        // Hard mute if all levels essentially off (noise/sub included)
        const float lowNoteLift = currentMidiNote < 36 ? 1.28f : (currentMidiNote < 48 ? 1.14f : 1.0f);
        const float g = env * currentVelocity * 0.45f * lowNoteLift;
        sampleL *= g;
        sampleR *= g;

        left[i] += sampleL;
        if (right != nullptr)
            right[i] += sampleR;
    }

    if (! adsr.isActive())
    {
        clearCurrentNote();
        isNoteOn = false;
        glideActive = false;
        lastEnvelopeLevel = 0.0f;
    }
}

} // namespace salek
