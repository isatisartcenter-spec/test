// Three live OSC shape monitors + ASCII shape presets (no broken Persian glyphs)
{
    oscMon1 = std::make_unique<OscShapeMonitor>();
    oscMon2 = std::make_unique<OscShapeMonitor>();
    oscMon3 = std::make_unique<OscShapeMonitor>();
    oscMon1->setAPVTS (&processor.getAPVTS()); oscMon1->setOscIndex (0);
    oscMon1->setAccent (SalekLookAndFeel::teal());
    oscMon1->setTitle ("OSC1");
    oscMon2->setAPVTS (&processor.getAPVTS()); oscMon2->setOscIndex (1);
    oscMon2->setAccent (SalekLookAndFeel::rose());
    oscMon2->setTitle ("OSC2");
    oscMon3->setAPVTS (&processor.getAPVTS()); oscMon3->setOscIndex (2);
    oscMon3->setAccent (juce::Colour (0xffa8c895));
    oscMon3->setTitle ("OSC3");
    oscTab.addAndMakeVisible (*oscMon1);
    oscTab.addAndMakeVisible (*oscMon2);
    oscTab.addAndMakeVisible (*oscMon3);

    auto setupBox = [&] (juce::ComboBox& box, int osc, juce::Colour col)
    {
        box.clear (juce::dontSendNotification);
        const auto& wavetable = salek::SynthVoice::getSharedWavetable();
        for (int frame = 0; frame < wavetable.getNumFrames(); ++frame)
            box.addItem (juce::String (frame + 1).paddedLeft ('0', 3) + "  "
                             + salek::Wavetable::getFrameName (frame), frame + 1);
        const char* tableIds[] = { "osc1_table", "osc2_table", "osc3_table" };
        float tablePosition = 0.f;
        if (auto* p = processor.getAPVTS().getRawParameterValue (tableIds[osc]))
            tablePosition = p->load();
        const int frameCount = wavetable.getNumFrames();
        const int lastFrame = juce::jmax (0, frameCount - 1);
        const int initialFrame = juce::roundToInt (juce::jlimit (0.f, 1.f, tablePosition)
                                                     * (float) lastFrame);
        box.setSelectedItemIndex (initialFrame, juce::dontSendNotification);
        box.setColour (juce::ComboBox::backgroundColourId, SalekLookAndFeel::panel());
        box.setColour (juce::ComboBox::outlineColourId, SalekLookAndFeel::border());
        box.setColour (juce::ComboBox::textColourId, col);
        oscTab.addAndMakeVisible (box);
        box.onChange = [this, combo = &box, osc]
        {
            const int frame = combo->getSelectedItemIndex();
            if (frame < 0) return;
            const char* ids[] = { "osc1_table", "osc2_table", "osc3_table" };
            if (auto* p = processor.getAPVTS().getParameter (ids[osc]))
            {
                const int lastFrame = juce::jmax (1, salek::SynthVoice::getSharedWavetable().getNumFrames() - 1);
                const float position = (float) frame / (float) lastFrame;
                p->setValueNotifyingHost (p->convertTo0to1 (position));
            }
        };
    };
    setupBox (osc1ShapeBox, 0, SalekLookAndFeel::teal());
    setupBox (osc2ShapeBox, 1, SalekLookAndFeel::rose());
    setupBox (osc3ShapeBox, 2, juce::Colour (0xffa8c895));
}
