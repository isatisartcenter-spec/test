#pragma once
#include <juce_graphics/juce_graphics.h>
// GITI BY SALEK HIGHTECH - 50 Genesis editions. DNA stays the same, each edition has its own colour language / name.
// Names + taglines marked "draft" are placeholders for your own lore (edit freely).
#ifndef GITI_GENESIS_INDEX
 #define GITI_GENESIS_INDEX 1
#endif
namespace giti
{
struct GenesisInfo { int number; const char* name; const char* tagline; unsigned primary, secondary, accent, tertiary; };
inline const GenesisInfo* genesisTable()
{
    static const GenesisInfo t[50] = {
    { 1, "ORIGIN", "Origin Edition - Cyber / Purple", 0xff22e6ff, 0xffff3df2, 0xffe8b84a, 0xff7b3cff },
    { 2, "FORGE", "Aggressive / Industrial", 0xffff462d, 0xffff922d, 0xff389fff, 0xffc9f224 },
    { 3, "COSMIC DRIFT", "Alien / Cosmic", 0xff2dff81, 0xff702dff, 0xffffdf38, 0xff248ff2 },
    { 4, "PERSIA CODE", "Ancient Persian / Mystical", 0xffffc42d, 0xff2dffff, 0xffffdf38, 0xff4df224 },
    { 5, "DARKPSY", "Darkpsy", 0xffa22dff, 0xffff2d6c, 0xff5fff38, 0xfff2246e },
    { 6, "SIGNAL", "Genesis entity - draft identity", 0xffff2d52, 0xff56ff2d, 0xffbfff38, 0xfff2de24 },
    { 7, "ALIEN MEMORY", "Alien / Green / Organic", 0xff32ff2d, 0xffffc42d, 0xff38ffff, 0xff24e5f2 },
    { 8, "NEON RAIN", "Genesis entity - draft identity", 0xff5eff2d, 0xff442dff, 0xffffc738, 0xff24f2d2 },
    { 9, "CRYSTAL TIDE", "Genesis entity - draft identity", 0xff2dffc8, 0xffff2dc9, 0xffffdf38, 0xff2449f2 },
    { 10, "IRON LOTUS", "Genesis entity - draft identity", 0xff2d6aff, 0xffff2d94, 0xfffff738, 0xffc624f2 },
    { 11, "GLITCH GARDEN", "Genesis entity - draft identity", 0xffbb2dff, 0xffffb72d, 0xffefff38, 0xfff22456 },
    { 12, "TEHRAN 2099", "Genesis entity - draft identity", 0xffff2d77, 0xff55ff2d, 0xffd7ff38, 0xfff2ba24 },
    { 13, "WAR SIGNAL", "Red / Aggressive / War Machine", 0xffff2d2d, 0xffff852d, 0xffffc738, 0xffe1f224 },
    { 14, "ECHO CHAMBER", "Genesis entity - draft identity", 0xff83ff2d, 0xff452dff, 0xffffaf38, 0xff24f2ae },
    { 15, "SOLAR WIND", "Genesis entity - draft identity", 0xff2dffa3, 0xff792dff, 0xffffc738, 0xff246ef2 },
    { 16, "VOID WALKER", "Genesis entity - draft identity", 0xff2d8fff, 0xffff2d93, 0xffffdf38, 0xffa224f2 },
    { 17, "ACID TEMPLE", "Genesis entity - draft identity", 0xff972dff, 0xffffb82d, 0xfffff738, 0xfff2247a },
    { 18, "MIRROR GATE", "Genesis entity - draft identity", 0xffff2d9b, 0xff54ff2d, 0xffefff38, 0xfff29624 },
    { 19, "PLASMA BLOOM", "Genesis entity - draft identity", 0xffff8a2d, 0xff2dfff7, 0xffd7ff38, 0xff86f224 },
    { 20, "STONE ORACLE", "Genesis entity - draft identity", 0xffa8ff2d, 0xff2dd1ff, 0xffbfff38, 0xff24f28a },
    { 21, "GOLDEN PERSIA", "Ancient Persian / Gold / Mystical", 0xffffc42d, 0xffff602d, 0xff38ffff, 0xff4df224 },
    { 22, "DEEP RELAY", "Genesis entity - draft identity", 0xff2db4ff, 0xffff2d92, 0xffffc738, 0xff7e24f2 },
    { 23, "SKY FORGE", "Genesis entity - draft identity", 0xff722dff, 0xffffb92d, 0xffffdf38, 0xfff2249e },
    { 24, "TOXIC DREAM", "Genesis entity - draft identity", 0xffff2dc0, 0xff53ff2d, 0xfffff738, 0xfff27224 },
    { 25, "PULSE NOMAD", "Genesis entity - draft identity", 0xffff662d, 0xff2dff3c, 0xffefff38, 0xffaaf224 },
    { 26, "OBSIDIAN", "Genesis entity - draft identity", 0xffccff2d, 0xff2dd0ff, 0xffd7ff38, 0xff24f266 },
    { 27, "LASER GARDEN", "Genesis entity - draft identity", 0xff2dff5a, 0xff7b2dff, 0xffbfff38, 0xff24b6f2 },
    { 28, "DESERT SIGNAL", "Genesis entity - draft identity", 0xff2dd8ff, 0xffff2d91, 0xffffaf38, 0xff5a24f2 },
    { 29, "HOLOGRAM", "Genesis entity - draft identity", 0xff4d2dff, 0xffffba2d, 0xffffc738, 0xfff224c2 },
    { 30, "NIGHT ENGINE", "Genesis entity - draft identity", 0xffff2de5, 0xffffef2d, 0xffffdf38, 0xfff24e24 },
    { 31, "SPIRAL GATE", "Genesis entity - draft identity", 0xffff412d, 0xff2dff3d, 0xfffff738, 0xffcef224 },
    { 32, "MOON CIRCUIT", "Genesis entity - draft identity", 0xfff1ff2d, 0xff2dcfff, 0xffefff38, 0xff24f242 },
    { 33, "UFO DREAM", "Cosmic / Blue / UFO", 0xff2d81ff, 0xff2dffff, 0xffff38af, 0xffb024f2 },
    { 34, "STORM CODE", "Genesis entity - draft identity", 0xff2dfdff, 0xffff2d90, 0xffbfff38, 0xff3624f2 },
    { 35, "RUBY ARC", "Genesis entity - draft identity", 0xff2d32ff, 0xffff2d5c, 0xffffaf38, 0xfff224e6 },
    { 36, "ZEN MACHINE", "Genesis entity - draft identity", 0xfff42dff, 0xfffff02d, 0xffffc738, 0xfff22a24 },
    { 37, "PHANTOM BASS", "Genesis entity - draft identity", 0xffff2d3e, 0xff2dff3e, 0xffffdf38, 0xfff2f224 },
    { 38, "AURORA", "Genesis entity - draft identity", 0xffffe82d, 0xff2dceff, 0xfffff738, 0xff2af224 },
    { 39, "SHATTERED SUN", "Genesis entity - draft identity", 0xff4aff2d, 0xff7d2dff, 0xffefff38, 0xff24f2e6 },
    { 40, "LUNAR ACID", "Genesis entity - draft identity", 0xff2dffdb, 0xffb22dff, 0xffd7ff38, 0xff2436f2 },
    { 41, "CYBER SAGE", "Genesis entity - draft identity", 0xff2d57ff, 0xffff2d5b, 0xffbfff38, 0xffda24f2 },
    { 42, "FLUX ENTITY", "Genesis entity - draft identity", 0xffcf2dff, 0xfffff12d, 0xffffaf38, 0xfff22442 },
    { 43, "DARK NEBULA", "Genesis entity - draft identity", 0xffff2d63, 0xff2dff3f, 0xffffc738, 0xfff2ce24 },
    { 44, "CORAL SIGNAL", "Genesis entity - draft identity", 0xffffc32d, 0xff2dcdff, 0xffffdf38, 0xff4ef224 },
    { 45, "TITAN", "Genesis entity - draft identity", 0xff6fff2d, 0xff2d99ff, 0xfffff738, 0xff24f2c2 },
    { 46, "SILENT STAR", "Genesis entity - draft identity", 0xff2dffb7, 0xffb32dff, 0xffefff38, 0xff245af2 },
    { 47, "EMBER WORLD", "Genesis entity - draft identity", 0xff2d7bff, 0xffff2d5a, 0xffd7ff38, 0xffb624f2 },
    { 48, "INFINITE LOOP", "Genesis entity - draft identity", 0xffab2dff, 0xfffff22d, 0xffbfff38, 0xfff22466 },
    { 49, "PRIME NODE", "Genesis entity - draft identity", 0xffff2d87, 0xff2dff40, 0xffffaf38, 0xfff2aa24 },
    { 50, "FINAL ASCENSION", "Ultimate / SALEK / Final Evolution", 0xffffc42d, 0xfffa2dff, 0xff38e7ff, 0xff4df224 }
    };
    return t;
}
inline const GenesisInfo& genesis()
{
    const int i = (GITI_GENESIS_INDEX < 1 ? 1 : (GITI_GENESIS_INDEX > 50 ? 50 : GITI_GENESIS_INDEX)) - 1;
    return genesisTable()[i];
}
inline juce::Colour primaryColour()   { return juce::Colour ((juce::uint32) genesis().primary); }
inline juce::Colour secondaryColour() { return juce::Colour ((juce::uint32) genesis().secondary); }
inline juce::Colour accentColour()    { return juce::Colour ((juce::uint32) genesis().accent); }
inline juce::Colour tertiaryColour()  { return juce::Colour ((juce::uint32) genesis().tertiary); }
// hue offset of this edition relative to the original cyan - used to recolour the crystal artwork
inline float genesisHueShift()
{
    float h0, s0, b0, h1, s1, b1;
    juce::Colour (0xff22e6ff).getHSB (h0, s0, b0);
    primaryColour().getHSB (h1, s1, b1);
    float d = h1 - h0;
    if (d > 0.5f) d -= 1.f; if (d < -0.5f) d += 1.f;
    return d;
}
inline juce::String genesisLabel()
{
    return "GENESIS " + juce::String (genesis().number).paddedLeft ('0', 2) + " // " + juce::String (genesis().name);
}
}
