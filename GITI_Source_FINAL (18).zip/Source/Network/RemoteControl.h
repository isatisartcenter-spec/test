#pragma once
// GITI remote control over Wi-Fi (UDP). The phone pairs with a 6-digit code, then sends normalized values
// (0..1) for the tab-1 controls. The plugin also reports values back when they change in the DAW.
//
// Protocol (ASCII lines, one datagram each):
//   phone -> plugin   H <code>            pair; plugin answers OK and sends the full state
//   phone -> plugin   S <index> <value>   set control <index> to <value> (0..1)
//   plugin -> phone   V <index> <value>   control <index> is now <value> (0..1)
//   plugin -> phone   OK / ERR            answer to H
#include <juce_core/juce_core.h>
#include <functional>
#include "HttpServer.h"
#include "RemotePage.h"

namespace giti { namespace remote {

// Tab 1 layout (rows): filters | LFO rates | LFO phases. The phone shows them in the same order.
inline const char* const controlIds[] = {
    "filter_cutoff", "filter_reso", "filter2_cutoff", "filter2_reso",
    "lfo_rate", "lfo2_rate", "lfo3_rate",
    "lfo_phase", "lfo2_phase", "lfo3_phase"
};
constexpr int numControls = (int) (sizeof (controlIds) / sizeof (controlIds[0]));

class RemoteControl : private juce::Thread
{
public:
    using GetFn = std::function<float (const juce::String& paramId)>;          // normalized 0..1
    using SetFn = std::function<void (const juce::String& paramId, float v01)>; // normalized 0..1

    RemoteControl (GetFn g, SetFn s, int port, juce::String pairingCode)
        : juce::Thread ("GITI Remote"), getValue (std::move (g)), setValue (std::move (s)),
          listenPort (port), code (std::move (pairingCode))
    {}

    ~RemoteControl() override { stop(); }

    void start()
    {
        if (! isThreadRunning()) startThread (juce::Thread::Priority::low);
        if (http) http->start();
    }
    void stop()
    {
        if (http) http->stop();
        signalThreadShouldExit(); socket.shutdown(); stopThread (1000);
    }

    // Set by the processor: list of "id|name" for every parameter, and a sink for keyboard notes from the phone
    using ListFn = std::function<juce::StringArray()>;
    using NoteFn = std::function<void (bool on, int note, int velocity)>;
    void setParamList (ListFn f) { listFn = std::move (f); }
    using PresetListFn = std::function<juce::StringArray()>;            // "idx|name"
    using PresetLoadFn = std::function<void (int idx)>;
    using SeqGetFn     = std::function<juce::StringArray()>;            // "i off vel gate prob act acc"
    using SeqSetFn     = std::function<void (int step, const juce::String& key, float value)>;
    void setPresetFns (PresetListFn l, PresetLoadFn load) { presetListFn = std::move (l); presetLoadFn = std::move (load); }
    void setSeqFns (SeqGetFn g, SeqSetFn s2) { seqGetFn = std::move (g); seqSetFn = std::move (s2); }
    void setNoteSink (NoteFn f)  { noteFn = std::move (f); }

    // Enable the phone web page (TCP on the same port number as the UDP control)
    void enableWebPage()
    {
        http = std::make_unique<HttpServer> (listenPort, [this] (const HttpRequest& q) {
            return handleHttp (q.path, q.query, q.body, q.method);
        });
    }

    // Web page API (used by the HTTP server; also called directly by the tests)
    HttpResponse handleHttp (const juce::String& path, const juce::String& query,
                             const juce::String& body = {}, const juce::String& method = "GET")
    {
        HttpResponse r;
        auto param = [&] (const char* key) {
            for (auto& kv : juce::StringArray::fromTokens (query, "&", ""))
                if (kv.upToFirstOccurrenceOf ("=", false, false) == key)
                    return juce::URL::removeEscapeChars (kv.fromFirstOccurrenceOf ("=", false, false));
            return juce::String();
        };
        auto authed = [&] { auto t = param ("t"); return t.isNotEmpty() && t == webToken; };

        if (path == "/api/ping") { r.body = "GITI 1"; return r; }   // discovery: no token needed
        if (path == "/") { r.contentType = "text/html; charset=utf-8"; r.body = phonePageHtml(); return r; }
        if (path == "/api/pair")
        {
            if (param ("code") != code) { r.status = 403; r.body = "wrong code"; return r; }
            webToken = juce::String::toHexString (juce::Random::getSystemRandom().nextInt64())
                     + juce::String::toHexString (juce::Random::getSystemRandom().nextInt64());
            r.body = webToken; return r;
        }
        if (! authed()) { r.status = 403; r.body = "not paired"; return r; }
        if (path == "/api/state")
        {
            for (int i = 0; i < numControls; ++i) r.body << formatV (i) << "\n";
            return r;
        }
        if (path == "/api/set")
        {
            const float v = juce::jlimit (0.0f, 1.0f, (float) param ("v").getDoubleValue());
            const auto id = param ("id");
            if (id.isNotEmpty()) setValue (id, v);
            else
            {
                const int idx = param ("i").getIntValue();
                if (idx >= 0 && idx < numControls) setValue (controlIds[idx], v);
            }
            r.body = "OK"; return r;
        }
        if (path == "/api/params")
        {
            if (listFn) for (auto& line : listFn()) r.body << line << "\n";
            return r;
        }
        if (path == "/api/get")
        {
            for (auto& id : juce::StringArray::fromTokens (param ("ids"), ",", ""))
                if (id.isNotEmpty()) r.body << id << " " << juce::String (getValue (id), 4) << "\n";
            return r;
        }
        if (path == "/api/note")
        {
            if (noteFn) noteFn (param ("on") == "1", param ("n").getIntValue(), param ("v").getIntValue());
            r.body = "OK"; return r;
        }
        if (! authed()) { r.status = 403; r.body = "not paired"; return r; }
        if (path == "/api/layout")
        {
            if (method == "POST")
            {
                if (body.length() > 65536 || ! layoutFile().replaceWithText (body)) { r.status = 500; r.body = "cannot save"; return r; }
                r.body = "OK"; return r;
            }
            r.contentType = "application/json; charset=utf-8";
            r.body = layoutFile().existsAsFile() ? layoutFile().loadFileAsString() : juce::String ("null");
            return r;
        }
        if (path == "/api/presets")
        {
            if (presetListFn) for (auto& line : presetListFn()) r.body << line << "\n";
            return r;
        }
        if (path == "/api/preset")
        {
            if (presetLoadFn) presetLoadFn (param ("idx").getIntValue());
            r.body = "OK"; return r;
        }
        if (path == "/api/seq")
        {
            if (seqGetFn) for (auto& line : seqGetFn()) r.body << line << "\n";
            return r;
        }
        if (path == "/api/seqset")
        {
            if (seqSetFn) seqSetFn (param ("i").getIntValue(), param ("k"), (float) param ("v").getDoubleValue());
            r.body = "OK"; return r;
        }
        r.status = 404; r.body = "not found"; return r;
    }

    // Layout is stored on the computer, so every phone sees the same screens (plus the GITI user folder)
    static juce::File layoutFile()
    {
        auto f = juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory).getChildFile ("GITI").getChildFile ("phone_layout.json");
        f.getParentDirectory().createDirectory();
        return f;
    }

    bool isPaired() const noexcept { return paired.load(); }

    // Pure protocol handler (also used by the test). Returns the datagrams to send back to the sender.
    juce::StringArray handleLine (const juce::String& line, const juce::String& senderHost, int senderPort)
    {
        juce::StringArray out;
        auto parts = juce::StringArray::fromTokens (line.trim(), " ", "");
        if (parts.isEmpty()) return out;

        if (parts[0] == "H")
        {
            if (parts.size() >= 2 && parts[1] == code)
            {
                pairedHost = senderHost; pairedPort = senderPort; paired = true;
                out.add ("OK");
                for (int i = 0; i < numControls; ++i) out.add (formatV (i));
            }
            else out.add ("ERR");
            return out;
        }

        if (! paired.load() || senderHost != pairedHost || senderPort != pairedPort) return out;   // only the paired phone

        if (parts[0] == "S" && parts.size() >= 3)
        {
            const int idx = parts[1].getIntValue();
            const float v = juce::jlimit (0.0f, 1.0f, (float) parts[2].getDoubleValue());
            if (idx >= 0 && idx < numControls)
            {
                setValue (controlIds[idx], v);
                lastSent[(size_t) idx] = v;
                out.add (formatV (idx));
            }
        }
        return out;
    }

private:
    juce::String formatV (int idx)
    {
        const float v = getValue (controlIds[idx]);
        lastSent[(size_t) idx] = v;
        return "V " + juce::String (idx) + " " + juce::String (v, 4);
    }

    void run() override
    {
        if (! socket.bindToPort (listenPort)) return;
        while (! threadShouldExit())
        {
            if (socket.waitUntilReady (true, 100) == 1)
            {
                char buf[512];
                juce::String host; int port = 0;
                const int n = socket.read (buf, (int) sizeof (buf) - 1, false, host, port);
                if (n > 0)
                {
                    buf[n] = 0;
                    for (auto& reply : handleLine (juce::String::fromUTF8 (buf, n), host, port))
                        socket.write (host, port, reply.toRawUTF8(), (int) reply.getNumBytesAsUTF8());
                }
            }
            // report changes made in the DAW / on the plugin to the paired phone
            if (paired.load())
                for (int i = 0; i < numControls; ++i)
                {
                    const float v = getValue (controlIds[i]);
                    if (std::abs (v - lastSent[(size_t) i]) > 0.0005f)
                    {
                        lastSent[(size_t) i] = v;
                        const auto msg = formatV (i);
                        socket.write (pairedHost, pairedPort, msg.toRawUTF8(), (int) msg.getNumBytesAsUTF8());
                    }
                }
        }
        socket.shutdown();
    }

    GetFn getValue;
    SetFn setValue;
    int listenPort;
    juce::String code;
    juce::DatagramSocket socket { false };
    std::unique_ptr<HttpServer> http;
    ListFn listFn;
    NoteFn noteFn;
    PresetListFn presetListFn;
    PresetLoadFn presetLoadFn;
    SeqGetFn seqGetFn;
    SeqSetFn seqSetFn;
    juce::String webToken;
    std::atomic<bool> paired { false };
    juce::String pairedHost; int pairedPort = 0;
    std::array<float, numControls> lastSent {};
};

// Pairing code: random 6 digits, created once and kept in the user's application data folder.
inline juce::String loadOrCreatePairingCode()
{
    auto f = juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
                 .getChildFile ("GITI").getChildFile ("pairing_code.txt");
    f.getParentDirectory().createDirectory();
    auto code = f.loadFileAsString().trim();
    if (code.length() != 6)
    {
        code = juce::String (juce::Random::getSystemRandom().nextInt (1000000)).paddedLeft ('0', 6);
        f.replaceWithText (code);
    }
    return code;
}

}} // namespace giti::remote
