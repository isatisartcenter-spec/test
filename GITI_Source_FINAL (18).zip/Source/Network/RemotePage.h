#pragma once
// The phone page (GITI mobile UI). Served by the plugin at http://<computer-ip>:9731
namespace giti { namespace remote {
inline juce::String phonePageHtml()
{
    juce::String s;
    s += R"HTML(<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<meta name="apple-mobile-web-app-capable" content="yes">
<title>GITI</title>
<style>
:root{--bg:#060815;--panel:#0c1030;--line:#1f2a6b;--cy:#35e6ff;--mg:#ff3ccf;--gd:#ffc861;--tx:#d7ecff;--dim:#7e88b8}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;height:100%;background:radial-gradient(900px 600px at 50% -10%,#1d1260 0,var(--bg) 60%);color:var(--tx);font:13px/1.2 system-ui,-apple-system,Segoe UI,Tahoma,sans-serif;overflow:hidden;user-select:none;-webkit-user-select:none}
#top{height:56px;display:flex;align-items:center;justify-content:space-between;padding:0 14px;padding-top:env(safe-area-inset-top);border-bottom:1px solid var(--line);background:rgba(8,10,34,.9)}
.logo{font-weight:900;font-size:26px;letter-spacing:5px;background:linear-gradient(90deg,var(--cy),#fff 45%,var(--mg));-webkit-background-clip:text;color:transparent;filter:drop-shadow(0 0 8px rgba(53,230,255,.5))}
.sub{font-size:8px;letter-spacing:3px;color:var(--dim)}
#dot{width:9px;height:9px;border-radius:50%;background:#444;box-shadow:0 0 0 0 transparent;margin-left:8px;display:inline-block}
#dot.on{background:var(--cy);box-shadow:0 0 10px var(--cy)}
#pg{position:absolute;top:56px;bottom:calc(64px + env(safe-area-inset-bottom));left:0;right:0;overflow-y:auto;overflow-x:hidden;-webkit-overflow-scrolling:touch;padding:12px 12px 24px}
.screen{display:none}.screen.on{display:block}
.frame{position:relative;margin:0 0 14px;padding:26px 10px 12px;border-radius:14px;border:1.4px solid var(--c,var(--cy));background:linear-gradient(180deg,rgba(14,18,50,.9),rgba(8,10,28,.95));box-shadow:0 0 14px -6px var(--c,var(--cy)),inset 0 0 22px -12px var(--c,var(--cy))}
.frame>h3{position:absolute;top:-9px;left:14px;margin:0;padding:0 8px;background:var(--bg);font-size:11px;letter-spacing:2px;color:var(--c,var(--cy))}
.grid{display:grid;grid-template-columns:repeat(var(--cols,3),1fr);gap:10px 6px;justify-items:center}
.ctl{width:100%;display:flex;flex-direction:column;align-items:center;gap:4px;touch-action:none}
.ctl .lab{font-size:10px;letter-spacing:1px;color:var(--c,var(--cy));text-align:center;min-height:12px}
.ctl .val{font-size:10px;color:var(--tx);opacity:.85}
.knob{width:64px;height:64px}
.fader{width:46px;height:110px;position:relative;border-radius:10px;background:#070a20;border:1px solid var(--line)}
.fader .fill{position:absolute;left:4px;right:4px;bottom:4px;border-radius:6px;background:linear-gradient(0deg,var(--c),transparent);box-shadow:0 0 12px var(--c)}
.fader .cap{position:absolute;left:-3px;right:-3px;height:12px;border-radius:4px;background:#fff;box-shadow:0 0 10px var(--c)}
.btn{min-width:74px;height:34px;padding:0 10px;border-radius:9px;border:1px solid var(--c);background:transparent;color:var(--c);font-weight:800;font-size:11px;letter-spacing:1px}
.btn.on{background:var(--c);color:#050614;box-shadow:0 0 14px var(--c)}
.kbd{position:relative;height:150px;margin-top:6px;border-radius:10px;overflow:hidden;background:#05071a;border:1px solid var(--line)}
.wk{position:absolute;top:0;bottom:0;width:calc(100%/14);background:linear-gradient(#f2f6ff,#c9d4f2);border:1px solid #6a78b5;border-radius:0 0 6px 6px}
.wk.dn{background:linear-gradient(#7fe9ff,#35e6ff)}
.bk{position:absolute;top:0;height:60%;width:calc(100%/22);background:linear-gradient(#222,#060610);border-radius:0 0 5px 5px;z-index:2;border:1px solid #000}
.bk.dn{background:linear-gradient(#ff7ae3,#ff3ccf)}
#nav{position:absolute;bottom:0;left:0;right:0;height:calc(64px + env(safe-area-inset-bottom));padding-bottom:env(safe-area-inset-bottom);display:flex;justify-content:space-around;align-items:center;background:rgba(8,10,34,.96);border-top:1px solid var(--line)}
#nav button{background:none;border:0;color:var(--dim);font-size:10px;letter-spacing:1px;display:flex;flex-direction:column;align-items:center;gap:3px;padding:6px 4px;min-width:52px}
#nav button i{display:block;width:22px;height:22px;border-radius:7px;border:1.6px solid currentColor}
#nav button.on{color:var(--cy);text-shadow:0 0 8px var(--cy)}
#pair{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;padding:24px;background:var(--bg);z-index:9}
#pair input{width:100%;max-width:300px;padding:14px;font-size:22px;border-radius:10px;border:1px solid var(--line);background:#070a1f;color:#fff;letter-spacing:8px;text-align:center}
#pair button{width:100%;max-width:300px;padding:14px;border:0;border-radius:10px;background:var(--cy);color:#001;font-weight:900;letter-spacing:2px}
#sheet{position:fixed;inset:0;background:rgba(0,0,0,.6);display:none;z-index:20}
#sheet .box{position:absolute;left:8px;right:8px;bottom:8px;max-height:72%;display:flex;flex-direction:column;background:#0b0f2e;border:1px solid var(--cy);border-radius:14px;padding:10px}
#sheet input{padding:10px;border-radius:8px;border:1px solid var(--line);background:#050719;color:#fff;margin-bottom:8px}
#sheet .list{overflow:auto;flex:1}
#sheet .list div{padding:10px 8px;border-bottom:1px solid #1a2050;font-size:12px}
#sheet .list div:active{background:#16205a}

#tabs{display:flex;gap:6px;overflow-x:auto;padding:8px 10px;border-bottom:1px solid var(--line);background:rgba(8,10,34,.9);-webkit-overflow-scrolling:touch}
#tabs button{flex:0 0 auto;padding:7px 12px;border-radius:9px;border:1px solid var(--line);background:transparent;color:var(--dim);font-weight:800;font-size:11px;letter-spacing:1px}
#tabs button.on{color:#050614;background:var(--cy);border-color:var(--cy);box-shadow:0 0 12px var(--cy)}
#pg{position:absolute;top:104px;bottom:0;left:0;right:0;overflow-y:auto;overflow-x:hidden;-webkit-overflow-scrolling:touch;padding:12px 12px calc(28px + env(safe-area-inset-bottom))}
#top{height:56px}
.xy{position:relative;height:190px;border-radius:12px;border:1px solid var(--mg);background:radial-gradient(circle at 50% 50%,#1a1450,#05061a);touch-action:none}
.xy .dot{position:absolute;width:18px;height:18px;margin:-9px 0 0 -9px;border-radius:50%;background:#fff;box-shadow:0 0 16px var(--mg)}
.step{display:flex;flex-direction:column;align-items:center;gap:4px;width:100%}
.stepgrid{display:grid;grid-template-columns:repeat(8,1fr);gap:6px}
.pre{padding:11px 10px;border-bottom:1px solid #1a2050;font-size:13px}
.pre:active{background:#16205a}
.pre.cur{color:var(--gd)}
.search{width:100%;padding:11px;border-radius:9px;border:1px solid var(--line);background:#050719;color:#fff;margin-bottom:8px}
.ctl select{background:#070a1f;color:#fff;border:1px solid var(--line);border-radius:8px;padding:8px}

</style></head>
<body>
<div id="top"><div><span class="logo">GITI</span><div class="sub">BY SALEK HIGHTECH</div></div><div><span id="dot"></span></div></div>
<div id="tabs"></div>
<div id="pg"><div id="screens"></div></div>
<div id="pair"><div class="logo">GITI</div><div class="sub">ENTER THE 6-DIGIT CODE SHOWN IN THE PLUGIN (PHONE BUTTON)</div>
 <input id="code" inputmode="numeric" maxlength="6" placeholder="------"><button id="go">CONNECT</button><div id="err" style="color:#ff3ccf;min-height:18px"></div></div>
<div id="sheet"><div class="box"><div style="display:flex;justify-content:space-between;margin-bottom:8px"><b id="shT" style="color:var(--cy)">ASSIGN</b><button id="shX" class="btn" style="min-width:60px">CLOSE</button></div>
 <input id="shQ" placeholder="search parameter"><div class="list" id="shL"></div></div></div>
<script>
const C=(id,label,type)=>({id,label,type});
const DEFAULT=[
 {key:'osc',name:'OSC',frames:[
  {t:'Oscillator 1',c:'#35e6ff',cols:3,items:[C('osc1_level','LEVEL','knob'),C('osc1_table','TABLE','knob'),C('osc1_warp','WARP','knob'),C('osc1_fold','FOLD','knob'),C('osc1_octave','OCT','fader'),C('osc1_semi','SEMI','fader'),C('osc1_fine','FINE','fader'),C('osc1_detune','DETUNE','fader'),C('osc1_unison','UNISON','fader')]},
  {t:'Oscillator 2',c:'#ff3ccf',cols:3,items:[C('osc2_level','LEVEL','knob'),C('osc2_table','TABLE','knob'),C('osc2_warp','WARP','knob'),C('osc2_fold','FOLD','knob'),C('osc2_octave','OCT','fader'),C('osc2_semi','SEMI','fader'),C('osc2_fine','FINE','fader')]},
  {t:'Amp envelope',c:'#ffc861',cols:4,items:[C('amp_attack','ATTACK','fader'),C('amp_decay','DECAY','fader'),C('amp_sustain','SUSTAIN','fader'),C('amp_release','RELEASE','fader')]},
  {t:'Voice',c:'#ffc861',cols:3,items:[C('glide','GLIDE','fader'),C('voice_mode','VOICE','fader'),C('perf_eco','ECO','btn')]}]},
 {key:'flt',name:'FILTER',frames:[
  {t:'Filter 1',c:'#35e6ff',cols:3,items:[C('filter_cutoff','CUTOFF','knob'),C('filter_reso','RESO','knob'),C('filter_drive','DRIVE','knob'),C('filter_env','F ENV','knob'),C('filter_mix','MIX','knob')]},
  {t:'Filter 2',c:'#ff3ccf',cols:3,items:[C('filter2_cutoff','CUTOFF','knob'),C('filter2_reso','RESO','knob'),C('filter2_drive','DRIVE','knob'),C('filter2_env','F ENV','knob'),C('filter2_mix','MIX','knob')]}]},
 {key:'lfo',name:'LFO',frames:[
  {t:'LFO 1',c:'#35e6ff',cols:3,items:[C('lfo_rate','RATE','knob'),C('lfo_amount','AMT','knob'),C('lfo_phase','PHASE','knob'),C('lfo_smooth','SMOOTH','fader'),C('lfo_rise','RISE','fader'),C('lfo_bip','BIPOLAR','btn'),C('lfo_sync','SYNC','btn')]},
  {t:'LFO 2',c:'#ff3ccf',cols:3,items:[C('lfo2_rate','RATE','knob'),C('lfo2_amount','AMT','knob'),C('lfo2_phase','PHASE','knob'),C('lfo2_smooth','SMOOTH','fader'),C('lfo2_rise','RISE','fader')]},
  {t:'LFO 3',c:'#ffc861',cols:3,items:[C('lfo3_rate','RATE','knob'),C('lfo3_amount','AMT','knob'),C('lfo3_phase','PHASE','knob'),C('lfo3_smooth','SMOOTH','fader'),C('lfo3_rise','RISE','fader')]}]},
 {key:'mod',name:'MOD',frames:[
  {t:'FM',c:'#35e6ff',cols:3,items:[C('fm_2to1','FM 2>1','knob'),C('fm_3to1','FM 3>1','knob'),C('fm_3to2','FM 3>2','knob')]},
  {t:'AM / PM / RM',c:'#ff3ccf',cols:3,items:[C('am_2to1','AM 2>1','knob'),C('pm_2to1','PM 2>1','knob'),C('rm_2to1','RM 2>1','knob')]}]},
 {key:'mac',name:'MACRO',frames:[
  {t:'Macros (GITI)',c:'#35e6ff',cols:4,items:[C('macro1','BRIGHT','knob'),C('macro2','MOTION','knob'),C('macro3','SPACE','knob'),C('macro4','GRIT','knob')]},
  {t:'Macros (USER)',c:'#ff3ccf',cols:4,items:[C('macro5','MACRO 5','knob'),C('macro6','MACRO 6','knob'),C('macro7','MACRO 7','knob'),C('macro8','MACRO 8','knob')]}]},
 {key:'seq',name:'SEQ',special:'seq',frames:[
  {t:'Sequencer',c:'#35e6ff',cols:3,items:[C('seq_on','ON','btn'),C('seq_play','PLAY','btn'),C('seq_sync','DAW SYNC','btn'),C('seq_rate','RATE','fader'),C('seq_length','LENGTH','fader'),C('seq_swing','SWING','fader'),C('seq_gate','GATE','fader'),C('arp_on','ARP','btn'),C('arp_rate','ARP RATE','fader')]}]},
 {key:'fx',name:'FX',frames:[
  {t:'Delay',c:'#35e6ff',cols:3,items:[C('delay_mix','MIX','knob'),C('delay_time','TIME','knob'),C('delay_fb','FEEDBACK','knob'),C('delay_tone','TONE','knob')]},
  {t:'Reverb',c:'#ff3ccf',cols:3,items:[C('reverb_mix','MIX','knob'),C('reverb_size','SIZE','knob'),C('reverb_decay','DECAY','knob'),C('reverb_damp','DAMP','knob')]},
  {t:'Chorus / Phaser / Dist',c:'#ffc861',cols:3,items:[C('chorus_mix','CHORUS','knob'),C('phaser_mix','PHASER','knob'),C('dist_drive','DRIVE','knob'),C('dist_mix','DIST MIX','knob'),C('granular_mix','GRANULAR','knob')]}]},
 {key:'mag',name:'MAGIC',special:'magic',frames:[
  {t:'Magic',c:'#ff3ccf',cols:3,items:[C('magic_on','MAGIC','btn'),C('seq_magic_depth','DEPTH','fader'),C('seq_magic_target','TARGET','fader')]}]},
 {key:'pre',name:'PRESETS',special:'presets',frames:[]},
 {key:'key',name:'KEYS',special:'keys',frames:[
  {t:'Performance',c:'#ffc861',cols:3,items:[C('master_gain','VOL','fader'),C('glide','GLIDE','fader'),C('perf_eco','ECO','btn')]}]}
];
let layout=JSON.parse(JSON.stringify(DEFAULT)), curTab='osc';
let token=localStorage.getItem('giti_token')||'',params=[],vals={},busy={},sel=null,oct=4,saveT=0;
const $=s=>document.querySelector(s);
function api(path,q=''){return fetch(path+'?t='+token+(q?'&'+q:''));}
function clamp(v){return Math.max(0,Math.min(1,v));}
function saveLayout(){clearTimeout(saveT);saveT=setTimeout(()=>{fetch('/api/layout?t='+token,{method:'POST',headers:{'Content-Type':'text/plain'},body:JSON.stringify(layout)}).catch(()=>{});},700);}
function sendSet(id,v){vals[id]=v;api('/api/set','id='+encodeURIComponent(id)+'&v='+v.toFixed(4)).catch(()=>{});}
function tabs(){const T=$('#tabs');T.innerHTML='';for(const t of layout){const b=document.createElement('button');b.textContent=t.name;b.dataset.k=t.key;b.onclick=()=>show(t.key);T.appendChild(b);}}
function show(k){curTab=k;document.querySelectorAll('#tabs button').forEach(b=>b.classList.toggle('on',b.dataset.k===k));buildScreen(k);document.getElementById('pg').scrollTop=0;}
function buildScreen(k){const S=$('#screens');S.innerHTML='';const t=layout.find(x=>x.key===k);if(!t)return;
 if(t.special==='presets'){S.appendChild(presetsView());refreshPresets();return;}
 if(t.special==='keys'){for(const fr of t.frames)S.appendChild(frameEl(fr));S.appendChild(keysView());return;}
 if(t.special==='magic'){for(const fr of t.frames)S.appendChild(frameEl(fr));S.appendChild(magicView());return;}
 for(const fr of t.frames)S.appendChild(frameEl(fr));
 if(t.special==='seq')S.appendChild(seqView());
 refresh();}
function frameEl(fr){const f=document.createElement('div');f.className='frame';f.style.setProperty('--c',fr.c);
 f.innerHTML='<h3>'+fr.t+'</h3><div class="grid" style="--cols:'+fr.cols+'"></div>';const g=f.querySelector('.grid');
 for(const it of fr.items)g.appendChild(makeCtl(it,fr.c));return f;}
function makeCtl(it,col){const w=document.createElement('div');w.className='ctl';w.style.setProperty('--c',col);w.dataset.id=it.id;
 const lab='<div class="lab">'+it.label+'</div>';
 if(it.type==='btn'){w.innerHTML=lab+'<button class="btn"></button>';const b=w.querySelector('button');
  b.onclick=()=>{const on=!(vals[it.id]>.5);vals[it.id]=on?1:0;sendSet(it.id,on?1:0);b.classList.toggle('on',on);};}
)HTML";
    s += R"HTML( else if(it.type==='fader'){w.innerHTML=lab+'<div class="fader"><div class="fill"></div><div class="cap"></div></div><div class="val"></div>';bindDrag(w.querySelector('.fader'),it.id,true);}
 else{w.innerHTML=lab+'<svg class="knob" viewBox="0 0 64 64"><circle cx="32" cy="32" r="26" fill="none" stroke="#1a2050" stroke-width="5"/><path fill="none" stroke="'+col+'" stroke-width="5" stroke-linecap="round"/><circle r="3.5" fill="#fff"/></svg><div class="val"></div>';bindDrag(w.querySelector('.knob'),it.id,false);}
 bindLong(w,it.id);return w;}
function bindDrag(el,id,fader){let y0=0,v0=0,on=false;
 el.addEventListener('pointerdown',e=>{on=true;busy[id]=true;y0=e.clientY;v0=vals[id]||0;el.setPointerCapture(e.pointerId);e.preventDefault();});
 el.addEventListener('pointermove',e=>{if(!on)return;const v=clamp(v0+(y0-e.clientY)/(fader?110:150));vals[id]=v;throttle(id);paint(id);});
 const end=()=>{on=false;setTimeout(()=>{busy[id]=false},400);};el.addEventListener('pointerup',end);el.addEventListener('pointercancel',end);
 el.addEventListener('dblclick',()=>{vals[id]=.5;sendSet(id,.5);paint(id);});}
const thr={};function throttle(id){if(thr[id])return;thr[id]=setTimeout(()=>{thr[id]=0;sendSet(id,vals[id]);},35);}
function bindLong(w,id){let t=0;w.addEventListener('pointerdown',()=>{t=setTimeout(()=>openAssign(w,id),600)});for(const ev of['pointerup','pointercancel','pointermove'])w.addEventListener(ev,()=>clearTimeout(t));}
function paint(id){document.querySelectorAll('.ctl[data-id="'+id+'"]').forEach(w=>{const v=vals[id]||0,f=w.querySelector('.fader'),k=w.querySelector('.knob'),b=w.querySelector('.btn'),x=w.querySelector('.val');
 if(f){f.querySelector('.fill').style.height=(v*100)+'%';f.querySelector('.cap').style.bottom=(v*100)+'%';}
 if(k){const a=Math.PI*.75+Math.PI*1.5*v,cx=32,cy=32,r=26,p=k.querySelector('path');
  p.setAttribute('d',v<=.001?'':'M'+(cx+r*Math.cos(Math.PI*.75))+' '+(cy+r*Math.sin(Math.PI*.75))+' A'+r+' '+r+' 0 '+(Math.PI*1.5*v>Math.PI?1:0)+' 1 '+(cx+r*Math.cos(a))+' '+(cy+r*Math.sin(a)));
  const d=k.querySelector('circle[r="3.5"]');d.setAttribute('cx',cx+(r-6)*Math.cos(a));d.setAttribute('cy',cy+(r-6)*Math.sin(a));}
 if(b)b.classList.toggle('on',v>.5);
 if(x){const p=params.find(p=>p.id===id);x.textContent=p&&p.unit?p.unit:Math.round(v*100)+'%';}});}
function refresh(){if(!token)return;const ids=[...new Set(layout.flatMap(t=>t.frames.flatMap(f=>f.items.map(i=>i.id))))].join(',');
 api('/api/get','ids='+ids).then(r=>{if(!r.ok)throw 0;$('#dot').classList.add('on');return r.text();}).then(t=>{
  for(const line of t.split('\n')){const p=line.trim().split(' ');if(p.length===2&&!busy[p[0]]&&!thr[p[0]]){vals[p[0]]=+p[1];paint(p[0]);}}}).catch(()=>{$('#dot').classList.remove('on');});
 if(curTab==='seq')refreshSeq();}
function openAssign(w,id){sel={id};$('#sheet').style.display='block';$('#shT').textContent='ASSIGN  ('+id+')';$('#shQ').value='';renderList();}
function renderList(){const q=$('#shQ').value.toLowerCase();const L=$('#shL');L.innerHTML='';
 for(const p of params.filter(p=>!q||(p.id+' '+p.name).toLowerCase().includes(q)).slice(0,400)){const d=document.createElement('div');d.textContent=p.name+'   ('+p.id+')';d.onclick=()=>assign(p.id);L.appendChild(d);}}
function assign(newId){const oldId=sel.id;let done=false;
 for(const t of layout)for(const fr of t.frames)for(const it of fr.items)if(!done&&it.id===oldId){it.id=newId;done=true;}
 saveLayout();$('#sheet').style.display='none';buildScreen(curTab);}
$('#shQ').oninput=renderList;$('#shX').onclick=()=>$('#sheet').style.display='none';
// ---- SEQ steps ----
function seqView(){const d=document.createElement('div');d.className='frame';d.style.setProperty('--c','#35e6ff');d.id='seqsteps';
 d.innerHTML='<h3>STEPS</h3><div class="stepgrid" id="sg"></div>';return d;}
let seqState=[];
function refreshSeq(){if(!token)return;api('/api/seq').then(r=>r.text()).then(t=>{seqState=t.split('\n').filter(Boolean).map(l=>{const p=l.split(' ');return{i:+p[0],off:+p[1],vel:+p[2],gate:+p[3],prob:+p[4],act:+p[5],acc:+p[6]};});drawSeq();}).catch(()=>{});}
function drawSeq(){const g=$('#sg');if(!g||g.dataset.busy)return;g.innerHTML='';
 for(const s of seqState){const c=document.createElement('div');c.className='step';
  c.innerHTML='<div class="lab" style="font-size:9px;color:var(--cy)">'+(s.i+1)+'</div><div class="fader" style="height:80px;width:26px"><div class="fill"></div><div class="cap"></div></div><div class="val" style="font-size:9px">'+(s.off>0?'+':'')+s.off+'</div><button class="btn" style="min-width:0;width:100%;height:24px;font-size:9px">'+(s.act?'ON':'OFF')+'</button>';
  const f=c.querySelector('.fader');f.querySelector('.fill').style.height=((s.off+12)/24*100)+'%';f.querySelector('.cap').style.bottom=((s.off+12)/24*100)+'%';
  let y0=0,o0=s.off,dr=false;f.addEventListener('pointerdown',e=>{dr=true;y0=e.clientY;o0=s.off;f.setPointerCapture(e.pointerId);});
  f.addEventListener('pointermove',e=>{if(!dr)return;const o=Math.max(-12,Math.min(12,Math.round(o0+(y0-e.clientY)/6)));s.off=o;drawSeq();seqSet(s.i,'off',o);});
  f.addEventListener('pointerup',()=>dr=false);
  c.querySelector('button').onclick=()=>{s.act=s.act?0:1;seqSet(s.i,'act',s.act);drawSeq();};
  g.appendChild(c);}}
function seqSet(i,k,v){api('/api/seqset','i='+i+'&k='+k+'&v='+v).catch(()=>{});}
// ---- MAGIC pad: X/Y drag sends magic_x and magic_y ----
function magicView(){const d=document.createElement('div');d.className='frame';d.style.setProperty('--c','#ff3ccf');
 d.innerHTML='<h3>MAGIC PAD</h3><div class="xy" id="xy"><div class="dot" id="xyd"></div></div>';
 const pad=d.querySelector('#xy');let on=false;
 const mv=e=>{const r=pad.getBoundingClientRect();const x=clamp((e.clientX-r.left)/r.width),y=clamp(1-(e.clientY-r.top)/r.height);
  vals.magic_x=x;vals.magic_y=y;throttle('magic_x');throttle('magic_y');moveDot();};
 pad.addEventListener('pointerdown',e=>{on=true;pad.setPointerCapture(e.pointerId);mv(e);});
 pad.addEventListener('pointermove',e=>{if(on)mv(e);});pad.addEventListener('pointerup',()=>on=false);
 function moveDot(){const dd=d.querySelector('#xyd');dd.style.left=((vals.magic_x||0)*100)+'%';dd.style.top=((1-(vals.magic_y||0))*100)+'%';}
 setTimeout(moveDot,0);return d;}
// ---- PRESETS on the phone ----
let presetList=[];
function presetsView(){const d=document.createElement('div');d.className='frame';d.style.setProperty('--c','#ffc861');
 d.innerHTML='<h3>PRESETS</h3><input class="search" id="psq" placeholder="search presets"><div id="plist"></div>';
 setTimeout(()=>{$('#psq').oninput=drawPresets;},0);return d;}
function refreshPresets(){if(!token)return;api('/api/presets').then(r=>r.text()).then(t=>{presetList=t.split('\n').filter(Boolean).map(l=>{const i=l.indexOf('|');return{idx:+l.slice(0,i),name:l.slice(i+1)};});drawPresets();}).catch(()=>{});}
function drawPresets(){const q=($('#psq')?$('#psq').value:'').toLowerCase();const L=$('#plist');if(!L)return;L.innerHTML='';
 for(const p of presetList.filter(p=>!q||p.name.toLowerCase().includes(q)).slice(0,600)){const d=document.createElement('div');d.className='pre';d.textContent=p.idx+'  '+p.name;
  d.onclick=()=>{api('/api/preset','idx='+p.idx).then(()=>{refresh();});};L.appendChild(d);}}
// ---- KEYS (at the bottom of the KEYS page) ----
function keysView(){const wrap=document.createElement('div');wrap.className='frame';wrap.style.setProperty('--c','#35e6ff');
 wrap.innerHTML='<h3>KEYBOARD</h3><div class="grid" style="--cols:3"><div class="ctl"><div class="lab">OCTAVE</div><button class="btn" id="od">-</button></div><div class="ctl"><div class="lab">&nbsp;</div><div class="val" id="ov"></div></div><div class="ctl"><div class="lab">&nbsp;</div><button class="btn" id="ou">+</button></div></div><div class="kbd" id="kb"></div>';
 setTimeout(()=>{wrap.querySelector('#od').onclick=()=>{oct=Math.max(1,oct-1);draw();};wrap.querySelector('#ou').onclick=()=>{oct=Math.min(7,oct+1);draw();};draw();},0);
 function draw(){const kb=wrap.querySelector('#kb');if(!kb)return;kb.innerHTML='';wrap.querySelector('#ov').textContent='C'+oct;
  const base=(oct+1)*12,whites=[0,2,4,5,7,9,11,12,14,16,17,19,21,23],blacks=[1,3,6,8,10,13,15,18,20,22],WN=14;
  whites.forEach((s,i)=>{const k=document.createElement('div');k.className='wk';k.style.left=(i*100/WN)+'%';key(k,base+s);kb.appendChild(k);});
  blacks.forEach((s,i)=>{const k=document.createElement('div');k.className='bk';const pos=[0,1,3,4,5,7,8,10,11,12][i];k.style.left=((pos+0.66)*100/WN)+'%';k.style.width=(100/WN*0.6)+'%';key(k,base+s);kb.appendChild(k);});}
 function key(el,n){const on=()=>{el.classList.add('dn');note(n,true);};const off=()=>{el.classList.remove('dn');note(n,false);};
  el.addEventListener('pointerdown',e=>{el.setPointerCapture(e.pointerId);on();});el.addEventListener('pointerup',off);el.addEventListener('pointercancel',off);}
 return wrap;}
function note(n,on){if(token)api('/api/note','on='+(on?1:0)+'&n='+n+'&v=100').catch(()=>{});}
// ---- pairing, layout from the plugin ----
async function loadParams(){try{const t=await (await api('/api/params')).text();params=t.split('\n').filter(Boolean).map(l=>{const p=l.split('|');return{id:p[0],name:p[1]||p[0]};});}catch(e){}}
async function loadLayout(){try{const r=await api('/api/layout');const t=await r.text();const j=JSON.parse(t);if(Array.isArray(j)&&j.length)layout=j;}catch(e){}}
async function startUp(){await loadParams();await loadLayout();tabs();show(curTab);setInterval(refresh,300);setInterval(()=>{if(curTab==='pre')refreshPresets();},3000);}
$('#go').onclick=async()=>{try{const r=await fetch('/api/pair?code='+encodeURIComponent($('#code').value.trim()));
 if(!r.ok){$('#err').textContent='wrong code';return;}token=(await r.text()).trim();localStorage.setItem('giti_token',token);
 $('#pair').style.display='none';await startUp();}catch(e){$('#err').textContent='cannot reach the computer';}};
if(token){fetch('/api/get?t='+token+'&ids=master_gain').then(r=>{if(r.ok){$('#pair').style.display='none';startUp();}}).catch(()=>{});}
</script></body></html>
)HTML";
    return s;
}
}} // namespace giti::remote
