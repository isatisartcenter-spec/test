#pragma once
// Tiny HTTP/1.1 server for the GITI phone page. One connection at a time, GET and POST, LAN use.
// Every answer carries CORS headers, so the connector page (opened from a file) can reach the plugin.
#include <juce_core/juce_core.h>
#include <functional>

namespace giti { namespace remote {

struct HttpResponse { int status = 200; juce::String contentType = "text/plain; charset=utf-8"; juce::String body; };

struct HttpRequest { juce::String method, path, query, body; };

class HttpServer : private juce::Thread
{
public:
    using Handler = std::function<HttpResponse (const HttpRequest&)>;

    HttpServer (int port, Handler h) : juce::Thread ("GITI HTTP"), listenPort (port), handler (std::move (h)) {}
    ~HttpServer() override { stop(); }

    void start() { if (! isThreadRunning()) startThread (juce::Thread::Priority::low); }
    void stop()  { signalThreadShouldExit(); listener.close(); stopThread (1500); }

    // Parse one raw request and build the full answer. Public for tests.
    static HttpRequest parse (const juce::String& raw)
    {
        HttpRequest q;
        auto head = raw.upToFirstOccurrenceOf ("\r\n\r\n", false, false);
        if (head == raw) head = raw.upToFirstOccurrenceOf ("\n\n", false, false);
        q.body = raw.substring (head.length()).trimCharactersAtStart ("\r\n");
        auto firstLine = head.upToFirstOccurrenceOf ("\n", false, false).trim();
        auto parts = juce::StringArray::fromTokens (firstLine, " ", "");
        if (parts.size() >= 2)
        {
            q.method = parts[0];
            auto target = parts[1];
            q.path = target.upToFirstOccurrenceOf ("?", false, false);
            q.query = target.contains ("?") ? target.fromFirstOccurrenceOf ("?", false, false) : juce::String();
        }
        return q;
    }

    static juce::String render (const juce::String& raw, const Handler& h)
    {
        auto q = parse (raw);
        HttpResponse r;
        if (q.method.isEmpty()) { r.status = 400; r.body = "bad request"; }
        else if (q.method == "OPTIONS") { r.status = 204; }
        else if (q.method != "GET" && q.method != "POST") { r.status = 405; r.body = "Method not allowed"; }
        else r = h (q);
        const char* reason = r.status == 200 ? "OK" : r.status == 204 ? "No Content" : r.status == 404 ? "Not Found"
                           : r.status == 403 ? "Forbidden" : r.status == 405 ? "Method Not Allowed" : "Error";
        return "HTTP/1.1 " + juce::String (r.status) + " " + reason + "\r\n"
             + "Content-Type: " + r.contentType + "\r\n"
             + "Content-Length: " + juce::String ((int) r.body.getNumBytesAsUTF8()) + "\r\n"
             + "Access-Control-Allow-Origin: *\r\nAccess-Control-Allow-Methods: GET, POST, OPTIONS\r\nAccess-Control-Allow-Headers: *\r\n"
             + "Cache-Control: no-store\r\nConnection: close\r\n\r\n" + r.body;
    }

private:
    void run() override
    {
        if (! listener.createListener (listenPort)) return;
        while (! threadShouldExit())
        {
            std::unique_ptr<juce::StreamingSocket> client (listener.waitForNextConnection());
            if (client == nullptr) continue;
            // do not block on a silent client: give up after ~1 s, and stop at once when the plugin closes
            bool ready = false;
            for (int tries = 0; tries < 10 && ! threadShouldExit(); ++tries)
                if (client->waitUntilReady (true, 100) == 1) { ready = true; break; }
            if (! ready) continue;
            juce::String req;
            char c;
            while (req.length() < 8192 && ! req.contains ("\r\n\r\n") && ! req.contains ("\n\n"))
            {
                if (client->read (&c, 1, true) <= 0) break;
                req += juce::String::charToString ((juce::juce_wchar) (unsigned char) c);
            }
            // POST: read the body announced by Content-Length (max 64 KB)
            const auto lenPos = req.indexOfIgnoreCase ("Content-Length:");
            if (lenPos >= 0)
            {
                const int len = juce::jmin (65536, req.substring (lenPos + 15).upToFirstOccurrenceOf ("\n", false, false).trim().getIntValue());
                if (len > 0)
                {
                    juce::HeapBlock<char> buf ((size_t) len + 1);
                    int got = 0;
                    while (got < len)
                    {
                        const int n = client->read (buf.get() + got, len - got, false);
                        if (n <= 0) break;
                        got += n;
                    }
                    buf[got] = 0;
                    req += juce::String::fromUTF8 (buf.get(), got);
                }
            }
            const auto reply = render (req, handler);
            client->write (reply.toRawUTF8(), (int) reply.getNumBytesAsUTF8());
            client->close();
        }
        listener.close();
    }

    int listenPort;
    Handler handler;
    juce::StreamingSocket listener;
};

}} // namespace giti::remote
