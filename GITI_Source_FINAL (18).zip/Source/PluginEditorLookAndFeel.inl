#include "GitiCrystalAssets.h"
#include "GitiGenesis.h"
#include <map>
class SalekLookAndFeel : public juce::LookAndFeel_V4 {
public:
    static juce::Colour ink()       { return juce::Colour (0xff04050f); }
    static juce::Colour panel()     { return juce::Colour (0xff0b0d26); }
    static juce::Colour raised()    { return juce::Colour (0xff151a45); }
    static juce::Colour border()    { return juce::Colour (0xff2f5d8f); }
    static juce::Colour text()      { return juce::Colour (0xfff2f8ff); }
    static juce::Colour mutedText() { return juce::Colour (0xff9db4d6); }
    static juce::Colour teal()      { return giti::primaryColour(); }
    static juce::Colour rose()      { return giti::secondaryColour(); }
    static juce::Colour purple()    { return giti::tertiaryColour(); }
    static float& corePhase() { static float p = 0.f; return p; }   // set by the editor each frame
    static juce::Colour champagne(){ return giti::accentColour(); }

    SalekLookAndFeel() {
        setColour (juce::Slider::textBoxTextColourId, text());
        setColour (juce::Slider::textBoxBackgroundColourId, panel());
        setColour (juce::Slider::textBoxOutlineColourId, border().withAlpha (0.72f));
        setColour (juce::Slider::textBoxHighlightColourId, teal().withAlpha (0.45f));
        setColour (juce::Slider::rotarySliderFillColourId, teal());
        setColour (juce::Slider::rotarySliderOutlineColourId, border());
        setColour (juce::ResizableWindow::backgroundColourId, ink());
        setColour (juce::TabbedComponent::backgroundColourId, ink());
        setColour (juce::TabbedComponent::outlineColourId, border().withAlpha (0.55f));
        setColour (juce::TabbedButtonBar::tabOutlineColourId, border().withAlpha (0.62f));
        setColour (juce::TabbedButtonBar::frontOutlineColourId, teal());
        setColour (juce::TabbedButtonBar::frontTextColourId, text());
        setColour (juce::TabbedButtonBar::tabTextColourId, mutedText());

        // Keep preset-browser widgets on their existing palette. Non-browser
        // controls opt into the new palette at their own component level.
        setColour (juce::ComboBox::backgroundColourId, juce::Colour (0xff0b0d26));
        setColour (juce::ComboBox::outlineColourId, juce::Colour (0xff7b3cff));
        setColour (juce::ComboBox::textColourId, juce::Colour (0xffeaf4ff));
        setColour (juce::ListBox::backgroundColourId, juce::Colour (0xff070918));
        setColour (juce::ListBox::outlineColourId, juce::Colour (0xff151a45));
        setColour (juce::TextButton::buttonColourId, juce::Colour (0xff151a45));
        setColour (juce::TextButton::textColourOffId, juce::Colour (0xff22e6ff));
        setColour (juce::ToggleButton::textColourId, juce::Colour (0xffeaf4ff));
        setColour (juce::ToggleButton::tickColourId, juce::Colour (0xffff3df2));
        setColour (juce::Label::textColourId, juce::Colour (0xffb9cdea));
        setColour (juce::PopupMenu::backgroundColourId, juce::Colour (0xff0a0d26));
        setColour (juce::PopupMenu::textColourId, juce::Colour (0xffeaf4ff));
        setColour (juce::PopupMenu::highlightedBackgroundColourId, juce::Colour (0xff2a1a7a));
        setColour (juce::PopupMenu::highlightedTextColourId, juce::Colour (0xffffffff));
        setColour (juce::PopupMenu::headerTextColourId, juce::Colour (0xff22e6ff));
        setColour (juce::ScrollBar::thumbColourId, juce::Colour (0xff22e6ff).withAlpha (0.55f));
    }

    void drawButtonText (juce::Graphics& g, juce::TextButton& button,
                          bool, bool) override
    {
        if (button.getComponentID().startsWith ("giti_img_"))
        {
            drawImageButtonText (g, button);
            return;
        }
        if (button.getComponentID() == "giti_led") return;   // drawn in the background pass
        const auto t = button.getButtonText().trim().toUpperCase();
        const auto area = button.getLocalBounds().toFloat().reduced (4.f);
        const auto accent = button.findColour (juce::TextButton::textColourOffId);
        g.setColour (accent.withAlpha (0.95f));

        // Compact icon language for navigation / utility controls.
        // Text remains in the component for accessibility/tooltips, but the
        // visible control is an icon so the top bar and preset browser stay clean.
        juce::Path p;
        const auto c = area.getCentre();
        const float s = juce::jmin (area.getWidth(), area.getHeight()) * 0.28f;

        if (t == "<" || t == "PREV")
        {
            p.startNewSubPath (c.x + s, c.y - s * 1.25f);
            p.lineTo (c.x - s, c.y);
            p.lineTo (c.x + s, c.y + s * 1.25f);
            g.strokePath (p, juce::PathStrokeType (2.4f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }
        else if (t == ">" || t == "NEXT")
        {
            p.startNewSubPath (c.x - s, c.y - s * 1.25f);
            p.lineTo (c.x + s, c.y);
            p.lineTo (c.x - s, c.y + s * 1.25f);
            g.strokePath (p, juce::PathStrokeType (2.4f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }
        else if (t == "INIT")
        {
            g.drawEllipse (c.x - s, c.y - s, 2.f * s, 2.f * s, 1.7f);
            g.drawLine (c.x, c.y - s * 0.55f, c.x, c.y + s * 0.55f, 1.8f);
            g.drawLine (c.x - s * 0.55f, c.y, c.x + s * 0.55f, c.y, 1.8f);
        }
        else if (t == "SAVE")
        {
            auto rr = juce::Rectangle<float> (c.x - s, c.y - s, 2.f*s, 2.f*s);
            g.drawRoundedRectangle (rr, 2.f, 1.7f);
            g.fillRect (c.x - s * 0.55f, c.y - s * 0.78f, s * 1.1f, s * 0.42f);
            g.drawLine (c.x - s * 0.55f, c.y + s * 0.15f, c.x + s * 0.55f, c.y + s * 0.15f, 1.5f);
        }
        else if (t == "LOAD")
        {
            g.drawRoundedRectangle (c.x - s, c.y - s * 0.7f, 2.f*s, s * 1.5f, 2.f, 1.7f);
            p.startNewSubPath (c.x, c.y + s * 0.65f);
            p.lineTo (c.x, c.y - s * 0.15f);
            p.startNewSubPath (c.x - s * 0.4f, c.y + s * 0.15f);
            p.lineTo (c.x, c.y - s * 0.25f);
            p.lineTo (c.x + s * 0.4f, c.y + s * 0.15f);
            g.strokePath (p, juce::PathStrokeType (1.8f));
        }
        else if (t == "BANK")
        {
            g.drawRoundedRectangle (c.x - s * 1.15f, c.y - s * 0.75f, s * 2.3f, s * 1.5f, 2.f, 1.5f);
            g.drawLine (c.x - s * 0.65f, c.y - s * 0.25f, c.x + s * 0.65f, c.y - s * 0.25f, 1.4f);
            g.drawLine (c.x - s * 0.65f, c.y + s * 0.25f, c.x + s * 0.65f, c.y + s * 0.25f, 1.4f);
        }
        else if (t == "INSPIRE")
        {
            for (int i = 0; i < 8; ++i)
            {
                const float a = juce::MathConstants<float>::twoPi * (float) i / 8.f;
                g.drawLine (c.x + std::cos(a)*s*0.35f, c.y + std::sin(a)*s*0.35f,
                            c.x + std::cos(a)*s*1.15f, c.y + std::sin(a)*s*1.15f, 1.5f);
            }
            g.fillEllipse (c.x - s*0.35f, c.y - s*0.35f, s*0.7f, s*0.7f);
        }
        else if (t == "BG")
        {
            g.drawRoundedRectangle (c.x-s*1.1f,c.y-s*0.75f,s*2.2f,s*1.5f,2.f,1.5f);
            g.fillEllipse (c.x-s*0.55f,c.y-s*0.35f,s*0.38f,s*0.38f);
            p.startNewSubPath(c.x-s*0.9f,c.y+s*0.5f);
            p.lineTo(c.x-s*0.1f,c.y-s*0.05f);
            p.lineTo(c.x+s*0.25f,c.y+s*0.3f);
            p.lineTo(c.x+s*0.95f,c.y-s*0.45f);
            g.strokePath(p,juce::PathStrokeType(1.5f));
        }
        else if (t == "CHAR" || t == "MODEL")
        {
            g.drawEllipse (c.x-s*0.45f,c.y-s*0.9f,s*0.9f,s*0.9f,1.5f);
            g.drawRoundedRectangle(c.x-s*0.75f,c.y,s*1.5f,s*0.9f,3.f,1.5f);
        }
        else if (t == "BYP")
        {
            g.drawEllipse (c.x-s,c.y-s,2.f*s,2.f*s,1.5f);
            g.drawLine(c.x,c.y-s*0.75f,c.x,c.y+s*0.1f,2.f);
        }
        else
        {
            // Keep compact labels such as LFO1 / ARP / SEQ readable.
            g.setFont (juce::FontOptions (juce::jlimit (10.f, 12.f, area.getHeight() * 0.55f), juce::Font::bold));
            g.drawText (button.getButtonText(), area.toNearestInt(), juce::Justification::centred);
        }
    }

    void drawButtonBackground (juce::Graphics& g, juce::Button& button,
                               const juce::Colour& backgroundColour,
                               bool highlighted, bool down) override
    {
        if (button.getComponentID().startsWith ("giti_img_"))
        {
            drawImageButton (g, button, highlighted, down);
            return;
        }
        if (button.getComponentID() == "giti_led")
        {
            drawLed (g, button, highlighted, down);
            return;
        }
        auto bounds = button.getLocalBounds().toFloat().reduced (1.f);
        if (bounds.isEmpty()) return;

        const bool toggled = button.getToggleState();
        auto base = toggled ? button.findColour (juce::TextButton::buttonOnColourId)
                            : backgroundColour;
        if (! base.isOpaque())
            base = button.findColour (juce::TextButton::buttonColourId);
        const auto accent = button.findColour (juce::TextButton::textColourOffId, true)
                                .withMultipliedSaturation (1.2f);
        const float lift = (down ? 0.05f : (highlighted || toggled ? 0.17f : 0.07f));
        const float radius = juce::jmin (7.f, bounds.getHeight() * 0.20f);
        auto face = bounds.translated (0.f, down ? 0.f : 1.f);

        if (highlighted || toggled)                       // hover / on glow
        {
            g.setColour (accent.withAlpha (toggled ? 0.20f : 0.14f));
            g.fillRoundedRectangle (bounds.expanded (2.5f), radius + 3.f);
        }
        g.setColour (juce::Colours::black.withAlpha (0.56f));
        g.fillRoundedRectangle (bounds.translated (0.f, 2.f), radius);
        juce::ColourGradient faceGradient (base.brighter (lift), face.getX(), face.getY(),
                                            base.darker (0.20f), face.getX(), face.getBottom(), false);
        g.setGradientFill (faceGradient);
        g.fillRoundedRectangle (face, radius);
        {   // glass gloss on the upper half + dark lower bevel (3D look)
            auto gloss = face.reduced (1.5f).withHeight (face.getHeight() * 0.48f);
            g.setGradientFill (juce::ColourGradient (juce::Colours::white.withAlpha (down ? 0.04f : 0.15f), gloss.getX(), gloss.getY(),
                                                     juce::Colours::white.withAlpha (0.0f), gloss.getX(), gloss.getBottom(), false));
            g.fillRoundedRectangle (gloss, radius - 1.f);
            g.setColour (juce::Colours::black.withAlpha (0.28f));
            g.drawLine (face.getX() + radius, face.getBottom() - 1.f, face.getRight() - radius, face.getBottom() - 1.f, 1.4f);
        }

        if (highlighted || toggled || down)
        {
            g.setColour (accent.withAlpha (down ? 0.28f : (toggled ? 0.18f : 0.10f)));
            g.fillRoundedRectangle (face.reduced (1.5f), radius - 1.f);
        }

        g.setColour (accent.withAlpha (down ? 0.94f : (toggled ? 0.88f : (highlighted ? 0.76f : 0.48f))));
        g.drawRoundedRectangle (face, radius, toggled || down ? 1.45f : 1.0f);
        g.setColour (juce::Colours::white.withAlpha (highlighted || toggled ? 0.18f : 0.08f));
        g.drawLine (face.getX() + radius, face.getY() + 1.f,
                    face.getRight() - radius, face.getY() + 1.f, 0.8f);
    }

    // ------------------------------------------------------------------
    // Persian-ornate glass panel: glass fill, double border, gold corner brackets, bilingual header
    static void drawOrnateCorners (juce::Graphics& g, juce::Rectangle<float> r, juce::Colour c, float len = 15.f)
    {
        g.setColour (c);
        const float pi = juce::MathConstants<float>::pi;
        for (int i = 0; i < 4; ++i)
        {
            const float dx = (i & 1) ? -1.f : 1.f, dy = (i & 2) ? -1.f : 1.f;
            const float x = (i & 1) ? r.getRight() : r.getX(), y = (i & 2) ? r.getBottom() : r.getY();
            juce::Path p;
            p.startNewSubPath (x + dx * len, y);
            p.lineTo (x, y);
            p.lineTo (x, y + dy * len);
            g.strokePath (p, juce::PathStrokeType (1.7f, juce::PathStrokeType::mitered, juce::PathStrokeType::butt));
            juce::Path d;
            d.addPolygon ({ x + dx * 6.f, y + dy * 6.f }, 4, 2.8f, 0.f);
            g.fillPath (d);
            juce::Path star;
            star.addStar ({ x + dx * 6.f, y + dy * 6.f }, 8, 3.6f, 5.2f, pi / 8.f);
            g.setColour (c.withAlpha (0.45f));
            g.strokePath (star, juce::PathStrokeType (0.7f));
            g.setColour (c);
        }
    }

    static void drawOrnatePanel (juce::Graphics& g, juce::Rectangle<float> r, juce::Colour accent,
                                 const juce::String& en, const juce::String& fa, float pulse = 0.f)
    {
        g.setColour (juce::Colours::black.withAlpha (0.55f));
        g.fillRoundedRectangle (r.translated (0.f, 5.f).expanded (1.f), 12.f);      // depth shadow
        g.setColour (accent.withAlpha (0.07f));
        g.fillRoundedRectangle (r.expanded (3.f), 13.f);
        g.setGradientFill (juce::ColourGradient (juce::Colour (0xc4121a42), r.getX(), r.getY(),
                                                 juce::Colour (0xc4060920), r.getX(), r.getBottom(), false));
        g.fillRoundedRectangle (r, 10.f);
        if (en.isNotEmpty() || fa.isNotEmpty())
        {
            auto head = r.withHeight (17.f);
            g.setGradientFill (juce::ColourGradient (accent.withAlpha (0.26f), head.getX(), head.getY(),
                                                     juce::Colours::transparentBlack, head.getRight(), head.getY(), false));
            g.fillRoundedRectangle (head.reduced (1.f), 9.f);
            g.setFont (juce::FontOptions (10.5f, juce::Font::bold));
            g.setColour (accent.brighter (0.25f));
            g.drawText (en.toUpperCase(), head.reduced (14.f, 0.f).toNearestInt(), juce::Justification::centredLeft);
            g.setColour (champagne());
            g.drawText (fa, head.reduced (14.f, 0.f).toNearestInt(), juce::Justification::centredRight);
            g.setColour (accent.withAlpha (0.35f));
            g.drawLine (r.getX() + 12.f, head.getBottom(), r.getRight() - 12.f, head.getBottom(), 1.f);
        }
        g.setGradientFill (juce::ColourGradient (juce::Colours::white.withAlpha (0.10f), r.getX(), r.getY(),
                                                 juce::Colours::transparentBlack, r.getX(), r.getY() + r.getHeight() * 0.35f, false));
        g.fillRoundedRectangle (r.reduced (1.5f), 9.f);                              // glass sheen
        g.setColour (accent.withAlpha (0.62f + pulse * 0.08f));
        g.drawRoundedRectangle (r, 10.f, 1.2f);
        g.setColour (accent.withAlpha (0.14f));
        g.drawRoundedRectangle (r.reduced (3.5f), 7.f, 0.8f);
        drawOrnateCorners (g, r.reduced (1.f), champagne().withAlpha (0.92f));
    }

    // Source lamp (OSC1/2/3/NOISE/SUB): glowing LED + label
    static void drawLed (juce::Graphics& g, juce::Button& b, bool hot, bool down)
    {
        const bool on = b.getToggleState();
        const auto col = juce::Colour ((juce::uint32) (juce::int64) b.getProperties().getWithDefault ("led_col", (juce::int64) 0xff22e6ff));
        auto r = b.getLocalBounds().toFloat().reduced (2.f);
        g.setGradientFill (juce::ColourGradient (raised().withAlpha (0.85f), r.getX(), r.getY(), ink().withAlpha (0.95f), r.getX(), r.getBottom(), false));
        g.fillRoundedRectangle (r, 6.f);
        g.setColour ((on ? col : border()).withAlpha (on ? 0.9f : 0.5f));
        g.drawRoundedRectangle (r, 6.f, on || hot ? 1.5f : 1.f);
        const float lr = juce::jmin (r.getHeight() * 0.28f, 7.f);
        const auto lc = juce::Point<float> (r.getX() + lr + 7.f, r.getCentreY());
        if (on)
        {
            g.setColour (col.withAlpha (0.35f));
            g.fillEllipse (lc.x - lr * 2.1f, lc.y - lr * 2.1f, lr * 4.2f, lr * 4.2f);
        }
        g.setGradientFill (juce::ColourGradient (on ? juce::Colours::white : col.darker (0.8f).withAlpha (0.55f), lc.x - lr * 0.3f, lc.y - lr * 0.3f,
                                                 on ? col : col.darker (1.6f).withAlpha (0.6f), lc.x + lr, lc.y + lr, true));
        g.fillEllipse (lc.x - lr, lc.y - lr, lr * 2.f, lr * 2.f);
        g.setColour (on ? juce::Colours::white : mutedText());
        g.setFont (juce::FontOptions (juce::jlimit (9.f, 12.f, r.getHeight() * 0.42f), juce::Font::bold));
        g.drawText (b.getButtonText(), r.withTrimmedLeft (lr * 2.f + 12.f).toNearestInt(), juce::Justification::centredLeft);
        if (down) { g.setColour (juce::Colours::black.withAlpha (0.2f)); g.fillRoundedRectangle (r, 6.f); }
    }

    // Bevelled glass tabs with neon underglow (reference: OSC / FILTER / ENV / MOD / FX bar)
    void drawTabButton (juce::TabBarButton& button, juce::Graphics& g, bool over, bool down) override
    {
        auto r = button.getLocalBounds().toFloat().reduced (1.5f, 2.f);
        const bool active = button.isFrontTab();
        const auto accent = active ? rose() : teal();
        const float c = 7.f;
        juce::Path p;
        p.startNewSubPath (r.getX() + c, r.getY());           p.lineTo (r.getRight() - c, r.getY());
        p.lineTo (r.getRight(), r.getY() + c);                 p.lineTo (r.getRight(), r.getBottom() - c);
        p.lineTo (r.getRight() - c, r.getBottom());            p.lineTo (r.getX() + c, r.getBottom());
        p.lineTo (r.getX(), r.getBottom() - c);                p.lineTo (r.getX(), r.getY() + c);
        p.closeSubPath();
        if (active || over)
            juce::DropShadow (accent.withAlpha (active ? 0.55f : 0.32f), 9, {}).drawForPath (g, p);
        g.setGradientFill (juce::ColourGradient (active ? purple().withAlpha (0.62f) : raised().withAlpha (0.55f), r.getX(), r.getY(),
                                                 ink().withAlpha (0.9f), r.getX(), r.getBottom(), false));
        g.fillPath (p);
        g.setColour (juce::Colours::white.withAlpha (active ? 0.16f : 0.07f));
        g.drawLine (r.getX() + c, r.getY() + 1.5f, r.getRight() - c, r.getY() + 1.5f, 1.f);
        g.setColour (accent.withAlpha (active ? 0.98f : (over ? 0.75f : 0.38f)));
        g.strokePath (p, juce::PathStrokeType (active ? 1.5f : 1.1f));
        if (active)
        {
            g.setColour (champagne());
            g.fillRoundedRectangle (r.getCentreX() - r.getWidth() * 0.22f, r.getBottom() - 3.f, r.getWidth() * 0.44f, 2.2f, 1.1f);
        }
        g.setFont (juce::FontOptions (12.f, juce::Font::bold));
        g.setColour (active ? juce::Colours::white : (over ? teal().brighter (0.4f) : mutedText().brighter (0.2f)));
        g.drawText (button.getButtonText(), button.getLocalBounds().withTrimmedBottom (down ? 0 : 1), juce::Justification::centred);
    }
    void drawTabAreaBehindFrontButton (juce::TabbedButtonBar&, juce::Graphics&, int, int) override {}

    // ------------------------------------------------------------------
    // Image buttons (LFO1-3, random/creative, preset open/close) - crystal artwork + clear label
    static juce::Colour lfoGlow (int i) { return i == 0 ? juce::Colour (0xff35f0d0) : (i == 1 ? juce::Colour (0xffff3df2) : juce::Colour (0xffffc94a)); }

    static void drawImageButton (juce::Graphics& g, juce::Button& button, bool highlighted, bool down)
    {
        const auto cid = button.getComponentID();
        const bool on = button.getToggleState();
        auto b = button.getLocalBounds().toFloat();
        juce::Colour glow = teal();
        const juce::Image* img = &GitiCrystal::get (GitiCrystal::Octagon);
        float labelH = 0.f;
        if (cid.startsWith ("giti_img_lfo"))
        {
            const int idx = cid.getTrailingIntValue();
            img = &GitiCrystal::vortexForLfo (idx);
            glow = lfoGlow (idx);
            labelH = 17.f;
        }
        else if (cid == "giti_img_random")
        {
            img = &GitiCrystal::get (GitiCrystal::Arabic);
            glow = rose();
            labelH = 17.f;
        }
        else if (cid == "giti_img_toggle")
            glow = champagne();

        auto icon = b.withTrimmedBottom (labelH).reduced (1.f);
        const float side = juce::jmin (icon.getWidth(), icon.getHeight());
        auto sq = juce::Rectangle<float> (side, side).withCentre (icon.getCentre());
        if (down) sq = sq.reduced (side * 0.04f);
        const auto c = sq.getCentre();
        g.setColour (glow.withAlpha (on ? 0.42f : (highlighted ? 0.30f : 0.14f)));
        g.fillEllipse (c.x - side * 0.62f, c.y - side * 0.62f, side * 1.24f, side * 1.24f);
        g.setOpacity (down ? 0.85f : 1.f);
        g.drawImage (*img, highlighted ? sq.expanded (side * 0.04f) : sq, juce::RectanglePlacement::centred);
        g.setOpacity (1.f);
        if (on)
        {
            g.setColour (glow.withAlpha (0.95f));
            g.drawEllipse (sq.expanded (1.5f), 2.f);
        }
    }

    static void drawImageButtonText (juce::Graphics& g, juce::TextButton& button)
    {
        const auto cid = button.getComponentID();
        auto b = button.getLocalBounds().toFloat();
        if (cid == "giti_img_toggle")
        {
            // chevrons: « when open, » when collapsed
            const auto c = b.getCentre();
            const float s = juce::jmin (b.getWidth(), b.getHeight()) * 0.16f;
            const float dir = button.getToggleState() ? 1.f : -1.f;
            juce::Path p;
            for (int k = 0; k < 2; ++k)
            {
                const float ox = (k - 0.5f) * s * 1.5f;
                p.startNewSubPath (c.x + ox - dir * s * 0.7f, c.y - s);
                p.lineTo (c.x + ox + dir * s * 0.7f, c.y);
                p.lineTo (c.x + ox - dir * s * 0.7f, c.y + s);
            }
            const auto st = juce::PathStrokeType (3.4f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded);
            g.setColour (juce::Colours::black.withAlpha (0.75f));
            g.strokePath (p, st);
            g.setColour (juce::Colours::white);
            g.strokePath (p, juce::PathStrokeType (1.9f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
            return;
        }
        juce::String label = cid == "giti_img_random" ? "RANDOM" : button.getButtonText().toUpperCase();
        juce::Colour glow = cid == "giti_img_random" ? rose() : lfoGlow (cid.getTrailingIntValue());
        auto strip = b.removeFromBottom (16.f);
        const float tw = juce::jmin (strip.getWidth(), 12.f + 7.4f * (float) label.length());
        auto pill = juce::Rectangle<float> (tw, 15.f).withCentre (strip.getCentre());
        g.setGradientFill (juce::ColourGradient (juce::Colour (0xf0141a3c), pill.getX(), pill.getY(),
                                                 juce::Colour (0xf0060818), pill.getX(), pill.getBottom(), false));
        g.fillRoundedRectangle (pill, 7.5f);
        g.setColour (glow.withAlpha (button.getToggleState() ? 1.f : 0.75f));
        g.drawRoundedRectangle (pill, 7.5f, 1.1f);
        g.setColour (juce::Colours::white);
        g.setFont (juce::FontOptions (11.5f, juce::Font::bold));
        g.drawText (label, pill.toNearestInt(), juce::Justification::centred);
    }

    // ------------------------------------------------------------------
    // Knob "personality": different crystal body per control family
    static int knobStyleFor (const juce::String& id)
    {
        auto has = [&] (const char* t) { return id.containsIgnoreCase (t); };
        if (id == "master_gain") return 7;
        if (id.isEmpty()) return 0;
        if (has ("level") || has ("gain") || has ("mix") || has ("volume")) return 2;     // metal ring dial
        if (has ("udet") || has ("uspread") || has ("unison") || has ("spread")) return 1; // hexagon
        if (has ("table") || has ("warp") || has ("fold") || has ("reso")) return 4;       // waveform disc
        if (has ("drive") || has ("cutoff")) return 5;                                      // swirl crystal
        if (has ("octave") || has ("semi") || has ("coarse") || has ("fine") || has ("detune")
            || has ("filter_env")) return 6;                                                // diamond gem
        if (has ("phase") || has ("rand") || has ("pan") || has ("noise") || has ("sub")
            || has ("glide") || has ("voice")) return 3;                                    // 12-point star
        if (has ("attack") || has ("decay") || has ("sustain") || has ("release")) return 0; // octagon
        static const int pool[4] = { 0, 1, 2, 3 };
        return pool[(int) (id.hashCode() & 0x7fffffff) % 4];
    }

    static const juce::Image& crystalVariant (GitiCrystal::Id id, float hue)
    {
        static std::map<int, juce::Image> cache;
        const int key = (int) id * 1000 + (int) std::round (hue * 100.f) + 500;
        auto it = cache.find (key);
        if (it != cache.end()) return it->second;
        auto img = GitiCrystal::get (id).createCopy();
        hue += giti::genesisHueShift();
        if (std::abs (hue) > 0.001f && img.isValid())
        {
            juce::Image::BitmapData bd (img, juce::Image::BitmapData::readWrite);
            for (int y = 0; y < bd.height; ++y)
                for (int x = 0; x < bd.width; ++x)
                {
                    auto c = bd.getPixelColour (x, y);
                    if (c.getAlpha() > 0) bd.setPixelColour (x, y, c.withRotatedHue (hue));
                }
        }
        return cache.emplace (key, img).first->second;
    }

    // Crystal knob: gradient value arc + per-family body (vector or crystal artwork) + energy core
    void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
        float sliderPos, float rotaryStartAngle, float rotaryEndAngle, juce::Slider& slider) override
    {
        auto bounds = juce::Rectangle<float> ((float) x, (float) y, (float) width, (float) height).reduced (3.f);
        const float radius = juce::jmin (bounds.getWidth(), bounds.getHeight()) * 0.40f;
        const float cx = bounds.getCentreX();
        const float cy = bounds.getCentreY() - 1.f;
        const float value = juce::jlimit (0.f, 1.f, sliderPos);
        const float angle = rotaryStartAngle + value * (rotaryEndAngle - rotaryStartAngle);
        const auto accent = slider.findColour (juce::Slider::rotarySliderFillColourId)
                                  .withMultipliedSaturation (1.1f);
        const bool dragging = slider.isMouseButtonDown();
        const bool hovered  = slider.isMouseOverOrDragging();
        const int style = knobStyleFor (slider.getProperties()["pid"].toString());
        const float pi = juce::MathConstants<float>::pi;

        // soft halo
        g.setColour (accent.withAlpha (0.07f + value * 0.10f + (hovered ? 0.07f : 0.f)));
        g.fillEllipse (cx - radius - 5.f, cy - radius - 5.f, radius * 2.f + 10.f, radius * 2.f + 10.f);

        // modulation badges: one coloured bead per LFO that is routed to this knob (green / violet / gold)
        {
            const int mm = (int) slider.getProperties().getWithDefault ("mod_mask", 0);
            if (mm != 0)
            {
                int n = 0;
                for (int i = 0; i < 3; ++i)
                    if ((mm >> i) & 1)
                    {
                        const float bx = cx + radius * 0.95f - (float) n * 10.f, by = cy - radius * 1.05f;
                        g.setColour (juce::Colours::black.withAlpha (0.75f));
                        g.fillEllipse (bx - 6.f, by - 6.f, 12.f, 12.f);
                        g.setColour (lfoGlow (i));
                        g.fillEllipse (bx - 4.5f, by - 4.5f, 9.f, 9.f);
                        g.setColour (juce::Colours::white.withAlpha (0.9f));
                        g.setFont (juce::FontOptions (7.5f, juce::Font::bold));
                        g.drawText (juce::String (i + 1), juce::Rectangle<float> (bx - 5.f, by - 5.f, 10.f, 10.f), juce::Justification::centred);
                        ++n;
                    }
            }
        }

        // value arc (accent -> magenta)
        const float ar = radius * 1.0f + 1.5f;
        juce::Path track, valueArc;
        track.addCentredArc (cx, cy, ar, ar, 0.f, rotaryStartAngle, rotaryEndAngle, true);
        valueArc.addCentredArc (cx, cy, ar, ar, 0.f, rotaryStartAngle, angle, true);
        g.setColour (juce::Colours::white.withAlpha (0.09f));
        g.strokePath (track, juce::PathStrokeType (2.4f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        if (value > 0.01f && ! valueArc.isEmpty())
        {
            g.setColour (accent.withAlpha (dragging ? 0.30f : 0.16f));
            g.strokePath (valueArc, juce::PathStrokeType (7.f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
            g.setGradientFill (juce::ColourGradient (accent, cx - ar, cy, rose(), cx + ar, cy, false));
            g.strokePath (valueArc, juce::PathStrokeType (3.2f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }

        const float br = radius * 0.80f;

        {   // ---- every knob is a crystal PNG that turns with the value ----
            GitiCrystal::Id imgId = GitiCrystal::Octagon; float hue = 0.f;
            switch (style)
            {
                case 1: imgId = GitiCrystal::Vortex;   hue = -0.30f; break;
                case 2: imgId = GitiCrystal::CyanPuck; break;
                case 3: imgId = GitiCrystal::Vortex;   hue =  0.33f; break;
                case 4: imgId = GitiCrystal::WaveDisc; break;
                case 5: imgId = GitiCrystal::HexSwirl; break;
                case 6: imgId = GitiCrystal::Diamond;  break;
                case 7: imgId = GitiCrystal::CyanPuck; break;
                default: imgId = GitiCrystal::Octagon; break;
            }
            const auto& img = crystalVariant (imgId, hue);
            const float sz = style == 7 ? radius * 2.15f : br * 2.55f;
            auto dest = juce::Rectangle<float> (sz, sz).withCentre ({ cx, cy });
            const float rot = angle - (rotaryStartAngle + rotaryEndAngle) * 0.5f;
            g.setColour (juce::Colours::black.withAlpha (0.38f));
            g.fillEllipse (dest.reduced (sz * 0.2f).translated (0.f, 2.5f));
            {
                juce::Graphics::ScopedSaveState ss (g);
                g.addTransform (juce::AffineTransform::rotation (rot, cx, cy));
                g.setOpacity (hovered || dragging ? 1.f : 0.95f);
                g.drawImage (img, dest, juce::RectanglePlacement::centred);
                g.setOpacity (1.f);
                // rim marker turns with the artwork so the value is always readable
                const float my = cy - sz * 0.40f;
                g.setColour (juce::Colours::black.withAlpha (0.7f));
                g.fillEllipse (cx - 3.2f, my - 3.2f, 6.4f, 6.4f);
                g.setColour (accent.brighter (0.6f));
                g.fillEllipse (cx - 2.2f, my - 2.2f, 4.4f, 4.4f);
            }
            if (hovered || dragging)
            {
                g.setColour (accent.withAlpha (0.35f));
                g.drawEllipse (cx - sz * 0.46f, cy - sz * 0.46f, sz * 0.92f, sz * 0.92f, 1.5f);
            }
            return;
        }

        // ---- vector bodies ----
        juce::Path body;
        if (style == 1)      body.addPolygon ({ cx, cy }, 6, br * 1.05f, pi / 6.f);
        else if (style == 2) body.addEllipse (cx - br, cy - br, br * 2.f, br * 2.f);
        else if (style == 3) body.addStar ({ cx, cy }, 12, br * 0.80f, br * 1.04f, 0.f);
        else                 body.addPolygon ({ cx, cy }, 8, br, pi / 8.f);

        g.setColour (juce::Colours::black.withAlpha (0.45f));
        g.fillPath (body, juce::AffineTransform::translation (0.f, 2.f));
        g.setGradientFill (juce::ColourGradient (raised().brighter (0.35f), cx, cy - br, ink(), cx, cy + br, false));
        g.fillPath (body);
        g.setColour (accent.withAlpha (0.75f));
        g.strokePath (body, juce::PathStrokeType (style == 2 ? 1.8f : 1.2f));

        if (style == 2)      // metal ring dial: tick dots
        {
            g.setColour (accent.withAlpha (0.35f));
            for (int i = 0; i < 12; ++i)
            {
                const float a = i * juce::MathConstants<float>::twoPi / 12.f;
                g.fillEllipse (cx + std::sin (a) * br * 0.84f - 1.1f, cy - std::cos (a) * br * 0.84f - 1.1f, 2.2f, 2.2f);
            }
        }
        else
        {
            g.setColour (accent.withAlpha (0.20f));
            const int n = style == 1 ? 6 : 8;
            for (int i = 0; i < n; ++i)
            {
                const float a = (i + 0.5f) * juce::MathConstants<float>::twoPi / (float) n;
                g.drawLine (cx + std::sin (a) * br * 0.38f, cy - std::cos (a) * br * 0.38f,
                            cx + std::sin (a) * br, cy - std::cos (a) * br, 0.8f);
            }
            juce::Path star;
            star.addStar ({ cx, cy }, n, br * 0.46f, br * 0.70f, pi / (float) n);
            g.setColour (champagne().withAlpha (0.38f));
            g.strokePath (star, juce::PathStrokeType (0.9f));
        }

        const float core = br * (0.30f + 0.04f * std::sin (corePhase() * 3.f) + value * 0.12f + (dragging ? 0.05f : 0.f));
        g.setGradientFill (juce::ColourGradient (juce::Colours::white.withAlpha (0.95f), cx, cy,
                                                 accent.withAlpha (0.f), cx + core * 1.6f, cy, true));
        g.fillEllipse (cx - core * 1.6f, cy - core * 1.6f, core * 3.2f, core * 3.2f);

        g.setColour (text());
        g.drawLine (cx + std::sin (angle) * br * 0.55f, cy - std::cos (angle) * br * 0.55f,
                    cx + std::sin (angle) * br * 0.94f, cy - std::cos (angle) * br * 0.94f, 2.f);
    }

    // Crystal fader (used next to the big filter knobs): glass groove + gradient fill + gem thumb
    void drawLinearSlider (juce::Graphics& g, int x, int y, int width, int height, float sliderPos,
                           float, float, juce::Slider::SliderStyle style, juce::Slider& s) override
    {
        const auto accent = s.findColour (juce::Slider::rotarySliderFillColourId);
        const bool vertical = (style == juce::Slider::LinearVertical);
        auto b = juce::Rectangle<float> ((float) x, (float) y, (float) width, (float) height);
        const bool hot = s.isMouseOverOrDragging();
        juce::Rectangle<float> groove = vertical ? juce::Rectangle<float> (5.f, b.getHeight() - 12.f).withCentre (b.getCentre())
                                                 : juce::Rectangle<float> (b.getWidth() - 12.f, 5.f).withCentre (b.getCentre());
        g.setGradientFill (juce::ColourGradient (ink().brighter (0.05f), groove.getX(), groove.getY(),
                                                 raised(), groove.getRight(), groove.getBottom(), false));
        g.fillRoundedRectangle (groove, 2.5f);
        g.setColour (border().withAlpha (0.8f));
        g.drawRoundedRectangle (groove, 2.5f, 1.f);

        juce::Rectangle<float> fill = vertical ? groove.withTop (sliderPos) : groove.withRight (sliderPos);
        g.setColour (accent.withAlpha (hot ? 0.34f : 0.20f));
        g.fillRoundedRectangle (fill.expanded (vertical ? 3.f : 0.f, vertical ? 0.f : 3.f), 3.f);
        g.setGradientFill (juce::ColourGradient (accent, fill.getX(), fill.getBottom(), rose(), fill.getX(), fill.getY(), false));
        g.fillRoundedRectangle (fill, 2.5f);

        const auto c = vertical ? juce::Point<float> (groove.getCentreX(), sliderPos) : juce::Point<float> (sliderPos, groove.getCentreY());
        const float tw = vertical ? 9.f : 7.f, th = vertical ? 7.f : 9.f;
        juce::Path gem;
        gem.startNewSubPath (c.x, c.y - th * 1.2f);
        gem.lineTo (c.x + tw, c.y);
        gem.lineTo (c.x, c.y + th * 1.2f);
        gem.lineTo (c.x - tw, c.y);
        gem.closeSubPath();
        g.setColour (accent.withAlpha (0.35f));
        g.fillPath (gem, juce::AffineTransform::scale (1.35f, 1.35f, c.x, c.y));
        g.setGradientFill (juce::ColourGradient (juce::Colours::white, c.x, c.y - th, accent.darker (0.3f), c.x, c.y + th, false));
        g.fillPath (gem);
        g.setColour (juce::Colours::white.withAlpha (0.9f));
        g.strokePath (gem, juce::PathStrokeType (1.f));
    }
};
