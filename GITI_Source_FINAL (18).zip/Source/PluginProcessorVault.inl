#include "GitiVault.h"

static juce::File salekBanksDir()
{
    auto dir = juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory).getChildFile ("SALEK_HIGHTECH").getChildFile ("Banks");
    dir.createDirectory();
    return dir;
}

static juce::File salekHiddenFile() { return salekBanksDir().getParentDirectory().getChildFile ("hidden_folders.txt"); }

int SalekHightechAudioProcessor::loadBankXml (const juce::XmlElement& root)
{
    if (! root.hasTagName ("SALEK_USER_PRESETS")) return -1;
    juce::StringArray hidden;
    hidden.addLines (salekHiddenFile().loadFileAsString());
    hidden.removeEmptyStrings();
    int n = 0;
    for (auto* px : root.getChildIterator())
    {
        if (! px->hasTagName ("PRESET")) continue;
        FactoryPreset pr;
        pr.name = px->getStringAttribute ("name");
        if (pr.name.isEmpty() || pr.name.startsWith ("USER/")) continue;   // must not collide with saved user presets
        bool isHidden = false;
        for (auto& h : hidden) if (pr.name.startsWith (h + "/")) { isHidden = true; break; }
        if (isHidden) continue;                                             // folder removed by the user
        for (auto* c : px->getChildIterator())
        {
            if (c->hasTagName ("PARAM")) { auto id = c->getStringAttribute ("id"); if (id.isNotEmpty()) pr.values[id] = (float) c->getDoubleAttribute ("value"); }
            else if (c->hasTagName ("MOD_MATRIX")) pr.modMatrixXml = c->toString();
        }
        if (pr.values.empty()) continue;
        int found = -1;
        for (int i = 0; i < (int) factoryPresets.size(); ++i) if (factoryPresets[(size_t) i].name == pr.name) { found = i; break; }
        if (found >= 0) factoryPresets[(size_t) found] = pr; else factoryPresets.push_back (pr);
        lockedPresetNames.insert (pr.name);
        lockedSource[pr.name] = loadingBankFile;
        ++n;
    }
    return n;
}

static juce::File salekAccountFile() { return salekBanksDir().getParentDirectory().getChildFile ("account.txt"); }

juce::String SalekHightechAudioProcessor::getAccountEmail() const { return salekAccountFile().loadFileAsString().trim(); }

void SalekHightechAudioProcessor::setAccountEmail (const juce::String& email)
{
    salekAccountFile().replaceWithText (email.trim());
    // drop every preset that came from an encrypted bank, then rescan with the new e-mail
    for (int i = (int) factoryPresets.size() - 1; i >= 1; --i)
        if (lockedPresetNames.count (factoryPresets[(size_t) i].name) > 0)
        {
            factoryPresets.erase (factoryPresets.begin() + i);
            if (currentProgram == i) currentProgram = 0; else if (currentProgram > i) --currentProgram;
        }
    lockedPresetNames.clear();
    lockedSource.clear();
    loadEncryptedBanks();
}

int SalekHightechAudioProcessor::loadBankFile (const juce::File& f)
{
    juce::MemoryBlock raw;
    if (! f.loadFileAsData (raw)) return -1;
    juce::MemoryBlock plain;
    if (! giti::vault::decrypt (raw.getData(), raw.getSize(), plain, getAccountEmail()))
        return giti::vault::isEmailLocked (raw.getData(), raw.getSize()) ? -2 : -1;   // -2: locked to another e-mail, -1: invalid/tampered
    std::unique_ptr<juce::XmlElement> xml (juce::XmlDocument::parse (plain.toString()));
    if (xml == nullptr) return -1;
    loadingBankFile = f;
    return loadBankXml (*xml);
}

void SalekHightechAudioProcessor::loadEncryptedBanks()
{
    for (auto& f : salekBanksDir().findChildFiles (juce::File::findFiles, false, "*.gitibank"))
        loadBankFile (f);
}

int SalekHightechAudioProcessor::installEncryptedBank (const juce::File& file)
{
    // copy first, then load FROM the installed copy: removing the bank later deletes that copy, never the user's original
    auto target = salekBanksDir().getChildFile (file.getFileName());
    if (file != target && ! file.copyFileTo (target))
        return -3;                                   // could not copy into the Banks folder
    const int n = loadBankFile (target);
    if (n <= 0 && file != target) target.deleteFile();
    return n;
}

int SalekHightechAudioProcessor::deletePresets (const juce::String& path)
{
    int removed = 0, cur = currentProgram;
    bool userChanged = false, hideFolder = false;
    juce::StringArray filesToDelete;
    for (int i = (int) factoryPresets.size() - 1; i >= 1; --i)       // 0 = Init, never removed
    {
        const auto n = factoryPresets[(size_t) i].name;
        if (! (n.startsWith (path + "/") || n.startsWith ("USER/" + path + "/"))) continue;
        if (n.startsWith ("USER/")) userChanged = true;
        else if (lockedPresetNames.count (n) > 0)
        {
            if (! path.containsChar ('/'))
            {
                auto it = lockedSource.find (n);
                if (it != lockedSource.end()) filesToDelete.addIfNotAlreadyThere (it->second.getFullPathName());
            }
            else hideFolder = true;
            lockedPresetNames.erase (n);
            lockedSource.erase (n);
        }
        factoryPresets.erase (factoryPresets.begin() + i);
        if (cur == i) cur = -1; else if (cur > i) --cur;
        ++removed;
    }
    for (auto& f : filesToDelete) juce::File (f).deleteFile();
    if (hideFolder)
    {
        auto hf = salekHiddenFile();
        juce::StringArray lines; lines.addLines (hf.loadFileAsString());
        lines.addIfNotAlreadyThere (path);
        hf.replaceWithText (lines.joinIntoString ("\n"));
    }
    if (userChanged) saveUserPresetsToDisk();
    currentProgram = (cur < 0 || cur >= (int) factoryPresets.size()) ? 0 : cur;
    return removed;
}

float SalekHightechAudioProcessor::fastParam (const char* id) noexcept
{
    // open-addressing table keyed by the literal's address: no allocation, no string hashing after the first call
    const size_t h = (reinterpret_cast<size_t> (id) >> 3) * (size_t) 2654435761u;
    for (size_t i = 0; i < (size_t) kParamSlots; ++i)
    {
        auto& s = paramCache[(h + i) & ((size_t) kParamSlots - 1)];
        if (s.key == id) return s.value != nullptr ? s.value->load (std::memory_order_relaxed) : 0.f;
        if (s.key == nullptr)
        {
            s.key = id;
            s.value = apvts.getRawParameterValue (id);
            return s.value != nullptr ? s.value->load (std::memory_order_relaxed) : 0.f;
        }
    }
    auto* p = apvts.getRawParameterValue (id);    // table full (never expected): plain lookup
    return p != nullptr ? p->load (std::memory_order_relaxed) : 0.f;
}
