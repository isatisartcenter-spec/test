#pragma once
// ---------------------------------------------------------------------------------------------
// GITI Vault: reads encrypted preset banks (.gitibank).
// Format: "GTV1" | salt[16] | nonce[12] | ciphertext | HMAC-SHA256[32]
// Cipher: ChaCha20 (counter starts at 0). Keys are derived per file: SHA256(master|salt|'E' or 'M').
// The plugin can only DECRYPT. Packs are produced by the private tool giti_pack.py.
// Decrypted data lives only in memory (it is never written back to disk in clear text).
// ---------------------------------------------------------------------------------------------

#include <juce_core/juce_core.h>
#include <array>
#include <cstdint>
#include <cstring>
#include <vector>

namespace giti { namespace vault
{
    inline std::array<uint8_t, 32> masterKey()
    {
        static const uint8_t d[32] = { 77,58,67,122,93,18,153,103,50,229,173,116,225,215,114,189,36,203,117,189,74,70,241,157,236,102,113,58,169,4,108,89 };
        std::array<uint8_t, 32> k {};
        for (int i = 0; i < 32; ++i) k[(size_t) i] = (uint8_t) (d[i] ^ (uint8_t) ((((i * 37) + 91) ^ 0xA5) & 0xFF));
        return k;
    }

    // self-contained SHA-256 (no extra JUCE module needed)
    inline void sha256 (const uint8_t* d, size_t n, uint8_t out[32])
    {
        static const uint32_t K[64] = {
            0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
            0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
            0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
            0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2 };
        uint32_t h[8] = { 0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19 };
        std::vector<uint8_t> m (d, d + n);
        m.push_back (0x80);
        while (m.size() % 64 != 56) m.push_back (0);
        const uint64_t bits = (uint64_t) n * 8;
        for (int i = 7; i >= 0; --i) m.push_back ((uint8_t) (bits >> (i * 8)));
        auto rr = [] (uint32_t v, int c) { return (v >> c) | (v << (32 - c)); };
        for (size_t off = 0; off < m.size(); off += 64)
        {
            uint32_t w[64];
            for (int i = 0; i < 16; ++i) w[i] = ((uint32_t) m[off + i*4] << 24) | ((uint32_t) m[off + i*4+1] << 16) | ((uint32_t) m[off + i*4+2] << 8) | (uint32_t) m[off + i*4+3];
            for (int i = 16; i < 64; ++i)
            {
                const uint32_t s0 = rr (w[i-15], 7) ^ rr (w[i-15], 18) ^ (w[i-15] >> 3);
                const uint32_t s1 = rr (w[i-2], 17) ^ rr (w[i-2], 19) ^ (w[i-2] >> 10);
                w[i] = w[i-16] + s0 + w[i-7] + s1;
            }
            uint32_t a = h[0], b = h[1], c = h[2], dd = h[3], e = h[4], f = h[5], g = h[6], hh = h[7];
            for (int i = 0; i < 64; ++i)
            {
                const uint32_t S1 = rr (e, 6) ^ rr (e, 11) ^ rr (e, 25), ch = (e & f) ^ (~e & g), t1 = hh + S1 + ch + K[i] + w[i];
                const uint32_t S0 = rr (a, 2) ^ rr (a, 13) ^ rr (a, 22), mj = (a & b) ^ (a & c) ^ (b & c), t2 = S0 + mj;
                hh = g; g = f; f = e; e = dd + t1; dd = c; c = b; b = a; a = t1 + t2;
            }
            h[0] += a; h[1] += b; h[2] += c; h[3] += dd; h[4] += e; h[5] += f; h[6] += g; h[7] += hh;
        }
        for (int i = 0; i < 8; ++i) { out[i*4] = (uint8_t) (h[i] >> 24); out[i*4+1] = (uint8_t) (h[i] >> 16); out[i*4+2] = (uint8_t) (h[i] >> 8); out[i*4+3] = (uint8_t) h[i]; }
    }

    inline void hmac (const uint8_t key[32], const uint8_t* msg, size_t n, uint8_t out[32])
    {
        uint8_t ipad[64], opad[64];
        for (int i = 0; i < 64; ++i) { const uint8_t kb = i < 32 ? key[i] : 0; ipad[i] = kb ^ 0x36; opad[i] = kb ^ 0x5c; }
        std::vector<uint8_t> inner (ipad, ipad + 64);
        inner.insert (inner.end(), msg, msg + n);
        uint8_t ih[32]; sha256 (inner.data(), inner.size(), ih);
        std::vector<uint8_t> outer (opad, opad + 64);
        outer.insert (outer.end(), ih, ih + 32);
        sha256 (outer.data(), outer.size(), out);
    }

    static inline uint32_t rotl (uint32_t v, int c) { return (v << c) | (v >> (32 - c)); }
    #define GV_QR(a,b,c,d) a += b; d ^= a; d = rotl (d,16); c += d; b ^= c; b = rotl (b,12); a += b; d ^= a; d = rotl (d,8); c += d; b ^= c; b = rotl (b,7);

    inline void chacha20Xor (const uint8_t key[32], const uint8_t nonce[12], uint8_t* data, size_t n)
    {
        uint32_t st[16] = { 0x61707865u, 0x3320646eu, 0x79622d32u, 0x6b206574u };
        for (int i = 0; i < 8; ++i) st[4 + i] = (uint32_t) key[i*4] | ((uint32_t) key[i*4+1] << 8) | ((uint32_t) key[i*4+2] << 16) | ((uint32_t) key[i*4+3] << 24);
        st[12] = 0;
        for (int i = 0; i < 3; ++i) st[13 + i] = (uint32_t) nonce[i*4] | ((uint32_t) nonce[i*4+1] << 8) | ((uint32_t) nonce[i*4+2] << 16) | ((uint32_t) nonce[i*4+3] << 24);
        for (size_t off = 0; off < n; off += 64)
        {
            uint32_t x[16]; std::memcpy (x, st, sizeof (x));
            for (int r = 0; r < 10; ++r)
            {
                GV_QR (x[0],x[4],x[8],x[12]) GV_QR (x[1],x[5],x[9],x[13]) GV_QR (x[2],x[6],x[10],x[14]) GV_QR (x[3],x[7],x[11],x[15])
                GV_QR (x[0],x[5],x[10],x[15]) GV_QR (x[1],x[6],x[11],x[12]) GV_QR (x[2],x[7],x[8],x[13]) GV_QR (x[3],x[4],x[9],x[14])
            }
            uint8_t ks[64];
            for (int i = 0; i < 16; ++i) { const uint32_t v = x[i] + st[i]; ks[i*4] = (uint8_t) v; ks[i*4+1] = (uint8_t) (v >> 8); ks[i*4+2] = (uint8_t) (v >> 16); ks[i*4+3] = (uint8_t) (v >> 24); }
            const size_t m = (n - off) < 64 ? (n - off) : 64;
            for (size_t i = 0; i < m; ++i) data[off + i] ^= ks[i];
            ++st[12];
        }
    }
    #undef GV_QR

    // Bank layout:  "GTV1" | salt16 | nonce12 | cipher | mac32           (global key)
    //               "GTV2" | flags1 | salt16 | nonce12 | cipher | mac32  (flags bit0 = locked to a customer e-mail)
    inline bool isEmailLocked (const void* raw, size_t size)
    {
        return size > 5 && std::memcmp (raw, "GTV2", 4) == 0 && (static_cast<const uint8_t*> (raw)[4] & 1) != 0;
    }

    // returns false if the file is not a valid, untampered bank (or the e-mail does not match)
    inline bool decrypt (const void* raw, size_t size, juce::MemoryBlock& plainOut, const juce::String& email = {})
    {
        if (size < 4) return false;
        const uint8_t* p = static_cast<const uint8_t*> (raw);
        size_t hdr = 0; uint8_t flags = 0;
        if (std::memcmp (raw, "GTV1", 4) == 0) hdr = 4;
        else if (std::memcmp (raw, "GTV2", 4) == 0 && size > 5) { hdr = 5; flags = p[4]; }
        else return false;
        if (size < hdr + 16 + 12 + 32) return false;
        const uint8_t* salt = p + hdr; const uint8_t* nonce = p + hdr + 16;
        const size_t cn = size - hdr - 16 - 12 - 32;
        const uint8_t* cipher = p + hdr + 28; const uint8_t* mac = p + hdr + 28 + cn;
        const auto mk = masterKey();
        const juce::String em = email.trim().toLowerCase();
        auto derive = [&] (char tag, uint8_t out[32])
        {
            std::vector<uint8_t> b (mk.begin(), mk.end());
            b.insert (b.end(), salt, salt + 16); b.push_back ((uint8_t) tag);
            if (flags & 1) { auto u = em.toStdString(); b.insert (b.end(), u.begin(), u.end()); }
            sha256 (b.data(), b.size(), out);
        };
        uint8_t ek[32], mkk[32]; derive ('E', ek); derive ('M', mkk);
        std::vector<uint8_t> msg (p, p + hdr + 28 + cn);
        uint8_t calc[32]; hmac (mkk, msg.data(), msg.size(), calc);
        uint8_t diff = 0; for (int i = 0; i < 32; ++i) diff |= (uint8_t) (calc[i] ^ mac[i]);
        if (diff != 0) return false;
        std::vector<uint8_t> buf (cipher, cipher + cn);
        chacha20Xor (ek, nonce, buf.data(), buf.size());
        plainOut.replaceAll (buf.data(), buf.size());
        return true;
    }
}}
