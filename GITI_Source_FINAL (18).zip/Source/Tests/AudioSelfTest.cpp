#include "../FX/EffectTailEstimate.h"
#include "../FX/MagicEngine.h"
#include "../FX/SimpleChorus.h"
#include "../FX/SimpleCompressor.h"
#include "../FX/SimpleDelay.h"
#include "../FX/SimpleDistortion.h"
#include "../FX/SimplePhaser.h"
#include "../FX/SimpleReverb.h"
#include "../Filters/StateVariableFilter.h"
#include "../GITI/GitiPresetBank.h"
#include "../GITI/ThisIsSalekPresetBank.h"
#include "../Synth/SynthEngine.h"

#include <cmath>
#include <iostream>
#include <set>
#include <string>
#include <vector>

namespace
{
bool require (bool condition, const char* message)
{
    if (! condition)
        std::cerr << "FAIL: " << message << '\n';
    return condition;
}

struct FilterMeasure
{
    float rms = 0.0f;
    float mean = 0.0f;
    float peak = 0.0f;
};

FilterMeasure measureLowPass (float resonance, float drive)
{
    constexpr float sampleRate = 48000.0f;
    constexpr int sampleCount = 48000;
    constexpr int warmup = 4096;
    salek::StateVariableFilter filter;
    filter.prepare (sampleRate);
    filter.setMode (salek::StateVariableFilter::Mode::LowPass12);
    filter.setCutoff (12000.0f);
    filter.setResonance (resonance);
    filter.setDrive (drive);

    double sumSquares = 0.0;
    double sum = 0.0;
    float peak = 0.0f;
    int count = 0;
    for (int i = 0; i < sampleCount; ++i)
    {
        const float input = 0.1f * std::sin (juce::MathConstants<float>::twoPi
                                             * 1000.0f * static_cast<float> (i) / sampleRate);
        const float output = filter.process (input);
        if (i >= warmup)
        {
            sumSquares += static_cast<double> (output) * output;
            sum += output;
            peak = juce::jmax (peak, std::abs (output));
            ++count;
        }
    }

    return { static_cast<float> (std::sqrt (sumSquares / count)),
             static_cast<float> (sum / count), peak };
}

bool testFactoryBank ()
{
    using namespace salek::giti;
    const auto presets = makePresets();
    if (! require (identities.size() == 50, "GITI still contains all 50 identities")) return false;
    if (! require (presets.size() == 250, "GITI still contains five variants per identity")) return false;

    static constexpr const char* variants[] = { "[CORE]", "[DEEP]", "[SKY]", "[HALO]", "[MOTION]" };
    std::set<std::string> names;
    for (std::size_t i = 0; i < presets.size(); ++i)
    {
        const auto& preset = presets[i];
        if (! require (names.insert (preset.name.toStdString()).second, "GITI preset names are unique")) return false;
        if (! require (preset.name.contains (variants[i % 5]), "GITI variant ordering remains stable")) return false;
        for (const auto& [id, value] : preset.values)
        {
            juce::ignoreUnused (id);
            if (! require (std::isfinite (value), "GITI preset values are finite")) return false;
        }
    }
    return true;
}

template <typename PresetType>
bool renderFactoryPreset (const PresetType& preset, float& rms, float& peak, float& dc)
{
    constexpr double sampleRate = 44100.0;
    constexpr int blockSize = 128;
    constexpr int renderBlocks = 88;
    const auto value = [&preset] (const char* id, float fallback = 0.0f)
    {
        const auto it = preset.values.find (juce::String (id));
        return it == preset.values.end() ? fallback : it->second;
    };
    const auto integer = [&value] (const char* id, int fallback = 0)
    {
        return juce::roundToInt (value (id, static_cast<float> (fallback)));
    };

    salek::SynthEngine synth;
    synth.prepareToPlay (sampleRate, blockSize);
    synth.setOsc1Level (value ("osc1_level")); synth.setOsc2Level (value ("osc2_level")); synth.setOsc3Level (value ("osc3_level"));
    synth.setOsc1TablePos (value ("osc1_table")); synth.setOsc2TablePos (value ("osc2_table")); synth.setOsc3TablePos (value ("osc3_table"));
    synth.setOsc1Pan (value ("osc1_pan", 0.5f)); synth.setOsc2Pan (value ("osc2_pan", 0.5f)); synth.setOsc3Pan (value ("osc3_pan", 0.5f));
    synth.setOsc1Warp (value ("osc1_warp")); synth.setOsc2Warp (value ("osc2_warp")); synth.setOsc3Warp (value ("osc3_warp"));
    synth.setOsc1Fold (value ("osc1_fold")); synth.setOsc2Fold (value ("osc2_fold")); synth.setOsc3Fold (value ("osc3_fold"));
    synth.setOsc1Drive (value ("osc1_drive")); synth.setOsc2Drive (value ("osc2_drive")); synth.setOsc3Drive (value ("osc3_drive"));
    synth.setOsc1Phase (value ("osc1_phase")); synth.setOsc2Phase (value ("osc2_phase")); synth.setOsc3Phase (value ("osc3_phase"));
    synth.setOsc1Rand (value ("osc1_rand")); synth.setOsc2Rand (value ("osc2_rand")); synth.setOsc3Rand (value ("osc3_rand"));
    synth.setOsc1Octave (integer ("osc1_octave")); synth.setOsc2Octave (integer ("osc2_octave")); synth.setOsc3Octave (integer ("osc3_octave"));
    synth.setOsc1Semi (integer ("osc1_semi")); synth.setOsc2Semi (integer ("osc2_semi")); synth.setOsc3Semi (integer ("osc3_semi"));
    synth.setOsc1Fine (value ("osc1_fine")); synth.setOsc2Fine (value ("osc2_fine")); synth.setOsc3Fine (value ("osc3_fine"));
    synth.setOsc1Unison (integer ("osc1_unison", 1), value ("osc1_udet"), value ("osc1_uspread", 0.35f));
    synth.setOsc2Unison (integer ("osc2_unison", 1), value ("osc2_udet"), value ("osc2_uspread", 0.35f));
    synth.setOsc3Unison (integer ("osc3_unison", 1), value ("osc3_udet"), value ("osc3_uspread", 0.35f));
    synth.setFm2to1 (value ("fm_2to1")); synth.setFm3to1 (value ("fm_3to1")); synth.setFm3to2 (value ("fm_3to2"));
    synth.setPm2to1 (value ("pm_2to1")); synth.setAm2to1 (value ("am_2to1")); synth.setRm2to1 (value ("rm_2to1"));
    synth.setFilterCutoff (value ("filter_cutoff", 12000.0f));
    synth.setFilterResonance (value ("filter_reso")); synth.setFilterDrive (value ("filter_drive"));
    synth.setFilterMode (integer ("filter_mode")); synth.setFilterEnvAmt (value ("filter_env"));
    synth.setFilterRoute (integer ("filter_route"));
    synth.setNoiseLevel (value ("noise_level")); synth.setSubLevel (value ("sub_level")); synth.setGlide (value ("glide"));
    synth.setAmpAttack (value ("amp_attack", 0.008f)); synth.setAmpDecay (value ("amp_decay", 0.32f));
    synth.setAmpSustain (value ("amp_sustain", 0.55f)); synth.setAmpRelease (value ("amp_release", 0.34f));
    synth.setLfoRate (value ("lfo_rate", 0.18f)); synth.setLfoAmount (value ("lfo_amount"));
    synth.setLfoWave (integer ("lfo_wave")); synth.setScaleMode (integer ("scale_mode"));
    synth.setKoronCents (value ("koron_cents"));

    salek::SimpleChorus chorus;
    salek::SimpleDelay delay;
    salek::SimpleReverb reverb;
    salek::SimplePhaser phaser;
    salek::SimpleCompressor compressor;
    salek::SimpleDistortion distortion;
    chorus.prepare (sampleRate, blockSize); delay.prepare (sampleRate, blockSize);
    reverb.prepare (sampleRate, blockSize); phaser.prepare (sampleRate, blockSize);
    compressor.prepare (sampleRate, blockSize); distortion.prepare (sampleRate, blockSize);
    chorus.setMix (value ("chorus_mix")); chorus.setRate (value ("chorus_rate", 0.35f)); chorus.setDepth (value ("chorus_depth", 0.5f));
    delay.setMix (value ("delay_mix")); delay.setTimeMs (value ("delay_time", 280.0f)); delay.setFeedback (value ("delay_fb", 0.35f));
    delay.setTone (value ("delay_tone", 0.72f)); delay.setMode (integer ("delay_mode"));
    reverb.setMix (value ("reverb_mix")); reverb.setSize (value ("reverb_size", 0.5f)); reverb.setDecay (value ("reverb_decay", 0.55f));
    reverb.setDamping (value ("reverb_damp", 0.35f)); reverb.setMode (integer ("reverb_mode"));
    phaser.setMix (value ("phaser_mix")); phaser.setRate (value ("phaser_rate", 0.4f)); phaser.setDepth (value ("phaser_depth", 0.6f));
    distortion.setMix (value ("dist_mix")); distortion.setDrive (value ("dist_drive"));
    distortion.setBitcrush (value ("dist_crush")); distortion.setMode (integer ("dist_mode"));
    compressor.setMix (value ("comp_mix")); compressor.setThresholdDb (value ("comp_threshold", -12.0f));
    compressor.setRatio (value ("comp_ratio", 4.0f)); compressor.setDepth (value ("comp_depth", 1.0f));
    compressor.setAttackMs (value ("comp_attack", 8.0f)); compressor.setReleaseMs (value ("comp_release", 80.0f));
    compressor.setMakeupDb (value ("comp_gain"));

    juce::AudioBuffer<float> buffer (2, blockSize);
    juce::MidiBuffer midi;
    midi.addEvent (juce::MidiMessage::noteOn (1, 60, 0.75f), 0);
    const int noteOffBlock = juce::roundToInt (sampleRate * 0.15 / blockSize);
    bool sentNoteOff = false;
    double sumSquares = 0.0, sum = 0.0;
    int sampleCount = 0;
    peak = 0.0f;
    for (int block = 0; block < renderBlocks; ++block)
    {
        buffer.clear();
        if (block >= noteOffBlock && ! sentNoteOff)
        {
            midi.addEvent (juce::MidiMessage::noteOff (1, 60), 0);
            sentNoteOff = true;
        }
        synth.processBlock (buffer, midi);
        midi.clear();
        chorus.process (buffer); delay.process (buffer); reverb.process (buffer);
        compressor.process (buffer); phaser.process (buffer); distortion.process (buffer);
        for (int channel = 0; channel < buffer.getNumChannels(); ++channel)
            for (int i = 0; i < buffer.getNumSamples(); ++i)
            {
                const float sample = buffer.getSample (channel, i);
                if (! std::isfinite (sample)) return false;
                peak = juce::jmax (peak, std::abs (sample));
                sumSquares += static_cast<double> (sample) * sample;
                sum += sample;
                ++sampleCount;
            }
    }
    rms = sampleCount > 0 ? static_cast<float> (std::sqrt (sumSquares / sampleCount)) : 0.0f;
    dc = sampleCount > 0 ? static_cast<float> (sum / sampleCount) : 0.0f;
    return std::isfinite (rms) && std::isfinite (peak) && std::isfinite (dc);
}

bool testFactoryBankAudio ()
{
    const auto presets = salek::giti::makePresets();
    float minRmsDb = 0.0f, maxRmsDb = -200.0f, maxPeak = 0.0f, maxAbsDc = 0.0f;
    std::size_t audibleCount = 0;
    for (const auto& preset : presets)
    {
        float rms = 0.0f, peak = 0.0f, dc = 0.0f;
        if (! require (renderFactoryPreset (preset, rms, peak, dc), "GITI patch renders finite audio")) return false;
        if (! require (peak < 8.0f, "GITI patch render remains below the safety bound")) return false;
        if (rms > 1.0e-6f) ++audibleCount;
        const float rmsDb = juce::Decibels::gainToDecibels (rms, -120.0f);
        minRmsDb = juce::jmin (minRmsDb, rmsDb);
        maxRmsDb = juce::jmax (maxRmsDb, rmsDb);
        maxPeak = juce::jmax (maxPeak, peak);
        maxAbsDc = juce::jmax (maxAbsDc, std::abs (dc));
    }
    if (! require (audibleCount == presets.size(), "all 250 GITI variants produce audible audio")) return false;
    std::cout << "GITI bank render: " << audibleCount << "/" << presets.size()
              << " finite; RMS " << minRmsDb << " to " << maxRmsDb
              << " dBFS, peak <= " << maxPeak << ", |DC| <= " << maxAbsDc << '\n';
    return true;
}

bool testThisIsSalekBank ()
{
    const auto presets = salek::thisIsSalek::makePresets();
    if (! require (presets.size() == 90, "This Is Salek contains exactly 90 presets")) return false;
    std::set<std::string> names;
    std::size_t audibleCount = 0;
    for (const auto& preset : presets)
    {
        if (! require (preset.name.startsWith ("THIS IS SALEK/"), "new presets have their own browser category")) return false;
        if (! require (names.insert (preset.name.toStdString()).second, "This Is Salek preset names are unique")) return false;
        for (const auto& [id, value] : preset.values)
        {
            juce::ignoreUnused (id);
            if (! require (std::isfinite (value), "This Is Salek parameter values are finite")) return false;
        }
        float rms = 0.0f, peak = 0.0f, dc = 0.0f;
        if (! require (renderFactoryPreset (preset, rms, peak, dc), "This Is Salek patch renders finite audio")) return false;
        if (! require (peak < 8.0f, "This Is Salek patch remains below the safety bound")) return false;
        if (rms > 1.0e-6f) ++audibleCount;
    }
    if (! require (audibleCount == presets.size(), "all 90 This Is Salek presets produce audible audio")) return false;
    std::cout << "This Is Salek render: " << audibleCount << "/" << presets.size() << " finite and audible\n";
    return true;
}

bool testNeutralBypassAndCrossfades ()
{
    constexpr int blockSize = 128;
    juce::AudioBuffer<float> dry (2, blockSize);
    for (int channel = 0; channel < dry.getNumChannels(); ++channel)
        for (int i = 0; i < blockSize; ++i)
            dry.setSample (channel, i, 0.17f * std::sin (0.07f * i + 0.3f * channel));

    juce::AudioBuffer<float> original (2, blockSize);
    original.makeCopyOf (dry);
    salek::SimpleDistortion distortion;
    distortion.prepare (48000.0, blockSize);
    distortion.setDrive (0.8f);
    distortion.setBitcrush (0.7f);
    distortion.setMode (4);
    distortion.setMix (0.0f);
    distortion.process (dry);
    for (int channel = 0; channel < dry.getNumChannels(); ++channel)
        for (int i = 0; i < blockSize; ++i)
            if (! require (dry.getSample (channel, i) == original.getSample (channel, i),
                           "distortion mix zero is exact dry bypass")) return false;

    distortion.setMix (1.0f);
    juce::AudioBuffer<float> transition (2, blockSize);
    transition.clear();
    transition.addSample (0, 0, 0.2f);
    transition.addSample (1, 0, 0.2f);
    for (int channel = 0; channel < transition.getNumChannels(); ++channel)
        for (int i = 1; i < blockSize; ++i)
            transition.setSample (channel, i, 0.2f);
    distortion.process (transition);
    if (! require (std::abs (transition.getSample (0, 0) - 0.2f) < 0.01f,
                   "distortion enable fades in without a sample jump")) return false;

    salek::SimpleChorus chorus;
    salek::SimpleDelay delay;
    salek::SimpleReverb reverb;
    salek::SimplePhaser phaser;
    salek::SimpleCompressor compressor;
    chorus.prepare (48000.0, blockSize);
    delay.prepare (48000.0, blockSize);
    reverb.prepare (48000.0, blockSize);
    phaser.prepare (48000.0, blockSize);
    compressor.prepare (48000.0, blockSize);

    juce::AudioBuffer<float> neutralFx (2, blockSize);
    neutralFx.makeCopyOf (original);
    chorus.process (neutralFx);
    delay.process (neutralFx);
    reverb.process (neutralFx);
    phaser.process (neutralFx);
    compressor.process (neutralFx);
    for (int channel = 0; channel < neutralFx.getNumChannels(); ++channel)
        for (int i = 0; i < blockSize; ++i)
            if (! require (neutralFx.getSample (channel, i) == original.getSample (channel, i),
                           "zero-mix chorus/delay/reverb/phaser/compressor are dry bypass")) return false;

    chorus.setMix (1.0f);
    delay.setMix (1.0f);
    reverb.setMix (1.0f);
    phaser.setMix (1.0f);
    compressor.setMix (1.0f);

    juce::AudioBuffer<float> enableBuffer (2, blockSize);
    enableBuffer.clear();
    for (int channel = 0; channel < enableBuffer.getNumChannels(); ++channel)
        for (int i = 0; i < blockSize; ++i)
            enableBuffer.setSample (channel, i, 0.2f);

    chorus.process (enableBuffer);
    if (! require (std::abs (enableBuffer.getSample (0, 0) - 0.2f) < 0.01f,
                   "chorus enable fades in without a sample jump")) return false;
    enableBuffer.clear();
    for (int channel = 0; channel < enableBuffer.getNumChannels(); ++channel)
        for (int i = 0; i < blockSize; ++i) enableBuffer.setSample (channel, i, 0.2f);
    delay.process (enableBuffer);
    if (! require (std::abs (enableBuffer.getSample (0, 0) - 0.2f) < 0.01f,
                   "delay enable fades in without a sample jump")) return false;
    enableBuffer.clear();
    for (int channel = 0; channel < enableBuffer.getNumChannels(); ++channel)
        for (int i = 0; i < blockSize; ++i) enableBuffer.setSample (channel, i, 0.2f);
    reverb.process (enableBuffer);
    if (! require (std::abs (enableBuffer.getSample (0, 0) - 0.2f) < 0.01f,
                   "reverb enable fades in without a sample jump")) return false;
    enableBuffer.clear();
    for (int channel = 0; channel < enableBuffer.getNumChannels(); ++channel)
        for (int i = 0; i < blockSize; ++i) enableBuffer.setSample (channel, i, 0.2f);
    phaser.process (enableBuffer);
    if (! require (std::abs (enableBuffer.getSample (0, 0) - 0.2f) < 0.01f,
                   "phaser enable fades in without a sample jump")) return false;
    enableBuffer.clear();
    for (int channel = 0; channel < enableBuffer.getNumChannels(); ++channel)
        for (int i = 0; i < blockSize; ++i) enableBuffer.setSample (channel, i, 0.2f);
    compressor.setThresholdDb (-40.0f);
    compressor.setRatio (20.0f);
    compressor.process (enableBuffer);
    return require (std::abs (enableBuffer.getSample (0, 0) - 0.2f) < 0.01f,
                    "compressor enable fades in without a sample jump");
}

bool testFilterLevelAndSafety ()
{
    const auto clean = measureLowPass (0.0f, 0.0f);
    const auto resonant = measureLowPass (0.9f, 0.0f);
    const auto driven = measureLowPass (0.0f, 0.75f);
    constexpr float expectedRms = 0.0707107f;
    if (! require (std::abs (clean.rms - expectedRms) < 0.0015f,
                   "zero-drive filter preserves passband level")) return false;
    if (! require (std::abs (resonant.rms - expectedRms) < 0.0020f,
                   "filter resonance does not add broadband gain")) return false;
    if (! require (driven.rms <= clean.rms * 1.01f,
                   "filter drive does not raise low-level output gain")) return false;
    if (! require (std::abs (clean.mean) < 1.0e-4f && std::abs (resonant.mean) < 1.0e-4f,
                   "filter passband has negligible DC offset")) return false;
    if (! require (clean.peak < 0.11f && resonant.peak < 0.11f,
                   "filter resonance sweep remains bounded")) return false;

    salek::StateVariableFilter allPass;
    allPass.prepare (48000.0);
    allPass.setMode (salek::StateVariableFilter::Mode::AllPass);
    allPass.setCutoff (1000.0f);
    allPass.setResonance (0.2f);
    double allPassSquares = 0.0;
    int measured = 0;
    for (int i = 0; i < 48000; ++i)
    {
        const float input = 0.1f * std::sin (juce::MathConstants<float>::twoPi
                                             * 1000.0f * static_cast<float> (i) / 48000.0f);
        const float output = allPass.process (input);
        if (i > 4096) { allPassSquares += static_cast<double> (output) * output; ++measured; }
    }
    const float allPassRms = static_cast<float> (std::sqrt (allPassSquares / measured));
    if (! require (std::abs (allPassRms - expectedRms) < 0.002f,
                   "all-pass mode preserves signal magnitude")) return false;
    return true;
}

std::vector<float> renderSingleOscillator (int totalSamples, int mode, float detuneCents,
                                           float glide, int nextNoteAt = -1, int nextNote = 0,
                                           int pitchWheelAt = -1, int pitchWheelValue = 8192)
{
    constexpr double sampleRate = 48000.0;
    constexpr int blockSize = 128;
    salek::SynthEngine synth;
    synth.prepareToPlay (sampleRate, blockSize);
    synth.setOsc1Level (1.0f); synth.setOsc2Level (0.0f); synth.setOsc3Level (0.0f);
    synth.setOsc1TablePos (0.0f); synth.setOsc1Unison (1, 0.0f, 0.0f);
    synth.setOsc1Detune (detuneCents);
    synth.setFilterCutoff (20000.0f); synth.setFilterResonance (0.0f);
    synth.setFilterMode (0); synth.setFilterRoute (0);
    synth.setNoiseLevel (0.0f); synth.setSubLevel (0.0f);
    synth.setAmpAttack (0.001f); synth.setAmpDecay (0.001f); synth.setAmpSustain (1.0f);
    synth.setAmpRelease (0.01f); synth.setGlide (glide); synth.setVoiceMode (mode, 1);

    std::vector<float> rendered (static_cast<size_t> (totalSamples));
    juce::AudioBuffer<float> buffer (2, blockSize);
    juce::MidiBuffer midi;
    for (int start = 0; start < totalSamples; start += blockSize)
    {
        const int count = juce::jmin (blockSize, totalSamples - start);
        buffer.clear();
        if (start == 0) midi.addEvent (juce::MidiMessage::noteOn (1, 69, 1.0f), 0);
        if (nextNoteAt >= start && nextNoteAt < start + count)
            midi.addEvent (juce::MidiMessage::noteOn (1, nextNote, 1.0f), nextNoteAt - start);
        if (pitchWheelAt >= start && pitchWheelAt < start + count)
            midi.addEvent (juce::MidiMessage::pitchWheel (1, pitchWheelValue), pitchWheelAt - start);
        synth.processBlock (buffer, midi);
        midi.clear();
        for (int i = 0; i < count; ++i)
            rendered[static_cast<size_t> (start + i)] = buffer.getSample (0, i);
    }
    return rendered;
}

float estimatePositiveCrossingFrequency (const std::vector<float>& audio, int start, int count,
                                         double sampleRate)
{
    float first = 0.0f, previous = 0.0f;
    int crossings = 0;
    for (int i = start; i < start + count - 1; ++i)
    {
        const float a = audio[static_cast<size_t> (i)];
        const float b = audio[static_cast<size_t> (i + 1)];
        if (a <= 0.0f && b > 0.0f)
        {
            const float crossing = static_cast<float> (i) + (-a / (b - a));
            if (crossings == 0) first = crossing;
            previous = crossing;
            ++crossings;
        }
    }
    if (crossings < 2) return 0.0f;
    return static_cast<float> ((crossings - 1) * sampleRate / (previous - first));
}

bool testPitchGlideAndHighPass24 ()
{
    constexpr double sampleRate = 48000.0;
    constexpr int noteStart = static_cast<int> (sampleRate * 0.25);
    const auto base = renderSingleOscillator (static_cast<int> (sampleRate * 0.9), 0, 0.0f, 0.0f);
    const auto detuned = renderSingleOscillator (static_cast<int> (sampleRate * 0.9), 0, 50.0f, 0.0f);
    const auto bent = renderSingleOscillator (static_cast<int> (sampleRate * 0.9), 0, 0.0f, 0.0f,
                                               -1, 0, noteStart, 16383);
    constexpr int measureStart = static_cast<int> (sampleRate * 0.55);
    constexpr int measureCount = 4096;
    const float baseHz = estimatePositiveCrossingFrequency (base, measureStart, measureCount, sampleRate);
    const float detuneHz = estimatePositiveCrossingFrequency (detuned, measureStart, measureCount, sampleRate);
    const float bendHz = estimatePositiveCrossingFrequency (bent, measureStart, measureCount, sampleRate);
    if (! require (std::abs (baseHz - 440.0f) < 2.0f, "A4 oscillator pitch tracks MIDI note 69")) return false;
    if (! require (detuneHz > baseHz + 10.0f, "oscillator detune control changes its audible pitch")) return false;
    if (! require (bendHz > baseHz * 1.11f && bendHz < baseHz * 1.14f,
                   "MIDI pitch wheel bends the active voice by its configured range")) return false;

    const auto gliding = renderSingleOscillator (static_cast<int> (sampleRate * 2.0), 1, 0.0f, 0.8f,
                                                  noteStart, 81);
    const float glideEarly = estimatePositiveCrossingFrequency (gliding, noteStart + 2048, 4096, sampleRate);
    const float glideLate = estimatePositiveCrossingFrequency (gliding, static_cast<int> (sampleRate * 1.65),
                                                                4096, sampleRate);
    if (! require (glideEarly > 455.0f && glideEarly < 760.0f,
                   "mono glide moves smoothly between held-note pitches")) return false;
    if (! require (glideLate > 850.0f && glideLate < 910.0f,
                   "mono glide reaches the new note pitch")) return false;

    const auto legato = renderSingleOscillator (static_cast<int> (sampleRate * 2.0), 2, 0.0f, 0.8f,
                                                 noteStart, 81);
    const float legatoEarly = estimatePositiveCrossingFrequency (legato, noteStart + 2048, 4096, sampleRate);
    const float legatoLate = estimatePositiveCrossingFrequency (legato, static_cast<int> (sampleRate * 1.65),
                                                                 4096, sampleRate);
    if (! require (legatoEarly > 455.0f && legatoEarly < 760.0f
                   && legatoLate > 850.0f && legatoLate < 910.0f,
                   "legato mode keeps the held voice and glides to the next note")) return false;

    salek::StateVariableFilter lowFilter, highFilter;
    lowFilter.prepare (sampleRate); highFilter.prepare (sampleRate);
    lowFilter.setMode (salek::StateVariableFilter::Mode::HighPass24);
    highFilter.setMode (salek::StateVariableFilter::Mode::HighPass24);
    lowFilter.setCutoff (500.0f); highFilter.setCutoff (500.0f);
    double lowEnergy = 0.0, highEnergy = 0.0;
    for (int i = 0; i < 48000; ++i)
    {
        const float time = static_cast<float> (i / sampleRate);
        const float low = lowFilter.process (std::sin (juce::MathConstants<float>::twoPi * 80.0f * time));
        const float high = highFilter.process (std::sin (juce::MathConstants<float>::twoPi * 8000.0f * time));
        if (i > 4096)
        {
            lowEnergy += static_cast<double> (low) * low;
            highEnergy += static_cast<double> (high) * high;
        }
    }
    return require (highEnergy > lowEnergy * 100.0,
                    "24 dB high-pass uses two stable filter stages and preserves high frequencies");
}

bool testMagicPreRollCapture ()
{
    constexpr double sampleRate = 48000.0;
    constexpr int blockSize = 128;
    salek::MagicEngine magic;
    magic.prepare (sampleRate, blockSize);
    juce::AudioBuffer<float> buffer (2, blockSize);

    // Prime the plug-in with a tone while Magic is bypassed. Loop/Freeze should
    // capture this recent signal as soon as the mode is enabled.
    for (int block = 0; block < 375; ++block)
    {
        for (int i = 0; i < blockSize; ++i)
        {
            const int sample = block * blockSize + i;
            const float value = 0.3f * std::sin (juce::MathConstants<float>::twoPi
                                                  * 440.0f * (float) sample / (float) sampleRate);
            buffer.setSample (0, i, value);
            buffer.setSample (1, i, value);
        }
        magic.process (buffer);
    }

    magic.setMode (0);
    magic.setXY (0.5f, 0.5f);
    magic.setActive (true);
    buffer.clear();
    magic.process (buffer);
    double sumSquares = 0.0;
    for (int i = 0; i < blockSize; ++i)
    {
        const float left = buffer.getSample (0, i);
        if (! require (std::isfinite (left), "Magic loop capture remains finite")) return false;
        sumSquares += static_cast<double> (left) * left;
    }
    const float rms = static_cast<float> (std::sqrt (sumSquares / blockSize));
    return require (rms > 0.05f, "Magic Loop/Freeze captures the live pre-roll after bypass");
}

bool testIndependentDelayTimes ()
{
    constexpr double sampleRate = 48000.0;
    constexpr int blockSize = 128;
    salek::SimpleDelay delay;
    delay.prepare (sampleRate, blockSize);
    delay.setMix (1.0f); delay.setFeedback (0.0f); delay.setTone (1.0f);
    delay.setTimeMsL (50.0f); delay.setTimeMsR (75.0f);

    juce::AudioBuffer<float> warmup (2, blockSize);
    for (int i = 0; i < 400; ++i)
    {
        warmup.clear();
        delay.process (warmup);
    }
    delay.reset();

    constexpr int renderLength = 5000;
    juce::AudioBuffer<float> impulse (2, renderLength);
    impulse.clear();
    impulse.setSample (0, 0, 1.0f); impulse.setSample (1, 0, 1.0f);
    delay.process (impulse);
    int firstLeft = -1, firstRight = -1;
    for (int i = 0; i < renderLength; ++i)
    {
        if (firstLeft < 0 && std::abs (impulse.getSample (0, i)) > 1.0e-3f) firstLeft = i;
        if (firstRight < 0 && std::abs (impulse.getSample (1, i)) > 1.0e-3f) firstRight = i;
    }
    return require (std::abs (firstLeft - 2400) <= 1 && std::abs (firstRight - 3600) <= 1,
                    "independent delay L/R controls set the actual stereo echo times");
}

bool testCompressorMakeupRange ()
{
    salek::SimpleCompressor compressor;
    compressor.prepare (48000.0, 48000);
    compressor.setMix (1.0f); compressor.setThresholdDb (0.0f);
    compressor.setRatio (1.0f); compressor.setDepth (1.0f); compressor.setMakeupDb (24.0f);
    juce::AudioBuffer<float> buffer (2, 48000);
    buffer.clear();
    for (int i = 0; i < buffer.getNumSamples(); ++i)
    {
        buffer.setSample (0, i, 0.01f);
        buffer.setSample (1, i, 0.01f);
    }
    compressor.process (buffer);
    double squares = 0.0;
    constexpr int tailSamples = 1024;
    for (int i = buffer.getNumSamples() - tailSamples; i < buffer.getNumSamples(); ++i)
        squares += static_cast<double> (buffer.getSample (0, i)) * buffer.getSample (0, i);
    const float rms = static_cast<float> (std::sqrt (squares / tailSamples));
    return require (rms > 0.15f && rms < 0.17f,
                    "compressor supports the full documented +24 dB makeup range");
}

bool testTailEstimate ()
{
    const auto dry = salek::estimateEffectTailSeconds (0.0f, 280.0f, 0.35f,
                                                        0.0f, 0.0f, 0.55f, 0.25f);
    const auto maxDelay = salek::estimateEffectTailSeconds (1.0f, 800.0f, 0.95f,
                                                             0.0f, 0.0f, 0.55f, 0.22f);
    const auto longReverb = salek::estimateEffectTailSeconds (0.0f, 280.0f, 0.35f,
                                                               0.0f, 1.0f, 0.95f, 0.22f);
    if (! require (std::abs (dry - 0.25) < 1.0e-6, "dry FX report only the amp release")) return false;
    if (! require (maxDelay > 110.0 && maxDelay < 120.0, "maximum delay tail is reported accurately")) return false;
    return require (longReverb > 8.5 && longReverb < 9.0,
                    "long reverb tail is not truncated by a two-second report");
}

bool testCommonAudioConfigurations ()
{
    static constexpr double sampleRates[] = { 44100.0, 48000.0, 96000.0 };
    static constexpr int blockSizes[] = { 32, 128, 512 };
    for (const auto sampleRate : sampleRates)
    {
        for (const auto blockSize : blockSizes)
        {
            salek::SimpleChorus chorus;
            salek::SimpleDelay delay;
            salek::SimpleReverb reverb;
            salek::SimpleCompressor compressor;
            salek::SimpleDistortion distortion;
            chorus.prepare (sampleRate, blockSize);
            delay.prepare (sampleRate, blockSize);
            reverb.prepare (sampleRate, blockSize);
            compressor.prepare (sampleRate, blockSize);
            distortion.prepare (sampleRate, blockSize);
            chorus.setMix (0.55f); chorus.setDepth (0.8f); chorus.setRate (0.7f);
            delay.setMix (0.35f); delay.setTimeMs (380.0f); delay.setFeedback (0.75f);
            reverb.setMix (0.28f); reverb.setSize (0.7f); reverb.setDecay (0.7f);
            compressor.setMix (0.3f); compressor.setThresholdDb (-18.0f); compressor.setRatio (3.0f);
            distortion.setMix (0.18f); distortion.setDrive (0.25f); distortion.setMode (0);

            juce::AudioBuffer<float> buffer (2, blockSize);
            const int numBlocks = static_cast<int> (std::ceil (sampleRate * 0.1 / blockSize));
            for (int block = 0; block < numBlocks; ++block)
            {
                for (int i = 0; i < blockSize; ++i)
                {
                    const auto sample = static_cast<float> (block * blockSize + i);
                    const float in = 0.2f * std::sin (juce::MathConstants<float>::twoPi
                                                       * 220.0f * sample / static_cast<float> (sampleRate));
                    buffer.setSample (0, i, in);
                    buffer.setSample (1, i, in * 0.93f);
                }
                chorus.process (buffer);
                delay.process (buffer);
                reverb.process (buffer);
                compressor.process (buffer);
                distortion.process (buffer);
                for (int channel = 0; channel < buffer.getNumChannels(); ++channel)
                    for (int i = 0; i < blockSize; ++i)
                    {
                        const float sample = buffer.getSample (channel, i);
                        if (! require (std::isfinite (sample) && std::abs (sample) < 8.0f,
                                       "FX chain stays finite at common rates and blocks")) return false;
                    }
            }
        }
    }
    return true;
}
} // namespace

int main()
{
    if (! testFactoryBank()
        || ! testFactoryBankAudio()
        || ! testThisIsSalekBank()
        || ! testNeutralBypassAndCrossfades()
        || ! testFilterLevelAndSafety()
        || ! testPitchGlideAndHighPass24()
        || ! testMagicPreRollCapture()
        || ! testIndependentDelayTimes()
        || ! testCompressorMakeupRange()
        || ! testTailEstimate()
        || ! testCommonAudioConfigurations())
        return 1;

    std::cout << "GITI audio self-test: PASS (250 GITI + 90 This Is Salek presets, pitch/detune, Mono+Legato glide, Magic pre-roll, stereo delay timing, filters, FX bypass/fades, tails, 3 sample rates x 3 block sizes)\n";
    return 0;
}
