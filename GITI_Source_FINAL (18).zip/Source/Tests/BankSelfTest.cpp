// GITI bank self-test: decrypts each .gitibank and checks structure. Run: GITI_BANK_SELFTEST <file.gitibank> ...
#include <juce_core/juce_core.h>
#include "../GitiVault.h"
#include <cmath>
#include <set>

int main (int argc, char** argv)
{
    int failures = 0;
    for (int a = 1; a < argc; ++a)
    {
        const juce::File f (argv[a]);
        juce::MemoryBlock raw, plain;
        auto fail = [&] (const char* why) { ++failures; std::printf ("FAIL  %s : %s\n", argv[a], why); };
        if (! f.loadFileAsData (raw)) { fail ("cannot read file"); continue; }
        if (! giti::vault::decrypt (raw.getData(), raw.getSize(), plain, {})) { fail ("decrypt / integrity check failed"); continue; }
        auto xml = juce::XmlDocument::parse (plain.toString());
        if (xml == nullptr || ! xml->hasTagName ("SALEK_USER_PRESETS")) { fail ("bad XML root"); continue; }
        int presets = 0, badValues = 0; std::set<juce::String> names; bool emptyName = false, dupName = false;
        for (auto* p : xml->getChildIterator())
        {
            if (! p->hasTagName ("PRESET")) continue;
            ++presets;
            const auto n = p->getStringAttribute ("name");
            if (n.trim().isEmpty()) emptyName = true;
            if (names.count (n)) dupName = true;
            names.insert (n);
            for (auto* c : p->getChildIterator())
                if (c->hasTagName ("PARAM"))
                {
                    const double v = c->getDoubleAttribute ("value");
                    if (! std::isfinite (v) || std::fabs (v) > 1.0e6) ++badValues;
                }
        }
        if (presets == 0) fail ("no presets inside");
        if (emptyName) fail ("a preset has an empty name");
        if (dupName) fail ("duplicate preset names");
        if (badValues) { std::printf ("     %d parameter values are not finite / out of range\n", badValues); fail ("bad parameter values"); }
        if (presets > 0 && ! emptyName && ! dupName && badValues == 0)
            std::printf ("PASS  %s : %d presets\n", argv[a], presets);
    }
    std::printf (failures == 0 ? "ALL BANK TESTS PASSED\n" : "%d BANK TEST FAILURE(S)\n", failures);
    return failures == 0 ? 0 : 1;
}
