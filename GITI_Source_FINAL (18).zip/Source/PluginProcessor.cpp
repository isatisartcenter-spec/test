#include <cmath>
#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "PluginProcessorVault.inl"
#include "PluginProcessorRandom.inl"
#include "PluginProcessorExtras.inl"
#include "PluginProcessor_full_p1.inl"
#include "PluginProcessor_full_p2.inl"
#include "FX/EffectTailEstimate.h"

double SalekHightechAudioProcessor::getTailLengthSeconds() const
{
    const auto value = [this] (const char* id, float fallback) noexcept
    {
        if (const auto* parameter = apvts.getRawParameterValue (id))
            return parameter->load (std::memory_order_relaxed);
        return fallback;
    };

    const float spaceScale = 0.5f + value ("macro2", 0.5f);
    const float widthScale = 0.5f + value ("macro4", 0.5f);
    const float delayMix = juce::jlimit (0.0f, 1.0f,
        value ("delay_mix", 0.0f) * spaceScale
        + modMatrix.getModulation (salek::ModMatrix::Dest::DelayMix) );
    const float chorusMix = juce::jlimit (0.0f, 1.0f,
        value ("chorus_mix", 0.0f) * widthScale
        + modMatrix.getModulation (salek::ModMatrix::Dest::ChorusMix) );
    const float reverbMix = juce::jlimit (0.0f, 1.0f,
        value ("reverb_mix", 0.0f) * spaceScale
        + modMatrix.getModulation (salek::ModMatrix::Dest::ReverbMix) );

    return salek::estimateEffectTailSeconds (delayMix, value ("delay_time", 280.0f),
        value ("delay_fb", 0.35f), chorusMix, reverbMix, value ("reverb_decay", 0.55f),
        value ("amp_release", 0.22f));
}
