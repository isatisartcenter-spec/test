#pragma once
// Extra state saved beside the mod matrix (inside its MOD_MATRIX element, as an EXTRAS child):
// the 16-step pattern and the 256-point custom shape of LFO 1, 2 and 3. Presets, banks, project state and
// exports all carry the MOD_MATRIX element, so they all carry these too.
