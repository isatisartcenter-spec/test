#pragma once
#include <JuceHeader.h>
#include <cmath>
#include <array>
#include <atomic>
namespace salek {
class LFO {
public:
    enum class Wave { Sine, Triangle, Saw, Square, SAndH, Custom, SmoothRnd, Chaos, Pulse, Exp, Sine3, SoftSquare };
    static constexpr int TableSize = 256;   // 256-point custom shape (was 32): smoother curves, exact step edges
    static constexpr int NumShapes = 32;

    LFO() noexcept
    {
        for (auto& point : customTable)
            point.store (0.0f, std::memory_order_relaxed);
    }

    void prepare(double sampleRate){ sr=sampleRate>0?sampleRate:44100; phase=0; if (! tableInit) { loadPresetShape(0); tableInit=true; } envSamples=1.0e9; smoothed=0.f; updateInc(); }
    void reset() noexcept { phase=0; lastSH=0; }
    void setRate(float hz) noexcept { rate=juce::jlimit(0.01f,160.f,hz); updateInc(); }
    // ---- tempo sync / shaping / envelope (all optional; defaults = old behaviour) ----
    void setSync (bool on) noexcept { sync = on; updateInc(); }
    void setTempo (double bpmIn) noexcept { bpm = juce::jlimit (20.0, 400.0, bpmIn); updateInc(); }
    void setDivision (int idx) noexcept
    {
        static const double beats[] = { 16.0, 8.0, 4.0, 2.0, 1.0, 0.5, 0.25, 0.125, 2.0/3.0, 1.0/3.0, 1.0/6.0, 1.5 };
        beatsPerCycle = beats[juce::jlimit (0, 11, idx)]; updateInc();
    }
    static const char* divisionName (int idx) noexcept
    {
        static const char* n[] = { "4/1","2/1","1/1","1/2","1/4","1/8","1/16","1/32","1/2T","1/4T","1/8T","1/4." };
        return n[juce::jlimit (0, 11, idx)];
    }
    void setSmooth (float v) noexcept { const float x = juce::jlimit (0.f, 1.f, v); smoothTau = x * x * 0.6f; }   // up to 0.6 s
    void setRise   (float v) noexcept { riseSec  = juce::jlimit (0.f, 1.f, v) * 5.f; }
    void setDelay  (float v) noexcept { delaySec = juce::jlimit (0.f, 1.f, v) * 2.f; }
    void setPhaseOffset (float v) noexcept { phaseOff = (double) juce::jlimit (0.f, 1.f, v); }
    void setBipolar (bool b) noexcept { bipolar = b; }
    void setSteps (int n) noexcept { steps = juce::jlimit (0, 16, n); }
    // UI read-outs (benign unsynchronised reads, display only)
    float getLastOut() const noexcept { return lastOut.load (std::memory_order_relaxed); }
    float getPlayPosition() const noexcept { return (float) std::fmod (phasePub.load (std::memory_order_relaxed) + phaseOff, 1.0); }
    int   getSteps() const noexcept { return steps.load (std::memory_order_relaxed); }
    bool  isBipolar() const noexcept { return bipolar.load (std::memory_order_relaxed); }
    void retrigger() noexcept { phase = 0; envSamples = 0.0; lastSH = 0; }

    void setWave(Wave w) noexcept { wave.store (w, std::memory_order_relaxed); }
    void setAmount(float a) noexcept { amount=juce::jlimit(0.f,1.f,a); }
    void setCustomPoint (int i, float v) noexcept
    {
        if (i >= 0 && i < TableSize)
            customTable[(size_t) i].store (juce::jlimit (-1.f, 1.f, v), std::memory_order_relaxed);
    }
    float getCustomPoint (int i) const noexcept
    {
        return (i >= 0 && i < TableSize) ? customTable[(size_t) i].load (std::memory_order_relaxed) : 0.f;
    }
    std::array<float, TableSize> getTableSnapshot() const noexcept
    {
        std::array<float, TableSize> result {};
        for (int i = 0; i < TableSize; ++i)
            result[(size_t) i] = customTable[(size_t) i].load (std::memory_order_relaxed);
        return result;
    }

    static const char* shapeName (int preset) noexcept
    {
        static const char* names[32] = {
            "Sine","Triangle","Saw Up","Saw Down","Square","Pulse 25","Pulse 12","Exp Rise",
            "Exp Fall","Log Rise","Bell","Wobble","3-Step","Gate Sweep","Soft Curve","Spike Train",
            "Sine x3","AM Sine","Rectified","Tent","Soft Sine","Late Ramp","Half Ramp","Dying Wobble",
            "3-State","Harmonic","Folded Saw","Cosine x2","Blip","Saturated","Pattern","FM Curve"
        };
        return names[((preset % 32) + 32) % 32];
    }

    void loadPresetShape (int preset) noexcept
    {
        const float twoPi = juce::MathConstants<float>::twoPi;
        preset = ((preset % 32) + 32) % 32;
        for (int i = 0; i < TableSize; ++i)
        {
            float t = (float) i / (float) (TableSize - 1);
            float v = 0.f;
            switch (preset)
            {
                case 0:  v = std::sin (t * twoPi); break;
                case 1:  v = 1.f - 4.f * std::abs (t - 0.5f); break;
                case 2:  v = 2.f * t - 1.f; break;
                case 3:  v = 1.f - 2.f * t; break;
                case 4:  v = t < 0.5f ? 1.f : -1.f; break;
                case 5:  v = t < 0.25f ? 1.f : -1.f; break;
                case 6:  v = t < 0.12f ? 1.f : -1.f; break;
                case 7:  v = 2.f * (1.f - std::exp (-4.f * t)) - 1.f; break;
                case 8:  v = 2.f * std::exp (-4.f * t) - 1.f; break;
                case 9:  v = 2.f * std::log (1.f + 9.f * t) / std::log (10.f) - 1.f; break;
                case 10: v = 0.5f - 0.5f * std::cos (t * twoPi); break;
                case 11: v = std::sin (t * twoPi * 2.f) * (1.f - 0.35f * t); break;
                case 12: v = (i % 3 == 0) ? 1.f : ((i % 3 == 1) ? -0.6f : 0.15f); break;
                case 13: v = t < 0.15f ? (t / 0.15f) * 2.f - 1.f
                         : (t < 0.7f ? 1.f : 1.f - (t - 0.7f) / 0.3f * 2.f); break;
                case 14: v = std::tanh ((t - 0.5f) * 6.f); break;
                case 15: v = (i == 2 || i == 9 || i == 13) ? 1.f : ((i == 5 || i == 11) ? -1.f : 0.f); break;
                case 16: v = std::sin (t * twoPi * 3.f); break;
                case 17: v = std::sin (t * twoPi) * std::sin (t * twoPi * 2.f); break;
                case 18: v = std::abs (std::sin (t * twoPi)) * 2.f - 1.f; break;
                case 19: v = t < 0.5f ? 2.f * t : 2.f - 2.f * t; break;
                case 20: v = std::sin (std::pow (t, 0.4f) * twoPi); break;
                case 21: v = std::sin (std::pow (t, 2.2f) * twoPi); break;
                case 22: v = (t < 0.5f ? t * 2.f : 0.f) * 2.f - 1.f; break;
                case 23: v = std::sin (t * twoPi * 4.f) * (1.f - t); break;
                case 24: v = t < 0.33f ? -1.f : (t < 0.66f ? 0.f : 1.f); break;
                case 25: v = std::sin (t * twoPi) + 0.35f * std::sin (t * twoPi * 5.f); break;
                case 26: v = 2.f * std::fmod (t * 3.f, 1.f) - 1.f; break;
                case 27: v = std::cos (t * twoPi) * std::cos (t * twoPi * 0.5f); break;
                case 28: v = t < 0.08f ? 1.f : (t < 0.16f ? -1.f : 0.f); break;
                case 29: v = std::tanh (std::sin (t * twoPi * 2.f) * 3.f); break;
                case 30: v = (i % 4 == 0) ? 1.f : ((i % 4 == 2) ? -1.f : 0.f); break;
                default: v = std::sin (t * twoPi * 2.f + std::sin (t * twoPi * 3.f)); break;
            }
            customTable[(size_t) i].store (juce::jlimit (-1.f, 1.f, v), std::memory_order_relaxed);
        }
    }

    void setRandomSeed (uint32_t seed) noexcept { randomState = seed ? seed : 0xA341316Cu; }
    float nextRandom() noexcept
    {
        randomState ^= randomState << 13;
        randomState ^= randomState >> 17;
        randomState ^= randomState << 5;
        return (float) (randomState & 0x00FFFFFFu) / 16777215.0f;
    }

    float process() noexcept {
        float v=0, p=float(std::fmod(phase+phaseOff,1.0));
        switch(wave.load (std::memory_order_relaxed)){
            case Wave::Sine: v=std::sin(p*juce::MathConstants<float>::twoPi); break;
            case Wave::Triangle: v=1-4*std::abs(p-0.5f); break;
            case Wave::Saw: v=2*p-1; break;
            case Wave::Square: v=p<0.5f?1.f:-1.f; break;
            case Wave::SAndH:
                if(phase<phaseInc) lastSH=nextRandom()*2-1;
                v=lastSH; break;
            case Wave::SmoothRnd:
            {
                if (phase < phaseInc)
                {
                    lastSH2 = lastSH;
                    lastSH = nextRandom()*2-1;
                }
                float frac = (float) (phase / juce::jmax (1e-9, phaseInc));
                frac = juce::jlimit (0.f, 1.f, frac);
                frac = frac * frac * (3.f - 2.f * frac);
                v = lastSH2 * (1.f - frac) + lastSH * frac;
                break;
            }
            case Wave::Chaos:
                chaosState = 3.7f * chaosState * (1.f - chaosState);
                v = chaosState * 2.f - 1.f;
                break;
            case Wave::Pulse:
                v = p < 0.18f ? 1.f : -0.35f;
                break;
            case Wave::Exp:
                v = 2.f * (1.f - std::exp (-5.f * p)) - 1.f;
                break;
            case Wave::Sine3:
                v = std::sin (p * juce::MathConstants<float>::twoPi)
                  + 0.35f * std::sin (3.f * p * juce::MathConstants<float>::twoPi);
                v *= 0.75f;
                break;
            case Wave::SoftSquare:
            {
                float s = std::sin (p * juce::MathConstants<float>::twoPi);
                v = std::tanh (s * 4.f);
                break;
            }
            case Wave::Custom:
            {
                float idx = p * (float) (TableSize - 1);
                int i0 = juce::jlimit (0, TableSize - 1, (int) idx);
                int i1 = juce::jmin (TableSize - 1, i0 + 1);
                float f = idx - (float) i0;
                v = customTable[(size_t) i0].load (std::memory_order_relaxed) * (1.f - f)
                  + customTable[(size_t) i1].load (std::memory_order_relaxed) * f;
                break;
            }
        }
        phase+=phaseInc; if(phase>=1) phase-=1;
        phasePub.store (phase, std::memory_order_relaxed);
        return v*amount;
    }

    // The modulation matrix is evaluated once per audio block. Advance the
    // LFO through the whole block so its speed stays in Hz at every buffer size.
    float processBlock (int numSamples) noexcept
    {
        const int n = juce::jmax (1, numSamples);
        float value = 0.f;
        for (int i = 0; i < n; ++i)
            value = process();
        // 1) step quantiser: gives the hard, digital "number / bubble" staircase sound
        if (steps >= 2)
        {
            const float u = juce::jlimit (0.f, 1.f, value * 0.5f + 0.5f);
            value = std::round (u * (float) (steps - 1)) / (float) (steps - 1) * 2.f - 1.f;
        }
        // 2) smoothing (rounds off hard edges; time constant is block-size independent)
        if (smoothTau > 1.0e-4f)
        {
            const float a = 1.f - std::exp (-(float) n / ((float) sr * smoothTau));
            smoothed += (value - smoothed) * a;
            value = smoothed;
        }
        else smoothed = value;
        // 3) delay + rise (restarted by retrigger())
        float fade = 1.f;
        if (delaySec > 0.f || riseSec > 0.f)
        {
            const float tt = (float) (envSamples / sr);
            fade = tt < delaySec ? 0.f : (riseSec > 0.f ? juce::jlimit (0.f, 1.f, (tt - delaySec) / riseSec) : 1.f);
            envSamples += (double) n;
        }
        // 4) polarity
        if (! bipolar) value = 0.5f * (value + 1.f);
        lastOut = value * fade;
        return lastOut;
    }

    float getPhase() const noexcept { return (float) phase; }

private:
    double sr=44100, phase=0, phaseInc=0; float rate=1, amount=0, lastSH=0, lastSH2=0, chaosState=0.3f;
    uint32_t randomState = 0xA341316Cu;
    void updateInc() noexcept { phaseInc = sync ? (bpm / 60.0) / beatsPerCycle / sr : double (rate) / sr; }
    bool tableInit = false, sync = false;
    std::atomic<bool> bipolar { true };
    std::atomic<double> phasePub { 0.0 };   // phase copy for the display (the audio thread owns "phase")
    double bpm = 120.0, beatsPerCycle = 1.0, phaseOff = 0.0, envSamples = 1.0e9;
    float smoothTau = 0.f, riseSec = 0.f, delaySec = 0.f, smoothed = 0.f;
    std::atomic<int> steps { 0 };
    std::atomic<float> lastOut { 0.f };          // read by the UI thread
    std::atomic<Wave> wave { Wave::Sine };
    std::array<std::atomic<float>, TableSize> customTable {};
};
}
