#pragma once

#include <JuceHeader.h>
#include <array>
#include <atomic>
#include <cmath>

namespace salek
{

class ModMatrix
{
public:
    ModMatrix() noexcept
    {
        for (auto& value : sourceValues)
            value.store (0.0f, std::memory_order_relaxed);
    }

    static constexpr int MaxRoutes = 64;

    enum class Source : int
    {
        LFO1 = 0,
        LFO2,
        LFO3,
        Env1,
        Velocity,
        ModWheel,
        Macro1,
        Macro2,
        Macro3,
        Macro4,
        Macro5,
        Macro6,
        Macro7,
        Macro8,
        Random,
        PitchBend,
        Aftertouch,
        NumSources
    };

    enum class Dest : int
    {
        FilterCutoff = 0,
        FilterReso,
        Osc1Level,
        Osc2Level,
        Osc3Level,
        Osc1Table,
        Osc2Table,
        Osc3Table,
        Osc1Warp,
        Osc2Warp,
        Osc3Warp,
        Osc1Fold,
        Osc2Fold,
        Osc3Fold,
        Fm2to1,
        Fm3to1,
        Pitch,
        Amp,
        Osc1Pan,
        Osc2Pan,
        Osc3Pan,
        Osc1Drive,
        Osc2Drive,
        Osc3Drive,
        DelayMix,
        ReverbMix,
        DistDrive,
        ChorusMix,
        FilterEnv,
        PhaserMix,
        Bassify,
        MagicX,
        MagicY,
        NoiseLevel,
        SubLevel,
        DistMix,
        MasterDrive,
        FilterDrive,
        Filter2Cutoff,
        Filter2Reso,
        Filter2Drive,
        Filter1Mix,
        Filter2Mix,
        Osc1Oct, Osc2Oct, Osc3Oct, Osc1Semi, Osc2Semi, Osc3Semi, Osc1Crs, Osc2Crs, Osc3Crs,
        Osc1FineP, Osc2FineP, Osc3FineP, Osc1DetP, Osc2DetP, Osc3DetP, SubOct, SubSemi,
        Lfo1Rate, Lfo2Rate, Lfo3Rate, Lfo1Amt, Lfo2Amt, Lfo3Amt,
        Osc1UDet, Osc2UDet, Osc3UDet, DelayFb, ReverbSize,
        DelayTime, ChorusRate, ChorusDepth, PhaserRate, PhaserDepth, ReverbDecay,
        AmpAttack, AmpDecay, AmpSustain, AmpRelease, MacroMod1, MacroMod2, MacroMod3, MacroMod4, MacroMod5, MacroMod6, MacroMod7, MacroMod8,
        NumDests
    };

    static const char* sourceName (Source s)
    {
        static const char* n[] = {
            "LFO1","LFO2","LFO3","ENV","VEL","MW",
            "MAC1","MAC2","MAC3","MAC4","MAC5","MAC6","MAC7","MAC8","RND","BEND","AFT"
        };
        int i = (int) s;
        return (i >= 0 && i < (int) Source::NumSources) ? n[i] : "?";
    }

    static const char* destName (Dest d)
    {
        static const char* n[] = {
            "CUT","RESO","O1LVL","O2LVL","O3LVL",
            "O1TBL","O2TBL","O3TBL","O1WRP","O2WRP","O3WRP",
            "O1FLD","O2FLD","O3FLD","FM21","FM31","PITCH","AMP",
            "O1PAN","O2PAN","O3PAN","O1DRV","O2DRV","O3DRV",
            "DLYMX","REVMX","DIST","CHOR","FENV","PHSR","BASS","MAGX","MAGY","NOISE","SUB","DSTMX","MDRV","FDRV","F2CUT","F2RES","F2DRV","F1MIX","F2MIX"
            ,"O1OCT","O2OCT","O3OCT","O1SEMI","O2SEMI","O3SEMI","O1CRS","O2CRS","O3CRS","O1FINE","O2FINE","O3FINE","O1DET","O2DET","O3DET","SUBOCT","SUBSEMI",
            "LFO1RT","LFO2RT","LFO3RT","LFO1AM","LFO2AM","LFO3AM","O1UDET","O2UDET","O3UDET","DLYFB","REVSZ","DLYTM","CHRRT","CHRDP","PHSRT","PHSDP","REVDC","ATK","DCY","SUS","REL","MAC1M","MAC2M","MAC3M","MAC4M","MAC5M","MAC6M","MAC7M","MAC8M"
        };
        int i = (int) d;
        return (i >= 0 && i < (int) Dest::NumDests) ? n[i] : "?";
    }

    struct Route
    {
        std::atomic<Source> source { Source::LFO1 };
        std::atomic<Dest> dest { Dest::FilterCutoff };
        std::atomic<float> amount { 0.0f };
        std::atomic<bool> active { false };
        std::atomic<int>   modSrc   { -1 };     // optional 2nd source that scales this route (-1 = none)
        std::atomic<float> modDepth { 0.5f };   // how strongly modSrc scales it (0..1)
    };

    void clear() noexcept
    {
        for (auto& r : routes) r.active.store (false, std::memory_order_release);
    }

    int addRoute (Source src, Dest dst, float amount) noexcept
    {
        for (int i = 0; i < MaxRoutes; ++i)
        {
            auto& route = routes[static_cast<size_t>(i)];
            if (route.active.load (std::memory_order_acquire)
                && route.source.load (std::memory_order_relaxed) == src
                && route.dest.load (std::memory_order_relaxed) == dst)
            {
                route.amount.store (juce::jlimit (-1.0f, 1.0f, amount), std::memory_order_relaxed);
                return i;
            }
        }
        for (int i = 0; i < MaxRoutes; ++i)
        {
            auto& route = routes[static_cast<size_t>(i)];
            if (! route.active.load (std::memory_order_acquire))
            {
                route.source.store (src, std::memory_order_relaxed);
                route.dest.store (dst, std::memory_order_relaxed);
                route.amount.store (juce::jlimit (-1.0f, 1.0f, amount), std::memory_order_relaxed);
                route.modSrc.store (-1, std::memory_order_relaxed);
                route.modDepth.store (0.5f, std::memory_order_relaxed);
                route.active.store (true, std::memory_order_release);
                return i;
            }
        }
        return -1;
    }

    void removeRoute (int slot) noexcept
    {
        if (slot >= 0 && slot < MaxRoutes)
            routes[static_cast<size_t>(slot)].active.store (false, std::memory_order_release);
    }

    void removeRoute (Source src, Dest dst) noexcept
    {
        for (int i = 0; i < MaxRoutes; ++i)
        {
            auto& route = routes[static_cast<size_t>(i)];
            if (route.active.load (std::memory_order_acquire)
                && route.source.load (std::memory_order_relaxed) == src
                && route.dest.load (std::memory_order_relaxed) == dst)
                route.active.store (false, std::memory_order_release);
        }
    }

    void setSourceValue (Source s, float v) noexcept
    {
        const int index = static_cast<int> (s);
        if (index >= 0 && index < static_cast<int> (Source::NumSources))
            sourceValues[static_cast<size_t> (index)].store (v, std::memory_order_relaxed);
    }

    float getSourceValue (Source s) const noexcept
    {
        const int index = static_cast<int> (s);
        return index >= 0 && index < static_cast<int> (Source::NumSources)
            ? sourceValues[static_cast<size_t> (index)].load (std::memory_order_relaxed) : 0.0f;
    }

    float getModulation (Dest d) const noexcept
    {
        float sum = 0.0f;
        for (const auto& r : routes)
        {
            if (r.active.load (std::memory_order_acquire))
            {
                const auto source = r.source.load (std::memory_order_relaxed);
                const auto dest = r.dest.load (std::memory_order_relaxed);
                const int sourceIndex = static_cast<int> (source);
                if (dest == d && sourceIndex >= 0 && sourceIndex < static_cast<int> (Source::NumSources))
                {
                    float scale = 1.0f;
                    const int ms = r.modSrc.load (std::memory_order_relaxed);
                    if (ms >= 0 && ms < static_cast<int> (Source::NumSources))
                        scale = juce::jlimit (0.0f, 2.0f, 1.0f + r.modDepth.load (std::memory_order_relaxed)
                                                              * sourceValues[static_cast<size_t> (ms)].load (std::memory_order_relaxed));
                    sum += sourceValues[static_cast<size_t> (sourceIndex)].load (std::memory_order_relaxed)
                         * r.amount.load (std::memory_order_relaxed) * scale;
                }
            }
        }
        // Built-in macro behaviour (always active, independent of the matrix):
        //  1 BRIGHT = filter cutoff/reso   2 MOTION = wavetable warp/position
        //  3 SPACE  = reverb/delay/chorus  4 GRIT   = distortion/fold/filter drive
        struct MacroTarget { Dest d; float amt; };
        static const MacroTarget map[4][4] = {
            { { Dest::FilterCutoff, 0.55f }, { Dest::Filter2Cutoff, 0.40f }, { Dest::FilterReso, 0.12f }, { Dest::FilterCutoff, 0.f } },
            { { Dest::Osc1Warp, 0.50f },     { Dest::Osc2Warp, 0.50f },      { Dest::Osc1Table, 0.35f },  { Dest::Osc2Table, 0.35f } },
            { { Dest::ReverbMix, 0.60f },    { Dest::DelayMix, 0.45f },      { Dest::ChorusMix, 0.30f },  { Dest::ReverbMix, 0.f } },
            { { Dest::DistDrive, 0.60f },    { Dest::DistMix, 0.40f },       { Dest::Osc1Fold, 0.40f },   { Dest::FilterDrive, 0.30f } }
        };
        for (int k = 0; k < 4; ++k)
        {
            const float mv = sourceValues[static_cast<size_t> (static_cast<int> (Source::Macro1) + k)].load (std::memory_order_relaxed);
            for (const auto& t : map[k]) if (t.d == d) sum += mv * t.amt;
        }
        return sum;
    }

    const std::array<Route, MaxRoutes>& getRoutes() const noexcept { return routes; }
    Route& getRoute (int i) noexcept { return routes[static_cast<size_t>(juce::jlimit(0, MaxRoutes-1, i))]; }

    /** Serialize active routes into <MOD_MATRIX> for project/preset state. */
    std::unique_ptr<juce::XmlElement> toXml() const
    {
        auto el = std::make_unique<juce::XmlElement> ("MOD_MATRIX");
        el->setAttribute ("version", 1);
        for (int i = 0; i < MaxRoutes; ++i)
        {
            const auto& r = routes[static_cast<size_t> (i)];
            if (! r.active.load (std::memory_order_acquire)) continue;
            auto* row = el->createNewChildElement ("ROUTE");
            row->setAttribute ("src", (int) r.source.load (std::memory_order_relaxed));
            row->setAttribute ("dst", (int) r.dest.load (std::memory_order_relaxed));
            row->setAttribute ("amt", (double) r.amount.load (std::memory_order_relaxed));
            row->setAttribute ("msrc", r.modSrc.load (std::memory_order_relaxed));
            row->setAttribute ("mdepth", (double) r.modDepth.load (std::memory_order_relaxed));
        }
        return el;
    }

    /** Replace routes from <MOD_MATRIX> (or no-op if null/wrong tag). */
    void fromXml (const juce::XmlElement* el)
    {
        clear();
        if (el == nullptr || ! el->hasTagName ("MOD_MATRIX")) return;

        for (auto* row = el->getFirstChildElement(); row != nullptr; row = row->getNextElement())
        {
            if (! row->hasTagName ("ROUTE")) continue;
            const int src = row->getIntAttribute ("src", -1);
            const int dst = row->getIntAttribute ("dst", -1);
            const float amt = (float) row->getDoubleAttribute ("amt", 0.5);
            if (src < 0 || src >= (int) Source::NumSources) continue;
            if (dst < 0 || dst >= (int) Dest::NumDests) continue;
            const int idx = addRoute ((Source) src, (Dest) dst, amt);
            if (idx >= 0)
            {
                const int ms = row->getIntAttribute ("msrc", -1);
                routes[static_cast<size_t> (idx)].modSrc.store ((ms >= 0 && ms < (int) Source::NumSources) ? ms : -1, std::memory_order_relaxed);
                routes[static_cast<size_t> (idx)].modDepth.store ((float) row->getDoubleAttribute ("mdepth", 0.5), std::memory_order_relaxed);
            }
        }
    }

private:
    std::array<Route, MaxRoutes> routes {};
    std::array<std::atomic<float>, static_cast<size_t>(Source::NumSources)> sourceValues {};
};

} // namespace salek
