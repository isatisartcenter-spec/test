#pragma once
// DRAW editor: draw the CUSTOM single-cycle wavetable like the LFO shape editor (64 points, drag, presets, tools)
#include <juce_gui_basics/juce_gui_basics.h>
#include <array>
#include <cmath>

class CustomWaveEditor : public juce::Component
{
public:
    explicit CustomWaveEditor (juce::AudioProcessorValueTreeState& s) : apvts (s)
    {
        setSize (760, 330);
        static const char* names[] = { "SINE", "SAW", "SQUARE", "TRIANGLE", "SMOOTH", "INVERT", "RANDOM", "CLEAR" };
        for (int i = 0; i < 8; ++i)
        {
            auto& b = btn[i];
            b.setButtonText (names[i]);
            b.setColour (juce::TextButton::buttonColourId, juce::Colour (0xff10162e));
            b.setColour (juce::TextButton::textColourOffId, juce::Colour (0xff9fd8dc));
            addAndMakeVisible (b);
            b.onClick = [this, i] { applyTool (i); };
        }
        loadFromApvts();
    }

    void paint (juce::Graphics& g) override
    {
        g.fillAll (juce::Colour (0xff0b0d26));
        auto plot = getLocalBounds().reduced (12, 40).removeFromTop (plotH()).toFloat();
        g.setColour (juce::Colour (0xff04030c)); g.fillRoundedRectangle (plot, 6.f);
        g.setColour (juce::Colours::white.withAlpha (0.08f));
        for (int i = 1; i < 4; ++i) g.drawHorizontalLine ((int) (plot.getY() + plot.getHeight() * (float) i / 4.f), plot.getX(), plot.getRight());
        g.drawHorizontalLine ((int) plot.getCentreY(), plot.getX(), plot.getRight());
        juce::Path p;
        for (int i = 0; i < N; ++i)
        {
            const float x = plot.getX() + plot.getWidth() * (float) i / (float) (N - 1);
            const float y = yOf (plot, pts[(size_t) i]);
            if (i == 0) p.startNewSubPath (x, y); else p.lineTo (x, y);
        }
        g.setColour (juce::Colour (0xff35e6ff)); g.strokePath (p, juce::PathStrokeType (2.f));
        g.setColour (juce::Colour (0xffffc861));
        for (int i = 0; i < N; i += 4)
            g.fillEllipse (plot.getX() + plot.getWidth() * (float) i / (float) (N - 1) - 2.5f, yOf (plot, pts[(size_t) i]) - 2.5f, 5.f, 5.f);
        g.setColour (juce::Colour (0xffd5bd88)); g.setFont (juce::FontOptions (11.f, juce::Font::bold));
        g.drawText ("CUSTOM WAVETABLE  -  drag on the plot to draw  |  tools below  |  used by any oscillator set to REF 64 CUSTOM",
                    getLocalBounds().removeFromTop (22).reduced (12, 0), juce::Justification::centredLeft);
    }

    void resized() override
    {
        auto r = getLocalBounds().reduced (12, 8);
        r.removeFromTop (34 + plotH() - 34 + 6);     // plot area (painted directly)
        auto row = r.removeFromBottom (30);
        const int w = row.getWidth() / 8;
        for (int i = 0; i < 8; ++i) btn[i].setBounds (row.removeFromLeft (w).reduced (2, 0));
    }

    void mouseDown (const juce::MouseEvent& e) override { lastIdx = -1; drawAt (e.position); }
    void mouseDrag (const juce::MouseEvent& e) override { drawAt (e.position); }

private:
    static constexpr int N = 64;
    int plotH() const { return 200; }
    juce::Rectangle<float> plotRect() const { return getLocalBounds().reduced (12, 40).removeFromTop (plotH()).toFloat(); }
    static float yOf (juce::Rectangle<float> r, float v) { return r.getCentreY() - juce::jlimit (-1.f, 1.f, v) * r.getHeight() * 0.46f; }

    void drawAt (juce::Point<float> p)
    {
        auto r = plotRect();
        if (r.isEmpty()) return;
        const float fx = juce::jlimit (0.f, 1.f, (p.x - r.getX()) / r.getWidth());
        const float fy = juce::jlimit (0.f, 1.f, (p.y - r.getY()) / r.getHeight());
        const int idx = juce::jlimit (0, N - 1, (int) std::round (fx * (float) (N - 1)));
        const float v = juce::jlimit (-1.f, 1.f, (0.5f - fy) / 0.46f * 0.5f + 0.0f) ;
        const float val = juce::jlimit (-1.f, 1.f, (r.getCentreY() - p.y) / (r.getHeight() * 0.46f));
        (void) v;
        if (lastIdx < 0) { set (idx, val); }
        else
        {   // fill between the previous and the current point: the drawn line stays continuous
            const int a = lastIdx, b = idx;
            const int step = a <= b ? 1 : -1;
            for (int i = a; ; i += step)
            {
                const float t = (b == a) ? 1.f : (float) std::abs (i - a) / (float) std::abs (b - a);
                set (i, lastVal + (val - lastVal) * t);
                if (i == b) break;
            }
        }
        lastIdx = idx; lastVal = val;
        repaint();
    }

    void set (int i, float v)
    {
        pts[(size_t) i] = v;
        if (auto* p = apvts.getParameter ("custom_wt_" + juce::String (i)))
            p->setValueNotifyingHost (p->convertTo0to1 (v));
    }

    void loadFromApvts()
    {
        for (int i = 0; i < N; ++i)
            if (auto* raw = apvts.getRawParameterValue ("custom_wt_" + juce::String (i))) pts[(size_t) i] = raw->load();
        repaint();
    }

    void applyTool (int t)
    {
        loadFromApvts();
        std::array<float, N> out = pts;
        for (int i = 0; i < N; ++i)
        {
            const float x = (float) i / (float) N;
            switch (t)
            {
                case 0: out[(size_t) i] = std::sin (2.f * 3.14159265f * x); break;
                case 1: out[(size_t) i] = 2.f * x - 1.f; break;
                case 2: out[(size_t) i] = x < 0.5f ? 1.f : -1.f; break;
                case 3: out[(size_t) i] = 1.f - 4.f * std::fabs (x - 0.5f); break;
                case 4: { const float a = pts[(size_t) ((i + N - 1) % N)], b = pts[(size_t) i], c = pts[(size_t) ((i + 1) % N)]; out[(size_t) i] = 0.25f * a + 0.5f * b + 0.25f * c; break; }
                case 5: out[(size_t) i] = -pts[(size_t) i]; break;
                case 6: out[(size_t) i] = juce::Random::getSystemRandom().nextFloat() * 2.f - 1.f; break;
                default: out[(size_t) i] = 0.f; break;
            }
        }
        for (int i = 0; i < N; ++i) set (i, out[(size_t) i]);
        repaint();
    }

    juce::AudioProcessorValueTreeState& apvts;
    std::array<float, N> pts {};
    juce::TextButton btn[8];
    int lastIdx = -1;
    float lastVal = 0.f;
};
