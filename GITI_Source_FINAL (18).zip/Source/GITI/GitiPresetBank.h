#pragma once

#include "GitiIdentityBank.h"
#include <JuceHeader.h>
#include <cstring>
#include <iterator>
#include <map>
#include <utility>
#include <vector>

namespace salek::giti
{
struct Preset
{
    juce::String name;
    std::map<juce::String, float> values;
};

enum class VoiceBranch { Breath, Strings, Voice, Pulse, EarthWater };

inline VoiceBranch branchFor (const char* branch) noexcept
{
    if (branch != nullptr && std::strcmp (branch, "Strings") == 0) return VoiceBranch::Strings;
    if (branch != nullptr && std::strcmp (branch, "Voice") == 0) return VoiceBranch::Voice;
    if (branch != nullptr && std::strcmp (branch, "Pulse") == 0) return VoiceBranch::Pulse;
    if (branch != nullptr && std::strcmp (branch, "Earth & Water") == 0) return VoiceBranch::EarthWater;
    return VoiceBranch::Breath;
}

inline std::map<juce::String, float> designVoice (std::size_t identityIndex, int variation)
{
    const auto& identity = identities[identityIndex];
    const auto branch = branchFor (identity.branch);
    // GITI identities are arranged in the reference bank as ten rounds of five
    // voices: breath, strings, voice, pulse, and earth/water.
    const int voiceIndex = static_cast<int> (identityIndex / 5);
    const float voicePosition = (float) voiceIndex / 9.f;

    std::map<juce::String, float> values {
        { "osc1_level", 0.78f }, { "osc2_level", 0.22f }, { "osc3_level", 0.08f },
        { "osc1_octave", 0.f }, { "osc2_octave", 0.f }, { "osc3_octave", 0.f },
        { "osc1_semi", 0.f }, { "osc2_semi", 0.f }, { "osc3_semi", 0.f },
        { "osc1_fine", 0.f }, { "osc2_fine", 0.f }, { "osc3_fine", 0.f },
        { "osc1_table", 0.f }, { "osc2_table", 0.f }, { "osc3_table", 0.f },
        { "osc1_warp", 0.f }, { "osc2_warp", 0.f }, { "osc3_warp", 0.f },
        { "osc1_fold", 0.f }, { "osc2_fold", 0.f }, { "osc3_fold", 0.f },
        { "osc1_drive", 0.f }, { "osc2_drive", 0.f }, { "osc3_drive", 0.f },
        { "osc1_pan", 0.5f }, { "osc2_pan", 0.5f }, { "osc3_pan", 0.5f },
        { "osc1_rand", 0.025f }, { "osc2_rand", 0.015f }, { "osc3_rand", 0.f },
        { "osc1_unison", 1.f }, { "osc2_unison", 1.f }, { "osc3_unison", 1.f },
        { "osc1_udet", 0.f }, { "osc2_udet", 0.f }, { "osc3_udet", 0.f },
        { "osc1_uspread", 0.35f }, { "osc2_uspread", 0.35f }, { "osc3_uspread", 0.35f },
        { "fm_2to1", 0.f }, { "fm_3to1", 0.f }, { "fm_3to2", 0.f },
        { "pm_2to1", 0.f }, { "pm_3to1", 0.f }, { "am_2to1", 0.f }, { "rm_2to1", 0.f },
        { "filter_cutoff", 5200.f }, { "filter_reso", 0.18f }, { "filter_drive", 0.04f },
        { "filter_env", 0.22f }, { "filter_mode", 0.f }, { "filter_route", 0.f },
        { "amp_attack", 0.008f }, { "amp_decay", 0.32f }, { "amp_sustain", 0.55f }, { "amp_release", 0.34f },
        { "lfo_rate", 0.18f }, { "lfo_amount", 0.035f }, { "lfo_wave", 0.f },
        { "lfo2_rate", 0.4f }, { "lfo2_amount", 0.f }, { "lfo2_wave", 0.f },
        { "lfo3_rate", 2.f }, { "lfo3_amount", 0.f }, { "lfo3_wave", 0.f },
        { "noise_level", 0.f }, { "sub_level", 0.08f }, { "glide", 0.f }, { "voice_mode", 0.f },
        { "delay_mix", 0.035f }, { "delay_time", 360.f }, { "delay_fb", 0.22f }, { "delay_tone", 0.72f },
        { "delay_mode", 0.f }, { "delay_time_l", 360.f }, { "delay_time_r", 420.f },
        { "chorus_mix", 0.06f }, { "chorus_rate", 0.24f }, { "chorus_depth", 0.34f },
        { "reverb_mix", 0.15f }, { "reverb_size", 0.48f }, { "reverb_decay", 0.48f },
        { "reverb_damp", 0.42f }, { "reverb_mode", 2.f },
        { "phaser_mix", 0.f }, { "phaser_rate", 0.22f }, { "phaser_depth", 0.3f },
        { "dist_mix", 0.f }, { "dist_drive", 0.14f }, { "dist_crush", 0.f }, { "dist_mode", 0.f },
        { "master_drive", 0.035f }, { "master_gain", 0.90f },
        { "comp_mix", 0.16f }, { "comp_threshold", -18.f }, { "comp_ratio", 2.2f },
        { "comp_depth", 0.28f }, { "comp_attack", 12.f }, { "comp_release", 120.f }, { "comp_gain", 0.f },
        { "comp_thr_lo", -20.f }, { "comp_thr_mid", -18.f }, { "comp_thr_hi", -16.f },
        { "eq_low", 0.f }, { "eq_mid", 0.f }, { "eq_high", 0.f },
        { "spatial_azim", 0.f }, { "spatial_dist", 0.f }, { "spatial_size", 0.5f }, { "spatial_elev", 0.f },
        { "macro1", 0.5f }, { "macro2", 0.5f }, { "macro3", 0.f }, { "macro4", 0.5f },
        { "macro5", 0.5f }, { "macro6", 0.5f }, { "macro7", 0.5f }, { "macro8", 0.5f },
        { "seq_on", 0.f }, { "arp_on", 0.f }, { "magic_on", 0.f }, { "granular_mix", 0.f },
        { "bassify", 0.f }, { "input_mix", 0.f }
    };
    auto set = [&] (const char* id, float value) { values[juce::String (id)] = value; };
    auto tablePos = [] (int frame) { return (float) frame / 127.f; };

    static constexpr int primaryFrames[5][10] = {
        { 0, 10, 1, 0, 6, 2, 14, 22, 11, 16 },       // breath / reed / air
        { 16, 16, 16, 16, 22, 22, 28, 10, 18, 29 },  // plucked and bowed strings
        { 68, 76, 84, 72, 80, 84, 92, 66, 88, 64 },  // vowel and choir colors
        { 24, 25, 30, 28, 24, 25, 24, 96, 31, 96 },  // skins, impacts, and sub
        { 28, 29, 96, 30, 30, 16, 96, 96, 16, 96 }   // bells, water, rain, earth
    };
    static constexpr int secondaryFrames[5][10] = {
        { 1, 6, 0, 1, 10, 0, 1, 6, 0, 10 },
        { 28, 10, 6, 18, 10, 16, 22, 22, 16, 18 },
        { 84, 68, 76, 88, 72, 80, 68, 92, 72, 84 },
        { 2, 24, 25, 30, 28, 22, 24, 96, 29, 96 },
        { 96, 28, 29, 12, 28, 12, 90, 28, 16, 72 }
    };
    const int branchIndex = static_cast<int> (branch);
    set ("osc1_table", tablePos (primaryFrames[branchIndex][voiceIndex]));
    set ("osc2_table", tablePos (secondaryFrames[branchIndex][voiceIndex]));
    set ("osc3_table", tablePos (primaryFrames[branchIndex][(voiceIndex + 3) % 10]));

    switch (branch)
    {
        case VoiceBranch::Breath:
        {
            static constexpr float breathiness[10] = { 0.18f, 0.25f, 0.90f, 0.50f, 0.30f, 0.45f, 0.20f, 0.05f, 0.35f, 0.30f };
            const float breath = breathiness[voiceIndex];
            set ("osc1_level", 0.83f); set ("osc2_level", 0.17f + 0.04f * (1.f - breath));
            set ("noise_level", 0.035f + 0.16f * breath);
            set ("filter_cutoff", 3600.f + 2600.f * (1.f - breath));
            set ("filter_reso", 0.10f + 0.08f * (1.f - breath));
            set ("filter_env", 0.12f);
            set ("amp_attack", 0.025f + 0.055f * breath); set ("amp_decay", 0.42f);
            set ("amp_sustain", 0.62f); set ("amp_release", 0.48f + 0.5f * breath);
            set ("lfo_rate", 4.4f + 0.18f * (float) voiceIndex);
            set ("lfo_amount", 0.028f + 0.042f * breath);
            set ("reverb_mix", 0.11f + 0.10f * breath); set ("chorus_mix", 0.04f + 0.055f * breath);
            break;
        }
        case VoiceBranch::Strings:
        {
            static constexpr float brightness[10] = { 0.90f, 0.60f, 0.35f, 0.70f, 0.50f, 0.60f, 0.80f, 0.70f, 0.90f, 0.70f };
            const float bright = brightness[voiceIndex];
            const bool bowed = voiceIndex == 3 || voiceIndex == 9;
            set ("osc1_level", 0.81f); set ("osc2_level", 0.20f + 0.08f * bright);
            set ("osc2_semi", (voiceIndex == 0 || voiceIndex == 7) ? 12.f : 0.f);
            set ("fm_2to1", 0.10f + 0.25f * bright); set ("pm_2to1", 0.04f + 0.09f * bright);
            set ("filter_cutoff", 3200.f + 4700.f * bright); set ("filter_reso", 0.13f + 0.11f * bright);
            set ("filter_env", bowed ? 0.16f : 0.36f);
            set ("amp_attack", bowed ? 0.055f : 0.0015f);
            set ("amp_decay", bowed ? 0.7f : 0.23f + 0.27f * bright);
            set ("amp_sustain", bowed ? 0.62f : 0.07f + 0.12f * bright);
            set ("amp_release", bowed ? 0.72f : 0.16f + 0.22f * bright);
            set ("noise_level", 0.008f + 0.012f * (1.f - bright));
            set ("reverb_mix", 0.12f + 0.08f * voicePosition); set ("chorus_mix", bowed ? 0.13f : 0.045f);
            break;
        }
        case VoiceBranch::Voice:
        {
            static constexpr float formantCutoff[10] = { 2700.f, 3300.f, 3900.f, 3000.f, 4300.f, 4600.f, 5200.f, 2450.f, 4900.f, 3600.f };
            set ("osc1_level", 0.76f); set ("osc2_level", 0.27f);
            set ("osc2_semi", voiceIndex == 7 ? 0.f : (voiceIndex == 8 ? 7.f : 0.f));
            set ("filter_mode", voiceIndex == 7 ? 18.f : 11.f);
            set ("filter_cutoff", formantCutoff[voiceIndex]);
            set ("filter_reso", 0.26f + 0.025f * (float) (voiceIndex % 5));
            set ("filter_env", 0.18f + 0.025f * (float) (voiceIndex % 4));
            set ("fm_2to1", 0.08f + 0.035f * (float) (voiceIndex % 4));
            set ("noise_level", 0.018f + (voiceIndex == 1 ? 0.025f : 0.f));
            set ("amp_attack", 0.045f + 0.012f * (float) voiceIndex);
            set ("amp_decay", 0.38f); set ("amp_sustain", voiceIndex == 7 ? 0.78f : 0.72f);
            set ("amp_release", 0.46f + 0.035f * (float) voiceIndex);
            set ("lfo_rate", 5.2f + (voiceIndex == 4 ? 0.6f : 0.f)); set ("lfo_amount", 0.045f);
            set ("chorus_mix", 0.10f + 0.025f * voicePosition); set ("reverb_mix", 0.16f + 0.04f * voicePosition);
            break;
        }
        case VoiceBranch::Pulse:
        {
            static constexpr float decay[10] = { 0.50f, 0.22f, 0.12f, 0.35f, 0.90f, 0.16f, 0.40f, 1.80f, 1.20f, 0.70f };
            const float hit = decay[voiceIndex];
            const bool deepVoice = voiceIndex == 7 || voiceIndex == 8;
            set ("osc1_level", 0.88f); set ("osc2_level", 0.13f + (voiceIndex == 4 ? 0.12f : 0.f));
            set ("osc1_octave", deepVoice ? -1.f : 0.f); set ("sub_level", voiceIndex == 7 ? 0.64f : (voiceIndex == 8 ? 0.42f : 0.16f));
            set ("noise_level", (voiceIndex == 0 || voiceIndex == 3 || voiceIndex == 6) ? 0.10f : 0.045f);
            set ("filter_cutoff", 820.f + (float) voiceIndex * 245.f);
            set ("filter_reso", voiceIndex == 3 ? 0.36f : 0.22f); set ("filter_env", 0.76f);
            set ("filter_drive", voiceIndex == 3 ? 0.15f : 0.07f);
            set ("amp_attack", 0.001f); set ("amp_decay", hit);
            set ("amp_sustain", deepVoice ? 0.16f : 0.035f); set ("amp_release", 0.06f + hit * 0.32f);
            set ("fm_2to1", voiceIndex == 4 ? 0.48f : 0.08f + 0.035f * (float) (voiceIndex % 3));
            set ("master_drive", voiceIndex == 3 ? 0.12f : 0.055f);
            set ("reverb_mix", deepVoice ? 0.13f : 0.07f); set ("comp_mix", 0.12f);
            break;
        }
        case VoiceBranch::EarthWater:
        {
            const bool bell = voiceIndex == 0 || voiceIndex == 7;
            const bool droplet = voiceIndex == 1 || voiceIndex == 2 || voiceIndex == 6;
            const bool texture = voiceIndex == 3 || voiceIndex == 4;
            const bool drone = voiceIndex == 5 || voiceIndex == 8;
            set ("osc1_level", 0.78f); set ("osc2_level", bell ? 0.34f : 0.20f);
            set ("noise_level", texture ? (voiceIndex == 3 ? 0.17f : 0.075f) : (droplet ? 0.026f : 0.045f));
            set ("filter_cutoff", bell ? 9800.f : (drone ? 1250.f + 450.f * voicePosition : 3600.f + 900.f * voicePosition));
            set ("filter_reso", bell ? 0.10f : 0.20f); set ("filter_env", texture ? 0.32f : 0.14f);
            set ("fm_2to1", bell ? (voiceIndex == 0 ? 0.58f : 0.42f) : (droplet ? 0.24f : 0.10f));
            set ("osc2_octave", bell ? 1.f : 0.f);
            set ("amp_attack", bell || droplet ? 0.0015f : (drone ? 0.28f : 0.10f));
            set ("amp_decay", bell ? (voiceIndex == 0 ? 1.05f : 0.42f) : (droplet ? 0.20f : 0.62f));
            set ("amp_sustain", bell || droplet ? 0.045f : (drone ? 0.62f : 0.30f));
            set ("amp_release", bell ? 1.25f : (droplet ? 0.18f : (drone ? 1.35f : 0.70f)));
            set ("sub_level", drone ? 0.32f : 0.07f);
            set ("lfo_rate", texture ? 0.32f : (drone ? 0.16f : 0.24f));
            set ("lfo_amount", drone ? 0.075f : (texture ? 0.055f : 0.025f));
            set ("chorus_mix", drone ? 0.08f : 0.035f);
            set ("reverb_mix", bell ? 0.20f : (texture || drone ? 0.22f : 0.11f));
            if (voiceIndex == 9) // The Last Voice combines each sonic branch.
            {
                set ("osc2_level", 0.31f); set ("osc2_semi", 7.f);
                set ("osc3_level", 0.20f); set ("osc3_octave", 1.f); set ("osc3_semi", 0.f);
                set ("osc3_table", tablePos (72)); set ("sub_level", 0.23f); set ("noise_level", 0.035f);
                set ("amp_attack", 0.12f); set ("amp_decay", 0.72f); set ("amp_sustain", 0.68f);
                set ("amp_release", 1.8f); set ("reverb_mix", 0.24f); set ("chorus_mix", 0.11f);
            }
            break;
        }
    }

    // A handful of identities need a deliberately different envelope or
    // spectrum to match the instrument described by their name.
    switch (identityIndex)
    {
        case 9: // 010 Cave Choir: sustained vocal tones inside a large room.
            set ("osc1_table", tablePos (72)); set ("osc2_table", tablePos (80));
            set ("filter_mode", 18.f); set ("filter_cutoff", 2450.f); set ("filter_reso", 0.28f);
            set ("osc1_level", 0.65f); set ("osc2_level", 0.34f); set ("noise_level", 0.035f);
            set ("amp_attack", 0.18f); set ("amp_decay", 0.9f); set ("amp_sustain", 0.68f); set ("amp_release", 2.6f);
            set ("lfo_rate", 0.16f); set ("lfo_amount", 0.08f);
            set ("reverb_mix", 0.36f); set ("reverb_size", 0.88f); set ("reverb_decay", 0.76f);
            break;
        case 10: // 011 Glass Whisper: noise is the voice; oscillator pitch stays faint.
            set ("osc1_level", 0.075f); set ("osc2_level", 0.012f); set ("osc3_level", 0.f);
            set ("noise_level", 0.88f); set ("filter_mode", 2.f); set ("filter_cutoff", 2350.f);
            set ("amp_attack", 0.012f); set ("amp_decay", 0.24f); set ("amp_sustain", 0.08f); set ("amp_release", 0.12f);
            set ("lfo_amount", 0.f); set ("delay_mix", 0.f); set ("reverb_mix", 0.045f);
            break;
        case 11: // 012 Setar Thread: restrained level, fine pick transient, long tail.
            set ("osc1_level", 0.42f); set ("osc2_level", 0.11f); set ("filter_cutoff", 6900.f);
            set ("amp_attack", 0.0015f); set ("amp_decay", 0.34f); set ("amp_sustain", 0.06f); set ("amp_release", 0.42f);
            set ("reverb_mix", 0.16f); set ("master_gain", 0.84f);
            break;
        case 21: // 022 Oud Ember: round, dark body with a gentle pluck.
            set ("osc1_level", 0.68f); set ("osc2_level", 0.15f); set ("filter_cutoff", 2550.f);
            set ("filter_reso", 0.13f); set ("fm_2to1", 0.09f); set ("eq_low", 0.8f); set ("eq_high", -0.6f);
            set ("amp_attack", 0.003f); set ("amp_decay", 0.48f); set ("amp_sustain", 0.12f); set ("amp_release", 0.34f);
            break;
        case 25: // 026 Monsoon Sigh: long exhale rather than a short flute note.
            set ("osc1_level", 0.68f); set ("osc2_level", 0.18f); set ("noise_level", 0.24f);
            set ("amp_attack", 0.18f); set ("amp_decay", 1.05f); set ("amp_sustain", 0.42f); set ("amp_release", 1.55f);
            set ("lfo_rate", 0.14f); set ("lfo_amount", 0.025f); set ("filter_cutoff", 4550.f);
            break;
        case 30: // 031 Cloud Choir: several softly detuned breath and overtone layers.
            set ("osc1_unison", 3.f); set ("osc1_udet", 4.5f); set ("osc1_uspread", 0.7f);
            set ("osc2_semi", 7.f); set ("osc2_level", 0.25f); set ("osc2_table", tablePos (92));
            set ("noise_level", 0.08f); set ("amp_attack", 0.12f); set ("amp_decay", 0.8f);
            set ("amp_sustain", 0.68f); set ("amp_release", 1.45f);
            set ("chorus_mix", 0.15f); set ("reverb_mix", 0.24f); set ("reverb_size", 0.72f);
            break;
        case 34: // 035 Tide Ledger: slow swell with a wide, softened high end.
            set ("osc1_table", tablePos (16)); set ("osc2_table", tablePos (29));
            set ("osc1_level", 0.66f); set ("osc2_level", 0.18f); set ("noise_level", 0.12f); set ("sub_level", 0.2f);
            set ("filter_cutoff", 1850.f); set ("amp_attack", 0.9f); set ("amp_decay", 1.2f);
            set ("amp_sustain", 0.58f); set ("amp_release", 2.6f); set ("lfo_rate", 0.09f); set ("lfo_amount", 0.1f);
            set ("reverb_mix", 0.32f); set ("reverb_size", 0.86f); set ("reverb_decay", 0.76f);
            break;
        case 40: // 041 Sky Lung: a slow, low-breathing cinematic pad.
            set ("osc1_level", 0.56f); set ("osc2_level", 0.3f); set ("noise_level", 0.13f); set ("sub_level", 0.2f);
            set ("filter_cutoff", 2900.f); set ("amp_attack", 0.72f); set ("amp_decay", 1.1f);
            set ("amp_sustain", 0.72f); set ("amp_release", 2.8f); set ("lfo_rate", 0.11f); set ("lfo_amount", 0.08f);
            set ("reverb_mix", 0.34f); set ("reverb_size", 0.86f); set ("reverb_decay", 0.74f);
            break;
        default: break;
    }

    // Register and performance variants are deliberately small, deterministic
    // transformations of the identity patch, so each one keeps its own voice.
    switch (variation)
    {
        case 1: // DEEP — low register, controlled sub, short stereo tail.
            set ("osc1_octave", -1.f); set ("osc2_octave", -1.f);
            set ("osc3_octave", -1.f); set ("sub_level", juce::jmax (0.28f, values["sub_level"]));
            set ("filter_cutoff", values["filter_cutoff"] * 0.86f);
            set ("eq_low", 0.8f); set ("eq_high", -0.5f);
            set ("reverb_mix", juce::jmin (0.16f, values["reverb_mix"])); set ("master_gain", 0.87f);
            break;
        case 2: // SKY — upper register, clear transient and reduced sub energy.
            set ("osc1_octave", 1.f); set ("osc2_octave", 1.f);
            set ("osc2_level", juce::jmax (0.23f, values["osc2_level"])); set ("sub_level", 0.015f);
            set ("noise_level", values["noise_level"] * 0.7f);
            set ("filter_cutoff", juce::jmin (11200.f, values["filter_cutoff"] * 1.12f));
            set ("eq_high", 0.8f); set ("master_gain", 0.87f);
            break;
        case 3: // HALO — wider unison, restrained chorus and room around the core.
            set ("osc1_unison", 3.f); set ("osc1_udet", 7.5f); set ("osc1_uspread", 0.76f);
            set ("osc2_unison", 2.f); set ("osc2_udet", 5.f); set ("osc2_uspread", 0.88f);
            set ("chorus_mix", 0.14f); set ("chorus_depth", 0.42f);
            set ("reverb_mix", juce::jmin (0.30f, values["reverb_mix"] + 0.10f));
            set ("reverb_size", 0.66f); set ("master_gain", 0.84f);
            break;
        case 4: // MOTION — slow timbral movement with the internal filter LFO.
            set ("lfo_rate", 0.11f + 0.025f * (float) voiceIndex);
            set ("lfo_amount", 0.15f); set ("lfo_wave", 0.f);
            set ("filter_env", juce::jmin (0.58f, values["filter_env"] + 0.10f));
            set ("osc1_warp", 0.06f + 0.025f * (float) (voiceIndex % 4));
            set ("delay_mix", 0.10f); set ("delay_fb", 0.24f); set ("delay_time", 410.f);
            break;
        default: break;
    }

    return values;
}

inline std::vector<Preset> makePresets()
{
    static constexpr const char* variants[] = { "CORE", "DEEP", "SKY", "HALO", "MOTION" };
    std::vector<Preset> result;
    result.reserve (identities.size() * std::size (variants));

    for (std::size_t i = 0; i < identities.size(); ++i)
    {
        const auto& identity = identities[i];
        for (int variant = 0; variant < (int) std::size (variants); ++variant)
        {
            const auto name = juce::String ("GITI/") + identity.number + " · " + identity.name
                            + " [" + variants[variant] + "]";
            result.push_back ({ name, designVoice (i, variant) });
        }
    }

    return result;
}
} // namespace salek::giti
