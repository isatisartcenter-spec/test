#pragma once

#include <JuceHeader.h>
#include <array>
#include <map>
#include <vector>

namespace salek::thisIsSalek
{
struct Preset
{
    juce::String name;
    std::map<juce::String, float> values;
};

enum class VoiceKind { Bass, Acid, Lead, Pluck, Keys, Pad, Drone, Effect };

inline VoiceKind kindFor (int bank, int index) noexcept
{
    if (bank == 0)
    {
        if (index < 6) return VoiceKind::Bass;
        if (index < 12) return VoiceKind::Acid;
        if (index < 21) return VoiceKind::Lead;
        if (index < 25) return VoiceKind::Pluck;
        return VoiceKind::Effect;
    }
    if (bank == 1)
    {
        if (index < 6) return VoiceKind::Bass;
        if (index < 12) return VoiceKind::Lead;
        if (index < 19) return VoiceKind::Keys;
        if (index < 25) return VoiceKind::Pluck;
        return VoiceKind::Pad;
    }
    if (index < 8) return VoiceKind::Drone;
    if (index < 18) return VoiceKind::Effect;
    if (index < 24) return VoiceKind::Pad;
    return VoiceKind::Effect;
}

inline std::vector<Preset> makePresets()
{
    static constexpr const char* bankLabels[] = { "PSY HITECH", "CLASSIC SIGNALS", "ODD WORLDS" };
    static constexpr const char* names[3][30] = {
        {
            "Kick-Locked Sub Bass", "Rolling 16th Pulse", "Rubberline Reese", "Dark Rolling Mono", "Low Orbit Bass", "Tight Night Bass",
            "303 Memory Squelch", "Acid Ladder Bite", "Resonant Spiral", "Rubber Acid Sequence", "Forest Acid Rake", "Glass Acid Drop",
            "Neon Razor Lead", "Full-On Peak Lead", "Hi-Tech Photon Saw", "Darkpsy Bark Lead", "Forest Root Growl", "Morning Goa Ribbon",
            "Psycho Hoover Rise", "Phase Splitter", "Cyan Arpeggio Blade", "Crystal Pluck Relay", "Staccato Shroom", "Bell Comet Pluck",
            "Alien Radio Phrase", "Night Ritual Drone", "Psy Portal Sweep", "Glitch Comet Burst", "Rising Plasma Arc", "Interstellar Hit"
        },
        {
            "TB-Flavoured Acid Box", "Minimoog Mono Bass", "MS-20 Filter Growl", "SH-101 Pulse Sequence", "Model-D Subline", "Odyssey Rubber Bass",
            "JP-Style Arena Supersaw", "Jupiter Brass Poly", "Prophet Unison Lead", "CS-80 Expressive Lead", "Portamento Synth Lead", "Virus-Style Trance Stack",
            "DX-Style FM Glass Bell", "FM Metal Pluck", "Rhodes-Like Electric Key", "Synclavier Mallet Key", "FM EP Chime", "DX FM Tine", "Retro Chip Pulse",
            "Goa Gate Pluck", "Mallet Circuit", "PPG Glass Pluck", "Damped Bell Arp", "Juno Jangle Sequence", "Prophet Crystal Keys",
            "Juno Ensemble Pad", "Solina-Style Strings", "OB Poly Bloom", "Mellotron Choir", "Jupiter Brass Pad"
        },
        {
            "Submerged Machine", "Black Moss Drone", "Distant Metal Choir", "Underwater Lantern", "Cold Reactor Bed", "Low Orbit Haze", "Breathing Stone", "Forest Pressure",
            "Alien Abduction Beam", "Radio Nebula", "Fractal Mouth", "Bent Glass Transmission", "Space Dentist", "Pseudofrog Signal", "Antimatter Bell", "Broken Satellite",
            "Wormhole Vocal Shard", "Quantum Larva", "Soft Plasma Veil", "Hollow Observatory", "Slow Phase Mist", "Polar Carrier", "Cosmic Dust Bloom", "Ghost Current",
            "Phase Displacement", "UFO Tractor Beam", "Glitch Gate Array", "Impact Vector", "Portal Unfolding", "Last Signal Falling"
        }
    };

    const auto unit = [] (int bank, int index, int salt) noexcept
    {
        const int n = (index * 137 + index * index * 19 + bank * 263 + salt * 97 + 41) % 997;
        return static_cast<float> (n) / 996.0f;
    };
    const auto tablePos = [] (int bank, int index, int offset) noexcept
    {
        return static_cast<float> ((index * 29 + bank * 37 + offset * 17 + 11) % 128) / 127.0f;
    };

    std::vector<Preset> result;
    result.reserve (90);
    for (int bank = 0; bank < 3; ++bank)
        for (int i = 0; i < 30; ++i)
        {
            const auto kind = kindFor (bank, i);
            const float a = unit (bank, i, 1), b = unit (bank, i, 2), c = unit (bank, i, 3);
            const float d = unit (bank, i, 4), e = unit (bank, i, 5), f = unit (bank, i, 6);
            float level1 = 0.76f, level2 = 0.23f, level3 = 0.08f;
            float cutoff = 4200.0f, resonance = 0.28f, filterEnv = 0.28f, filterDrive = 0.08f;
            float attack = 0.003f, decay = 0.26f, sustain = 0.48f, release = 0.22f;
            float sub = 0.04f, noise = 0.0f, glide = 0.0f;
            float lfoRate = 1.1f, lfoAmount = 0.12f;
            float delayMix = 0.17f, reverbMix = 0.16f, chorusMix = 0.08f, phaserMix = 0.0f;
            float distMix = 0.04f, distDrive = 0.18f, masterDrive = 0.12f;
            float fm = 0.08f, pm = 0.0f, warp = 0.08f, fold = 0.04f;
            float detune = 9.0f, spread = 0.58f;
            int voices = 2, octave = 0, semi = 0, filterMode = 0, voiceMode = 0;

            switch (kind)
            {
                case VoiceKind::Bass:
                    level1 = 0.84f; level2 = 0.13f + b * 0.10f; level3 = 0.03f;
                    cutoff = 170.0f + a * 1050.0f; resonance = 0.18f + b * 0.34f;
                    filterEnv = 0.34f + c * 0.52f; filterDrive = 0.08f + d * 0.18f;
                    attack = 0.001f; decay = 0.12f + a * 0.19f; sustain = 0.48f + b * 0.38f;
                    release = 0.07f + c * 0.19f; sub = 0.18f + d * 0.22f; glide = 0.02f + e * 0.13f;
                    lfoRate = 0.12f + f * 1.1f; lfoAmount = 0.04f + a * 0.13f;
                    detune = 1.0f + b * 7.0f; spread = 0.12f + c * 0.28f; voices = 1 + (i % 2);
                    octave = -1; filterMode = (i % 3 == 0 ? 9 : (i % 3 == 1 ? 8 : 0));
                    fm = 0.02f + d * 0.18f; distMix = 0.04f + e * 0.15f; masterDrive = 0.08f + f * 0.16f;
                    voiceMode = 1;
                    break;
                case VoiceKind::Acid:
                    level1 = 0.82f; level2 = 0.0f; level3 = 0.0f;
                    cutoff = 260.0f + a * 1650.0f; resonance = 0.58f + b * 0.34f;
                    filterEnv = 0.68f + c * 0.30f; filterDrive = 0.16f + d * 0.30f;
                    attack = 0.0008f; decay = 0.08f + a * 0.24f; sustain = 0.03f + b * 0.26f;
                    release = 0.045f + c * 0.14f; glide = 0.04f + d * 0.20f;
                    lfoRate = 2.0f + e * 7.0f; lfoAmount = 0.10f + f * 0.28f;
                    voices = 1; detune = 0.0f; spread = 0.0f; filterMode = (i % 2 == 0 ? 8 : 9);
                    warp = 0.10f + a * 0.28f; fold = 0.02f + b * 0.13f; fm = 0.02f + c * 0.16f;
                    distMix = 0.08f + d * 0.20f; masterDrive = 0.12f + e * 0.22f; voiceMode = 1;
                    break;
                case VoiceKind::Lead:
                    level1 = 0.71f + a * 0.12f; level2 = 0.18f + b * 0.18f; level3 = 0.04f + c * 0.10f;
                    cutoff = 2100.0f + a * 6200.0f; resonance = 0.18f + b * 0.38f;
                    filterEnv = 0.18f + c * 0.62f; filterDrive = 0.04f + d * 0.18f;
                    attack = 0.001f + a * 0.012f; decay = 0.14f + b * 0.28f; sustain = 0.34f + c * 0.48f;
                    release = 0.10f + d * 0.40f; lfoRate = 0.35f + e * 6.8f; lfoAmount = 0.08f + f * 0.28f;
                    detune = 5.0f + a * 18.0f; spread = 0.48f + b * 0.44f; voices = 2 + (i % 4);
                    filterMode = (i % 5 == 0 ? 11 : (i % 5 == 1 ? 16 : 0));
                    fm = 0.08f + c * 0.40f; pm = 0.02f + d * 0.17f; warp = 0.04f + e * 0.32f;
                    delayMix = 0.17f + f * 0.22f; reverbMix = 0.08f + a * 0.20f;
                    distMix = 0.02f + b * 0.12f; masterDrive = 0.08f + c * 0.20f;
                    break;
                case VoiceKind::Pluck:
                    level1 = 0.75f + a * 0.12f; level2 = 0.08f + b * 0.26f; level3 = 0.02f + c * 0.10f;
                    cutoff = 2800.0f + a * 9900.0f; resonance = 0.08f + b * 0.32f;
                    filterEnv = 0.28f + c * 0.60f; attack = 0.0007f; decay = 0.12f + a * 0.54f;
                    sustain = 0.0f + b * 0.18f; release = 0.08f + c * 0.42f;
                    voices = 1 + (i % 3); detune = 2.0f + d * 10.0f; spread = 0.25f + e * 0.55f;
                    fm = 0.08f + f * 0.54f; pm = 0.03f + a * 0.18f; warp = 0.04f + b * 0.24f;
                    lfoRate = 0.7f + c * 5.0f; lfoAmount = 0.03f + d * 0.15f;
                    delayMix = 0.12f + e * 0.32f; reverbMix = 0.12f + f * 0.30f;
                    filterMode = (i % 4 == 0 ? 6 : (i % 4 == 1 ? 4 : 0));
                    break;
                case VoiceKind::Keys:
                    level1 = 0.70f + a * 0.10f; level2 = 0.20f + b * 0.28f; level3 = 0.05f + c * 0.08f;
                    cutoff = 1800.0f + a * 8800.0f; resonance = 0.06f + b * 0.23f;
                    filterEnv = 0.08f + c * 0.35f; attack = 0.002f + a * 0.045f;
                    decay = 0.34f + b * 1.05f; sustain = 0.15f + c * 0.46f; release = 0.22f + d * 0.82f;
                    voices = 1 + (i % 3); detune = 1.0f + e * 8.0f; spread = 0.22f + f * 0.56f;
                    fm = 0.12f + a * 0.58f; pm = 0.04f + b * 0.24f;
                    lfoRate = 0.08f + c * 1.6f; lfoAmount = 0.02f + d * 0.14f;
                    delayMix = 0.08f + e * 0.20f; reverbMix = 0.12f + f * 0.30f;
                    filterMode = (i % 4 == 0 ? 6 : (i % 4 == 1 ? 11 : 0));
                    break;
                case VoiceKind::Pad:
                case VoiceKind::Drone:
                    level1 = 0.57f + a * 0.16f; level2 = 0.23f + b * 0.20f; level3 = 0.10f + c * 0.13f;
                    cutoff = 750.0f + a * 6100.0f; resonance = 0.06f + b * 0.24f;
                    filterEnv = 0.05f + c * 0.28f; attack = 0.22f + a * (kind == VoiceKind::Drone ? 2.2f : 1.4f);
                    decay = 0.45f + b * 1.0f; sustain = 0.52f + c * 0.38f; release = 1.0f + d * 3.2f;
                    sub = 0.0f + e * 0.10f; noise = 0.015f + f * 0.11f;
                    voices = 3 + (i % 4); detune = 6.0f + a * 18.0f; spread = 0.60f + b * 0.38f;
                    lfoRate = 0.035f + c * 0.52f; lfoAmount = 0.05f + d * 0.28f;
                    chorusMix = 0.14f + e * 0.28f; reverbMix = 0.28f + f * 0.34f;
                    delayMix = 0.04f + a * 0.20f; fm = 0.02f + b * 0.18f;
                    filterMode = (i % 4 == 0 ? 18 : (i % 4 == 1 ? 5 : 0));
                    break;
                case VoiceKind::Effect:
                    level1 = 0.61f + a * 0.16f; level2 = 0.15f + b * 0.25f; level3 = 0.04f + c * 0.12f;
                    cutoff = 280.0f + a * 10400.0f; resonance = 0.12f + b * 0.60f;
                    filterEnv = 0.22f + c * 0.72f; filterDrive = 0.08f + d * 0.28f;
                    attack = (i % 3 == 0 ? 0.001f : 0.03f + a * 0.55f);
                    decay = 0.14f + b * 1.0f; sustain = (i % 4 == 0 ? 0.0f : 0.10f + c * 0.58f);
                    release = 0.16f + d * 2.5f; noise = 0.01f + e * 0.22f;
                    voices = 1 + (i % 5); detune = 2.0f + f * 20.0f; spread = 0.36f + a * 0.58f;
                    lfoRate = 0.12f + b * 11.0f; lfoAmount = 0.12f + c * 0.62f;
                    delayMix = 0.12f + d * 0.34f; reverbMix = 0.16f + e * 0.43f;
                    phaserMix = 0.08f + f * 0.36f; distMix = 0.04f + a * 0.28f;
                    distDrive = 0.16f + b * 0.45f; masterDrive = 0.08f + c * 0.28f;
                    fm = 0.12f + d * 0.58f; pm = 0.04f + e * 0.28f; warp = 0.12f + f * 0.58f; fold = 0.04f + a * 0.40f;
                    filterMode = (i % 5 == 0 ? 19 : (i % 5 == 1 ? 10 : (i % 5 == 2 ? 11 : 4)));
                    break;
            }

            const int semitones[] = { 0, 0, 7, 12, -12, 5, -7 };
            semi = semitones[(i * 3 + bank * 2) % 7];
            const float pan2 = juce::jlimit (0.18f, 0.82f, 0.5f + (b - 0.5f) * 0.38f);
            const float pan3 = juce::jlimit (0.15f, 0.85f, 0.5f + (c - 0.5f) * 0.50f);
            std::map<juce::String, float> values {
                { "osc1_level", level1 }, { "osc2_level", level2 }, { "osc3_level", level3 },
                { "osc1_table", tablePos (bank, i, 0) }, { "osc2_table", tablePos (bank, i, 3) }, { "osc3_table", tablePos (bank, i, 6) },
                { "osc1_warp", warp }, { "osc2_warp", 0.02f + b * 0.16f }, { "osc3_warp", 0.01f + c * 0.12f },
                { "osc1_fold", fold }, { "osc2_fold", 0.02f + d * 0.12f }, { "osc3_fold", 0.0f },
                { "osc1_drive", 0.04f + a * 0.22f }, { "osc2_drive", 0.03f + b * 0.16f }, { "osc3_drive", 0.02f + c * 0.12f },
                { "osc1_octave", static_cast<float> (octave) }, { "osc2_octave", 0.0f }, { "osc3_octave", -1.0f },
                { "osc1_semi", 0.0f }, { "osc2_semi", static_cast<float> (semi) }, { "osc3_semi", static_cast<float> (semi == 0 ? 7 : -5) },
                { "osc1_fine", 0.0f }, { "osc2_fine", -4.0f + d * 8.0f }, { "osc3_fine", 3.0f - e * 6.0f },
                { "osc1_pan", 0.5f }, { "osc2_pan", pan2 }, { "osc3_pan", pan3 },
                { "osc1_rand", 0.015f + a * 0.08f }, { "osc2_rand", 0.01f + b * 0.06f }, { "osc3_rand", 0.01f + c * 0.04f },
                { "osc1_unison", static_cast<float> (voices) }, { "osc2_unison", 1.0f }, { "osc3_unison", 1.0f },
                { "osc1_udet", detune }, { "osc2_udet", detune * 0.62f }, { "osc3_udet", detune * 0.42f },
                { "osc1_uspread", spread }, { "osc2_uspread", juce::jlimit (0.0f, 1.0f, spread + 0.12f) }, { "osc3_uspread", spread * 0.82f },
                { "fm_2to1", fm }, { "fm_3to1", fm * 0.36f }, { "fm_3to2", fm * 0.22f },
                { "pm_2to1", pm }, { "rm_2to1", 0.01f + f * 0.08f }, { "am_2to1", 0.01f + e * 0.07f },
                { "filter_cutoff", cutoff }, { "filter_reso", resonance }, { "filter_drive", filterDrive },
                { "filter_env", filterEnv }, { "filter_mode", static_cast<float> (filterMode) }, { "filter_route", 0.0f },
                { "amp_attack", attack }, { "amp_decay", decay }, { "amp_sustain", sustain }, { "amp_release", release },
                { "lfo_rate", lfoRate }, { "lfo_amount", lfoAmount }, { "lfo_wave", static_cast<float> ((i + bank * 3) % 12) },
                { "lfo2_rate", 0.08f + f * 3.4f }, { "lfo2_amount", lfoAmount * 0.42f }, { "lfo2_wave", static_cast<float> ((i + 3) % 12) },
                { "lfo3_rate", 0.2f + d * 7.0f }, { "lfo3_amount", lfoAmount * 0.24f }, { "lfo3_wave", static_cast<float> ((i + 7) % 12) },
                { "noise_level", noise }, { "sub_level", sub }, { "glide", glide }, { "voice_mode", static_cast<float> (voiceMode) },
                { "poly_voices", (voiceMode == 1 ? 1.0f : 8.0f) },
                { "delay_mix", delayMix }, { "delay_time", 170.0f + c * 470.0f }, { "delay_fb", 0.18f + d * 0.42f },
                { "delay_tone", 0.44f + e * 0.46f }, { "delay_mode", static_cast<float> (i % 2) },
                { "delay_time_l", 180.0f + a * 420.0f }, { "delay_time_r", 230.0f + b * 430.0f },
                { "chorus_mix", chorusMix }, { "chorus_rate", 0.12f + a * 0.85f }, { "chorus_depth", 0.24f + b * 0.60f },
                { "reverb_mix", reverbMix }, { "reverb_size", 0.34f + c * 0.60f }, { "reverb_decay", 0.35f + d * 0.48f },
                { "reverb_damp", 0.22f + e * 0.58f }, { "reverb_mode", static_cast<float> (i % 5) },
                { "phaser_mix", phaserMix }, { "phaser_rate", 0.10f + f * 1.8f }, { "phaser_depth", 0.32f + a * 0.55f },
                { "dist_mix", distMix }, { "dist_drive", distDrive }, { "dist_crush", (kind == VoiceKind::Effect ? 0.02f + c * 0.22f : 0.0f) },
                { "dist_mode", static_cast<float> (i % 6) }, { "master_drive", masterDrive }, { "master_gain", 0.84f },
                { "comp_mix", 0.16f + f * 0.24f }, { "comp_threshold", -18.0f + e * 5.0f },
                { "comp_ratio", 2.0f + d * 3.0f }, { "comp_depth", 0.24f + c * 0.42f },
                { "comp_attack", 5.0f + a * 14.0f }, { "comp_release", 65.0f + b * 100.0f },
                { "comp_gain", 0.0f }, { "eq_low", -1.5f + a * 3.0f }, { "eq_mid", -1.0f + b * 2.0f },
                { "eq_high", -1.2f + c * 2.8f }, { "spatial_azim", -24.0f + d * 48.0f },
                { "spatial_dist", (kind == VoiceKind::Effect || kind == VoiceKind::Drone ? 0.18f + e * 0.45f : 0.0f) },
                { "spatial_size", 0.42f + f * 0.45f }, { "spatial_elev", -12.0f + a * 24.0f },
                { "arp_on", 0.0f }, { "seq_on", 0.0f }, { "magic_on", 0.0f }, { "granular_mix", 0.0f },
                { "bassify", (kind == VoiceKind::Bass || kind == VoiceKind::Acid ? 0.12f + b * 0.24f : 0.0f) }
            };

            // Pin the classic section to its intended synthesis archetype rather
            // than relying on the shared family variations alone.
            auto set = [&values] (const char* id, float value) { values[juce::String (id)] = value; };
            if (bank == 1)
            {
                switch (i)
                {
                    case 0: // 303-style resonant acid line
                        set ("osc1_table", 0.70f); set ("osc1_unison", 1.0f); set ("osc2_level", 0.0f); set ("osc3_level", 0.0f);
                        set ("filter_mode", 8.0f); set ("filter_cutoff", 520.0f); set ("filter_reso", 0.88f); set ("filter_env", 0.94f);
                        set ("filter_drive", 0.24f); set ("amp_attack", 0.0008f); set ("amp_decay", 0.17f); set ("amp_sustain", 0.12f);
                        set ("amp_release", 0.08f); set ("glide", 0.10f); set ("dist_mix", 0.06f); set ("master_drive", 0.23f); break;
                    case 1: // round mono analog bass
                        set ("osc1_table", 0.42f); set ("osc2_level", 0.30f); set ("osc2_semi", 7.0f); set ("osc1_unison", 1.0f);
                        set ("osc2_unison", 1.0f); set ("filter_mode", 9.0f); set ("filter_cutoff", 920.0f); set ("filter_reso", 0.26f);
                        set ("amp_attack", 0.004f); set ("amp_decay", 0.34f); set ("amp_sustain", 0.78f); set ("amp_release", 0.16f);
                        set ("voice_mode", 1.0f); set ("glide", 0.06f); break;
                    case 2: // aggressive filter growl
                        set ("osc1_table", 0.77f); set ("osc1_fold", 0.28f); set ("osc1_drive", 0.30f); set ("fm_2to1", 0.26f);
                        set ("filter_mode", 16.0f); set ("filter_cutoff", 1380.0f); set ("filter_reso", 0.76f); set ("filter_drive", 0.34f);
                        set ("filter_env", 0.88f); set ("dist_mix", 0.14f); set ("dist_drive", 0.36f); set ("master_drive", 0.20f); break;
                    case 3: // tight pulse-sequence voice
                        set ("osc1_table", 0.62f); set ("osc1_unison", 1.0f); set ("osc2_level", 0.12f); set ("osc2_semi", 0.0f);
                        set ("filter_mode", 8.0f); set ("filter_cutoff", 1850.0f); set ("filter_reso", 0.48f); set ("filter_env", 0.62f);
                        set ("amp_attack", 0.001f); set ("amp_decay", 0.19f); set ("amp_sustain", 0.22f); set ("amp_release", 0.09f);
                        set ("voice_mode", 1.0f); break;
                    case 4: // classic dual-oscillator sub bass
                        set ("osc1_table", 0.40f); set ("osc2_level", 0.22f); set ("osc2_fine", 5.0f); set ("sub_level", 0.28f);
                        set ("filter_mode", 9.0f); set ("filter_cutoff", 740.0f); set ("filter_reso", 0.22f); set ("amp_decay", 0.42f);
                        set ("amp_sustain", 0.82f); set ("amp_release", 0.20f); set ("voice_mode", 1.0f); break;
                    case 5: // sharp, rubbery analog lead/bass
                        set ("osc1_table", 0.73f); set ("osc2_level", 0.24f); set ("osc2_semi", 7.0f); set ("osc1_fold", 0.12f);
                        set ("filter_mode", 16.0f); set ("filter_cutoff", 1100.0f); set ("filter_reso", 0.62f); set ("filter_drive", 0.22f);
                        set ("glide", 0.12f); set ("dist_mix", 0.10f); break;
                    case 6: // wide trance unison
                        set ("osc1_unison", 6.0f); set ("osc1_udet", 17.0f); set ("osc1_uspread", 0.96f); set ("osc2_unison", 1.0f);
                        set ("filter_cutoff", 6900.0f); set ("filter_reso", 0.30f); set ("chorus_mix", 0.10f); set ("delay_mix", 0.24f); break;
                    case 7: // brass poly stack
                        set ("osc1_unison", 4.0f); set ("osc1_udet", 9.0f); set ("osc2_semi", 7.0f); set ("osc2_level", 0.31f);
                        set ("filter_mode", 1.0f); set ("filter_cutoff", 3400.0f); set ("amp_attack", 0.035f); set ("amp_decay", 0.40f);
                        set ("amp_sustain", 0.70f); set ("amp_release", 0.42f); set ("chorus_mix", 0.14f); break;
                    case 8: // compact warm poly lead
                        set ("osc1_unison", 3.0f); set ("osc1_udet", 6.0f); set ("osc2_semi", 7.0f); set ("filter_cutoff", 4100.0f);
                        set ("filter_reso", 0.25f); set ("amp_attack", 0.008f); set ("amp_sustain", 0.62f); set ("chorus_mix", 0.12f); break;
                    case 9: // expressive, slightly slower lead
                        set ("osc1_unison", 2.0f); set ("osc2_semi", 12.0f); set ("osc2_level", 0.28f); set ("pm_2to1", 0.18f);
                        set ("filter_mode", 1.0f); set ("filter_cutoff", 5200.0f); set ("amp_attack", 0.075f); set ("amp_release", 0.72f);
                        set ("lfo_rate", 0.28f); set ("lfo_amount", 0.10f); set ("reverb_mix", 0.20f); break;
                    case 10: // legato portamento line
                        set ("voice_mode", 2.0f); set ("glide", 0.32f); set ("osc1_unison", 1.0f); set ("osc2_level", 0.20f);
                        set ("osc2_semi", 12.0f); set ("amp_attack", 0.012f); set ("amp_sustain", 0.68f); set ("amp_release", 0.38f); break;
                    case 11: // compact digital trance stack
                        set ("osc1_unison", 5.0f); set ("osc1_udet", 16.0f); set ("osc1_uspread", 0.94f); set ("osc2_unison", 1.0f);
                        set ("osc1_warp", 0.28f); set ("fm_2to1", 0.40f); set ("filter_cutoff", 6400.0f);
                        set ("delay_mix", 0.26f); set ("chorus_mix", 0.13f); set ("master_drive", 0.17f); break;
                    case 12: // FM bell with a long clean tail
                        set ("osc1_level", 0.54f); set ("osc2_level", 0.58f); set ("osc2_octave", 1.0f); set ("osc2_semi", 0.0f);
                        set ("osc1_unison", 1.0f); set ("fm_2to1", 0.68f); set ("pm_2to1", 0.12f); set ("filter_cutoff", 12000.0f);
                        set ("amp_attack", 0.001f); set ("amp_decay", 1.35f); set ("amp_sustain", 0.0f); set ("amp_release", 1.50f);
                        set ("reverb_mix", 0.24f); break;
                    case 13: // metallic inharmonic FM pluck
                        set ("osc1_level", 0.62f); set ("osc2_level", 0.52f); set ("osc2_semi", 5.0f); set ("osc2_fine", 13.0f);
                        set ("fm_2to1", 0.78f); set ("rm_2to1", 0.12f); set ("filter_mode", 19.0f); set ("filter_cutoff", 9500.0f);
                        set ("amp_attack", 0.001f); set ("amp_decay", 0.52f); set ("amp_sustain", 0.02f); set ("amp_release", 0.62f); break;
                    case 14: // rounded electric-key transient
                        set ("osc1_unison", 1.0f); set ("osc1_level", 0.70f); set ("osc2_level", 0.36f); set ("fm_2to1", 0.25f);
                        set ("filter_cutoff", 6800.0f); set ("amp_attack", 0.002f); set ("amp_decay", 0.62f); set ("amp_sustain", 0.24f);
                        set ("amp_release", 0.66f); set ("reverb_mix", 0.18f); break;
                    case 15: // crisp digital mallet
                        set ("osc1_level", 0.58f); set ("osc2_level", 0.60f); set ("osc2_octave", 1.0f); set ("fm_2to1", 0.72f);
                        set ("pm_2to1", 0.18f); set ("amp_attack", 0.001f); set ("amp_decay", 0.38f); set ("amp_sustain", 0.0f);
                        set ("amp_release", 0.34f); set ("reverb_mix", 0.14f); break;
                    case 16: // soft FM electric piano
                        set ("osc1_level", 0.68f); set ("osc2_level", 0.32f); set ("fm_2to1", 0.31f); set ("filter_cutoff", 5800.0f);
                        set ("amp_attack", 0.003f); set ("amp_decay", 0.92f); set ("amp_sustain", 0.34f); set ("amp_release", 0.76f); break;
                    case 17: // bright FM tine
                        set ("osc1_level", 0.60f); set ("osc2_level", 0.44f); set ("osc2_semi", 7.0f); set ("fm_2to1", 0.56f);
                        set ("filter_cutoff", 8200.0f); set ("amp_attack", 0.001f); set ("amp_decay", 0.66f); set ("amp_sustain", 0.16f);
                        set ("amp_release", 0.54f); break;
                    case 18: // single-voice chip pulse
                        set ("osc1_level", 0.82f); set ("osc1_unison", 1.0f); set ("osc2_level", 0.0f); set ("osc3_level", 0.0f);
                        set ("osc1_fold", 0.0f); set ("fm_2to1", 0.0f); set ("filter_cutoff", 7200.0f); set ("filter_reso", 0.12f);
                        set ("amp_attack", 0.001f); set ("amp_decay", 0.24f); set ("amp_sustain", 0.0f); set ("amp_release", 0.12f); break;
                    case 19: // gated melodic pluck with echo
                        set ("amp_attack", 0.001f); set ("amp_decay", 0.20f); set ("amp_sustain", 0.0f); set ("amp_release", 0.09f);
                        set ("filter_env", 0.68f); set ("filter_cutoff", 4400.0f); set ("delay_mix", 0.28f); set ("delay_fb", 0.28f); break;
                    case 20: // wooden mallet transient
                        set ("osc1_level", 0.65f); set ("osc2_level", 0.42f); set ("fm_2to1", 0.34f); set ("filter_cutoff", 7200.0f);
                        set ("amp_attack", 0.001f); set ("amp_decay", 0.30f); set ("amp_sustain", 0.0f); set ("amp_release", 0.26f); break;
                    case 21: // wavetable glass with measured frame motion
                        set ("osc1_table", 0.78f); set ("osc2_table", 0.32f); set ("osc1_warp", 0.14f); set ("filter_mode", 6.0f);
                        set ("filter_cutoff", 7600.0f); set ("lfo_rate", 0.13f); set ("lfo_amount", 0.11f); set ("delay_mix", 0.22f); break;
                    case 22: // short damped bell
                        set ("osc1_level", 0.56f); set ("osc2_level", 0.48f); set ("fm_2to1", 0.48f); set ("amp_decay", 0.82f);
                        set ("amp_sustain", 0.0f); set ("amp_release", 0.74f); set ("filter_cutoff", 8900.0f); break;
                    case 23: // ensemble-style bright sequence voice
                        set ("osc1_unison", 3.0f); set ("osc1_udet", 6.0f); set ("osc1_uspread", 0.74f); set ("chorus_mix", 0.28f);
                        set ("filter_cutoff", 4700.0f); set ("amp_decay", 0.36f); set ("amp_sustain", 0.28f); set ("delay_mix", 0.20f); break;
                    case 24: // clear poly keys
                        set ("osc1_unison", 2.0f); set ("osc1_udet", 3.0f); set ("osc2_level", 0.28f); set ("fm_2to1", 0.22f);
                        set ("filter_cutoff", 7100.0f); set ("amp_attack", 0.008f); set ("amp_decay", 0.52f); set ("amp_sustain", 0.44f); break;
                    case 25: // chorus-forward ensemble pad
                        set ("osc1_unison", 5.0f); set ("osc1_udet", 15.0f); set ("osc1_uspread", 0.92f); set ("chorus_mix", 0.42f);
                        set ("amp_attack", 0.18f); set ("amp_decay", 0.65f); set ("amp_sustain", 0.78f); set ("amp_release", 1.70f);
                        set ("reverb_mix", 0.25f); break;
                    case 26: // slow string ensemble
                        set ("osc1_unison", 5.0f); set ("osc1_udet", 12.0f); set ("osc1_uspread", 0.88f); set ("osc2_semi", 7.0f);
                        set ("chorus_mix", 0.48f); set ("amp_attack", 0.32f); set ("amp_sustain", 0.74f); set ("amp_release", 2.30f); break;
                    case 27: // warm detuned poly bloom
                        set ("osc1_unison", 4.0f); set ("osc1_udet", 8.0f); set ("osc1_uspread", 0.78f); set ("osc2_level", 0.32f);
                        set ("osc2_fine", 6.0f); set ("filter_cutoff", 3300.0f); set ("chorus_mix", 0.20f); set ("amp_release", 0.82f); break;
                    case 28: // tape-like choir layer through formants
                        set ("osc1_level", 0.56f); set ("osc2_level", 0.38f); set ("osc3_level", 0.16f); set ("filter_mode", 11.0f);
                        set ("filter_cutoff", 2450.0f); set ("amp_attack", 0.20f); set ("amp_sustain", 0.68f); set ("amp_release", 2.1f);
                        set ("reverb_mix", 0.24f); break;
                    case 29: // slow brass chord bed
                        set ("osc1_unison", 4.0f); set ("osc1_udet", 8.0f); set ("osc2_level", 0.34f); set ("osc2_semi", 7.0f);
                        set ("filter_mode", 1.0f); set ("filter_cutoff", 2850.0f); set ("amp_attack", 0.28f); set ("amp_sustain", 0.78f);
                        set ("amp_release", 1.40f); set ("reverb_mix", 0.18f); break;
                }
            }

            const auto fullName = juce::String ("THIS IS SALEK/") + bankLabels[bank] + "/"
                                + juce::String (i + 1).paddedLeft ('0', 2) + " - " + names[bank][i];
            result.push_back ({ fullName, std::move (values) });
        }
    return result;
}
}
