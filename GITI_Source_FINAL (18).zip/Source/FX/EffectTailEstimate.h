#pragma once

#include <algorithm>
#include <cmath>

namespace salek
{
/** Conservative audible-tail estimate for the current serial FX chain.
    Delay feedback is measured to -60 dB; reverb uses its RT60-style control. */
inline double estimateEffectTailSeconds (float delayMix, float delayTimeMs, float delayFeedback,
                                         float chorusMix, float reverbMix, float reverbDecay,
                                         float ampReleaseSeconds) noexcept
{
    double tail = std::clamp (ampReleaseSeconds, 0.0f, 10.0f);

    if (chorusMix > 1.0e-4f)
        tail += 0.06; // maximum modulated delay line length

    if (delayMix > 1.0e-4f)
    {
        const double delaySeconds = std::max (0.001, std::clamp (delayTimeMs, 0.0f, 1800.0f)
                                                    * 0.001 * 1.07);
        const double feedback = std::clamp (static_cast<double> (delayFeedback), 0.0, 0.95);
        tail += feedback > 1.0e-5
              ? delaySeconds * std::log (0.001) / std::log (feedback)
              : delaySeconds;
    }

    if (reverbMix > 1.0e-4f)
    {
        const double decay = std::clamp (static_cast<double> (reverbDecay), 0.05, 0.98);
        // A little headroom covers the longest comb/AP path and the early taps.
        tail += (0.25 + decay * decay * 8.0) * 1.12 + 0.12;
    }

    return tail;
}
} // namespace salek
