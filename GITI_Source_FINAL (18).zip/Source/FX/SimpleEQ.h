#pragma once
#include <JuceHeader.h>
#include <cmath>

namespace salek
{
// Musical three-band EQ: low/high shelves with a broad peaking mid band.
// Coefficients and wet/dry mix glide smoothly; sample processing is allocation-free.
class SimpleEQ
{
public:
    void prepare (double sr, int)
    {
        sampleRate = sr > 1000.0 ? sr : 44100.0;
        mixSmoothCoeff = 1.0f - std::exp (-1.0f / (0.010f * (float) sampleRate));
        coeffSmoothCoeff = 1.0f - std::exp (-1.0f / (0.018f * (float) sampleRate));
        reset();
        update();
        lowGain = targetLowGain; highGain = targetHighGain;
        b0 = targetB0; b1 = targetB1; b2 = targetB2; a1 = targetA1; a2 = targetA2;
        mixSmoothValue = mix;
    }
    void reset() noexcept
    {
        lowState[0] = lowState[1] = highState[0] = highState[1] = 0.0f;
        z1[0] = z1[1] = z2[0] = z2[1] = 0.0f;
    }
    void setLowGainDb (float db)  { db = juce::jlimit (-12.0f, 12.0f, db); if (std::abs (db - lowDb) > 1.0e-4f) { lowDb = db; update(); } }
    void setMidGainDb (float db)  { db = juce::jlimit (-12.0f, 12.0f, db); if (std::abs (db - midDb) > 1.0e-4f) { midDb = db; update(); } }
    void setHighGainDb (float db) { db = juce::jlimit (-12.0f, 12.0f, db); if (std::abs (db - highDb) > 1.0e-4f) { highDb = db; update(); } }
    void setMix (float value) noexcept { mix = juce::jlimit (0.f, 1.f, value); }
    bool needsProcessing() const noexcept
    {
        const bool targetHasTone = std::abs (lowDb) > 1.0e-3f
                                || std::abs (midDb) > 1.0e-3f
                                || std::abs (highDb) > 1.0e-3f;
        const bool coefficientsSettling = std::abs (lowGain - targetLowGain) > 1.0e-4f
                                       || std::abs (highGain - targetHighGain) > 1.0e-4f
                                       || std::abs (b0 - targetB0) > 1.0e-4f
                                       || std::abs (b1 - targetB1) > 1.0e-4f
                                       || std::abs (b2 - targetB2) > 1.0e-4f
                                       || std::abs (a1 - targetA1) > 1.0e-4f
                                       || std::abs (a2 - targetA2) > 1.0e-4f;
        return (mix > 1.0e-4f && targetHasTone)
            || (mixSmoothValue > 1.0e-4f && (targetHasTone || coefficientsSettling));
    }

    void process (juce::AudioBuffer<float>& buffer) noexcept
    {
        const int channels = juce::jmin (2, buffer.getNumChannels());
        for (int i = 0; i < buffer.getNumSamples(); ++i)
        {
            mixSmoothValue += mixSmoothCoeff * (mix - mixSmoothValue);
            lowGain += coeffSmoothCoeff * (targetLowGain - lowGain);
            highGain += coeffSmoothCoeff * (targetHighGain - highGain);
            b0 += coeffSmoothCoeff * (targetB0 - b0);
            b1 += coeffSmoothCoeff * (targetB1 - b1);
            b2 += coeffSmoothCoeff * (targetB2 - b2);
            a1 += coeffSmoothCoeff * (targetA1 - a1);
            a2 += coeffSmoothCoeff * (targetA2 - a2);
            for (int ch = 0; ch < channels; ++ch)
            {
                auto* data = buffer.getWritePointer (ch);
                float x = data[i];
                lowState[ch] += lowA * (x - lowState[ch]);
                float lowShelved = x + (lowGain - 1.0f) * lowState[ch];
                highState[ch] += highA * (x - highState[ch]);
                float highPassed = x - highState[ch];
                float highShelved = lowShelved + (highGain - 1.0f) * highPassed;

                const float midOut = b0 * highShelved + z1[ch];
                z1[ch] = b1 * highShelved - a1 * midOut + z2[ch];
                z2[ch] = b2 * highShelved - a2 * midOut;
                const float wet = std::isfinite (midOut) ? midOut : 0.0f;
                data[i] = x + (wet - x) * juce::jlimit (0.f, 1.f, mixSmoothValue);
            }
        }
    }

private:
    void update() noexcept
    {
        targetLowGain = juce::Decibels::decibelsToGain (lowDb);
        targetHighGain = juce::Decibels::decibelsToGain (highDb);
        const float sr = (float) sampleRate;
        lowA = 1.0f - std::exp (-2.0f * juce::MathConstants<float>::pi * 180.0f / sr);
        highA = 1.0f - std::exp (-2.0f * juce::MathConstants<float>::pi * 6500.0f / sr);

        // RBJ peaking filter, centre 1.2 kHz, broad Q=0.72.
        const float A = std::sqrt (juce::Decibels::decibelsToGain (midDb));
        const float w = 2.0f * juce::MathConstants<float>::pi * 1200.0f / sr;
        const float c = std::cos (w), alpha = std::sin (w) / (2.0f * 0.72f);
        const float a0 = 1.0f + alpha / A;
        targetB0 = (1.0f + alpha * A) / a0;
        targetB1 = (-2.0f * c) / a0;
        targetB2 = (1.0f - alpha * A) / a0;
        targetA1 = (-2.0f * c) / a0;
        targetA2 = (1.0f - alpha / A) / a0;
    }

    double sampleRate = 44100.0;
    float lowDb = 0.0f, midDb = 0.0f, highDb = 0.0f, mix = 0.0f;
    float lowGain = 1.0f, highGain = 1.0f, targetLowGain = 1.0f, targetHighGain = 1.0f;
    float lowA = 0.02f, highA = 0.5f;
    float b0 = 1.0f, b1 = 0.0f, b2 = 0.0f, a1 = 0.0f, a2 = 0.0f;
    float targetB0 = 1.0f, targetB1 = 0.0f, targetB2 = 0.0f, targetA1 = 0.0f, targetA2 = 0.0f;
    float mixSmoothValue = 0.0f, mixSmoothCoeff = 1.0f, coeffSmoothCoeff = 1.0f;
    float lowState[2] {}, highState[2] {}, z1[2] {}, z2[2] {};
};
}
