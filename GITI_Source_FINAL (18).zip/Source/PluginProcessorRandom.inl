#include "RandomPatch.h"

void SalekHightechAudioProcessor::applyRandomPatch (int style)
{
    pushUndoPoint();
    // start from a clean slate: every parameter back to its default, matrix cleared
    for (auto* param : getParameters())
        if (auto* rp = dynamic_cast<juce::RangedAudioParameter*> (param))
            rp->setValueNotifyingHost (rp->getDefaultValue());
    if (! factoryPresets.empty())
        for (auto& kv : factoryPresets[0].values)       // "Init" values
            if (auto* p = apvts.getParameter (kv.first))
                p->setValueNotifyingHost (p->convertTo0to1 (kv.second));

    auto patch = giti::makeRandomPatch (style, juce::Random::getSystemRandom());
    for (auto& kv : patch.v)
        if (auto* p = apvts.getParameter (kv.first))
            p->setValueNotifyingHost (p->convertTo0to1 (kv.second));

    modMatrix.clear();
    for (auto& rt : patch.routes)
        modMatrix.addRoute ((salek::ModMatrix::Source) (int) rt[0], (salek::ModMatrix::Dest) (int) rt[1], rt[2]);
}

SalekHightechAudioProcessor::Snapshot SalekHightechAudioProcessor::captureSnapshot()
{
    Snapshot s;
    for (auto* p : getParameters()) s.values.push_back (p->getValue());
    if (auto x = modMatrix.toXml()) s.matrix = x->toString();
    return s;
}

void SalekHightechAudioProcessor::applySnapshot (const Snapshot& s)
{
    restoringSnapshot = true;
    const auto& params = getParameters();
    for (int i = 0; i < (int) s.values.size() && i < params.size(); ++i)
        params[i]->setValueNotifyingHost (s.values[(size_t) i]);
    if (s.matrix.isNotEmpty()) { if (auto x = juce::XmlDocument::parse (s.matrix)) modMatrix.fromXml (x.get()); else modMatrix.clear(); }
    else modMatrix.clear();
    restoringSnapshot = false;
}

void SalekHightechAudioProcessor::pushUndoPoint()
{
    if (restoringSnapshot) return;
    undoStack.push_back (captureSnapshot());
    if (undoStack.size() > 100) undoStack.erase (undoStack.begin());
    redoStack.clear();
}

bool SalekHightechAudioProcessor::undoParams()
{
    if (undoStack.empty()) return false;
    redoStack.push_back (captureSnapshot());
    auto s = std::move (undoStack.back()); undoStack.pop_back();
    applySnapshot (s);
    return true;
}

bool SalekHightechAudioProcessor::redoParams()
{
    if (redoStack.empty()) return false;
    undoStack.push_back (captureSnapshot());
    auto s = std::move (redoStack.back()); redoStack.pop_back();
    applySnapshot (s);
    return true;
}

void SalekHightechAudioProcessor::updateCustomWavetableIfChanged()
{
    static const std::array<std::string, 64> names = [] { std::array<std::string, 64> a; for (int i = 0; i < 64; ++i) a[(size_t) i] = "custom_wt_" + std::to_string (i); return a; }();
    std::array<float, 64> v {};
    for (int i = 0; i < 64; ++i) v[(size_t) i] = fastParam (names[(size_t) i].c_str());
    if (customCacheValid && v == customCache) return;
    customCache = v; customCacheValid = true;
    salek::SynthVoice::sharedWavetableMutable().setCustomShape (v.data(), 64);
}

juce::String SalekHightechAudioProcessor::remoteInfoText()
{
    juce::String ips;
    for (auto& a : juce::IPAddress::getAllAddresses())
    {
        const auto t = a.toString();
        if (t.startsWith ("127.") || t.containsChar (':') || t.isEmpty()) continue;
        ips << "    http://" << t << ":9731\n";
    }
    if (ips.isEmpty()) ips = "    (no Wi-Fi address found - connect to a network)\n";
    return "Open this address in the phone browser (same Wi-Fi):\n\n" + ips
         + "\nPairing code:  " + giti::remote::loadOrCreatePairingCode()
         + "\n\nEnter the code on the phone page.";
}

void SalekHightechAudioProcessor::queueRemoteNote (bool on, int note, int vel)
{
    if (note < 0 || note > 127) return;
    const int w = remoteQueueWrite.load (std::memory_order_relaxed);
    const int next = (w + 1) % remoteQueueSize;
    if (next == remoteQueueRead.load (std::memory_order_acquire)) return;   // full: drop
    remoteQueue[(size_t) w] = on ? juce::MidiMessage::noteOn (1, note, (juce::uint8) juce::jlimit (1, 127, vel))
                                 : juce::MidiMessage::noteOff (1, note);
    remoteQueueWrite.store (next, std::memory_order_release);
}
