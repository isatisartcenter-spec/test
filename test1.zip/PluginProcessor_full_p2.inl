
void SalekHightechAudioProcessor::applyParamsToEngine (int samplesThisBlock)
{
    auto g = [&](const char* id) -> float { if (auto* p = apvts.getRawParameterValue(id)) return p->load(); return 0.f; };
    // Advance modulation before destinations so all sections use this block's values.
    auto setLfo = [] (salek::LFO& lfo, float rate, int wave)
    {
        lfo.setRate (rate);
        lfo.setAmount (1.0f);
        static const salek::LFO::Wave waves[] = {
            salek::LFO::Wave::Sine, salek::LFO::Wave::Triangle, salek::LFO::Wave::Saw,
            salek::LFO::Wave::Square, salek::LFO::Wave::SAndH, salek::LFO::Wave::Custom,
            salek::LFO::Wave::SmoothRnd, salek::LFO::Wave::Chaos, salek::LFO::Wave::Pulse,
            salek::LFO::Wave::Exp, salek::LFO::Wave::Sine3, salek::LFO::Wave::SoftSquare
        };
        lfo.setWave (waves[juce::jlimit (0, 11, wave)]);
    };
    auto cfgLfo = [&] (salek::LFO& lfo, const char* sy, const char* dv, const char* bp, const char* rt,
                       const char* sm, const char* ri, const char* de, const char* ph, const char* st)
    {
        lfo.setSync (g (sy) > 0.5f); lfo.setTempo (hostBpm); lfo.setDivision ((int) std::lround (g (dv)));
        lfo.setBipolar (g (bp) > 0.5f);
        lfo.setSmooth (g (sm)); lfo.setRise (g (ri)); lfo.setDelay (g (de)); lfo.setPhaseOffset (g (ph));
        lfo.setSteps ((int) std::lround (g (st)));
        if (lfoNoteTrig && g (rt) > 0.5f) lfo.retrigger();
    };
    cfgLfo (lfo1, "lfo_sync", "lfo_div", "lfo_bip", "lfo_retrig", "lfo_smooth", "lfo_rise", "lfo_delay", "lfo_phase", "lfo_steps");
    cfgLfo (lfo2, "lfo2_sync", "lfo2_div", "lfo2_bip", "lfo2_retrig", "lfo2_smooth", "lfo2_rise", "lfo2_delay", "lfo2_phase", "lfo2_steps");
    cfgLfo (lfo3, "lfo3_sync", "lfo3_div", "lfo3_bip", "lfo3_retrig", "lfo3_smooth", "lfo3_rise", "lfo3_delay", "lfo3_phase", "lfo3_steps");
    lfoNoteTrig = false;
    setLfo (lfo1, g ("lfo_rate"), (int) g ("lfo_wave"));
    setLfo (lfo2, g ("lfo2_rate"), (int) g ("lfo2_wave"));
    setLfo (lfo3, g ("lfo3_rate"), (int) g ("lfo3_wave"));
    modMatrix.setSourceValue (salek::ModMatrix::Source::LFO1, lfo1.processBlock (samplesThisBlock) * g ("lfo_amount"));
    modMatrix.setSourceValue (salek::ModMatrix::Source::LFO2, lfo2.processBlock (samplesThisBlock) * g ("lfo2_amount"));
    modMatrix.setSourceValue (salek::ModMatrix::Source::LFO3, lfo3.processBlock (samplesThisBlock) * g ("lfo3_amount"));
    static const char* macroIds[] = { "macro1", "macro2", "macro3", "macro4", "macro5", "macro6", "macro7", "macro8" };
    for (int i = 0; i < 8; ++i)
        modMatrix.setSourceValue (static_cast<salek::ModMatrix::Source> (
            static_cast<int> (salek::ModMatrix::Source::Macro1) + i), g (macroIds[i]) * 2.0f - 1.0f);
    // Deterministic xorshift: no allocation, lock, or global RNG in the callback.
    static thread_local uint32_t shaeRandState = 0x9E3779B9u;
    shaeRandState ^= shaeRandState << 13;
    shaeRandState ^= shaeRandState >> 17;
    shaeRandState ^= shaeRandState << 5;
    modMatrix.setSourceValue (salek::ModMatrix::Source::Random,
        (static_cast<float> (shaeRandState & 0x00FFFFFFu) / 16777215.0f) * 2.0f - 1.0f);
    modMatrix.setSourceValue (salek::ModMatrix::Source::Velocity, velocityValue);
    modMatrix.setSourceValue (salek::ModMatrix::Source::ModWheel, modWheelValue);
    modMatrix.setSourceValue (salek::ModMatrix::Source::Env1, synthEngine.getEnvelopeLevel());
    float o1l = juce::jlimit(0.f,1.f, g("osc1_level") + modMatrix.getModulation(salek::ModMatrix::Dest::Osc1Level));
    float o2l = juce::jlimit(0.f,1.f, g("osc2_level") + modMatrix.getModulation(salek::ModMatrix::Dest::Osc2Level));
    float o3l = juce::jlimit(0.f,1.f, g("osc3_level") + modMatrix.getModulation(salek::ModMatrix::Dest::Osc3Level));
    if (g("osc1_on") < 0.5f) o1l = 0.f;
    if (g("osc2_on") < 0.5f) o2l = 0.f;
    if (g("osc3_on") < 0.5f) o3l = 0.f;
    synthEngine.setOsc1Level(o1l); synthEngine.setOsc2Level(o2l); synthEngine.setOsc3Level(o3l);
    synthEngine.setOsc1Pan(juce::jlimit(0.f,1.f, g("osc1_pan")+modMatrix.getModulation(salek::ModMatrix::Dest::Osc1Pan)));
    synthEngine.setOsc2Pan(juce::jlimit(0.f,1.f, g("osc2_pan")+modMatrix.getModulation(salek::ModMatrix::Dest::Osc2Pan)));
    synthEngine.setOsc3Pan(juce::jlimit(0.f,1.f, g("osc3_pan")+modMatrix.getModulation(salek::ModMatrix::Dest::Osc3Pan)));
    synthEngine.setOsc1TablePos(juce::jlimit(0.f,1.f, g("osc1_table")+modMatrix.getModulation(salek::ModMatrix::Dest::Osc1Table)));
    synthEngine.setOsc2TablePos(juce::jlimit(0.f,1.f, g("osc2_table")+modMatrix.getModulation(salek::ModMatrix::Dest::Osc2Table)));
    synthEngine.setOsc3TablePos(juce::jlimit(0.f,1.f, g("osc3_table")+modMatrix.getModulation(salek::ModMatrix::Dest::Osc3Table)));
    synthEngine.setOsc1Warp(juce::jlimit(0.f,1.f, g("osc1_warp")+modMatrix.getModulation(salek::ModMatrix::Dest::Osc1Warp)));
    synthEngine.setOsc2Warp(juce::jlimit(0.f,1.f, g("osc2_warp")+modMatrix.getModulation(salek::ModMatrix::Dest::Osc2Warp)));
    synthEngine.setOsc3Warp(juce::jlimit(0.f,1.f, g("osc3_warp")+modMatrix.getModulation(salek::ModMatrix::Dest::Osc3Warp)));
    synthEngine.setOsc1Fold(juce::jlimit(0.f,1.f, g("osc1_fold")+modMatrix.getModulation(salek::ModMatrix::Dest::Osc1Fold)));
    synthEngine.setOsc2Fold(juce::jlimit(0.f,1.f, g("osc2_fold")+modMatrix.getModulation(salek::ModMatrix::Dest::Osc2Fold)));
    synthEngine.setOsc3Fold(juce::jlimit(0.f,1.f, g("osc3_fold")+modMatrix.getModulation(salek::ModMatrix::Dest::Osc3Fold)));
    synthEngine.setOsc1Drive(juce::jlimit(0.f,1.f,g("osc1_drive")+modMatrix.getModulation(salek::ModMatrix::Dest::Osc1Drive)));
    synthEngine.setOsc2Drive(juce::jlimit(0.f,1.f,g("osc2_drive")+modMatrix.getModulation(salek::ModMatrix::Dest::Osc2Drive)));
    synthEngine.setOsc3Drive(juce::jlimit(0.f,1.f,g("osc3_drive")+modMatrix.getModulation(salek::ModMatrix::Dest::Osc3Drive)));
    synthEngine.setOsc1Phase(g("osc1_phase")); synthEngine.setOsc2Phase(g("osc2_phase")); synthEngine.setOsc3Phase(g("osc3_phase"));
    synthEngine.setOsc1Rand(g("osc1_rand")); synthEngine.setOsc2Rand(g("osc2_rand")); synthEngine.setOsc3Rand(g("osc3_rand"));
    synthEngine.setOsc1Octave((int)g("osc1_octave")); synthEngine.setOsc2Octave((int)g("osc2_octave")); synthEngine.setOsc3Octave((int)g("osc3_octave"));
    synthEngine.setOsc1Semi((int)g("osc1_semi")); synthEngine.setOsc2Semi((int)g("osc2_semi")); synthEngine.setOsc3Semi((int)g("osc3_semi"));
    synthEngine.setOsc1CoarsePitch((int)g("osc1_coarse")); synthEngine.setOsc2CoarsePitch((int)g("osc2_coarse")); synthEngine.setOsc3CoarsePitch((int)g("osc3_coarse"));
    synthEngine.setOsc1Fine(g("osc1_fine")); synthEngine.setOsc2Fine(g("osc2_fine")); synthEngine.setOsc3Fine(g("osc3_fine"));
    synthEngine.setOsc1Detune(g("osc1_detune")); synthEngine.setOsc2Detune(g("osc2_detune")); synthEngine.setOsc3Detune(g("osc3_detune"));
    synthEngine.setUnison((int)g("unison_voices"));
    synthEngine.setUnisonDetune(g("unison_detune"));
    synthEngine.setUnisonSpread(g("unison_spread"));
    // The global controls act as a shared scale/offset; oscillator-specific
    // controls can still be shaped independently. Defaults combine neutrally.
    {
        const int globalVoices = juce::jlimit (1, 7, (int) std::lround (g("unison_voices")));
        const float globalDetuneOffset = g("unison_detune") - 12.0f;
        const float globalSpreadOffset = g("unison_spread") - 0.7f;
        const int u1 = juce::jlimit (1, 7, globalVoices + (int) std::lround (g("osc1_unison")) - 1);
        const int u2 = juce::jlimit (1, 7, globalVoices + (int) std::lround (g("osc2_unison")) - 1);
        const int u3 = juce::jlimit (1, 7, globalVoices + (int) std::lround (g("osc3_unison")) - 1);
        const float d1 = juce::jlimit (0.f, 50.f, g("osc1_udet") + globalDetuneOffset);
        const float d2 = juce::jlimit (0.f, 50.f, g("osc2_udet") + globalDetuneOffset);
        const float d3 = juce::jlimit (0.f, 50.f, g("osc3_udet") + globalDetuneOffset);
        const float s1 = juce::jlimit (0.f, 1.f, g("osc1_uspread") + globalSpreadOffset);
        const float s2 = juce::jlimit (0.f, 1.f, g("osc2_uspread") + globalSpreadOffset);
        const float s3 = juce::jlimit (0.f, 1.f, g("osc3_uspread") + globalSpreadOffset);
        synthEngine.setOsc1Unison (u1, d1, s1);
        synthEngine.setOsc2Unison (u2, d2, s2);
        synthEngine.setOsc3Unison (u3, d3, s3);
    }
    synthEngine.setFm2to1(juce::jlimit(0.f,1.f, g("fm_2to1")+modMatrix.getModulation(salek::ModMatrix::Dest::Fm2to1)));
    synthEngine.setFm3to1(juce::jlimit(0.f,1.f, g("fm_3to1")+modMatrix.getModulation(salek::ModMatrix::Dest::Fm3to1)));
    synthEngine.setFm3to2(g("fm_3to2"));
    synthEngine.setPitchModulation (modMatrix.getModulation (salek::ModMatrix::Dest::Pitch) * 1200.0f);
    synthEngine.setPm2to1(g("pm_2to1"));
    synthEngine.setRm2to1(g("rm_2to1"));
    synthEngine.setAm2to1(g("am_2to1"));
    float cut = g("filter_cutoff");
    float reso = g("filter_reso");
    // Smart macros: 1=Bright 2=Space 3=Destroy 4=Width
    const float mBright = g("macro1");
    const float mSpace  = g("macro2");
    const float mWidth  = g("macro4");
    // Smart macros are neutral at their midpoint, so fresh presets do not
    // silently darken the filter, narrow the stereo image, or suppress FX.
    cut *= (0.70f + mBright * 0.60f);
    reso = juce::jlimit (0.f, 0.98f, reso + (mBright - 0.5f) * 0.15f);
    // space → delay/reverb (applied later via param push if available)
    // push smart macros into FX (non-destructive scale)
    if (auto* p = apvts.getParameter ("delay_mix"))
        juce::ignoreUnused (p);
    // runtime scale in render path:
    // stored as members for voice/FX - apply on buffer FX stage below
    const float spaceScale = 0.5f + mSpace;
    const float widthScale = 0.5f + mWidth;
    cut *= std::pow(2.0f, modMatrix.getModulation(salek::ModMatrix::Dest::FilterCutoff) * 4.0f);
    synthEngine.setFilterCutoff(juce::jlimit(20.f, 20000.f, cut));
    synthEngine.setFilterResonance(juce::jlimit(0.f,1.f, reso+modMatrix.getModulation(salek::ModMatrix::Dest::FilterReso)));
    synthEngine.setFilterDrive(juce::jlimit(0.f,1.f,g("filter_drive")+modMatrix.getModulation(salek::ModMatrix::Dest::FilterDrive))); synthEngine.setFilterEnvAmt(juce::jlimit(0.f,1.f,g("filter_env")+modMatrix.getModulation(salek::ModMatrix::Dest::FilterEnv)));
    synthEngine.setFilterMode((int)g("filter_mode"));
    synthEngine.setFilterRoute((int)g("filter_route"));
    synthEngine.setFilter2Cutoff(juce::jlimit(20.f,20000.f,g("filter2_cutoff")*std::pow(2.0f,modMatrix.getModulation(salek::ModMatrix::Dest::Filter2Cutoff)*4.0f)));
    synthEngine.setFilter2Resonance(juce::jlimit(0.f,1.f,g("filter2_reso")+modMatrix.getModulation(salek::ModMatrix::Dest::Filter2Reso)));
    synthEngine.setFilter2Drive(juce::jlimit(0.f,1.f,g("filter2_drive")+modMatrix.getModulation(salek::ModMatrix::Dest::Filter2Drive)));
    synthEngine.setFilter2EnvAmt(juce::jlimit(0.f,1.f,g("filter2_env")));
    synthEngine.setFilter2Mode((int)g("filter2_mode"));
    synthEngine.setFilter1Mix(juce::jlimit(0.f,1.f,g("filter1_mix")+modMatrix.getModulation(salek::ModMatrix::Dest::Filter1Mix)));
    synthEngine.setFilter2Mix(juce::jlimit(0.f,1.f,g("filter2_mix")+modMatrix.getModulation(salek::ModMatrix::Dest::Filter2Mix)));
    synthEngine.setFilter1Src((int)g("filter1_src"));
    synthEngine.setFilter2Src((int)g("filter2_src"));
    synthEngine.setNoiseLevel(g("noise_on") < 0.5f ? 0.f : juce::jlimit(0.f,1.f, g("noise_level")+modMatrix.getModulation(salek::ModMatrix::Dest::NoiseLevel)));
    synthEngine.setSubLevel(g("sub_on") < 0.5f ? 0.f : juce::jlimit(0.f,1.f, g("sub_level")+modMatrix.getModulation(salek::ModMatrix::Dest::SubLevel)));
    synthEngine.setNoiseType((int)std::lround(g("noise_type")));
    synthEngine.setNoiseTone(g("noise_tone")); synthEngine.setNoisePan(g("noise_pan"));
    synthEngine.setSubOctave((int)std::lround(g("sub_octave"))); synthEngine.setSubSemi((int)std::lround(g("sub_semi"))); synthEngine.setSubPan(g("sub_pan"));
    synthEngine.setGlide (g ("glide"));
    synthEngine.setVoiceMode ((int) g ("voice_mode"), (int) std::lround (g ("poly_voices")));
    synthEngine.setAmpAttack(g("amp_attack")); synthEngine.setAmpDecay(g("amp_decay"));
    synthEngine.setAmpSustain(g("amp_sustain")); synthEngine.setAmpRelease(g("amp_release"));
    synthEngine.setLfoRate(g("lfo_rate")); synthEngine.setLfoAmount(g("lfo_amount")); synthEngine.setLfoWave((int)g("lfo_wave"));
    synthEngine.setScaleMode((int)g("scale_mode"));
    synthEngine.setKoronCents(g("koron_cents"));

    const auto enabledMix = [&] (const char* mixId, const char* bypassId, float scale = 1.f, float modulation = 0.f)
    {
        return g (bypassId) > 0.5f ? 0.f
            : juce::jlimit (0.f, 1.f, g (mixId) * scale + modulation);
    };
    delay.setMix (enabledMix ("delay_mix", "delay_bypass", spaceScale,
                              modMatrix.getModulation (salek::ModMatrix::Dest::DelayMix)));
    // TIME is a shared shift around the saved L/R centre values; this keeps
    // old stereo presets intact while making all three time controls audible.
    const float delayMasterTime = g ("delay_time");
    delay.setTimeMsL (delayMasterTime + g ("delay_time_l") - 280.0f);
    delay.setTimeMsR (delayMasterTime + g ("delay_time_r") - 280.0f);
    delay.setFeedback(g("delay_fb"));
    delay.setTone(g ("delay_tone"));
    delay.setMode((int) g("delay_mode"));
    chorus.setMix (enabledMix ("chorus_mix", "chorus_bypass", widthScale,
                               modMatrix.getModulation (salek::ModMatrix::Dest::ChorusMix)));
    chorus.setRate(g("chorus_rate")); chorus.setDepth(g("chorus_depth"));
    reverb.setMix (enabledMix ("reverb_mix", "reverb_bypass", spaceScale,
                               modMatrix.getModulation (salek::ModMatrix::Dest::ReverbMix)));
    reverb.setSize(g("reverb_size")); reverb.setDecay(g("reverb_decay"));
    reverb.setMode ((int) g("reverb_mode"));
    reverb.setDamping (g ("reverb_damp"));
    phaser.setMix (enabledMix ("phaser_mix", "phaser_bypass", 1.f,
                              modMatrix.getModulation (salek::ModMatrix::Dest::PhaserMix)));
    phaser.setRate(g("phaser_rate")); phaser.setDepth(g("phaser_depth"));
    distortion.setMix (enabledMix ("dist_mix", "dist_bypass", 1.f,
                                   modMatrix.getModulation (salek::ModMatrix::Dest::DistMix)));
    distortion.setDrive(juce::jlimit(0.f,1.f,g("dist_drive")+modMatrix.getModulation(salek::ModMatrix::Dest::DistDrive))); distortion.setBitcrush(g("dist_crush"));
    distortion.setMode ((int) g("dist_mode"));
    compressor.setThresholdDb(g("comp_threshold")); compressor.setRatio(g("comp_ratio"));
    compressor.setMix (g ("comp_bypass") > 0.5f ? 0.f : g ("comp_mix"));
    compressor.setDepth(g("comp_depth")); compressor.setAttackMs(g("comp_attack")); compressor.setReleaseMs(g("comp_release"));
    compressor.setMakeupDb(g("comp_gain"));
    // Independent LO / MID / HI thresholds (overrides global offsets when set)
    compressor.setBandThresholdDb (0, g("comp_thr_lo"));
    compressor.setBandThresholdDb (1, g("comp_thr_mid"));
    compressor.setBandThresholdDb (2, g("comp_thr_hi"));
    eq.setLowGainDb(g("eq_low")); eq.setMidGainDb(g("eq_mid")); eq.setHighGainDb(g("eq_high"));
    eq.setMix (g ("eq_bypass") > 0.5f ? 0.f : 1.f);
    spatial.setAzimuth(g("spatial_azim")); spatial.setDistance(g("spatial_dist"));
    spatial.setSize(g("spatial_size")); spatial.setElevation(g("spatial_elev"));

    magic.setMode ((int) g("magic_mode"));
    {
        float mx = juce::jlimit (0.f, 1.f, g("magic_x") + modMatrix.getModulation (salek::ModMatrix::Dest::MagicX));
        float my = juce::jlimit (0.f, 1.f, g("magic_y") + modMatrix.getModulation (salek::ModMatrix::Dest::MagicY));
        const bool seqMotion = g ("seq_on") > 0.5f && g ("seq_magic_target") > 0.5f;
        if (seqMotion)
        {
            const float step = stepSequencer.getCurrentMod();
            const float bipolar = step * 2.0f - 1.0f;
            const float depth = g ("seq_magic_depth");
            const int target = (int) g ("seq_magic_target");
            if (target == 1 || target == 3) mx += bipolar * depth;
            if (target == 2 || target == 3) my += bipolar * depth;
        }
        magic.setXY (mx, my);
        // A selected SEQ→Magic lane is a performance source: it can animate
        // the held effect without needing a MIDI note to start the sequencer.
        magic.setActive (g ("magic_on") > 0.5f || seqMotion);
    }
}

void SalekHightechAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    const auto callbackStart = std::chrono::steady_clock::now();
    juce::ScopedNoDenormals noDenormals;
    for (auto i = getTotalNumInputChannels(); i < getTotalNumOutputChannels(); ++i)
        buffer.clear (i, 0, buffer.getNumSamples());

    if (presetVoiceResetRequested.exchange (false, std::memory_order_acquire))
    {
        keyboardState.allNotesOff (0);
        synthEngine.allNotesOff();
    }

    keyboardState.processNextMidiBuffer (midi, 0, buffer.getNumSamples(), true);
    // Capture live MIDI sources before evaluating the modulation matrix.
    for (const auto metadata : midi)
    {
        const auto message = metadata.getMessage();
        if (message.isNoteOn())
        {
            velocityValue = message.getFloatVelocity();
            lfoNoteTrig = true;
        }
        else if (message.isController() && message.getControllerNumber() == 1)
            modWheelValue = static_cast<float> (message.getControllerValue()) / 127.0f;
    }
    if (auto* ph = getPlayHead())
        if (auto pos = ph->getPosition())
            if (auto b = pos->getBpm()) hostBpm = *b;
    applyParamsToEngine (buffer.getNumSamples());

    const bool seqOn = apvts.getRawParameterValue("seq_on")->load() > 0.5f;
    const bool arpOn = apvts.getRawParameterValue("arp_on")->load() > 0.5f;
    if (seqOn)
    {
        stepSequencer.setRateDivisor ((int) apvts.getRawParameterValue("seq_rate")->load());
        stepSequencer.setPatternLength ((int) apvts.getRawParameterValue("seq_length")->load());
        stepSequencer.setSwing (apvts.getRawParameterValue("seq_swing")->load());
        stepSequencer.setGate (apvts.getRawParameterValue("seq_gate")->load());
    }
    if (arpOn)
    {
        arpeggiator.setRateDivisor ((int) apvts.getRawParameterValue("arp_rate")->load());
        arpeggiator.setOctaves ((int) apvts.getRawParameterValue("arp_octaves")->load());
        arpeggiator.setGate (apvts.getRawParameterValue("arp_gate")->load());
        arpeggiator.setSwing (apvts.getRawParameterValue("arp_swing")->load());
    }
    // Release generated notes on the transition to bypass. Otherwise the
    // generators stop receiving callbacks and their last note can hang.
    if (! seqOn && stepSequencer.isEnabled()) stepSequencer.stop (midi);
    if (! arpOn && arpeggiator.isEnabled()) arpeggiator.stop (midi);
    stepSequencer.setEnabled (seqOn);
    arpeggiator.setEnabled (arpOn);

    // Leave MIDI untouched on the common path when both generators are off;
    // copying it into temporary buffers every audio block caused avoidable
    // allocator and event-copy work during ordinary synth playback.
    if (seqOn || arpOn)
    {
        routedMidiBuffer.clear();
        routedMidiBuffer.addEvents (midi, 0, buffer.getNumSamples(), 0);

        if (seqOn)
        {
            for (const auto metadata : midi)
            {
                const auto msg = metadata.getMessage();
                if (msg.isNoteOn()) stepSequencer.setRootNote (msg.getNoteNumber());
            }
            stepSequencer.process(buffer.getNumSamples(), routedMidiBuffer);
        }

        if (arpOn)
        {
            arpMidiBuffer.clear();
            for (const auto metadata : routedMidiBuffer)
            {
                const auto msg = metadata.getMessage();
                if (msg.isNoteOn())
                    arpeggiator.noteOn (msg.getNoteNumber(), msg.getFloatVelocity());
                else if (msg.isNoteOff())
                    arpeggiator.noteOff (msg.getNoteNumber());
                else
                    arpMidiBuffer.addEvent (msg, metadata.samplePosition);
            }
            routedMidiBuffer.clear();
            routedMidiBuffer.addEvents (arpMidiBuffer, 0, buffer.getNumSamples(), 0);
            arpeggiator.process (buffer.getNumSamples(), routedMidiBuffer);
        }

        midi.swapWith (routedMidiBuffer);
    }

    // This instrument exposes an optional audio input. Preserve it only at the
    // user-selected input mix, and clear unused output channels before voices
    // are rendered into the buffer.
    const int inputChannels = juce::jmin (getTotalNumInputChannels(), buffer.getNumChannels());
    const float inputMix = juce::jlimit (0.0f, 1.0f, apvts.getRawParameterValue ("input_mix")->load());
    for (int ch = 0; ch < inputChannels; ++ch)
        buffer.applyGain (ch, 0, buffer.getNumSamples(), inputMix);
    for (int ch = inputChannels; ch < buffer.getNumChannels(); ++ch)
        buffer.clear (ch, 0, buffer.getNumSamples());

    synthEngine.processBlock(buffer, midi);
    modMatrix.setSourceValue (salek::ModMatrix::Source::Env1, synthEngine.getEnvelopeLevel());

    auto g = [&](const char* id) -> float {
        if (auto* p = apvts.getRawParameterValue (id))
            return p->load();
        return 0.f;
    };
   
    const float bassifyTarget = g ("bassify_bypass") > 0.5f ? 0.f
        : juce::jlimit (0.f, 1.f, g ("bassify")
            + modMatrix.getModulation (salek::ModMatrix::Dest::Bassify));
    if (bassifyTarget > 1e-4f || bassifyMixSmooth > 1e-4f)
    {
        const float a1 = 0.04f + bassifyTarget * 0.06f;
        const float a2 = 0.12f + bassifyTarget * 0.10f;
        for (int i = 0; i < buffer.getNumSamples(); ++i)
        {
            bassifyMixSmooth += bassifyMixCoeff * (bassifyTarget - bassifyMixSmooth);
            const float amount = juce::jlimit (0.f, 1.f, bassifyMixSmooth);
            float L = buffer.getSample (0, i);
            float R = buffer.getNumChannels() > 1 ? buffer.getSample (1, i) : L;
            bassifyState[0] += a1 * (L - bassifyState[0]);
            bassifyState[1] += a1 * (R - bassifyState[1]);
            bassifyState[2] += a2 * (bassifyState[0] - bassifyState[2]);
            bassifyState[3] += a2 * (bassifyState[1] - bassifyState[3]);
            float sub = 0.5f * (bassifyState[2] + bassifyState[3]);
            float grit = amount * 0.4f;
            sub = sub + grit * sub * sub * (sub >= 0.f ? 1.f : -1.f);
            sub = std::tanh (sub * (1.2f + amount * 1.6f));
            float dryKeep = 1.f - amount * 0.25f;
            float wet = sub * amount * 0.85f;
            buffer.setSample (0, i, L * dryKeep + wet);
            if (buffer.getNumChannels() > 1)
                buffer.setSample (1, i, R * dryKeep + wet);
        }
    }
    publishFxActivity (3, buffer);

    // Each FX owns a short, sample-rate-aware wet/dry ramp. Keep processing
    // during the fade so bypass and Mix automation do not click.
    chorus.process (buffer);
    publishFxActivity (0, buffer);
    phaser.process (buffer);
    publishFxActivity (6, buffer);
    distortion.process (buffer);
    publishFxActivity (7, buffer);
    if (eq.needsProcessing()) eq.process (buffer);
    publishFxActivity (5, buffer);
    compressor.process (buffer);
    publishFxActivity (4, buffer);
    delay.process (buffer);
    publishFxActivity (1, buffer);
    reverb.process (buffer);
    publishFxActivity (2, buffer);
    {
        const float az = std::abs (g ("spatial_azim"));
        const float ds = g ("spatial_dist");
        const float sizeDelta = std::abs (g ("spatial_size") - 0.5f);
        if (az > 0.5f || ds > 1e-3f || sizeDelta > 1e-3f || std::abs (g ("spatial_elev")) > 0.5f)
            spatial.process (buffer);
    }

    if (auto* gm = apvts.getRawParameterValue ("granular_mix"))
    {
        const float gMix = gm->load();
        if (gMix > 1e-4f)
        {
            granular.setMix (gMix);
            if (auto* p = apvts.getRawParameterValue ("granular_density")) granular.setDensity (p->load());
            if (auto* p = apvts.getRawParameterValue ("granular_size"))    granular.setGrainSize (p->load());
            if (auto* p = apvts.getRawParameterValue ("granular_pos"))     granular.setPosition (p->load());
            if (auto* p = apvts.getRawParameterValue ("granular_pitch"))   granular.setPitch (p->load());
            if (auto* p = apvts.getRawParameterValue ("granular_freeze"))  granular.setFreeze (p->load() > 0.5f);
            if (auto* p = apvts.getRawParameterValue ("granular_spray"))   granular.setSpray (p->load());
            if (auto* p = apvts.getRawParameterValue ("granular_pitchspray")) granular.setPitchSpray (p->load());
            if (auto* p = apvts.getRawParameterValue ("granular_feedback")) granular.setFeedback (p->load());
            granular.process (buffer);
        }
    }

    magic.process (buffer);

    const float gainTarget = juce::jlimit(0.f, 2.f, apvts.getRawParameterValue("master_gain")->load()
        + modMatrix.getModulation(salek::ModMatrix::Dest::Amp)*0.35f);
    const float destroy = apvts.getRawParameterValue ("macro3")->load();
    const float driveTarget = juce::jlimit(0.f, 1.f, apvts.getRawParameterValue("master_drive")->load()
        + modMatrix.getModulation(salek::ModMatrix::Dest::MasterDrive)*0.25f + destroy * 0.5f);
    // Default is a transparent gain stage. Master Drive adds one intentional
    // normalized saturator; the SHAE safety limiter remains the final ceiling.
    for (int i = 0; i < buffer.getNumSamples(); ++i)
    {
        masterGainSmooth += masterSmoothCoeff * (gainTarget - masterGainSmooth);
        masterDriveSmooth += masterSmoothCoeff * (driveTarget - masterDriveSmooth);
        for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
        {
            auto* d = buffer.getWritePointer (ch);
            float x = d[i] * masterGainSmooth;
            if (masterDriveSmooth > 1.0e-4f)
                x = shae::softClip (x, 1.0f + masterDriveSmooth * 4.0f);
            d[i] = x;
        }
    }

    // SHAE final safety stage: DC blocking + finite-value protection + conservative ceiling.
    shaeSafety.process (buffer);

    float peak = 0.f;
    for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
        peak = juce::jmax (peak, buffer.getMagnitude (ch, 0, buffer.getNumSamples()));
    outputPeak.store (peak);
    visualFifo.pushStereo (buffer);

    const float elapsedMs = std::chrono::duration<float, std::milli> (
        std::chrono::steady_clock::now() - callbackStart).count();
    const double sampleRate = getSampleRate();
    const float budgetMs = sampleRate > 0.0
        ? (1000.0f * (float) buffer.getNumSamples() / (float) sampleRate) : 0.0f;
    const float load = budgetMs > 0.0f ? juce::jlimit (0.f, 999.f, elapsedMs * 100.f / budgetMs) : 0.f;
    const float prior = audioLoadPercent.load (std::memory_order_relaxed);
    audioLoadPercent.store (prior + 0.18f * (load - prior), std::memory_order_relaxed);
    audioCallbackMs.store (elapsedMs, std::memory_order_relaxed);
    float peakLoad = audioPeakLoadPercent.load (std::memory_order_relaxed);
    while (load > peakLoad && ! audioPeakLoadPercent.compare_exchange_weak (
               peakLoad, load, std::memory_order_relaxed, std::memory_order_relaxed)) {}
}

void SalekHightechAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    juce::XmlElement root ("SALEK_STATE");
    root.setAttribute ("version", 2);
    root.setAttribute ("program", currentProgram);
    if (auto ap = apvts.copyState().createXml())
        root.addChildElement (new juce::XmlElement (*ap));
    // Persist LFO/mod routes with project + host preset save
    if (auto mx = modMatrix.toXml())
        root.addChildElement (mx.release());
    copyXmlToBinary (root, destData);
}
void SalekHightechAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary (data, sizeInBytes))
    {
        if (xml->hasTagName ("SALEK_STATE"))
        {
            if (auto* ap = xml->getChildByName (apvts.state.getType()))
                apvts.replaceState (juce::ValueTree::fromXml (*ap));
            // Restore mod routes (empty/missing child = clear matrix)
            modMatrix.fromXml (xml->getChildByName ("MOD_MATRIX"));
            const int prog = xml->getIntAttribute ("program", -1);
            if (prog >= 0 && prog < (int) factoryPresets.size())
                currentProgram = prog;
        }
        else if (xml->hasTagName (apvts.state.getType()))
        {
            apvts.replaceState (juce::ValueTree::fromXml (*xml));
            modMatrix.clear();
        }
    }
}

juce::AudioProcessorEditor* SalekHightechAudioProcessor::createEditor()
{
    return new SalekHightechAudioProcessorEditor (*this);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new SalekHightechAudioProcessor();
}
