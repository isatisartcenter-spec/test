@echo off
setlocal EnableDelayedExpansion
title GITI BY SALEK HIGHTECH - Windows build + install
cd /d "%~dp0"
rem ---------------------------------------------------------------
rem  Usage:   BUILD_WINDOWS.bat          -> Genesis 01  (GITI BY SALEK HIGHTECH V01)
rem           BUILD_WINDOWS.bat 7        -> Genesis 07  (GITI BY SALEK HIGHTECH V07)
rem  Builds the VST3 + Standalone, copies them to .\Builds and INSTALLS the VST3 so your DAW sees it.
rem ---------------------------------------------------------------
set "GEN=%~1"
if "%GEN%"=="" set "GEN=1"
set /a GENNUM=%GEN% 2>nul
if %GENNUM% LSS 1 (echo Genesis must be 1..50 & pause & exit /b 1)
if %GENNUM% GTR 50 (echo Genesis must be 1..50 & pause & exit /b 1)
set "NN=0%GENNUM%"
set "NN=%NN:~-2%"
set "PNAME=GITI BY SALEK HIGHTECH V%NN%"
echo ============================================
echo  Building: %PNAME%
echo ============================================

if not exist "Source\PluginEditor.cpp" (
  echo ERROR: put this file in the project root, next to CMakeLists.txt and the Source folder.
  pause & exit /b 1
)

rem ---- 1. Visual Studio C++ tools ----
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
set "VSPATH="
if exist "%VSWHERE%" (
  for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VSPATH=%%i"
)
if not defined VSPATH (
  echo Visual Studio C++ build tools not found. Installing Build Tools 2022 with winget...
  winget install --id Microsoft.VisualStudio.2022.BuildTools -e --override "--passive --wait --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended"
  for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VSPATH=%%i"
)
if not defined VSPATH (
  echo ERROR: could not find or install the C++ build tools. Install "Desktop development with C++" and run again.
  pause & exit /b 1
)
call "%VSPATH%\VC\Auxiliary\Build\vcvars64.bat" >nul || (echo vcvars64 failed & pause & exit /b 1)

rem ---- 2. cmake / ninja / git ----
where cmake >nul 2>nul || set "PATH=%VSPATH%\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin;%PATH%"
where ninja >nul 2>nul || set "PATH=%VSPATH%\Common7\IDE\CommonExtensions\Microsoft\CMake\Ninja;%PATH%"
where git >nul 2>nul || (echo Installing Git... & winget install --id Git.Git -e --silent & set "PATH=%ProgramFiles%\Git\cmd;%PATH%")
where cmake >nul 2>nul || (echo ERROR: cmake not found. & pause & exit /b 1)
where ninja >nul 2>nul || (echo ERROR: ninja not found. Run: winget install Ninja-build.Ninja & pause & exit /b 1)

rem ---- 3. JUCE ----
if not exist "JUCE\CMakeLists.txt" (
  echo Downloading JUCE 8.0.4...
  git clone --depth 1 --branch 8.0.4 https://github.com/juce-framework/JUCE.git JUCE || (echo JUCE download failed & pause & exit /b 1)
)

rem ---- 4. build (separate build folder per Genesis) ----
set "BDIR=build_g%NN%"
cmake -S . -B %BDIR% -G Ninja -DCMAKE_BUILD_TYPE=Release -DGITI_GENESIS=%GENNUM% || (echo Configure failed & pause & exit /b 1)
cmake --build %BDIR% --config Release --parallel --target GITI_BY_SALEK_HIGHTECH_VST3 GITI_BY_SALEK_HIGHTECH_Standalone || (echo Build failed & pause & exit /b 1)

rem ---- 5. copy results ----
set "ART=%BDIR%\GITI_BY_SALEK_HIGHTECH_artefacts\Release"
if not exist "Builds\VST3" mkdir "Builds\VST3"
if not exist "Builds\Standalone" mkdir "Builds\Standalone"
if exist "Builds\VST3\%PNAME%.vst3" rmdir /s /q "Builds\VST3\%PNAME%.vst3"
xcopy "%ART%\VST3\*" "Builds\VST3\" /E /I /Y >nul
xcopy "%ART%\Standalone\*" "Builds\Standalone\" /E /I /Y >nul

rem ---- 6. INSTALL the VST3 where DAWs look for it ----
set "SYS=%CommonProgramFiles%\VST3"
set "USR=%LOCALAPPDATA%\Programs\Common\VST3"
set "INSTALLED="
if exist "%SYS%\%PNAME%.vst3" rmdir /s /q "%SYS%\%PNAME%.vst3" 2>nul
xcopy "Builds\VST3\%PNAME%.vst3" "%SYS%\%PNAME%.vst3\" /E /I /Y >nul 2>nul && set "INSTALLED=%SYS%"
if not defined INSTALLED (
  if not exist "%USR%" mkdir "%USR%"
  xcopy "Builds\VST3\%PNAME%.vst3" "%USR%\%PNAME%.vst3\" /E /I /Y >nul 2>nul && set "INSTALLED=%USR%"
)

echo.
echo ============================================
echo  DONE:  %PNAME%
echo  Standalone: %CD%\Builds\Standalone
echo  VST3 built: %CD%\Builds\VST3\%PNAME%.vst3
if defined INSTALLED (echo  VST3 installed to: !INSTALLED!) else (echo  Could not auto-install: right-click this file ^> Run as administrator, or copy the .vst3 folder to "%SYS%")
echo.
echo  In your DAW: RESCAN plugins. The plugin is called "%PNAME%" ^(new name = new plugin^).
echo  An OLD "GITI BY SALEK HIGHTECH.vst3" in "%SYS%" is a different plugin - remove it to avoid mixing them up.
echo ============================================
pause
