        // MOD tab: FM/PM/RM/AM + Macros only (LFO rate/amt live on LFO tab)
        addKnob (modTab, "fm_2to1", "FM 2>1", O);
        addKnob (modTab, "fm_3to1", "FM 3>1", O);
        addKnob (modTab, "fm_3to2", "FM 3>2", O);
        addKnob (modTab, "pm_2to1", "PM 2>1", M);
        addKnob (modTab, "rm_2to1", "RM 2>1", M);
        addKnob (modTab, "am_2to1", "AM 2>1", V);
        addKnob (modTab, "macro1", "BRIGHT", C);
        addKnob (modTab, "macro2", "MOTION", M);
        addKnob (modTab, "macro3", "SPACE", O);
        addKnob (modTab, "macro4", "GRIT", G);
