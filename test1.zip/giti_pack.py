#!/usr/bin/env python3
"""
giti_pack.py  -  PRIVATE tool: turns preset files into an encrypted GITI bank (.gitibank).
DO NOT give this file to anyone: it contains the key.

Usage:
  python giti_pack.py "BASS PACK" out.gitibank preset1.salek.xml preset2.salek.xml bank.salekbank.xml ...
  python giti_pack.py "BASS PACK" out.gitibank some_folder
"""
import sys, os, struct, hashlib, hmac, xml.etree.ElementTree as ET

MASTER = bytes.fromhex("b31f431517a3059c14e8c523534eb69e2abe2502d087dd969a3bc9dd6b2d782a")

def rotl(v, c): return ((v << c) & 0xffffffff) | (v >> (32 - c))
def qr(x, a, b, c, d):
    x[a] = (x[a] + x[b]) & 0xffffffff; x[d] ^= x[a]; x[d] = rotl(x[d], 16)
    x[c] = (x[c] + x[d]) & 0xffffffff; x[b] ^= x[c]; x[b] = rotl(x[b], 12)
    x[a] = (x[a] + x[b]) & 0xffffffff; x[d] ^= x[a]; x[d] = rotl(x[d], 8)
    x[c] = (x[c] + x[d]) & 0xffffffff; x[b] ^= x[c]; x[b] = rotl(x[b], 7)

def chacha20(key, nonce, data):
    st = [0x61707865, 0x3320646e, 0x79622d32, 0x6b206574] + list(struct.unpack("<8I", key)) + [0] + list(struct.unpack("<3I", nonce))
    out = bytearray()
    for off in range(0, len(data), 64):
        x = st[:]
        for _ in range(10):
            qr(x,0,4,8,12); qr(x,1,5,9,13); qr(x,2,6,10,14); qr(x,3,7,11,15)
            qr(x,0,5,10,15); qr(x,1,6,11,12); qr(x,2,7,8,13); qr(x,3,4,9,14)
        ks = struct.pack("<16I", *[(x[i] + st[i]) & 0xffffffff for i in range(16)])
        chunk = data[off:off+64]
        out += bytes(a ^ b for a, b in zip(chunk, ks))
        st[12] = (st[12] + 1) & 0xffffffff
    return bytes(out)

def encrypt(plain: bytes) -> bytes:
    salt, nonce = os.urandom(16), os.urandom(12)
    ek = hashlib.sha256(MASTER + salt + b"E").digest()
    mk = hashlib.sha256(MASTER + salt + b"M").digest()
    cipher = chacha20(ek, nonce, plain)
    head = b"GTV1" + salt + nonce + cipher
    return head + hmac.new(mk, head, hashlib.sha256).digest()

def read_presets(path, bank):
    root = ET.parse(path).getroot()
    items = []
    if root.tag == "SALEK_PRESET":
        items.append((root.get("name") or os.path.basename(path).split(".")[0], root))
    elif root.tag in ("SALEK_USER_PRESETS", "USER_PRESETS"):
        for p in root.findall("PRESET"): items.append((p.get("name") or "Preset", p))
    else:
        print("skip (unknown format):", path); return []
    out = []
    for name, el in items:
        if name.startswith("USER/"): name = name[5:]
        name = name.replace("\\", "-")
        if "/" in name: name = name.split("/")[-1]
        pe = ET.Element("PRESET", {"name": bank + "/" + name})
        for c in el:
            if c.tag == "PARAM": ET.SubElement(pe, "PARAM", {"id": c.get("id"), "value": c.get("value")})
            elif c.tag == "P": ET.SubElement(pe, "PARAM", {"id": c.get("id"), "value": c.get("v")})
            elif c.tag == "MOD_MATRIX": pe.append(c)
        out.append(pe)
    return out

def main():
    if len(sys.argv) < 4: print(__doc__); sys.exit(1)
    bank, outpath, inputs = sys.argv[1], sys.argv[2], sys.argv[3:]
    files = []
    for i in inputs:
        if os.path.isdir(i):
            for r, _, fs in os.walk(i):
                files += [os.path.join(r, f) for f in sorted(fs) if f.lower().endswith(".xml")]
        else: files.append(i)
    root = ET.Element("SALEK_USER_PRESETS", {"version": "3", "plugin": "SALEK HIGHTECH"})
    n = 0
    for f in files:
        for pe in read_presets(f, bank): root.append(pe); n += 1
    if n == 0: print("No presets found."); sys.exit(2)
    data = ET.tostring(root, encoding="utf-8")
    open(outpath, "wb").write(encrypt(data))
    print("OK: %d presets -> %s (%d bytes)" % (n, outpath, os.path.getsize(outpath)))

if __name__ == "__main__": main()
