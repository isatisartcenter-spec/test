#include "GitiVault.h"

static juce::File salekBanksDir()
{
    auto dir = juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory).getChildFile ("SALEK_HIGHTECH").getChildFile ("Banks");
    dir.createDirectory();
    return dir;
}

int SalekHightechAudioProcessor::loadBankXml (const juce::XmlElement& root)
{
    if (! root.hasTagName ("SALEK_USER_PRESETS")) return -1;
    int n = 0;
    for (auto* px : root.getChildIterator())
    {
        if (! px->hasTagName ("PRESET")) continue;
        FactoryPreset pr;
        pr.name = px->getStringAttribute ("name");
        if (pr.name.isEmpty() || pr.name.startsWith ("USER/")) continue;   // must not collide with saved user presets
        for (auto* c : px->getChildIterator())
        {
            if (c->hasTagName ("PARAM")) { auto id = c->getStringAttribute ("id"); if (id.isNotEmpty()) pr.values[id] = (float) c->getDoubleAttribute ("value"); }
            else if (c->hasTagName ("MOD_MATRIX")) pr.modMatrixXml = c->toString();
        }
        if (pr.values.empty()) continue;
        int found = -1;
        for (int i = 0; i < (int) factoryPresets.size(); ++i) if (factoryPresets[(size_t) i].name == pr.name) { found = i; break; }
        if (found >= 0) factoryPresets[(size_t) found] = pr; else factoryPresets.push_back (pr);
        lockedPresetNames.insert (pr.name);
        ++n;
    }
    return n;
}

static juce::File salekAccountFile() { return salekBanksDir().getParentDirectory().getChildFile ("account.txt"); }

juce::String SalekHightechAudioProcessor::getAccountEmail() const { return salekAccountFile().loadFileAsString().trim(); }

void SalekHightechAudioProcessor::setAccountEmail (const juce::String& email)
{
    salekAccountFile().replaceWithText (email.trim());
    loadEncryptedBanks();
}

int SalekHightechAudioProcessor::loadBankFile (const juce::File& f)
{
    juce::MemoryBlock raw;
    if (! f.loadFileAsData (raw)) return -1;
    juce::MemoryBlock plain;
    if (! giti::vault::decrypt (raw.getData(), raw.getSize(), plain, getAccountEmail()))
        return giti::vault::isEmailLocked (raw.getData(), raw.getSize()) ? -2 : -1;   // -2: locked to another e-mail, -1: invalid/tampered
    std::unique_ptr<juce::XmlElement> xml (juce::XmlDocument::parse (plain.toString()));
    if (xml == nullptr) return -1;
    return loadBankXml (*xml);
}

void SalekHightechAudioProcessor::loadEncryptedBanks()
{
    for (auto& f : salekBanksDir().findChildFiles (juce::File::findFiles, false, "*.gitibank"))
        loadBankFile (f);
}

int SalekHightechAudioProcessor::installEncryptedBank (const juce::File& file)
{
    const int n = loadBankFile (file);
    if (n > 0)
    {
        auto target = salekBanksDir().getChildFile (file.getFileName());
        if (target != file) file.copyFileTo (target);
    }
    return n;
}
