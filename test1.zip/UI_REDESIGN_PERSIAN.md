# GITI — Persian crystal UI re-skin

Files changed (Source/):
- PluginEditorLookAndFeel.inl — new palette (deep space, electric cyan, magenta, gold, purple);
  new crystal knob (octagonal glass body, cyan->magenta value arc, 8-point star engraving, glowing core);
  preset-browser / combo / button colours moved to the same palette.
- PluginEditorPaint.inl — default theme (now "PERSIAN") draws a cached deep-space background:
  nebula glows, faint Persian 8-point-star lattice, star dust; gold outer bezel; legacy perspective
  grid is skipped. Other themes (ACID / NEON / PATINA) and the character art are unchanged.
- PluginEditorFullA.inl, PluginEditorCtor.inl — theme 1 renamed CYBER -> PERSIAN.

Layout, tabs, parameters, DSP and presets are untouched.

Build (Windows): push to GitHub and run the "GITI BY SALEK HIGHTECH Build" workflow, or locally:
  cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
  cmake --build build --config Release

## Round 2 changes
- New file Source/GitiCrystalAssets.h: your crystal artwork cut out of the checkerboard JPGs, embedded in the plugin.
- LFO1/2/3: vortex crystal buttons, hue-shifted per LFO (teal-green, violet-magenta, gold) with a clear label pill.
- RANDOM (was the star INSPIRE button): Arabic crystal gem + label.  Master volume: cyan crystal puck that turns with the value.
- Preset open/close: octagon crystal button (chevrons show the direction).  Prev/Next/Save/Load/Bank buttons: 3D glass look with hover glow.
- Hero banner stretched across the whole space between the preset panel and the LFO buttons (art stays sharp in the centre, edges blend into a soft backdrop).
- Knobs: different crystal bodies per control family (level = ring dial, unison = hexagon, table/warp/fold/reso = waveform disc, drive/cutoff = swirl crystal, pitch + filter env = diamond gem, phase/rand/pan/noise/sub/glide/voices = 12-point star, ADSR = octagon).
- Filter column: FADERS / KNOBS switch (crystal faders with gem thumb).
- Character art removed; preset browser now uses the full left column.
- Preset browser: taller 3D rows, hover glow + chevron, selected row glow, index numbers, gradient category headers.

## Round 3 - reference-style Persian redesign (design only; every control kept)
- Ornate glass panels (gold corner brackets + 8-point stars, double border, bilingual headers):
  OSCILLATORS / موج‌ساز, FILTER / پالایه, AMP ENV / پوشه, the three OSC columns, and the preset browser.
- New bevelled neon tab bar (MAIN MOD LFO FX MAGIC SEQ SPEED ABOUT) - active tab glows with a gold underline.
- Animated holographic lotus + orbit rings drawn behind the panels (PERSIAN theme).
- Same controls, same parameters, same tabs - only the drawing code changed.

## Round 4 - reference layout (ISATIS style), animated 3D centre, rotating crystal knobs
- MAIN page now follows the reference: oscillator panel on the left, BIG animated "Holographic Visualizer" in the centre,
  filter panel on the right, envelope/voice strip at the bottom. OSC 1 / OSC 2 / OSC 3 selector at the top of the oscillator panel
  (all controls are still there - one oscillator is shown at a time).
- Visualizer: counter-rotating lotus rings, tilted orbit rings with travelling beads, depth particles, scrolling perspective floor grid;
  it speeds up and glows with the output level.
- Every knob is a crystal PNG that ROTATES with the value (hue-shifted variants per control type) with a rim marker.
- Panels have deeper 3D shadows and glass sheen; LFO / RANDOM / master / preset buttons unchanged.

## Round 5 (V01) - new frames, 2 filters, Genesis system, logo, animated FX/About
- Product name is now "GITI BY SALEK HIGHTECH V01" (CMake: -DGITI_GENESIS=N gives V01..V50, own plugin ID, own colour language: Source/GitiGenesis.h).
- BUILD_WINDOWS.bat [N] builds AND INSTALLS the VST3 (COPY_PLUGIN_AFTER_BUILD was off before - that is why the old VST3 never changed).
- MAIN page: [OSC 1] [OSC 2 | OSC 3] [NOISE | SUB]; collapsible 2x6 knob block (- LESS / + MORE) in each OSC frame;
  ADSR + monitor frame and VOICE/GLIDE (Poly/Mono/Legato) frame; character models restored under the presets.
- Filter column: FILTER 1 | FILTER 2 (real second filter in the engine), 2 rows of 3 knobs, MIX per filter, 5 source lamps (OSC1/2/3, NOISE, SUB).
- Visualizer moved top-right (smaller, with orbiting crystals). GITI logo replaces the top banner.
- LFO: drag-and-drop now works on all modulatable knobs (incl. F DRIVE, SEMI, COARSE, filter 2, mixes), one drop = one knob,
  coloured numbered badges on every modulated knob (1 green, 2 violet, 3 gold). Clicking an LFO still arms it until you click it again.
- FX and ABOUT pages: animated backgrounds (aurora, warp stars, radar sweep, mandala, floating crystals); About shows Genesis + lore.
