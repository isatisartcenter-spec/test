#pragma once
// SPARK: generative patch maker. One style per colour zone: 0 BASS, 1 PAD, 2 LEAD, 3 PLUCK, 4 FX
#include <juce_core/juce_core.h>
#include <map>
#include <vector>
#include <array>
#include "Modulation/ModMatrix.h"

namespace giti
{
    struct RandomPatch
    {
        std::map<juce::String, float> v;
        std::vector<std::array<float, 3>> routes;   // src, dst, amount
    };

    inline RandomPatch makeRandomPatch (int style, juce::Random& r)
    {
        using S = salek::ModMatrix::Source;
        using D = salek::ModMatrix::Dest;
        RandomPatch p;
        auto J = [&] (float a, float b) { return a + r.nextFloat() * (b - a); };
        auto I = [&] (int a, int b) { return a + r.nextInt (b - a + 1); };
        auto T = [] (int idx) { return (float) idx / 127.f; };
        auto route = [&] (S s, D d, float a) { p.routes.push_back ({ (float) (int) s, (float) (int) d, a }); };
        auto set = [&] (const char* id, float x) { p.v[id] = x; };
        auto HI = [&] { return 31 + I (1, 16); };
        auto DARK = [&] { return 47 + I (1, 16); };
        auto FORM = [&] { return 63 + I (1, 32); };
        auto MET = [&] { return 95 + I (1, 32); };
        const int SAW = 3, BSAW = 4, SQR = 2, SINE = 0, PULSE = 24, WSAW = 16, SCRM = 15;
        const int LP24 = 1, ACID = 8, LADDER = 9, DIODE = 16, VOCAL = 18, BPQ = 20, FORMANT = 11, COMB = 10, BP = 4, HP12 = 2;
        auto pick = [&] (std::initializer_list<int> l) { return *(l.begin() + r.nextInt ((int) l.size())); };
        set ("lfo_amount", 1.f); set ("lfo2_amount", 1.f); set ("lfo3_amount", 1.f); set ("master_gain", 0.78f);

        switch (style)
        {
            case 0:   // ---- BASS: rolling / growl / acid / rumble
            {
                const int kind = r.nextInt (4);
                set ("voice_mode", 1.f); set ("osc1_octave", -1.f); set ("osc1_level", 0.85f);
                set ("amp_attack", 0.001f); set ("amp_release", J (0.06f, 0.12f)); set ("lfo_sync", 1.f);
                if (kind == 0)       // rolling
                {
                    set ("osc1_table", T (pick ({ HI(), DARK() }))); set ("osc2_table", T (SAW)); set ("osc2_level", J (0.3f, 0.6f)); set ("osc2_octave", -1.f); set ("osc2_fine", J (-14, 14));
                    set ("filter_mode", (float) pick ({ LADDER, LP24, DIODE })); set ("filter_cutoff", J (230, 620)); set ("filter_reso", J (0.22f, 0.5f)); set ("filter_env", J (0.4f, 0.75f)); set ("filter_drive", J (0.1f, 0.35f));
                    set ("amp_decay", J (0.1f, 0.2f)); set ("amp_sustain", J (0.3f, 0.6f)); set ("sub_level", J (0.2f, 0.4f));
                    set ("lfo_div", 6.f); set ("lfo_wave", (float) pick ({ 0, 1, 3 })); route (S::LFO1, D::FilterCutoff, J (0.12f, 0.3f));
                    set ("dist_mix", J (0.1f, 0.25f)); set ("dist_drive", J (0.2f, 0.4f)); set ("dist_mode", 1.f); set ("bassify", J (0.1f, 0.3f));
                }
                else if (kind == 1)  // growl
                {
                    set ("osc1_table", T (pick ({ DARK(), MET() }))); set ("osc1_warp", J (0.2f, 0.6f)); set ("osc1_fold", J (0.1f, 0.5f)); set ("osc2_table", T (pick ({ SAW, HI() })));
                    set ("osc2_level", J (0.4f, 0.7f)); set ("osc2_octave", -1.f); set ("fm_2to1", J (0.15f, 0.45f));
                    set ("filter_mode", (float) pick ({ ACID, LADDER, LP24 })); set ("filter_cutoff", J (320, 900)); set ("filter_reso", J (0.3f, 0.6f)); set ("filter_env", J (0.2f, 0.5f));
                    set ("amp_decay", 0.3f); set ("amp_sustain", J (0.6f, 0.9f)); set ("lfo_div", 5.f); set ("lfo_wave", (float) pick ({ 3, 1, 2 })); set ("lfo2_rate", J (0.5f, 2.5f));
                    route (S::LFO1, D::Osc1Table, J (0.3f, 0.6f)); route (S::LFO2, D::FilterCutoff, J (0.2f, 0.45f));
                    set ("dist_mix", J (0.25f, 0.5f)); set ("dist_drive", J (0.35f, 0.6f)); set ("dist_mode", (float) pick ({ 3, 2, 1 })); set ("bassify", 0.25f);
                }
                else if (kind == 2)  // acid
                {
                    set ("osc1_table", T (pick ({ SAW, SQR, BSAW }))); set ("glide", J (0.05f, 0.14f)); set ("filter_mode", (float) ACID); set ("filter_cutoff", J (300, 900));
                    set ("filter_reso", J (0.6f, 0.85f)); set ("filter_env", J (0.55f, 0.9f)); set ("filter_drive", J (0.2f, 0.5f)); set ("amp_decay", J (0.12f, 0.22f)); set ("amp_sustain", J (0.f, 0.3f));
                    set ("lfo_div", 6.f); route (S::LFO1, D::FilterCutoff, J (0.08f, 0.2f)); set ("dist_mix", J (0.2f, 0.4f)); set ("dist_mode", (float) pick ({ 2, 3 })); set ("dist_drive", J (0.4f, 0.65f));
                }
                else                 // rumble
                {
                    set ("osc1_level", 0.f); set ("noise_level", 0.95f); set ("noise_type", 5.f); set ("sub_level", J (0.4f, 0.6f)); set ("amp_decay", 0.5f); set ("amp_sustain", J (0.3f, 0.6f));
                    set ("filter_mode", (float) LP24); set ("filter_cutoff", J (200, 420)); set ("dist_mix", J (0.4f, 0.7f)); set ("dist_drive", J (0.4f, 0.7f)); set ("dist_mode", 1.f);
                    set ("reverb_mix", J (0.45f, 0.65f)); set ("reverb_decay", 0.75f); set ("bassify", 0.35f);
                }
                break;
            }
            case 1:   // ---- PAD
            {
                set ("osc1_table", T (pick ({ DARK(), 11, 13, 10 }))); set ("osc2_table", T (pick ({ SAW, WSAW }))); set ("osc2_level", 0.6f); set ("osc2_fine", J (-14, 14));
                set ("osc1_unison", 5.f); set ("osc1_udet", J (12, 24)); set ("osc1_uspread", 0.9f); set ("filter_mode", 0.f); set ("filter_cutoff", J (700, 2800)); set ("filter_reso", J (0.15f, 0.35f));
                set ("amp_attack", J (0.6f, 1.8f)); set ("amp_decay", 1.5f); set ("amp_sustain", 0.9f); set ("amp_release", J (1.5f, 3.0f));
                set ("lfo_rate", J (0.05f, 0.25f)); set ("lfo_wave", 1.f); set ("lfo2_rate", J (0.05f, 0.2f)); set ("lfo2_wave", 6.f);
                route (S::LFO1, D::FilterCutoff, J (0.2f, 0.5f)); route (S::LFO2, D::Osc1Table, J (0.1f, 0.3f));
                set ("chorus_mix", 0.4f); set ("reverb_mix", J (0.4f, 0.6f)); set ("reverb_size", 0.92f); set ("reverb_decay", 0.85f); set ("reverb_mode", 1.f); set ("delay_mix", 0.15f); set ("delay_time", 480.f); set ("delay_fb", 0.45f);
                break;
            }
            case 2:   // ---- LEAD
            {
                const int kind = r.nextInt (3);
                set ("osc1_table", T (kind == 1 ? pick ({ SCRM, MET(), 31 + I (8, 16) }) : pick ({ BSAW, HI(), SCRM }))); set ("osc2_table", T (pick ({ SAW, PULSE, HI() })));
                set ("osc2_level", J (0.4f, 0.7f)); set ("osc2_octave", (float) pick ({ 0, 1 })); set ("osc2_fine", J (-12, 12)); set ("osc1_unison", (float) I (2, 5)); set ("osc1_udet", J (8, 26)); set ("osc1_uspread", J (0.5f, 0.9f));
                set ("voice_mode", 2.f); set ("glide", J (0.05f, 0.2f)); set ("filter_mode", (float) pick ({ LP24, ACID, DIODE })); set ("filter_cutoff", kind == 1 ? J (3800, 8000) : J (2200, 6500));
                set ("filter_reso", J (0.25f, 0.55f)); set ("filter_env", J (0.25f, 0.5f)); set ("amp_attack", 0.004f); set ("amp_decay", 0.3f); set ("amp_sustain", J (0.7f, 0.95f)); set ("amp_release", 0.25f);
                set ("lfo_rate", 5.5f); set ("lfo2_rate", J (0.3f, 1.2f)); set ("lfo2_wave", 1.f);
                route (S::LFO1, D::Pitch, J (0.01f, 0.03f)); route (S::LFO2, D::FilterCutoff, J (0.1f, 0.25f));
                if (kind == 2) { route (S::LFO3, D::Osc1Table, 0.35f); set ("lfo3_rate", J (0.3f, 1.5f)); set ("lfo3_wave", 6.f); set ("osc1_warp", J (0.1f, 0.4f)); }
                set ("dist_mix", kind == 1 ? J (0.3f, 0.5f) : J (0.1f, 0.3f)); set ("dist_mode", 2.f); set ("dist_drive", 0.4f);
                set ("delay_mix", J (0.2f, 0.35f)); set ("delay_time", J (260, 380)); set ("delay_fb", J (0.35f, 0.55f)); set ("delay_mode", 1.f); set ("reverb_mix", J (0.12f, 0.25f)); set ("reverb_mode", 2.f); set ("chorus_mix", 0.2f);
                break;
            }
            case 3:   // ---- PLUCK
            {
                const bool arp = r.nextBool();
                if (arp) { set ("arp_on", 1.f); set ("arp_rate", (float) pick ({ 3, 4, 4 })); set ("arp_octaves", (float) I (2, 3)); set ("arp_gate", J (0.35f, 0.55f)); }
                set ("osc1_table", T (pick ({ HI(), BSAW, MET() }))); set ("osc2_table", T (SINE)); set ("osc2_level", J (0.2f, 0.5f)); set ("osc2_octave", 1.f); set ("fm_2to1", J (0.1f, 0.4f));
                set ("filter_mode", (float) LP24); set ("filter_cutoff", J (1800, 6000)); set ("filter_reso", J (0.2f, 0.5f)); set ("filter_env", J (0.4f, 0.7f));
                set ("amp_attack", 0.001f); set ("amp_decay", J (0.12f, 0.3f)); set ("amp_sustain", 0.f); set ("amp_release", 0.15f);
                set ("dist_mix", J (0.0f, 0.25f)); set ("dist_mode", 3.f); set ("delay_mix", J (0.25f, 0.4f)); set ("delay_time", J (230, 340)); set ("delay_fb", J (0.4f, 0.6f)); set ("delay_mode", 1.f);
                set ("reverb_mix", 0.2f); set ("reverb_mode", 2.f); set ("chorus_mix", 0.2f);
                break;
            }
            default:  // ---- FX: alien / noise riser / scream
            {
                const int kind = r.nextInt (3);
                if (kind == 0)
                {
                    set ("osc1_table", T (pick ({ MET(), FORM() }))); set ("osc2_table", T (pick ({ MET(), HI() }))); set ("osc2_level", J (0.4f, 0.7f)); set ("osc2_semi", (float) pick ({ -7, 5, 7, 12 })); set ("fm_2to1", J (0.25f, 0.6f));
                    set ("filter_mode", (float) pick ({ BPQ, FORMANT, COMB })); set ("filter_cutoff", J (900, 4500)); set ("filter_reso", J (0.35f, 0.7f)); set ("amp_attack", J (0.002f, 0.2f)); set ("amp_decay", 0.6f); set ("amp_sustain", J (0.3f, 0.8f)); set ("amp_release", J (0.4f, 1.2f));
                    set ("lfo_rate", J (0.4f, 3.5f)); set ("lfo_wave", (float) pick ({ 4, 6, 1 })); set ("lfo2_rate", J (0.2f, 2.f)); set ("lfo3_rate", J (4.f, 9.f));
                    route (S::LFO1, D::Osc1Table, J (0.3f, 0.7f)); route (S::LFO2, D::FilterCutoff, J (0.3f, 0.6f)); route (S::LFO3, D::Pitch, J (0.02f, 0.08f));
                    set ("delay_mix", J (0.3f, 0.5f)); set ("delay_time", J (230, 420)); set ("delay_fb", J (0.45f, 0.65f)); set ("delay_mode", 1.f); set ("reverb_mix", J (0.3f, 0.5f)); set ("reverb_size", 0.85f); set ("reverb_mode", 1.f);
                }
                else if (kind == 1)
                {
                    set ("osc1_level", 0.f); set ("noise_level", J (0.7f, 0.95f)); set ("noise_type", (float) I (0, 3)); set ("filter_mode", (float) pick ({ BP, BPQ, HP12 })); set ("filter_cutoff", J (200, 900)); set ("filter_reso", J (0.4f, 0.7f));
                    set ("amp_attack", J (1.5f, 4.f)); set ("amp_sustain", 1.f); set ("amp_release", J (1.f, 2.5f)); set ("lfo_rate", J (0.05f, 0.15f)); set ("lfo_wave", 2.f); set ("lfo_bip", 0.f);
                    route (S::LFO1, D::FilterCutoff, J (0.5f, 0.9f)); set ("reverb_mix", 0.5f); set ("reverb_mode", 1.f);
                }
                else
                {
                    set ("osc1_table", T (FORM())); set ("osc2_table", T (pick ({ FORM(), SCRM }))); set ("osc2_level", J (0.5f, 0.8f)); set ("osc1_unison", (float) I (2, 4)); set ("osc1_udet", J (10, 22));
                    set ("voice_mode", 2.f); set ("glide", 0.1f); set ("filter_mode", (float) VOCAL); set ("filter_cutoff", J (1800, 4800)); set ("filter_reso", J (0.45f, 0.7f)); set ("amp_attack", 0.004f); set ("amp_sustain", 0.85f);
                    set ("lfo_rate", J (3.f, 8.f)); set ("lfo_wave", 4.f); set ("lfo2_rate", J (0.5f, 2.f)); set ("lfo2_wave", 6.f); route (S::LFO1, D::Osc1Table, J (0.4f, 0.8f)); route (S::LFO2, D::FilterCutoff, J (0.3f, 0.6f));
                    set ("dist_mix", J (0.35f, 0.6f)); set ("dist_mode", (float) pick ({ 2, 4, 3 })); set ("dist_drive", J (0.5f, 0.8f)); set ("reverb_mix", 0.25f); set ("reverb_mode", 0.f);
                }
                break;
            }
        }
        return p;
    }
}
