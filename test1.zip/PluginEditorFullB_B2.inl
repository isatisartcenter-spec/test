void SalekHightechAudioProcessorEditor::refreshCharCache()
{
    // Downscale once — full-res PNGs destroy UI FPS
    charImgL = SalekAssets::loadCharPortrait (charPortraitIdx, 480, 720);
    charImgR = {}; // right portrait removed — saves RAM/CPU
}

void SalekHightechAudioProcessorEditor::applyHeroFromTheme()
{
    const int id = themeBox.getSelectedId();
    // ONLY the 2 official backgrounds:
    // 1/2 -> bg_isatis (you + cat / city)
    // 3/4 -> bg_salek (2 girls)
    if (id == 1 || id == 2)
    {
        themeAccent  = (id == 2) ? juce::Colour (0xff39ff14) : juce::Colour (0xff00e8ff);
        themeAccent2 = (id == 2) ? juce::Colour (0xffffab40) : juce::Colour (0xffffd700);
        themePanelBg = (id == 2) ? juce::Colour (0xff061408) : juce::Colour (0xff0a0614);
    }
    else
    {
        themeAccent  = (id == 3) ? juce::Colour (0xffff2d9b) : juce::Colour (0xffb388ff);
        themeAccent2 = juce::Colour (0xff00e8ff);
        themePanelBg = (id == 3) ? juce::Colour (0xff12081c) : juce::Colour (0xff0c0818);
    }
    {
        const int nImg = (int) bgImages.size();
        if (bgIndex < nImg) heroImg = bgImages[(size_t) juce::jmax (0, bgIndex)];
        else heroImg = proceduralBg (bgIndex - nImg, 1280, 820);
    }
    repaint();
}

void SalekHightechAudioProcessorEditor::cycleHero()
{
    // Toggle between the 2 official arts only
    // every press shows the next background; changing the theme no longer swaps the picture
    bgIndex = (bgIndex + 1) % ((int) bgImages.size() + 8);
    applyHeroFromTheme();
}

void SalekHightechAudioProcessorEditor::mouseDown (const juce::MouseEvent& e)
{
    juce::ignoreUnused (e);
}

void SalekHightechAudioProcessorEditor::mouseWheelMove (const juce::MouseEvent& e, const juce::MouseWheelDetails& wheel)
{
    juce::ignoreUnused (e, wheel);
}

// Computer keyboard → MIDI even while mouse is on knobs / other controls
// BG button modes after the pictures: 3 solid colours, 3 gradients, particles (live), light (live)
juce::Image SalekHightechAudioProcessorEditor::proceduralBg (int mode, int w, int h)
{
    juce::Image im (juce::Image::ARGB, w, h, true);
    juce::Graphics g (im);
    const float W = (float) w, H = (float) h;
    auto grad = [&] (juce::Colour a, juce::Colour b, juce::Colour c)
    {
        juce::ColourGradient cg (a, 0.f, 0.f, c, W, H, false);
        cg.addColour (0.5, b);
        g.setGradientFill (cg); g.fillAll();
    };
    switch (mode)
    {
        case 0: g.fillAll (juce::Colour (0xff070514)); break;                                   // deep navy
        case 1: g.fillAll (juce::Colour (0xff2a0a1c)); break;                                   // wine
        case 2: g.fillAll (juce::Colour (0xff04222a)); break;                                   // teal
        case 3: grad (juce::Colour (0xff04121f), juce::Colour (0xff3b1060), juce::Colour (0xff6a0a52)); break;   // cyan-violet-magenta
        case 4: grad (juce::Colour (0xff1a0838), juce::Colour (0xff7a1d4e), juce::Colour (0xffd8662a)); break;   // sunset
        case 5: grad (juce::Colour (0xff021c1a), juce::Colour (0xff0a5a52), juce::Colour (0xff0b2e6e)); break;   // emerald-ocean
        default: grad (juce::Colour (0xff05030f), juce::Colour (0xff10082a), juce::Colour (0xff1b0c3a)); break;  // base for live modes
    }
    return im;
}

bool SalekHightechAudioProcessorEditor::keyPressed (const juce::KeyPress& key)
{
    const auto ch = juce::CharacterFunctions::toLowerCase (key.getTextCharacter());
    if (ch == '-' || ch == '=')
    {
        computerKeyboardBase = juce::jlimit (24, 84, computerKeyboardBase + (ch == '-' ? -12 : 12));
        return true;
    }
    // Standard DAW layout: bottom row = white keys, row above = sharps (z s x d c v g b h n j m , l . ; /)
    // and q 2 w 3 e r 5 t 6 y 7 u i 9 o 0 p one octave higher
    static const juce::String lower = "zsxdcvgbhnjm,l.;/";
    static const juce::String upper = "q2w3er5t6y7ui9o0p";
    int note = -1;
    if (const int i = lower.indexOfChar (ch); i >= 0)       note = computerKeyboardBase + i;
    else if (const int j = upper.indexOfChar (ch); j >= 0)  note = computerKeyboardBase + 12 + j;
    if (note > 127) note = -1;
    if (note >= 0)
    {
        if (! computerKeyboardHeldKeys.contains ((int) ch))
        {
            const bool noteAlreadyHeld = computerKeyboardHeldNotes.contains (note);
            computerKeyboardHeldNotes.add (note);
            computerKeyboardHeldKeys.add ((int) ch);
            if (! noteAlreadyHeld)
                processor.getKeyboardState().noteOn (1, note, 0.92f);
        }
        return true;
    }
    if (keyboard.keyPressed (key))
        return true;
    return false;
}

bool SalekHightechAudioProcessorEditor::keyStateChanged (bool isKeyDown)
{
    juce::ignoreUnused (isKeyDown);
    for (int i = computerKeyboardHeldKeys.size(); --i >= 0;)
    {
        const int keyChar = computerKeyboardHeldKeys.getUnchecked (i);
        if (keyChar < 0 || ! juce::KeyPress::isKeyCurrentlyDown (keyChar))
        {
            const int note = computerKeyboardHeldNotes.getUnchecked (i);
            bool stillHeld = false;
            for (int j = 0; j < computerKeyboardHeldNotes.size(); ++j)
                if (j != i && computerKeyboardHeldNotes.getUnchecked (j) == note) { stillHeld = true; break; }
            if (! stillHeld)
                processor.getKeyboardState().noteOff (1, note, 0.0f);
            computerKeyboardHeldNotes.remove (i);
            computerKeyboardHeldKeys.remove (i);
        }
    }
    if (keyboard.keyStateChanged (isKeyDown))
        return true;
    return false;
}

void SalekHightechAudioProcessorEditor::applyUiLanguage()
{
    auto fa = [] (const char* u8) { return juce::String::fromUTF8 (u8); };
    const bool F = uiLangFa;
    tabs.setTabName (0, F ? fa ("\xd8\xa7\xd8\xb5\xd9\x84\xdb\x8c") : "MAIN");                                   // اصلی
    tabs.setTabName (1, F ? fa ("\xd9\x85\xd8\xaf\xd9\x88\xd9\x84\xd8\xa7\xd8\xb3\xdb\x8c\xd9\x88\xd9\x86") : "MOD"); // مدولاسیون
    tabs.setTabName (2, F ? fa ("\xd8\xa7\xd9\x84 \xd8\xa7\xd9\x81 \xd8\xa7\xd9\x88") : "LFO");                 // ال اف او
    tabs.setTabName (3, F ? fa ("\xd8\xa7\xd9\x81\xda\xa9\xd8\xaa") : "FX");                                    // افکت
    tabs.setTabName (4, F ? fa ("\xd8\xac\xd8\xa7\xd8\xaf\xd9\x88") : "MAGIC");                                 // جادو
    tabs.setTabName (5, F ? fa ("\xd8\xaa\xd8\xb1\xd8\xaa\xdb\x8c\xd8\xa8\xda\xaf\xd8\xb1") : "SEQ");       // ترتیبگر
    tabs.setTabName (6, F ? fa ("\xd8\xb3\xd8\xb1\xd8\xb9\xd8\xaa") : "SPEED");                                 // سرعت
    tabs.setTabName (7, F ? fa ("\xd8\xaf\xd8\xb1\xd8\xa8\xd8\xa7\xd8\xb1\xd9\x87") : "ABOUT");               // درباره
    storeBtn.setButtonText (F ? fa ("\xd9\x81\xd8\xb1\xd9\x88\xd8\xb4\xda\xaf\xd8\xa7\xd9\x87") : "STORE");   // فروشگاه
    updateBtn.setButtonText (F ? fa ("\xd8\xa8\xd8\xb1\xd9\x88\xd8\xb2\xd8\xb1\xd8\xb3\xd8\xa7\xd9\x86\xdb\x8c") : "UPDATE"); // بروزرسانی
    charCycleBtn.setButtonText (F ? fa ("\xd9\x85\xd8\xaf\xd9\x84") : "CHAR");                                    // مدل
    modStage.tabBtn[3].setButtonText (F ? fa ("\xd8\xac\xd8\xb1\xd9\x82\xd9\x87") : "SPARK");                     // جرقه
    aboutInfo->setPersian (uiLangFa);
    magicLoopBtn.setButtonText ("LOOP");
    magicGlitchBtn.setButtonText ("GLITCH");
    magicFlangeBtn.setButtonText ("FLANGE");
    magicPsychBtn.setButtonText ("PSY");
    magicHold.setButtonText ("HOLD");
    for (int i = 0; i < 8; ++i)
        fxBypass[i].setButtonText (juce::CharPointer_UTF8 ("\xe2\x8f\xbb"));
    resized();
    repaint();
}
