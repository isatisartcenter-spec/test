@echo off
rem Builds EVERY Genesis edition (1..50) one after another. Each edition = its own VST3 "GITI BY SALEK HIGHTECH Vnn".
rem First one takes ~15 min, the others reuse the compiled engine only if you keep the build_gNN folders (they do not share objects),
rem so expect a long run - start with BUILD_WINDOWS.bat <number> for the ones you want first.
cd /d "%~dp0"
for /l %%i in (1,1,50) do (
  echo ===== Genesis %%i =====
  call BUILD_WINDOWS.bat %%i
)
