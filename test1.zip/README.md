# GITI BY SALEK HIGHTECH

Windows x64 synthesizer instrument supplied as a JUCE VST3 plug-in and a Standalone application. The project uses C++17 and JUCE 8.0.4.

**Start with [START_HERE.md](START_HERE.md)** for the bilingual Persian/English guide: how to run the included builds, install the VST3 bundle, build from source, and navigate the source tree and GITI preset bank.

The latest voice-mode, pitch, filter, delay, Magic capture, and modulation verification is recorded in [AUDIO_ENGINE_AUDIT_2026-10-02.md](docs/AUDIO_ENGINE_AUDIT_2026-10-02.md).

## Included builds

- Standalone: `Builds/Standalone/GITI BY SALEK HIGHTECH.exe`
- VST3 bundle: `Builds/VST3/GITI BY SALEK HIGHTECH.vst3`

Both included builds target Windows x64. The source project and original UI assets are included. JUCE source is fetched by CMake when needed and is not vendored in this archive.
