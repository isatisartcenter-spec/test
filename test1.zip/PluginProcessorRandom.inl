#include "RandomPatch.h"

void SalekHightechAudioProcessor::applyRandomPatch (int style)
{
    // start from a clean slate: every parameter back to its default, matrix cleared
    for (auto* param : getParameters())
        if (auto* rp = dynamic_cast<juce::RangedAudioParameter*> (param))
            rp->setValueNotifyingHost (rp->getDefaultValue());
    if (! factoryPresets.empty())
        for (auto& kv : factoryPresets[0].values)       // "Init" values
            if (auto* p = apvts.getParameter (kv.first))
                p->setValueNotifyingHost (p->convertTo0to1 (kv.second));

    auto patch = giti::makeRandomPatch (style, juce::Random::getSystemRandom());
    for (auto& kv : patch.v)
        if (auto* p = apvts.getParameter (kv.first))
            p->setValueNotifyingHost (p->convertTo0to1 (kv.second));

    modMatrix.clear();
    for (auto& rt : patch.routes)
        modMatrix.addRoute ((salek::ModMatrix::Source) (int) rt[0], (salek::ModMatrix::Dest) (int) rt[1], rt[2]);
}
